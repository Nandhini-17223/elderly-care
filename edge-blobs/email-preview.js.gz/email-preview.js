// ../../../tmp/fn-src/supabase/functions/email-preview/index.ts

// ../../../tmp/fn-src/supabase/functions/_shared/email.ts
var SUPPORT_PHONE = "+91 73399 11220";
var HELPER_APP_LINK = "https://nandhini-17223.github.io/elderly-care/helper/";
var LOGO_URL = "https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg";
var BRAND_PRIMARY = "#1d6fd8";
var BRAND_ACCENT = "#4a9cf7";
var BRAND_TEXT = "#1f2937";
var BRAND_MUTED = "#6b7280";
var MONTHS_SHORT = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
];
var WEEKDAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
function escapeHtml(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}
function displayValue(value, fallback = "\u2013") {
  if (value === null || value === void 0) return fallback;
  const text = String(value).trim();
  if (!text || text.toLowerCase() === "null" || text.toLowerCase() === "undefined") {
    return fallback;
  }
  return text;
}
function displayOrNone(value) {
  return displayValue(value, "None given");
}
function parseDateParts(appointmentDate) {
  if (!appointmentDate) return null;
  const dateMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(appointmentDate.trim());
  if (!dateMatch) return null;
  const year = Number(dateMatch[1]);
  const month = Number(dateMatch[2]);
  const day = Number(dateMatch[3]);
  if (!month || month < 1 || month > 12 || !day || day < 1 || day > 31) {
    return null;
  }
  return { year, month, day };
}
function parseTimeParts(appointmentTime) {
  if (!appointmentTime) return null;
  const timeMatch = /^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(
    appointmentTime.trim()
  );
  if (!timeMatch) return null;
  const hour24 = Number(timeMatch[1]);
  const minute = Number(timeMatch[2]);
  if (!Number.isInteger(hour24) || !Number.isInteger(minute) || hour24 < 0 || hour24 > 23 || minute < 0 || minute > 59) {
    return null;
  }
  return { hour24, minute };
}
function appointmentMsIst(appointmentDate, appointmentTime) {
  const d = parseDateParts(appointmentDate);
  const t = parseTimeParts(appointmentTime) ?? { hour24: 0, minute: 0 };
  if (!d) return NaN;
  return Date.parse(
    `${String(d.year).padStart(4, "0")}-${String(d.month).padStart(2, "0")}-${String(d.day).padStart(2, "0")}T${String(t.hour24).padStart(2, "0")}:${String(t.minute).padStart(2, "0")}:00+05:30`
  );
}
function formatAppointmentDateShort(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  return `${d.day} ${MONTHS_SHORT[d.month - 1]}`;
}
function formatAppointmentDateLong(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  const weekday = new Date(Date.UTC(d.year, d.month - 1, d.day)).getUTCDay();
  return `${WEEKDAYS_SHORT[weekday]}, ${d.day} ${MONTHS_SHORT[d.month - 1]} ${d.year}`;
}
function formatAppointmentTime(appointmentTime) {
  const t = parseTimeParts(appointmentTime);
  if (!t) return null;
  const hour12 = t.hour24 % 12 || 12;
  const ampm = t.hour24 < 12 ? "AM" : "PM";
  return `${hour12}:${String(t.minute).padStart(2, "0")} ${ampm}`;
}
function istYmd(ms) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date(ms));
}
function formatRelativeTime(appointmentDate, appointmentTime, nowMs = Date.now()) {
  const appt = appointmentMsIst(appointmentDate, appointmentTime);
  if (!Number.isFinite(appt)) return "\u2013";
  const today = istYmd(nowMs);
  const apptDay = istYmd(appt);
  const todayParts = parseDateParts(today);
  const apptParts = parseDateParts(apptDay);
  const dayDiff = Math.round(
    (Date.UTC(apptParts.year, apptParts.month - 1, apptParts.day) - Date.UTC(todayParts.year, todayParts.month - 1, todayParts.day)) / 864e5
  );
  if (dayDiff === 0) {
    const deltaMs = appt - nowMs;
    if (deltaMs <= 0) return "today";
    const totalMinutes = Math.round(deltaMs / 6e4);
    if (totalMinutes < 60) {
      return `today \xB7 in ${totalMinutes} minute${totalMinutes === 1 ? "" : "s"}`;
    }
    const hours = Math.round(totalMinutes / 60);
    return `today \xB7 in ${hours} hour${hours === 1 ? "" : "s"}`;
  }
  if (dayDiff === 1) return "tomorrow";
  if (dayDiff > 1) return `in ${dayDiff} days`;
  if (dayDiff === -1) return "yesterday";
  return `${Math.abs(dayDiff)} days ago`;
}
function formatIstDateTime(iso) {
  if (!iso) return "\u2013";
  const ms = Date.parse(iso);
  if (!Number.isFinite(ms)) return displayValue(iso);
  const d = new Date(ms);
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata",
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true
  }).formatToParts(d);
  const get = (type) => parts.find((p) => p.type === type)?.value ?? "";
  const day = get("day");
  const month = get("month");
  const year = get("year");
  const weekday = get("weekday");
  const hour = get("hour");
  const minute = get("minute");
  const dayPeriod = get("dayPeriod").toUpperCase();
  return `${weekday}, ${day} ${month} ${year} \xB7 ${hour}:${minute} ${dayPeriod}`;
}
function emailButtonHtml(href, label, variant = "primary") {
  const bg = variant === "primary" ? BRAND_PRIMARY : "#e5e7eb";
  const color = variant === "primary" ? "#ffffff" : "#111827";
  return `<a href="${escapeHtml(href)}" style="background:${bg};color:${color};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${escapeHtml(label)}</a>`;
}
function emailFooterText() {
  return `This is an automated message from ABI Parent Care. For help, call ${SUPPORT_PHONE}.`;
}
function wrapEmailHtml(args) {
  const ref = displayValue(args.ref, "");
  const refHtml = ref ? `<td align="right" style="font-size:13px;color:${BRAND_MUTED};white-space:nowrap;">Ref <strong style="color:${BRAND_TEXT};">${escapeHtml(ref)}</strong></td>` : `<td></td>`;
  const preheader = args.preheader ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${escapeHtml(args.preheader)}</div>` : "";
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${preheader}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${BRAND_PRIMARY},${BRAND_ACCENT});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${LOGO_URL}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${ref ? `<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${escapeHtml(ref)}</strong></td>` : ""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${BRAND_TEXT};">
          ${args.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${BRAND_MUTED};">
          ${escapeHtml(emailFooterText())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`;
}
function wrapEmailText(args) {
  const lines = [
    "ABI Parent Care",
    args.ref ? `Ref ${displayValue(args.ref)}` : null,
    "",
    args.bodyText.trim(),
    "",
    emailFooterText()
  ].filter((line2) => line2 !== null);
  return lines.join("\n");
}
async function sendEmail(args) {
  const resendApiKey = Deno.env.get("RESEND_API_KEY");
  if (!resendApiKey) {
    throw new Error("Missing RESEND_API_KEY secret");
  }
  const testMode = Deno.env.get("EMAIL_TEST_MODE") === "true";
  const testTo = Deno.env.get("TEST_EMAIL_TO")?.trim() || "";
  const realRecipientLabel = (args.toName?.trim() || args.to).trim();
  const finalTo = testMode && testTo ? testTo : args.to;
  const finalSubject = testMode && testTo ? `[To: ${realRecipientLabel}] ${args.subject}` : args.subject;
  const payload = {
    from: "ABI Parent Care <onboarding@resend.dev>",
    to: [finalTo],
    subject: finalSubject,
    html: args.html
  };
  if (args.text && args.text.trim()) {
    payload.text = args.text;
  }
  const emailResponse = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${resendApiKey}`
    },
    body: JSON.stringify(payload)
  });
  const emailResult = await emailResponse.json();
  if (!emailResponse.ok) {
    console.error("Resend error:", emailResult);
    return {
      ok: false,
      status: emailResponse.status,
      to: finalTo,
      subject: finalSubject,
      testMode,
      error: emailResult
    };
  }
  return {
    ok: true,
    status: emailResponse.status,
    id: typeof emailResult?.id === "string" ? emailResult.id : void 0,
    to: finalTo,
    subject: finalSubject,
    testMode
  };
}

// ../../../tmp/fn-src/supabase/functions/_shared/templates.ts
function preferenceLabel(value) {
  if (value === "female") return "Female helper";
  if (value === "male") return "Male helper";
  if (value === "no_preference" || value === "none" || !value) {
    return "No preference";
  }
  return displayValue(value, "No preference");
}
function reasonPlain(reason) {
  switch (reason) {
    case "no_acceptance":
      return "No helper accepted within 2 hours";
    case "no_suitable_helpers":
      return "No suitable helper nearby";
    case "all_declined":
      return "All offered helpers declined";
    case "short_notice":
      return "Booked at short notice";
    case "helper_dropped":
      return "Helper dropped out";
    case "helper_not_confirmed":
      return "Helper didn't confirm";
    case "helper_unavailable":
      return "Helper no longer available";
    default:
      return reason ? reason.replaceAll("_", " ") : "Needs senior attention";
  }
}
function timeLabel(appointmentTime) {
  return formatAppointmentTime(appointmentTime) ?? displayValue(appointmentTime);
}
function sectionHeading(label) {
  return `<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${escapeHtml(label)}</p>`;
}
function line(label, value) {
  return `<div style="margin:0 0 6px;"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</div>`;
}
function textLine(label, value) {
  return `${label}: ${value}`;
}
function helperPhotoBlock(photoUrl) {
  if (!photoUrl) return "";
  return `<p style="margin:16px 0;"><img src="${escapeHtml(photoUrl)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`;
}
function joinAddress(parts) {
  return parts.map((p) => String(p ?? "").trim()).filter(Boolean).join(", ");
}
function build(id, subject, ref, bodyHtml, bodyText) {
  return {
    id,
    subject,
    html: wrapEmailHtml({ bodyHtml, ref, preheader: subject }),
    text: wrapEmailText({ bodyText, ref })
  };
}
function templateG1(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const pickup = joinAddress([v.area, v.city, v.pincode]) || "\u2013";
  const pref = preferenceLabel(v.helper_preference);
  const subject = `We've received your request \u2013 ${v.parent_name}, ${dateShort} \xB7 Ref ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Thank you for choosing ABI Parent Care. We've received your request for ${escapeHtml(v.parent_name)}'s doctor appointment.</p>
    ${sectionHeading("Appointment")}
    ${line("Date & time", `${dateLong} \xB7 ${time}`)}
    ${line("Doctor/Hospital", displayValue(v.doctor_hospital))}
    ${line("Pickup from", pickup)}
    ${line("Helper preference", pref)}
    ${sectionHeading("What happens next")}
    <p style="margin:0 0 12px;">We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.</p>
    <p style="margin:0 0 12px;">Need to change anything? Call us on ${escapeHtml(SUPPORT_PHONE)} and quote Ref ${escapeHtml(v.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `Thank you for choosing ABI Parent Care. We've received your request for ${v.parent_name}'s doctor appointment.`,
    "",
    "APPOINTMENT",
    textLine("Date & time", `${dateLong} \xB7 ${time}`),
    textLine("Doctor/Hospital", displayValue(v.doctor_hospital)),
    textLine("Pickup from", pickup),
    textLine("Helper preference", pref),
    "",
    "WHAT HAPPENS NEXT",
    "We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.",
    "",
    `Need to change anything? Call us on ${SUPPORT_PHONE} and quote Ref ${v.ref}.`,
    "",
    "Warm regards,",
    "The ABI Parent Care team"
  ].join("\n");
  return build("G1", subject, v.ref, bodyHtml, bodyText);
}
function templateG2(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const subject = `Update on ${v.parent_name}'s appointment \u2013 ${dateShort} \xB7 Ref ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${escapeHtml(v.parent_name)}'s appointment on ${escapeHtml(dateLong)} at ${escapeHtml(time)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${escapeHtml(SUPPORT_PHONE)} and quote Ref ${escapeHtml(v.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `A quick update: our care team is personally arranging a suitable helper for ${v.parent_name}'s appointment on ${dateLong} at ${time}.`,
    "",
    "You don't need to do anything. We'll email you the helper's details shortly.",
    "",
    `If you'd like to speak to us, call ${SUPPORT_PHONE} and quote Ref ${v.ref}.`,
    "",
    "Warm regards,",
    "The ABI Parent Care team"
  ].join("\n");
  return build("G2", subject, v.ref, bodyHtml, bodyText);
}
function templateG3(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const pickup = joinAddress([
    v.address_line1,
    v.street,
    v.area,
    v.city,
    v.pincode
  ]) || "\u2013";
  const subject = `Helper confirmed for ${v.parent_name} \u2013 ${v.helper_full_name}, ${dateShort} \xB7 Ref ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news \u2013 ${escapeHtml(v.helper_full_name)} will accompany ${escapeHtml(v.parent_name)} to the appointment.</p>
    ${helperPhotoBlock(v.helper_photo_url)}
    ${sectionHeading("Your helper")}
    ${line("Name", v.helper_full_name)}
    ${line("Phone", displayValue(v.helper_phone))}
    ${line("Verified", "ID and background checked by ABI Parent Care")}
    ${sectionHeading("Appointment")}
    ${line("Date & time", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Doctor/Hospital", displayValue(v.doctor_hospital))}
    ${line("Pickup from", pickup)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${escapeHtml(v.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `Good news \u2013 ${v.helper_full_name} will accompany ${v.parent_name} to the appointment.`,
    "",
    "YOUR HELPER",
    textLine("Name", v.helper_full_name),
    textLine("Phone", displayValue(v.helper_phone)),
    textLine("Verified", "ID and background checked by ABI Parent Care"),
    "",
    "APPOINTMENT",
    textLine("Date & time", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Doctor/Hospital", displayValue(v.doctor_hospital)),
    textLine("Pickup from", pickup),
    "",
    `For safety, please share this with ${v.parent_name} so they know who to expect.`,
    "",
    "Warm regards,",
    "The ABI Parent Care team"
  ].join("\n");
  return build("G3", subject, v.ref, bodyHtml, bodyText);
}
function templateG4(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const subject = `Change of helper for ${v.parent_name} \u2013 ${dateShort} \xB7 Ref ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${escapeHtml(v.old_helper_first_name)} is unable to attend ${escapeHtml(v.parent_name)}'s appointment on ${escapeHtml(dateLong)} at ${escapeHtml(time)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${escapeHtml(SUPPORT_PHONE)} and quote Ref ${escapeHtml(v.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `We're sorry \u2013 ${v.old_helper_first_name} is unable to attend ${v.parent_name}'s appointment on ${dateLong} at ${time}.`,
    "",
    "Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.",
    "",
    `The appointment itself is unchanged. If you have concerns, call ${SUPPORT_PHONE} and quote Ref ${v.ref}.`,
    "",
    "Warm regards,",
    "The ABI Parent Care team"
  ].join("\n");
  return build("G4", subject, v.ref, bodyHtml, bodyText);
}
function templateG5(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject = `New helper confirmed for ${v.parent_name} \u2013 ${v.helper_full_name} \xB7 Ref ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} will now accompany ${escapeHtml(v.parent_name)} to the appointment, in place of ${escapeHtml(v.old_helper_first_name)}.</p>
    ${helperPhotoBlock(v.helper_photo_url)}
    ${sectionHeading("Your new helper")}
    ${line("Name", v.helper_full_name)}
    ${line("Phone", displayValue(v.helper_phone))}
    ${line("Verified", "ID and background checked by ABI Parent Care")}
    ${sectionHeading("Appointment (unchanged)")}
    ${line("Date & time", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Doctor/Hospital", displayValue(v.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `${v.helper_full_name} will now accompany ${v.parent_name} to the appointment, in place of ${v.old_helper_first_name}.`,
    "",
    "YOUR NEW HELPER",
    textLine("Name", v.helper_full_name),
    textLine("Phone", displayValue(v.helper_phone)),
    textLine("Verified", "ID and background checked by ABI Parent Care"),
    "",
    "APPOINTMENT (unchanged)",
    textLine("Date & time", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Doctor/Hospital", displayValue(v.doctor_hospital)),
    "",
    "Thank you for your patience.",
    "",
    "Warm regards,",
    "The ABI Parent Care team"
  ].join("\n");
  return build("G5", subject, v.ref, bodyHtml, bodyText);
}
function templateH1(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const dist = v.distance_km == null || Number.isNaN(Number(v.distance_km)) ? "\u2013" : String(Math.round(Number(v.distance_km) * 10) / 10);
  const area = displayValue(v.area);
  const subject = `New visit near you \u2013 ${dateShort}, ${time} \xB7 ${area} (${dist} km)`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${line("When", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Pickup area", `${area}, ${displayValue(v.pincode)} \xB7 about ${dist} km from you`)}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Patient", `Age ${v.parent_age}`)}
    <p style="margin:22px 0;">
      ${emailButtonHtml(v.accept_url, "Accept", "primary")}
      ${emailButtonHtml(v.decline_url, "Decline", "secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    "A new hospital visit is available near you. The first helper to accept gets it.",
    "",
    textLine("When", `${dateLong} \xB7 ${time} (${relative})`),
    textLine(
      "Pickup area",
      `${area}, ${displayValue(v.pincode)} \xB7 about ${dist} km from you`
    ),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine("Patient", `Age ${v.parent_age}`),
    "",
    `Accept: ${v.accept_url}`,
    `Decline: ${v.decline_url}`,
    "",
    "The patient's name, full address and family contact are shared after you accept.",
    "",
    `Ref ${v.ref}`
  ].join("\n");
  return build("H1", subject, v.ref, bodyHtml, bodyText);
}
function templateH2(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const pickup = joinAddress([
    v.address_line1,
    v.street,
    v.area,
    v.city,
    v.pincode
  ]) || "\u2013";
  const subject = `Confirmed: ${v.parent_name}, ${dateShort} ${time} \xB7 Ref ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${sectionHeading("Patient")}
    ${line("Name", `${v.parent_name}, ${v.parent_age}`)}
    ${line("Pickup", pickup)}
    ${line("Landmark", displayValue(v.landmark))}
    <p style="margin:10px 0 16px;">${emailButtonHtml(v.maps_url, "Open in Google Maps", "secondary")}</p>
    ${sectionHeading("Appointment")}
    ${line("When", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${sectionHeading("Family contact")}
    <p style="margin:0 0 12px;">${escapeHtml(v.booking_person_name)} (${escapeHtml(displayValue(v.relationship))}) \xB7 ${escapeHtml(displayValue(v.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${emailButtonHtml(v.cant_make_it_url, "Can't make it", "secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    "This visit is yours. Thank you!",
    "",
    "PATIENT",
    textLine("Name", `${v.parent_name}, ${v.parent_age}`),
    textLine("Pickup", pickup),
    textLine("Landmark", displayValue(v.landmark)),
    `Open in Google Maps: ${v.maps_url}`,
    "",
    "APPOINTMENT",
    textLine("When", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    "",
    "FAMILY CONTACT",
    `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`,
    "",
    "We'll remind you 12 hours and 6 hours before.",
    "",
    `Can't make it? ${v.cant_make_it_url}`,
    "",
    `Ref ${v.ref}`
  ].join("\n");
  return build("H2", subject, v.ref, bodyHtml, bodyText);
}
function templateH3(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject = `Reminder: visit ${relative} ${time} \u2013 ${v.parent_name}, ${displayValue(v.area)}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${escapeHtml(v.parent_name)} ${escapeHtml(relative)}.</p>
    ${line("When", `${dateLong} \xB7 ${time}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${escapeHtml(displayValue(v.full_address))} \xB7 <a href="${escapeHtml(v.maps_url)}">Open in Google Maps</a></div>
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${emailButtonHtml(v.cant_make_it_url, "Can't make it", "secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    `A reminder that you're accompanying ${v.parent_name} ${relative}.`,
    "",
    textLine("When", `${dateLong} \xB7 ${time}`),
    textLine("Pickup", `${displayValue(v.full_address)} \xB7 ${v.maps_url}`),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`
    ),
    "",
    "Plan to reach the pickup address 15 minutes early.",
    "",
    `Can't make it? ${v.cant_make_it_url}`,
    "",
    `Ref ${v.ref}`
  ].join("\n");
  return build("H3", subject, v.ref, bodyHtml, bodyText);
}
function templateH4(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject = `Please confirm: ${v.parent_name} at ${time} \u2013 ${relative}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${escapeHtml(v.parent_name)} is ${escapeHtml(relative)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${emailButtonHtml(v.confirm_url, "I'll be there", "primary")}
      ${emailButtonHtml(v.cant_make_it_url, "Can't make it", "secondary")}
    </p>
    ${line("When", `${dateLong} \xB7 ${time}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${escapeHtml(displayValue(v.full_address))} \xB7 <a href="${escapeHtml(v.maps_url)}">Open in Google Maps</a></div>
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    `Your visit with ${v.parent_name} is ${relative}. Please confirm you'll be there.`,
    "",
    `I'll be there: ${v.confirm_url}`,
    `Can't make it: ${v.cant_make_it_url}`,
    "",
    textLine("When", `${dateLong} \xB7 ${time}`),
    textLine("Pickup", `${displayValue(v.full_address)} \xB7 ${v.maps_url}`),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`
    ),
    "",
    "If we don't hear from you, our care team will call you.",
    "",
    `Ref ${v.ref}`
  ].join("\n");
  return build("H4", subject, v.ref, bodyHtml, bodyText);
}
function templateH5(v) {
  const link = v.helper_app_link || HELPER_APP_LINK;
  const subject = "Welcome to ABI Parent Care \u2013 your helper app login";
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${line("App link", link)}
    ${line("Login email", v.helper_email)}
    ${line("Password", "the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${emailButtonHtml(link, "Open helper app", "primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${escapeHtml(SUPPORT_PHONE)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    "Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.",
    "",
    textLine("App link", link),
    textLine("Login email", v.helper_email),
    textLine("Password", "the temporary password given to you by your manager"),
    "",
    "You'll be asked to set your own password the first time you log in.",
    "",
    'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',
    "",
    `Questions? Call ${SUPPORT_PHONE}.`,
    "",
    "The ABI Parent Care team"
  ].join("\n");
  return build("H5", subject, null, bodyHtml, bodyText);
}
function templateM1(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject = `URGENT \u2013 Helper needed in ${v.time_remaining} \xB7 ${v.parent_name} (${v.parent_age}) \xB7 ${time} \xB7 ${displayValue(v.area)} \xB7 ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${escapeHtml(relative)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${sectionHeading("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${sectionHeading("Visit details")}
    ${line("Patient", `${v.parent_name}, ${v.parent_age}`)}
    ${line("When", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013")}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Preference", preferenceLabel(v.helper_preference))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`)}
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Assign a helper", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `A booking has come in for ${relative}. There isn't time to send offers automatically, so please assign a helper now.`,
    "",
    "WHAT TO DO NOW",
    "Open the request, pick an available helper and send them an offer.",
    "",
    "VISIT DETAILS",
    textLine("Patient", `${v.parent_name}, ${v.parent_age}`),
    textLine("When", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013"),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine("Preference", preferenceLabel(v.helper_preference)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`
    ),
    "",
    `Assign a helper: ${v.assign_url}`
  ].join("\n");
  return build("M1", subject, v.ref, bodyHtml, bodyText);
}
function templateM2(v) {
  const count = v.items.length;
  const subject = `${count} request(s) need a helper \u2013 ${v.digest_time}`;
  const itemsHtml = v.items.map((item, i) => {
    const dateShort = formatAppointmentDateShort(item.appointment_date);
    const time = timeLabel(item.appointment_time);
    const relative = formatRelativeTime(
      item.appointment_date,
      item.appointment_time
    );
    return `
      <div style="margin:0 0 16px;padding:12px 0;border-bottom:1px solid #e5e7eb;">
        <p style="margin:0 0 6px;"><strong>${i + 1}. ${escapeHtml(item.ref)}</strong> \xB7 ${escapeHtml(item.parent_name)} (${item.parent_age}) \xB7 ${escapeHtml(dateShort)} ${escapeHtml(time)} (${escapeHtml(relative)})</p>
        <p style="margin:0 0 6px;">${escapeHtml(displayValue(item.area))} ${escapeHtml(displayValue(item.pincode))} \xB7 Preference: ${escapeHtml(preferenceLabel(item.helper_preference))}</p>
        <p style="margin:0 0 10px;">Why: ${escapeHtml(reasonPlain(item.reason))}</p>
        <p style="margin:0;">${emailButtonHtml(item.assign_url, "Assign", "primary")}</p>
      </div>
    `;
  }).join("");
  const itemsText = v.items.map((item, i) => {
    const dateShort = formatAppointmentDateShort(item.appointment_date);
    const time = timeLabel(item.appointment_time);
    const relative = formatRelativeTime(
      item.appointment_date,
      item.appointment_time
    );
    return [
      `${i + 1}. ${item.ref} \xB7 ${item.parent_name} (${item.parent_age}) \xB7 ${dateShort} ${time} (${relative})`,
      `   ${displayValue(item.area)} ${displayValue(item.pincode)} \xB7 Preference: ${preferenceLabel(item.helper_preference)}`,
      `   Why: ${reasonPlain(item.reason)}`,
      `   Assign: ${item.assign_url}`
    ].join("\n");
  }).join("\n\n");
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">These requests still need a helper. The soonest appointment is first.</p>
    ${itemsHtml}
    <p style="margin:22px 0;">${emailButtonHtml(v.open_all_url, "Open all in the portal", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    "These requests still need a helper. The soonest appointment is first.",
    "",
    itemsText,
    "",
    `Open all in the portal: ${v.open_all_url}`
  ].join("\n");
  return build("M2", subject, null, bodyHtml, bodyText);
}
function templateM3(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const reason = displayOrNone(v.decline_reason);
  const subject = `${v.helper_full_name} declined \u2013 please assign another \xB7 ${v.parent_name}, ${dateShort} ${time} \xB7 ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} declined the visit you offered.</p>
    ${line("Reason given", reason)}
    <p style="margin:12px 0;">Appointment: ${escapeHtml(dateLong)} \xB7 ${escapeHtml(time)} (${escapeHtml(relative)}) \xB7 ${escapeHtml(displayValue(v.area))}</p>
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Choose another helper", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name} declined the visit you offered.`,
    textLine("Reason given", reason),
    "",
    `Appointment: ${dateLong} \xB7 ${time} (${relative}) \xB7 ${displayValue(v.area)}`,
    "",
    `Choose another helper: ${v.assign_url}`
  ].join("\n");
  return build("M3", subject, v.ref, bodyHtml, bodyText);
}
function templateM4(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject = `No response from ${v.helper_full_name} \u2013 please assign another \xB7 ${v.parent_name} \xB7 ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} didn't respond within ${escapeHtml(v.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${escapeHtml(dateLong)} \xB7 ${escapeHtml(time)} (${escapeHtml(relative)}) \xB7 ${escapeHtml(displayValue(v.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${escapeHtml(displayValue(v.helper_phone))}</p>
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Choose another helper", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name} didn't respond within ${v.expiry_window}, so the offer has been withdrawn.`,
    "",
    `Appointment: ${dateLong} \xB7 ${time} (${relative}) \xB7 ${displayValue(v.area)}`,
    `Helper phone (if you'd like to call): ${displayValue(v.helper_phone)}`,
    "",
    `Choose another helper: ${v.assign_url}`
  ].join("\n");
  return build("M4", subject, v.ref, bodyHtml, bodyText);
}
function templateM5(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const reason = displayOrNone(v.dropout_reason);
  const subject = `URGENT \u2013 ${v.helper_full_name} can't attend \xB7 ${v.parent_name} \xB7 ${time} (${relative}) \xB7 ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} has said they can't attend this visit.</p>
    ${line("Reason given", reason)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${sectionHeading("Visit details")}
    ${line("Patient", `${v.parent_name}, ${v.parent_age}`)}
    ${line("When", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013")}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`)}
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Assign a replacement", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name} has said they can't attend this visit.`,
    textLine("Reason given", reason),
    "",
    "The family has been told we're arranging a replacement. Please assign a new helper now.",
    "",
    "VISIT DETAILS",
    textLine("Patient", `${v.parent_name}, ${v.parent_age}`),
    textLine("When", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013"),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`
    ),
    "",
    `Assign a replacement: ${v.assign_url}`
  ].join("\n");
  return build("M5", subject, v.ref, bodyHtml, bodyText);
}
function templateM6(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const assigned = formatIstDateTime(v.assigned_at);
  const subject = v.urgent ? `URGENT \u2013 visit in 1 hour, ${v.helper_full_name} still not confirmed \xB7 ${v.parent_name} \xB7 ${v.ref}` : `Action needed \u2013 ${v.helper_full_name} hasn't confirmed \xB7 ${v.parent_name} \xB7 ${time} (${relative}) \xB7 ${v.ref}`;
  const lead = v.urgent ? `The visit starts in about 1 hour and ${escapeHtml(v.helper_full_name)} still hasn't confirmed. Please resolve this now.` : `${escapeHtml(v.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`;
  const leadText = v.urgent ? `The visit starts in about 1 hour and ${v.helper_full_name} still hasn't confirmed. Please resolve this now.` : `${v.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`;
  const stepsHtml = v.urgent ? `<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${escapeHtml(v.helper_first_name)}: ${escapeHtml(displayValue(v.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".</li>
      </ol>` : `${sectionHeading("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${escapeHtml(v.helper_first_name)}: ${escapeHtml(displayValue(v.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone \u2013 nothing else happens, or</li>
            <li>Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`;
  const stepsText = v.urgent ? [
    `1. Call ${v.helper_first_name}: ${displayValue(v.helper_phone)}`,
    `2. Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".`
  ].join("\n") : [
    "WHAT TO DO NOW",
    `1. Call ${v.helper_first_name}: ${displayValue(v.helper_phone)}`,
    "2. Then in the portal, choose:",
    "   \u2022 Helper confirmed by phone \u2013 nothing else happens, or",
    "   \u2022 Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper"
  ].join("\n");
  const detailsHtml = `
    ${sectionHeading("Visit details")}
    ${line("Patient", `${v.parent_name}, ${v.parent_age}`)}
    ${line("When", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013")}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${sectionHeading("Helper status")}
    ${line("Assigned", assigned)}
    ${line("Reminders", `12-hour ${v.r12_status} \xB7 6-hour ${v.r6_status}`)}
    ${line("Confirmed", "Not yet")}
  `;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${lead}</p>
    ${stepsHtml}
    ${detailsHtml}
    <p style="margin:22px 0;">${emailButtonHtml(v.open_url, "Open request", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    leadText,
    "",
    stepsText,
    "",
    "VISIT DETAILS",
    textLine("Patient", `${v.parent_name}, ${v.parent_age}`),
    textLine("When", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013"),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    "",
    "HELPER STATUS",
    textLine("Assigned", assigned),
    textLine("Reminders", `12-hour ${v.r12_status} \xB7 6-hour ${v.r6_status}`),
    textLine("Confirmed", "Not yet"),
    "",
    `Open request: ${v.open_url}`
  ].join("\n");
  return build(v.urgent ? "M7" : "M6", subject, v.ref, bodyHtml, bodyText);
}
function templateM7(v) {
  return templateM6({ ...v, urgent: true });
}
function templateM8(v) {
  const subject = `Driving licence ${v.expiry_phrase} \u2013 ${v.helper_full_name}`;
  const statusHtml = v.expired ? `<p style="margin:0 0 12px;">If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${v.upcoming_count} (moved to Needs action).</p>` : `<p style="margin:0 0 12px;">If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.</p>`;
  const statusText = v.expired ? `If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${v.upcoming_count} (moved to Needs action).` : "If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.";
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)}'s driving licence ${escapeHtml(v.expiry_phrase)} (${escapeHtml(v.dl_expiry)}).</p>
    ${statusHtml}
    <p style="margin:22px 0;">${emailButtonHtml(v.open_url, "Open helper profile", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name}'s driving licence ${v.expiry_phrase} (${v.dl_expiry}).`,
    "",
    statusText,
    "",
    `Open helper profile: ${v.open_url}`
  ].join("\n");
  return build("M8", subject, null, bodyHtml, bodyText);
}
function templateM9(v) {
  const subject = `Profile change request \u2013 ${v.helper_full_name}`;
  const note = displayOrNone(v.request_note);
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} has asked to update their profile:</p>
    <p style="margin:0 0 12px;padding:12px 14px;background:#f3f6fb;border-radius:8px;font-style:italic;">"${escapeHtml(note)}"</p>
    <p style="margin:0 0 12px;">Please review and update their details in the portal if appropriate.</p>
    <p style="margin:22px 0;">${emailButtonHtml(v.open_url, "Open helper profile", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name} has asked to update their profile:`,
    "",
    `"${note}"`,
    "",
    "Please review and update their details in the portal if appropriate.",
    "",
    `Open helper profile: ${v.open_url}`
  ].join("\n");
  return build("M9", subject, null, bodyHtml, bodyText);
}

// ../../../tmp/fn-src/supabase/functions/_shared/senior.ts
var ADMIN_PAGE_BASE = "https://nandhini-17223.github.io/elderly-care/admin";
var RESPOND_BASE = "https://nandhini-17223.github.io/elderly-care/respond.html";
var MANAGER_FIRST_NAME = "Manager";
function seniorAssignUrl(requestId) {
  const next = `needs-action.html?request=${encodeURIComponent(requestId)}`;
  return `${ADMIN_PAGE_BASE}/login.html?next=${encodeURIComponent(next)}`;
}
function needsActionUrl() {
  return `${ADMIN_PAGE_BASE}/login.html?next=${encodeURIComponent("needs-action.html")}`;
}
function helperProfileUrl(helperId) {
  const next = `helper.html?id=${encodeURIComponent(helperId)}`;
  return `${ADMIN_PAGE_BASE}/login.html?next=${encodeURIComponent(next)}`;
}

// ../../../tmp/fn-src/supabase/functions/email-preview/index.ts
function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", Connection: "keep-alive" }
  });
}
function sampleTemplates() {
  const appointment_date = "2026-11-13";
  const appointment_time = "10:00:00";
  const ref = "ABI-1042";
  const requestId = "00000000-0000-4000-8000-000000000001";
  const helperId = "00000000-0000-4000-8000-000000000002";
  const acceptUrl = `${RESPOND_BASE}?token=preview-token&action=accept`;
  const declineUrl = `${RESPOND_BASE}?token=preview-token&action=decline`;
  const cantMakeIt = `${RESPOND_BASE}?token=preview-token&action=cant_make_it`;
  const confirmUrl = `${RESPOND_BASE}?token=preview-token&action=confirm_attendance`;
  const maps = "https://www.google.com/maps/search/?api=1&query=12%20Gandhi%20Street%20T%20Nagar%20Chennai";
  const fullAddress = "12 Gandhi Street, T. Nagar, Chennai, 600017";
  return [
    templateG1({
      ref,
      booking_person_name: "Priya Sharma",
      parent_name: "Ramesh Sharma",
      appointment_date,
      appointment_time,
      doctor_hospital: "Apollo Hospitals, Greams Road",
      area: "T. Nagar",
      city: "Chennai",
      pincode: "600017",
      helper_preference: "female"
    }),
    templateG2({
      ref,
      booking_person_name: "Priya Sharma",
      parent_name: "Ramesh Sharma",
      appointment_date,
      appointment_time
    }),
    templateG3({
      ref,
      booking_person_name: "Priya Sharma",
      parent_name: "Ramesh Sharma",
      helper_full_name: "Anitha Kumar",
      helper_phone: "+91 98765 43210",
      helper_photo_url: null,
      appointment_date,
      appointment_time,
      doctor_hospital: "Apollo Hospitals, Greams Road",
      address_line1: "12 Gandhi Street",
      street: "Near Pondy Bazaar",
      area: "T. Nagar",
      city: "Chennai",
      pincode: "600017"
    }),
    templateG4({
      ref,
      booking_person_name: "Priya Sharma",
      parent_name: "Ramesh Sharma",
      old_helper_first_name: "Anitha",
      appointment_date,
      appointment_time
    }),
    templateG5({
      ref,
      booking_person_name: "Priya Sharma",
      parent_name: "Ramesh Sharma",
      helper_full_name: "Kavitha Rajan",
      helper_phone: "+91 91234 56789",
      helper_photo_url: null,
      old_helper_first_name: "Anitha",
      appointment_date,
      appointment_time,
      doctor_hospital: "Apollo Hospitals, Greams Road"
    }),
    templateH1({
      ref,
      helper_first_name: "Anitha",
      appointment_date,
      appointment_time,
      area: "T. Nagar",
      pincode: "600017",
      distance_km: 3.4,
      doctor_hospital: "Apollo Hospitals, Greams Road",
      parent_age: 72,
      accept_url: acceptUrl,
      decline_url: declineUrl
    }),
    templateH2({
      ref,
      helper_first_name: "Anitha",
      parent_name: "Ramesh Sharma",
      parent_age: 72,
      address_line1: "12 Gandhi Street",
      street: "Near Pondy Bazaar",
      area: "T. Nagar",
      city: "Chennai",
      pincode: "600017",
      landmark: "Opposite ICICI Bank",
      maps_url: maps,
      appointment_date,
      appointment_time,
      doctor_hospital: "Apollo Hospitals, Greams Road",
      booking_person_name: "Priya Sharma",
      relationship: "Daughter",
      guardian_phone: "+91 99887 76655",
      cant_make_it_url: cantMakeIt
    }),
    templateH3({
      ref,
      helper_first_name: "Anitha",
      parent_name: "Ramesh Sharma",
      area: "T. Nagar",
      appointment_date,
      appointment_time,
      full_address: fullAddress,
      maps_url: maps,
      doctor_hospital: "Apollo Hospitals, Greams Road",
      booking_person_name: "Priya Sharma",
      relationship: "Daughter",
      guardian_phone: "+91 99887 76655",
      cant_make_it_url: cantMakeIt
    }),
    templateH4({
      ref,
      helper_first_name: "Anitha",
      parent_name: "Ramesh Sharma",
      area: "T. Nagar",
      appointment_date,
      appointment_time,
      full_address: fullAddress,
      maps_url: maps,
      doctor_hospital: "Apollo Hospitals, Greams Road",
      booking_person_name: "Priya Sharma",
      relationship: "Daughter",
      guardian_phone: "+91 99887 76655",
      cant_make_it_url: cantMakeIt,
      confirm_url: confirmUrl
    }),
    templateH5({
      helper_first_name: "Anitha",
      helper_email: "anitha.helper@example.com",
      helper_app_link: HELPER_APP_LINK
    }),
    templateM1({
      ref,
      manager_first_name: MANAGER_FIRST_NAME,
      parent_name: "Ramesh Sharma",
      parent_age: 72,
      appointment_date,
      appointment_time,
      area: "T. Nagar",
      city: "Chennai",
      pincode: "600017",
      doctor_hospital: "Apollo Hospitals, Greams Road",
      helper_preference: "female",
      booking_person_name: "Priya Sharma",
      relationship: "Daughter",
      guardian_phone: "+91 99887 76655",
      time_remaining: "2 hours",
      assign_url: seniorAssignUrl(requestId)
    }),
    templateM2({
      manager_first_name: MANAGER_FIRST_NAME,
      digest_time: "1:00 PM",
      open_all_url: needsActionUrl(),
      items: [
        {
          ref: "ABI-1042",
          parent_name: "Ramesh Sharma",
          parent_age: 72,
          appointment_date,
          appointment_time,
          area: "T. Nagar",
          pincode: "600017",
          helper_preference: "female",
          reason: "no_acceptance",
          assign_url: seniorAssignUrl(requestId)
        },
        {
          ref: "ABI-1043",
          parent_name: "Lakshmi Iyer",
          parent_age: 68,
          appointment_date: "2026-11-14",
          appointment_time: "15:30:00",
          area: "Adyar",
          pincode: "600020",
          helper_preference: "no_preference",
          reason: "all_declined",
          assign_url: seniorAssignUrl(requestId)
        }
      ]
    }),
    templateM3({
      ref,
      manager_first_name: MANAGER_FIRST_NAME,
      helper_full_name: "Anitha Kumar",
      parent_name: "Ramesh Sharma",
      appointment_date,
      appointment_time,
      area: "T. Nagar",
      decline_reason: null,
      assign_url: seniorAssignUrl(requestId)
    }),
    templateM4({
      ref,
      manager_first_name: MANAGER_FIRST_NAME,
      helper_full_name: "Anitha Kumar",
      helper_phone: "+91 98765 43210",
      parent_name: "Ramesh Sharma",
      appointment_date,
      appointment_time,
      area: "T. Nagar",
      expiry_window: "1 hour",
      assign_url: seniorAssignUrl(requestId)
    }),
    templateM5({
      ref,
      manager_first_name: MANAGER_FIRST_NAME,
      helper_full_name: "Anitha Kumar",
      parent_name: "Ramesh Sharma",
      parent_age: 72,
      appointment_date,
      appointment_time,
      area: "T. Nagar",
      city: "Chennai",
      pincode: "600017",
      doctor_hospital: "Apollo Hospitals, Greams Road",
      booking_person_name: "Priya Sharma",
      relationship: "Daughter",
      guardian_phone: "+91 99887 76655",
      dropout_reason: "Feeling unwell",
      assign_url: seniorAssignUrl(requestId)
    }),
    templateM6({
      ref,
      manager_first_name: MANAGER_FIRST_NAME,
      helper_full_name: "Anitha Kumar",
      helper_first_name: "Anitha",
      helper_phone: "+91 98765 43210",
      parent_name: "Ramesh Sharma",
      parent_age: 72,
      appointment_date,
      appointment_time,
      area: "T. Nagar",
      city: "Chennai",
      pincode: "600017",
      doctor_hospital: "Apollo Hospitals, Greams Road",
      assigned_at: "2026-11-12T04:30:00.000Z",
      r12_status: "sent",
      r6_status: "sent",
      open_url: seniorAssignUrl(requestId)
    }),
    templateM7({
      ref,
      manager_first_name: MANAGER_FIRST_NAME,
      helper_full_name: "Anitha Kumar",
      helper_first_name: "Anitha",
      helper_phone: "+91 98765 43210",
      parent_name: "Ramesh Sharma",
      parent_age: 72,
      appointment_date,
      appointment_time,
      area: "T. Nagar",
      city: "Chennai",
      pincode: "600017",
      doctor_hospital: "Apollo Hospitals, Greams Road",
      assigned_at: "2026-11-12T04:30:00.000Z",
      r12_status: "sent",
      r6_status: "sent",
      open_url: seniorAssignUrl(requestId)
    }),
    templateM8({
      manager_first_name: MANAGER_FIRST_NAME,
      helper_full_name: "Anitha Kumar",
      expiry_phrase: "expires in 30 days",
      dl_expiry: "2026-12-12",
      upcoming_count: 2,
      open_url: helperProfileUrl(helperId),
      expired: false
    }),
    templateM9({
      manager_first_name: MANAGER_FIRST_NAME,
      helper_full_name: "Anitha Kumar",
      request_note: "Please update my phone number and home pincode.",
      open_url: helperProfileUrl(helperId)
    })
  ];
}
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }
  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  try {
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") || "";
    const authHeader = req.headers.get("Authorization") || "";
    const bearer = authHeader.replace(/^Bearer\s+/i, "").trim();
    const testMode = Deno.env.get("EMAIL_TEST_MODE") === "true";
    const authorized = Boolean(
      serviceRoleKey && bearer === serviceRoleKey || testMode && anonKey && bearer === anonKey
    );
    if (!authorized) {
      return jsonResponse({ error: "Unauthorized" }, 401);
    }
    const payload = await req.json().catch(() => ({}));
    if (payload.confirm !== "send-all-previews") {
      return jsonResponse({
        error: 'Pass {"confirm":"send-all-previews"} to send the batch',
        hint: "Subjects are prefixed [PREVIEW G1], [PREVIEW H1], etc. Test mode still redirects to TEST_EMAIL_TO."
      }, 400);
    }
    const testTo = Deno.env.get("TEST_EMAIL_TO")?.trim();
    if (!testTo) {
      return jsonResponse({ error: "TEST_EMAIL_TO is not set" }, 500);
    }
    const templates = sampleTemplates().filter(
      (t) => !payload.only?.length || payload.only.includes(t.id)
    );
    const results = [];
    for (const email of templates) {
      const subject = `[PREVIEW ${email.id}] ${email.subject}`;
      const sent = await sendEmail({
        to: testTo,
        toName: "Preview inbox",
        subject,
        html: email.html,
        text: email.text
      });
      results.push({
        id: email.id,
        ok: sent.ok,
        email_id: sent.id,
        subject: sent.subject,
        to: sent.to,
        testMode: sent.testMode,
        error: sent.error
      });
      await new Promise((r) => setTimeout(r, 400));
    }
    return jsonResponse({
      ok: results.every((r) => r.ok),
      count: results.length,
      portal_base: ADMIN_PAGE_BASE,
      results
    });
  } catch (error) {
    console.error(error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return jsonResponse({ error: message }, 500);
  }
});
