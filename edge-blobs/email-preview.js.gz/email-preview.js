const k="+91 73399 11220",W="https://nandhini-17223.github.io/elderly-care/helper/",Z="https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg",V="#1d6fd8",Q="#4a9cf7",B="#1f2937",L="#6b7280",M=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],X=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function r(e){return e.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;")}function i(e,n="\u2013"){if(e==null)return n;const t=String(e).trim();return!t||t.toLowerCase()==="null"||t.toLowerCase()==="undefined"?n:t}function D(e){return i(e,"None given")}function R(e){if(!e)return null;const n=/^(\d{4})-(\d{2})-(\d{2})$/.exec(e.trim());if(!n)return null;const t=Number(n[1]),a=Number(n[2]),o=Number(n[3]);return!a||a<1||a>12||!o||o<1||o>31?null:{year:t,month:a,day:o}}function G(e){if(!e)return null;const n=/^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(e.trim());if(!n)return null;const t=Number(n[1]),a=Number(n[2]);return!Number.isInteger(t)||!Number.isInteger(a)||t<0||t>23||a<0||a>59?null:{hour24:t,minute:a}}function v(e,n){const t=R(e),a=G(n)??{hour24:0,minute:0};return t?Date.parse(`${String(t.year).padStart(4,"0")}-${String(t.month).padStart(2,"0")}-${String(t.day).padStart(2,"0")}T${String(a.hour24).padStart(2,"0")}:${String(a.minute).padStart(2,"0")}:00+05:30`):NaN}function U(e){const n=R(e);return n?`${n.day} ${M[n.month-1]} ${n.year}`:null}function T(e){const n=R(e);return n?`${n.day} ${M[n.month-1]}`:i(e)}function b(e){const n=R(e);if(!n)return i(e);const t=new Date(Date.UTC(n.year,n.month-1,n.day)).getUTCDay();return`${X[t]}, ${n.day} ${M[n.month-1]} ${n.year}`}function j(e){const n=G(e);if(!n)return null;const t=n.hour24%12||12,a=n.hour24<12?"AM":"PM";return`${t}:${String(n.minute).padStart(2,"0")} ${a}`}function Ae(e,n){const t=U(e),a=j(n);return!t||!a?null:`${t}, ${a}`}function q(e){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(e))}function x(e,n,t=Date.now()){const a=v(e,n);if(!Number.isFinite(a))return"\u2013";const o=q(t),m=q(a),d=R(o),s=R(m),c=Math.round((Date.UTC(s.year,s.month-1,s.day)-Date.UTC(d.year,d.month-1,d.day))/864e5);if(c===0){const u=a-t;if(u<=0)return"today";const _=Math.round(u/6e4);if(_<60)return`today \xB7 in ${_} minute${_===1?"":"s"}`;const g=Math.round(_/60);return`today \xB7 in ${g} hour${g===1?"":"s"}`}return c===1?"tomorrow":c>1?`in ${c} days`:c===-1?"yesterday":`${Math.abs(c)} days ago`}function ee(e){if(!e)return"\u2013";const n=Date.parse(e);if(!Number.isFinite(n))return i(e);const t=new Date(n),a=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Kolkata",weekday:"short",day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit",hour12:!0}).formatToParts(t),o=S=>a.find(P=>P.type===S)?.value??"",m=o("day"),d=o("month"),s=o("year"),c=o("weekday"),u=o("hour"),_=o("minute"),g=o("dayPeriod").toUpperCase();return`${c}, ${m} ${d} ${s} \xB7 ${u}:${_} ${g}`}function f(e,n,t="primary"){const a=t==="primary"?V:"#e5e7eb",o=t==="primary"?"#ffffff":"#111827";return`<a href="${r(e)}" style="background:${a};color:${o};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${r(n)}</a>`}function F(){return`This is an automated message from ABI Parent Care. For help, call ${k}.`}function ne(e){const n=i(e.ref,""),t=n?`<td align="right" style="font-size:13px;color:${L};white-space:nowrap;">Ref <strong style="color:${B};">${r(n)}</strong></td>`:"<td></td>";return`<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${e.preheader?`<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${r(e.preheader)}</div>`:""}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${V},${Q});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${Z}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${n?`<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${r(n)}</strong></td>`:""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${B};">
          ${e.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${L};">
          ${r(F())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`}function te(e){return["ABI Parent Care",e.ref?`Ref ${i(e.ref)}`:null,"",e.bodyText.trim(),"",F()].filter(t=>t!==null).join(`
`)}async function re(e){const n=Deno.env.get("RESEND_API_KEY");if(!n)throw new Error("Missing RESEND_API_KEY secret");const t=Deno.env.get("EMAIL_TEST_MODE")==="true",a=Deno.env.get("TEST_EMAIL_TO")?.trim()||"",o=(e.toName?.trim()||e.to).trim(),m=t&&a?a:e.to,d=t&&a?`[To: ${o}] ${e.subject}`:e.subject,s={from:"ABI Parent Care <onboarding@resend.dev>",to:[m],subject:d,html:e.html};e.text&&e.text.trim()&&(s.text=e.text);const c=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify(s)}),u=await c.json();return c.ok?{ok:!0,status:c.status,id:typeof u?.id=="string"?u.id:void 0,to:m,subject:d,testMode:t}:(console.error("Resend error:",u),{ok:!1,status:c.status,to:m,subject:d,testMode:t,error:u})}function He(e){const n=String(e??"").trim();return n?n.split(/\s+/)[0]??n:"there"}function C(e){return e==="female"?"Female helper":e==="male"?"Male helper":e==="no_preference"||e==="none"||!e?"No preference":i(e,"No preference")}function O(e){switch(e){case"no_acceptance":return"No helper accepted within 2 hours";case"no_suitable_helpers":return"No suitable helper nearby";case"all_declined":return"All offered helpers declined";case"short_notice":return"Booked at short notice";case"helper_dropped":return"Helper dropped out";case"helper_not_confirmed":return"Helper didn't confirm";case"helper_unavailable":return"Helper no longer available";default:return e?e.replaceAll("_"," "):"Needs senior attention"}}function $(e){return j(e)??i(e)}function y(e){return`<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${r(e)}</p>`}function l(e,n){return`<div style="margin:0 0 6px;"><strong>${r(e)}:</strong> ${r(n)}</div>`}function p(e,n){return`${e}: ${n}`}function Y(e){return e?`<p style="margin:16px 0;"><img src="${r(e)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`:""}function A(e){return e.map(n=>String(n??"").trim()).filter(Boolean).join(", ")}function h(e,n,t,a,o){return{id:e,subject:n,html:ne({bodyHtml:a,ref:t,preheader:n}),text:te({bodyText:o,ref:t})}}function ae(e){const n=T(e.appointment_date),t=b(e.appointment_date),a=$(e.appointment_time),o=A([e.area,e.city,e.pincode])||"\u2013",m=C(e.helper_preference),d=`We've received your request \u2013 ${e.parent_name}, ${n} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${r(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Thank you for choosing ABI Parent Care. We've received your request for ${r(e.parent_name)}'s doctor appointment.</p>
    ${y("Appointment")}
    ${l("Date & time",`${t} \xB7 ${a}`)}
    ${l("Doctor/Hospital",i(e.doctor_hospital))}
    ${l("Pickup from",o)}
    ${l("Helper preference",m)}
    ${y("What happens next")}
    <p style="margin:0 0 12px;">We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.</p>
    <p style="margin:0 0 12px;">Need to change anything? Call us on ${r(k)} and quote Ref ${r(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`Thank you for choosing ABI Parent Care. We've received your request for ${e.parent_name}'s doctor appointment.`,"","APPOINTMENT",p("Date & time",`${t} \xB7 ${a}`),p("Doctor/Hospital",i(e.doctor_hospital)),p("Pickup from",o),p("Helper preference",m),"","WHAT HAPPENS NEXT","We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.","",`Need to change anything? Call us on ${k} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G1",d,e.ref,s,c)}function ie(e){const n=T(e.appointment_date),t=b(e.appointment_date),a=$(e.appointment_time),o=`Update on ${e.parent_name}'s appointment \u2013 ${n} \xB7 Ref ${e.ref}`,m=`
    <p style="margin:0 0 12px;">Dear ${r(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${r(e.parent_name)}'s appointment on ${r(t)} at ${r(a)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${r(k)} and quote Ref ${r(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,d=[`Dear ${e.booking_person_name},`,"",`A quick update: our care team is personally arranging a suitable helper for ${e.parent_name}'s appointment on ${t} at ${a}.`,"","You don't need to do anything. We'll email you the helper's details shortly.","",`If you'd like to speak to us, call ${k} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G2",o,e.ref,m,d)}function oe(e){const n=T(e.appointment_date),t=b(e.appointment_date),a=$(e.appointment_time),o=x(e.appointment_date,e.appointment_time),m=A([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",d=`Helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name}, ${n} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${r(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news \u2013 ${r(e.helper_full_name)} will accompany ${r(e.parent_name)} to the appointment.</p>
    ${Y(e.helper_photo_url)}
    ${y("Your helper")}
    ${l("Name",e.helper_full_name)}
    ${l("Phone",i(e.helper_phone))}
    ${l("Verified","ID and background checked by ABI Parent Care")}
    ${y("Appointment")}
    ${l("Date & time",`${t} \xB7 ${a} (${o})`)}
    ${l("Doctor/Hospital",i(e.doctor_hospital))}
    ${l("Pickup from",m)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${r(e.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`Good news \u2013 ${e.helper_full_name} will accompany ${e.parent_name} to the appointment.`,"","YOUR HELPER",p("Name",e.helper_full_name),p("Phone",i(e.helper_phone)),p("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT",p("Date & time",`${t} \xB7 ${a} (${o})`),p("Doctor/Hospital",i(e.doctor_hospital)),p("Pickup from",m),"",`For safety, please share this with ${e.parent_name} so they know who to expect.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G3",d,e.ref,s,c)}function se(e){const n=T(e.appointment_date),t=b(e.appointment_date),a=$(e.appointment_time),o=`Change of helper for ${e.parent_name} \u2013 ${n} \xB7 Ref ${e.ref}`,m=`
    <p style="margin:0 0 12px;">Dear ${r(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${r(e.old_helper_first_name)} is unable to attend ${r(e.parent_name)}'s appointment on ${r(t)} at ${r(a)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${r(k)} and quote Ref ${r(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,d=[`Dear ${e.booking_person_name},`,"",`We're sorry \u2013 ${e.old_helper_first_name} is unable to attend ${e.parent_name}'s appointment on ${t} at ${a}.`,"","Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.","",`The appointment itself is unchanged. If you have concerns, call ${k} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G4",o,e.ref,m,d)}function pe(e){const n=b(e.appointment_date),t=$(e.appointment_time),a=x(e.appointment_date,e.appointment_time),o=`New helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name} \xB7 Ref ${e.ref}`,m=`
    <p style="margin:0 0 12px;">Dear ${r(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${r(e.helper_full_name)} will now accompany ${r(e.parent_name)} to the appointment, in place of ${r(e.old_helper_first_name)}.</p>
    ${Y(e.helper_photo_url)}
    ${y("Your new helper")}
    ${l("Name",e.helper_full_name)}
    ${l("Phone",i(e.helper_phone))}
    ${l("Verified","ID and background checked by ABI Parent Care")}
    ${y("Appointment (unchanged)")}
    ${l("Date & time",`${n} \xB7 ${t} (${a})`)}
    ${l("Doctor/Hospital",i(e.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,d=[`Dear ${e.booking_person_name},`,"",`${e.helper_full_name} will now accompany ${e.parent_name} to the appointment, in place of ${e.old_helper_first_name}.`,"","YOUR NEW HELPER",p("Name",e.helper_full_name),p("Phone",i(e.helper_phone)),p("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT (unchanged)",p("Date & time",`${n} \xB7 ${t} (${a})`),p("Doctor/Hospital",i(e.doctor_hospital)),"","Thank you for your patience.","","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G5",o,e.ref,m,d)}function le(e){const n=T(e.appointment_date),t=b(e.appointment_date),a=$(e.appointment_time),o=x(e.appointment_date,e.appointment_time),m=e.distance_km==null||Number.isNaN(Number(e.distance_km))?"\u2013":String(Math.round(Number(e.distance_km)*10)/10),d=i(e.area),s=`New visit near you \u2013 ${n}, ${a} \xB7 ${d} (${m} km)`,c=`
    <p style="margin:0 0 12px;">Hi ${r(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${l("When",`${t} \xB7 ${a} (${o})`)}
    ${l("Pickup area",`${d}, ${i(e.pincode)} \xB7 about ${m} km from you`)}
    ${l("Hospital",i(e.doctor_hospital))}
    ${l("Patient",`Age ${e.parent_age}`)}
    <p style="margin:22px 0;">
      ${f(e.accept_url,"Accept","primary")}
      ${f(e.decline_url,"Decline","secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${r(e.ref)}</p>
  `,u=[`Hi ${e.helper_first_name},`,"","A new hospital visit is available near you. The first helper to accept gets it.","",p("When",`${t} \xB7 ${a} (${o})`),p("Pickup area",`${d}, ${i(e.pincode)} \xB7 about ${m} km from you`),p("Hospital",i(e.doctor_hospital)),p("Patient",`Age ${e.parent_age}`),"",`Accept: ${e.accept_url}`,`Decline: ${e.decline_url}`,"","The patient's name, full address and family contact are shared after you accept.","",`Ref ${e.ref}`].join(`
`);return h("H1",s,e.ref,c,u)}function me(e){const n=T(e.appointment_date),t=b(e.appointment_date),a=$(e.appointment_time),o=x(e.appointment_date,e.appointment_time),m=A([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",d=`Confirmed: ${e.parent_name}, ${n} ${a} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Hi ${r(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${y("Patient")}
    ${l("Name",`${e.parent_name}, ${e.parent_age}`)}
    ${l("Pickup",m)}
    ${l("Landmark",i(e.landmark))}
    <p style="margin:10px 0 16px;">${f(e.maps_url,"Open in Google Maps","secondary")}</p>
    ${y("Appointment")}
    ${l("When",`${t} \xB7 ${a} (${o})`)}
    ${l("Hospital",i(e.doctor_hospital))}
    ${y("Family contact")}
    <p style="margin:0 0 12px;">${r(e.booking_person_name)} (${r(i(e.relationship))}) \xB7 ${r(i(e.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${f(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${r(e.ref)}</p>
  `,c=[`Hi ${e.helper_first_name},`,"","This visit is yours. Thank you!","","PATIENT",p("Name",`${e.parent_name}, ${e.parent_age}`),p("Pickup",m),p("Landmark",i(e.landmark)),`Open in Google Maps: ${e.maps_url}`,"","APPOINTMENT",p("When",`${t} \xB7 ${a} (${o})`),p("Hospital",i(e.doctor_hospital)),"","FAMILY CONTACT",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`,"","We'll remind you 12 hours and 6 hours before.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return h("H2",d,e.ref,s,c)}function de(e){const n=b(e.appointment_date),t=$(e.appointment_time),a=x(e.appointment_date,e.appointment_time),o=`Reminder: visit ${a} ${t} \u2013 ${e.parent_name}, ${i(e.area)}`,m=`
    <p style="margin:0 0 12px;">Hi ${r(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${r(e.parent_name)} ${r(a)}.</p>
    ${l("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${r(i(e.full_address))} \xB7 <a href="${r(e.maps_url)}">Open in Google Maps</a></div>
    ${l("Hospital",i(e.doctor_hospital))}
    ${l("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${f(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${r(e.ref)}</p>
  `,d=[`Hi ${e.helper_first_name},`,"",`A reminder that you're accompanying ${e.parent_name} ${a}.`,"",p("When",`${n} \xB7 ${t}`),p("Pickup",`${i(e.full_address)} \xB7 ${e.maps_url}`),p("Hospital",i(e.doctor_hospital)),p("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`),"","Plan to reach the pickup address 15 minutes early.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return h("H3",o,e.ref,m,d)}function ce(e){const n=b(e.appointment_date),t=$(e.appointment_time),a=x(e.appointment_date,e.appointment_time),o=`Please confirm: ${e.parent_name} at ${t} \u2013 ${a}`,m=`
    <p style="margin:0 0 12px;">Hi ${r(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${r(e.parent_name)} is ${r(a)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${f(e.confirm_url,"I'll be there","primary")}
      ${f(e.cant_make_it_url,"Can't make it","secondary")}
    </p>
    ${l("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${r(i(e.full_address))} \xB7 <a href="${r(e.maps_url)}">Open in Google Maps</a></div>
    ${l("Hospital",i(e.doctor_hospital))}
    ${l("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${r(e.ref)}</p>
  `,d=[`Hi ${e.helper_first_name},`,"",`Your visit with ${e.parent_name} is ${a}. Please confirm you'll be there.`,"",`I'll be there: ${e.confirm_url}`,`Can't make it: ${e.cant_make_it_url}`,"",p("When",`${n} \xB7 ${t}`),p("Pickup",`${i(e.full_address)} \xB7 ${e.maps_url}`),p("Hospital",i(e.doctor_hospital)),p("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`),"","If we don't hear from you, our care team will call you.","",`Ref ${e.ref}`].join(`
`);return h("H4",o,e.ref,m,d)}function ue(e){const n=e.helper_app_link||W,t="Welcome to ABI Parent Care \u2013 your helper app login",a=`
    <p style="margin:0 0 12px;">Hi ${r(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${l("App link",n)}
    ${l("Login email",e.helper_email)}
    ${l("Password","the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${f(n,"Open helper app","primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${r(k)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `,o=[`Hi ${e.helper_first_name},`,"","Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.","",p("App link",n),p("Login email",e.helper_email),p("Password","the temporary password given to you by your manager"),"","You'll be asked to set your own password the first time you log in.","",'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',"",`Questions? Call ${k}.`,"","The ABI Parent Care team"].join(`
`);return h("H5",t,null,a,o)}function _e(e){const n=b(e.appointment_date),t=$(e.appointment_time),a=x(e.appointment_date,e.appointment_time),o=`URGENT \u2013 Helper needed in ${e.time_remaining} \xB7 ${e.parent_name} (${e.parent_age}) \xB7 ${t} \xB7 ${i(e.area)} \xB7 ${e.ref}`,m=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${r(a)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${y("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${y("Visit details")}
    ${l("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${l("When",`${n} \xB7 ${t} (${a})`)}
    ${l("Pickup",A([e.area,e.city,e.pincode])||"\u2013")}
    ${l("Hospital",i(e.doctor_hospital))}
    ${l("Preference",C(e.helper_preference))}
    ${l("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${f(e.assign_url,"Assign a helper","primary")}</p>
  `,d=[`Hi ${e.manager_first_name},`,"",`A booking has come in for ${a}. There isn't time to send offers automatically, so please assign a helper now.`,"","WHAT TO DO NOW","Open the request, pick an available helper and send them an offer.","","VISIT DETAILS",p("Patient",`${e.parent_name}, ${e.parent_age}`),p("When",`${n} \xB7 ${t} (${a})`),p("Pickup",A([e.area,e.city,e.pincode])||"\u2013"),p("Hospital",i(e.doctor_hospital)),p("Preference",C(e.helper_preference)),p("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`),"",`Assign a helper: ${e.assign_url}`].join(`
`);return h("M1",o,e.ref,m,d)}function ge(e){const t=`${e.items.length} request(s) need a helper \u2013 ${e.digest_time}`,a=e.items.map((s,c)=>{const u=T(s.appointment_date),_=$(s.appointment_time),g=x(s.appointment_date,s.appointment_time);return`
      <div style="margin:0 0 16px;padding:12px 0;border-bottom:1px solid #e5e7eb;">
        <p style="margin:0 0 6px;"><strong>${c+1}. ${r(s.ref)}</strong> \xB7 ${r(s.parent_name)} (${s.parent_age}) \xB7 ${r(u)} ${r(_)} (${r(g)})</p>
        <p style="margin:0 0 6px;">${r(i(s.area))} ${r(i(s.pincode))} \xB7 Preference: ${r(C(s.helper_preference))}</p>
        <p style="margin:0 0 10px;">Why: ${r(O(s.reason))}</p>
        <p style="margin:0;">${f(s.assign_url,"Assign","primary")}</p>
      </div>
    `}).join(""),o=e.items.map((s,c)=>{const u=T(s.appointment_date),_=$(s.appointment_time),g=x(s.appointment_date,s.appointment_time);return[`${c+1}. ${s.ref} \xB7 ${s.parent_name} (${s.parent_age}) \xB7 ${u} ${_} (${g})`,`   ${i(s.area)} ${i(s.pincode)} \xB7 Preference: ${C(s.helper_preference)}`,`   Why: ${O(s.reason)}`,`   Assign: ${s.assign_url}`].join(`
`)}).join(`

`),m=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">These requests still need a helper. The soonest appointment is first.</p>
    ${a}
    <p style="margin:22px 0;">${f(e.open_all_url,"Open all in the portal","primary")}</p>
  `,d=[`Hi ${e.manager_first_name},`,"","These requests still need a helper. The soonest appointment is first.","",o,"",`Open all in the portal: ${e.open_all_url}`].join(`
`);return h("M2",t,null,m,d)}function he(e){const n=T(e.appointment_date),t=b(e.appointment_date),a=$(e.appointment_time),o=x(e.appointment_date,e.appointment_time),m=D(e.decline_reason),d=`${e.helper_full_name} declined \u2013 please assign another \xB7 ${e.parent_name}, ${n} ${a} \xB7 ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${r(e.helper_full_name)} declined the visit you offered.</p>
    ${l("Reason given",m)}
    <p style="margin:12px 0;">Appointment: ${r(t)} \xB7 ${r(a)} (${r(o)}) \xB7 ${r(i(e.area))}</p>
    <p style="margin:22px 0;">${f(e.assign_url,"Choose another helper","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} declined the visit you offered.`,p("Reason given",m),"",`Appointment: ${t} \xB7 ${a} (${o}) \xB7 ${i(e.area)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return h("M3",d,e.ref,s,c)}function fe(e){const n=b(e.appointment_date),t=$(e.appointment_time),a=x(e.appointment_date,e.appointment_time),o=`No response from ${e.helper_full_name} \u2013 please assign another \xB7 ${e.parent_name} \xB7 ${e.ref}`,m=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${r(e.helper_full_name)} didn't respond within ${r(e.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${r(n)} \xB7 ${r(t)} (${r(a)}) \xB7 ${r(i(e.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${r(i(e.helper_phone))}</p>
    <p style="margin:22px 0;">${f(e.assign_url,"Choose another helper","primary")}</p>
  `,d=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} didn't respond within ${e.expiry_window}, so the offer has been withdrawn.`,"",`Appointment: ${n} \xB7 ${t} (${a}) \xB7 ${i(e.area)}`,`Helper phone (if you'd like to call): ${i(e.helper_phone)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return h("M4",o,e.ref,m,d)}function $e(e){const n=b(e.appointment_date),t=$(e.appointment_time),a=x(e.appointment_date,e.appointment_time),o=D(e.dropout_reason),m=`URGENT \u2013 ${e.helper_full_name} can't attend \xB7 ${e.parent_name} \xB7 ${t} (${a}) \xB7 ${e.ref}`,d=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${r(e.helper_full_name)} has said they can't attend this visit.</p>
    ${l("Reason given",o)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${y("Visit details")}
    ${l("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${l("When",`${n} \xB7 ${t} (${a})`)}
    ${l("Pickup",A([e.area,e.city,e.pincode])||"\u2013")}
    ${l("Hospital",i(e.doctor_hospital))}
    ${l("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${f(e.assign_url,"Assign a replacement","primary")}</p>
  `,s=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has said they can't attend this visit.`,p("Reason given",o),"","The family has been told we're arranging a replacement. Please assign a new helper now.","","VISIT DETAILS",p("Patient",`${e.parent_name}, ${e.parent_age}`),p("When",`${n} \xB7 ${t} (${a})`),p("Pickup",A([e.area,e.city,e.pincode])||"\u2013"),p("Hospital",i(e.doctor_hospital)),p("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`),"",`Assign a replacement: ${e.assign_url}`].join(`
`);return h("M5",m,e.ref,d,s)}function K(e){const n=b(e.appointment_date),t=$(e.appointment_time),a=x(e.appointment_date,e.appointment_time),o=ee(e.assigned_at),m=e.urgent?`URGENT \u2013 visit in 1 hour, ${e.helper_full_name} still not confirmed \xB7 ${e.parent_name} \xB7 ${e.ref}`:`Action needed \u2013 ${e.helper_full_name} hasn't confirmed \xB7 ${e.parent_name} \xB7 ${t} (${a}) \xB7 ${e.ref}`,d=e.urgent?`The visit starts in about 1 hour and ${r(e.helper_full_name)} still hasn't confirmed. Please resolve this now.`:`${r(e.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,s=e.urgent?`The visit starts in about 1 hour and ${e.helper_full_name} still hasn't confirmed. Please resolve this now.`:`${e.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,c=e.urgent?`<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${r(e.helper_first_name)}: ${r(i(e.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".</li>
      </ol>`:`${y("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${r(e.helper_first_name)}: ${r(i(e.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone \u2013 nothing else happens, or</li>
            <li>Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`,u=e.urgent?[`1. Call ${e.helper_first_name}: ${i(e.helper_phone)}`,'2. Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".'].join(`
`):["WHAT TO DO NOW",`1. Call ${e.helper_first_name}: ${i(e.helper_phone)}`,"2. Then in the portal, choose:","   \u2022 Helper confirmed by phone \u2013 nothing else happens, or","   \u2022 Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper"].join(`
`),_=`
    ${y("Visit details")}
    ${l("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${l("When",`${n} \xB7 ${t} (${a})`)}
    ${l("Pickup",A([e.area,e.city,e.pincode])||"\u2013")}
    ${l("Hospital",i(e.doctor_hospital))}
    ${y("Helper status")}
    ${l("Assigned",o)}
    ${l("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`)}
    ${l("Confirmed","Not yet")}
  `,g=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${d}</p>
    ${c}
    ${_}
    <p style="margin:22px 0;">${f(e.open_url,"Open request","primary")}</p>
  `,S=[`Hi ${e.manager_first_name},`,"",s,"",u,"","VISIT DETAILS",p("Patient",`${e.parent_name}, ${e.parent_age}`),p("When",`${n} \xB7 ${t} (${a})`),p("Pickup",A([e.area,e.city,e.pincode])||"\u2013"),p("Hospital",i(e.doctor_hospital)),"","HELPER STATUS",p("Assigned",o),p("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`),p("Confirmed","Not yet"),"",`Open request: ${e.open_url}`].join(`
`);return h(e.urgent?"M7":"M6",m,e.ref,g,S)}function ye(e){return K({...e,urgent:!0})}function be(e){const n=`Driving licence ${e.expiry_phrase} \u2013 ${e.helper_full_name}`,t=e.expired?`<p style="margin:0 0 12px;">If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).</p>`:'<p style="margin:0 0 12px;">If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.</p>',a=e.expired?`If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).`:"If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.",o=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${r(e.helper_full_name)}'s driving licence ${r(e.expiry_phrase)} (${r(e.dl_expiry)}).</p>
    ${t}
    <p style="margin:22px 0;">${f(e.open_url,"Open helper profile","primary")}</p>
  `,m=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name}'s driving licence ${e.expiry_phrase} (${e.dl_expiry}).`,"",a,"",`Open helper profile: ${e.open_url}`].join(`
`);return h("M8",n,null,o,m)}function xe(e){const n=`Profile change request \u2013 ${e.helper_full_name}`,t=D(e.request_note),a=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${r(e.helper_full_name)} has asked to update their profile:</p>
    <p style="margin:0 0 12px;padding:12px 14px;background:#f3f6fb;border-radius:8px;font-style:italic;">"${r(t)}"</p>
    <p style="margin:0 0 12px;">Please review and update their details in the portal if appropriate.</p>
    <p style="margin:22px 0;">${f(e.open_url,"Open helper profile","primary")}</p>
  `,o=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has asked to update their profile:`,"",`"${t}"`,"","Please review and update their details in the portal if appropriate.","",`Open helper profile: ${e.open_url}`].join(`
`);return h("M9",n,null,a,o)}const Pe={accept_confirm:{title:"Accept this visit?",message:"{{appointment_date_short}} \xB7 {{appointment_time}} \xB7 {{area}}. Tap Confirm to take this visit.",button:"Confirm"},accepted:{title:"This visit is yours!",message:"We've emailed you the full details. Thank you, {{helper_first_name}}."},already_taken:{title:"Already taken",message:"Another helper accepted this visit first. Thank you for responding quickly."},helper_engaged:{title:"You're already booked",message:"You have another visit around this time, so we can't assign this one to you."},declined:{title:"Thanks for letting us know",message:"We've offered this visit to another helper."},confirmed:{title:"See you there!",message:"Thanks for confirming. The family is counting on you."},cant_make_it_confirm:{title:"Can't make this visit?",message:"Tell us why (optional), then tap Confirm. We'll arrange a replacement.",button:"Confirm"},cant_make_it_done:{title:"Thanks for telling us",message:"Our care team will arrange a replacement."},link_inactive:{title:"This link is no longer active",message:"The visit may have been assigned, cancelled or already passed. Please contact your manager if you need help."}};function we(e,n){return e.replace(/\{\{(\w+)\}\}/g,(t,a)=>i(n[a],""))}const E="https://nandhini-17223.github.io/elderly-care/admin",I="https://nandhini-17223.github.io/elderly-care/respond.html",Re="https://nandhini-17223.github.io/elderly-care/admin/helper.html",H="Manager";function w(e){const n=`needs-action.html?request=${encodeURIComponent(e)}`;return`${E}/login.html?next=${encodeURIComponent(n)}`}function ke(){return`${E}/login.html?next=${encodeURIComponent("needs-action.html")}`}function z(e){const n=`helper.html?id=${encodeURIComponent(e)}`;return`${E}/login.html?next=${encodeURIComponent(n)}`}function Ce(e,n="Assign helper"){return`<a href="${e}" style="background:#1d6fd8;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;">${r(n)}</a>`}function Ne(e){const n=U(e.appointmentDate)??e.appointmentDate,t=j(e.appointmentTime)??e.appointmentTime,a=[e.area,e.pincode].filter(Boolean).join(" \xB7 ")||"Area on file";return`
    <p>
      ${e.refNumber?`<strong>Ref:</strong> ${r(e.refNumber)}<br />`:""}
      <strong>Patient:</strong> ${r(e.parentName)} (age ${r(String(e.parentAge))})<br />
      <strong>Date:</strong> ${r(n)}<br />
      <strong>Time:</strong> ${r(t)}<br />
      <strong>Area:</strong> ${r(a)}<br />
      ${e.doctorHospital?`<strong>Doctor / Hospital:</strong> ${r(e.doctorHospital)}<br />`:""}
      ${e.helperPreference?`<strong>Helper preference:</strong> ${r(C(e.helperPreference))}<br />`:""}
      ${e.reason?`<strong>Reason:</strong> ${r(O(e.reason))}<br />`:""}
      ${e.address?`<strong>Address:</strong> ${r(e.address)}<br />`:""}
    </p>
  `}function Se(e){return e==null||Number.isNaN(Number(e))?"Nearby":`~${Math.round(Number(e)*10)/10} km`}function Ee(e){return e?"sent":"not sent"}function N(e,n=200){return new Response(JSON.stringify(e),{status:n,headers:{"Content-Type":"application/json",Connection:"keep-alive"}})}function Te(){const e="2026-11-13",n="10:00:00",t="ABI-1042",a="00000000-0000-4000-8000-000000000001",o="00000000-0000-4000-8000-000000000002",m=`${I}?token=preview-token&action=accept`,d=`${I}?token=preview-token&action=decline`,s=`${I}?token=preview-token&action=cant_make_it`,c=`${I}?token=preview-token&action=confirm_attendance`,u="https://www.google.com/maps/search/?api=1&query=12%20Gandhi%20Street%20T%20Nagar%20Chennai",_="12 Gandhi Street, T. Nagar, Chennai, 600017";return[ae({ref:t,booking_person_name:"Priya Sharma",parent_name:"Ramesh Sharma",appointment_date:e,appointment_time:n,doctor_hospital:"Apollo Hospitals, Greams Road",area:"T. Nagar",city:"Chennai",pincode:"600017",helper_preference:"female"}),ie({ref:t,booking_person_name:"Priya Sharma",parent_name:"Ramesh Sharma",appointment_date:e,appointment_time:n}),oe({ref:t,booking_person_name:"Priya Sharma",parent_name:"Ramesh Sharma",helper_full_name:"Anitha Kumar",helper_phone:"+91 98765 43210",helper_photo_url:null,appointment_date:e,appointment_time:n,doctor_hospital:"Apollo Hospitals, Greams Road",address_line1:"12 Gandhi Street",street:"Near Pondy Bazaar",area:"T. Nagar",city:"Chennai",pincode:"600017"}),se({ref:t,booking_person_name:"Priya Sharma",parent_name:"Ramesh Sharma",old_helper_first_name:"Anitha",appointment_date:e,appointment_time:n}),pe({ref:t,booking_person_name:"Priya Sharma",parent_name:"Ramesh Sharma",helper_full_name:"Kavitha Rajan",helper_phone:"+91 91234 56789",helper_photo_url:null,old_helper_first_name:"Anitha",appointment_date:e,appointment_time:n,doctor_hospital:"Apollo Hospitals, Greams Road"}),le({ref:t,helper_first_name:"Anitha",appointment_date:e,appointment_time:n,area:"T. Nagar",pincode:"600017",distance_km:3.4,doctor_hospital:"Apollo Hospitals, Greams Road",parent_age:72,accept_url:m,decline_url:d}),me({ref:t,helper_first_name:"Anitha",parent_name:"Ramesh Sharma",parent_age:72,address_line1:"12 Gandhi Street",street:"Near Pondy Bazaar",area:"T. Nagar",city:"Chennai",pincode:"600017",landmark:"Opposite ICICI Bank",maps_url:u,appointment_date:e,appointment_time:n,doctor_hospital:"Apollo Hospitals, Greams Road",booking_person_name:"Priya Sharma",relationship:"Daughter",guardian_phone:"+91 99887 76655",cant_make_it_url:s}),de({ref:t,helper_first_name:"Anitha",parent_name:"Ramesh Sharma",area:"T. Nagar",appointment_date:e,appointment_time:n,full_address:_,maps_url:u,doctor_hospital:"Apollo Hospitals, Greams Road",booking_person_name:"Priya Sharma",relationship:"Daughter",guardian_phone:"+91 99887 76655",cant_make_it_url:s}),ce({ref:t,helper_first_name:"Anitha",parent_name:"Ramesh Sharma",area:"T. Nagar",appointment_date:e,appointment_time:n,full_address:_,maps_url:u,doctor_hospital:"Apollo Hospitals, Greams Road",booking_person_name:"Priya Sharma",relationship:"Daughter",guardian_phone:"+91 99887 76655",cant_make_it_url:s,confirm_url:c}),ue({helper_first_name:"Anitha",helper_email:"anitha.helper@example.com",helper_app_link:W}),_e({ref:t,manager_first_name:H,parent_name:"Ramesh Sharma",parent_age:72,appointment_date:e,appointment_time:n,area:"T. Nagar",city:"Chennai",pincode:"600017",doctor_hospital:"Apollo Hospitals, Greams Road",helper_preference:"female",booking_person_name:"Priya Sharma",relationship:"Daughter",guardian_phone:"+91 99887 76655",time_remaining:"2 hours",assign_url:w(a)}),ge({manager_first_name:H,digest_time:"1:00 PM",open_all_url:ke(),items:[{ref:"ABI-1042",parent_name:"Ramesh Sharma",parent_age:72,appointment_date:e,appointment_time:n,area:"T. Nagar",pincode:"600017",helper_preference:"female",reason:"no_acceptance",assign_url:w(a)},{ref:"ABI-1043",parent_name:"Lakshmi Iyer",parent_age:68,appointment_date:"2026-11-14",appointment_time:"15:30:00",area:"Adyar",pincode:"600020",helper_preference:"no_preference",reason:"all_declined",assign_url:w(a)}]}),he({ref:t,manager_first_name:H,helper_full_name:"Anitha Kumar",parent_name:"Ramesh Sharma",appointment_date:e,appointment_time:n,area:"T. Nagar",decline_reason:null,assign_url:w(a)}),fe({ref:t,manager_first_name:H,helper_full_name:"Anitha Kumar",helper_phone:"+91 98765 43210",parent_name:"Ramesh Sharma",appointment_date:e,appointment_time:n,area:"T. Nagar",expiry_window:"1 hour",assign_url:w(a)}),$e({ref:t,manager_first_name:H,helper_full_name:"Anitha Kumar",parent_name:"Ramesh Sharma",parent_age:72,appointment_date:e,appointment_time:n,area:"T. Nagar",city:"Chennai",pincode:"600017",doctor_hospital:"Apollo Hospitals, Greams Road",booking_person_name:"Priya Sharma",relationship:"Daughter",guardian_phone:"+91 99887 76655",dropout_reason:"Feeling unwell",assign_url:w(a)}),K({ref:t,manager_first_name:H,helper_full_name:"Anitha Kumar",helper_first_name:"Anitha",helper_phone:"+91 98765 43210",parent_name:"Ramesh Sharma",parent_age:72,appointment_date:e,appointment_time:n,area:"T. Nagar",city:"Chennai",pincode:"600017",doctor_hospital:"Apollo Hospitals, Greams Road",assigned_at:"2026-11-12T04:30:00.000Z",r12_status:"sent",r6_status:"sent",open_url:w(a)}),ye({ref:t,manager_first_name:H,helper_full_name:"Anitha Kumar",helper_first_name:"Anitha",helper_phone:"+91 98765 43210",parent_name:"Ramesh Sharma",parent_age:72,appointment_date:e,appointment_time:n,area:"T. Nagar",city:"Chennai",pincode:"600017",doctor_hospital:"Apollo Hospitals, Greams Road",assigned_at:"2026-11-12T04:30:00.000Z",r12_status:"sent",r6_status:"sent",open_url:w(a)}),be({manager_first_name:H,helper_full_name:"Anitha Kumar",expiry_phrase:"expires in 30 days",dl_expiry:"2026-12-12",upcoming_count:2,open_url:z(o),expired:!1}),xe({manager_first_name:H,helper_full_name:"Anitha Kumar",request_note:"Please update my phone number and home pincode.",open_url:z(o)})]}Deno.serve(async e=>{if(e.method==="OPTIONS")return new Response(null,{status:204});if(e.method!=="POST")return N({error:"Method not allowed"},405);try{const n=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")||"",t=Deno.env.get("SUPABASE_ANON_KEY")||"",o=(e.headers.get("Authorization")||"").replace(/^Bearer\s+/i,"").trim(),m=Deno.env.get("EMAIL_TEST_MODE")==="true";if(!!!(n&&o===n||m&&t&&o===t))return N({error:"Unauthorized"},401);const s=await e.json().catch(()=>({}));if(s.confirm!=="send-all-previews")return N({error:'Pass {"confirm":"send-all-previews"} to send the batch',hint:"Subjects are prefixed [PREVIEW G1], [PREVIEW H1], etc. Test mode still redirects to TEST_EMAIL_TO."},400);const c=Deno.env.get("TEST_EMAIL_TO")?.trim();if(!c)return N({error:"TEST_EMAIL_TO is not set"},500);const u=Te().filter(g=>!s.only?.length||s.only.includes(g.id)),_=[];for(const g of u){const S=`[PREVIEW ${g.id}] ${g.subject}`,P=await re({to:c,toName:"Preview inbox",subject:S,html:g.html,text:g.text});_.push({id:g.id,ok:P.ok,email_id:P.id,subject:P.subject,to:P.to,testMode:P.testMode,error:P.error}),await new Promise(J=>setTimeout(J,400))}return N({ok:_.every(g=>g.ok),count:_.length,portal_base:E,results:_})}catch(n){console.error(n);const t=n instanceof Error?n.message:"Unknown error";return N({error:t},500)}});
