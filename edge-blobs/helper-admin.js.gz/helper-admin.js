// ../../../tmp/fn-src/supabase/functions/helper-admin/index.ts
import { createClient as createClient2 } from "jsr:@supabase/supabase-js@2";

// ../../../tmp/fn-src/supabase/functions/_shared/email.ts
var SUPPORT_PHONE = "+91 73399 11220";
var HELPER_APP_LINK = "https://nandhini-17223.github.io/elderly-care/helper/";
var LOGO_URL = "https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg";
var BRAND_PRIMARY = "#1d6fd8";
var BRAND_ACCENT = "#4a9cf7";
var BRAND_TEXT = "#1f2937";
var BRAND_MUTED = "#6b7280";
var MONTHS_SHORT = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
];
var WEEKDAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
function escapeHtml(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}
function displayValue(value, fallback = "\u2013") {
  if (value === null || value === void 0) return fallback;
  const text = String(value).trim();
  if (!text || text.toLowerCase() === "null" || text.toLowerCase() === "undefined") {
    return fallback;
  }
  return text;
}
function displayOrNone(value) {
  return displayValue(value, "None given");
}
function parseDateParts(appointmentDate) {
  if (!appointmentDate) return null;
  const dateMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(appointmentDate.trim());
  if (!dateMatch) return null;
  const year = Number(dateMatch[1]);
  const month = Number(dateMatch[2]);
  const day = Number(dateMatch[3]);
  if (!month || month < 1 || month > 12 || !day || day < 1 || day > 31) {
    return null;
  }
  return { year, month, day };
}
function parseTimeParts(appointmentTime) {
  if (!appointmentTime) return null;
  const timeMatch = /^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(
    appointmentTime.trim()
  );
  if (!timeMatch) return null;
  const hour24 = Number(timeMatch[1]);
  const minute = Number(timeMatch[2]);
  if (!Number.isInteger(hour24) || !Number.isInteger(minute) || hour24 < 0 || hour24 > 23 || minute < 0 || minute > 59) {
    return null;
  }
  return { hour24, minute };
}
function appointmentMsIst(appointmentDate, appointmentTime) {
  const d = parseDateParts(appointmentDate);
  const t = parseTimeParts(appointmentTime) ?? { hour24: 0, minute: 0 };
  if (!d) return NaN;
  return Date.parse(
    `${String(d.year).padStart(4, "0")}-${String(d.month).padStart(2, "0")}-${String(d.day).padStart(2, "0")}T${String(t.hour24).padStart(2, "0")}:${String(t.minute).padStart(2, "0")}:00+05:30`
  );
}
function formatAppointmentDateShort(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  return `${d.day} ${MONTHS_SHORT[d.month - 1]}`;
}
function formatAppointmentDateLong(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  const weekday = new Date(Date.UTC(d.year, d.month - 1, d.day)).getUTCDay();
  return `${WEEKDAYS_SHORT[weekday]}, ${d.day} ${MONTHS_SHORT[d.month - 1]} ${d.year}`;
}
function formatAppointmentTime(appointmentTime) {
  const t = parseTimeParts(appointmentTime);
  if (!t) return null;
  const hour12 = t.hour24 % 12 || 12;
  const ampm = t.hour24 < 12 ? "AM" : "PM";
  return `${hour12}:${String(t.minute).padStart(2, "0")} ${ampm}`;
}
function istYmd(ms) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date(ms));
}
function formatRelativeTime(appointmentDate, appointmentTime, nowMs = Date.now()) {
  const appt = appointmentMsIst(appointmentDate, appointmentTime);
  if (!Number.isFinite(appt)) return "\u2013";
  const today = istYmd(nowMs);
  const apptDay = istYmd(appt);
  const todayParts = parseDateParts(today);
  const apptParts = parseDateParts(apptDay);
  const dayDiff = Math.round(
    (Date.UTC(apptParts.year, apptParts.month - 1, apptParts.day) - Date.UTC(todayParts.year, todayParts.month - 1, todayParts.day)) / 864e5
  );
  if (dayDiff === 0) {
    const deltaMs = appt - nowMs;
    if (deltaMs <= 0) return "today";
    const totalMinutes = Math.round(deltaMs / 6e4);
    if (totalMinutes < 60) {
      return `today \xB7 in ${totalMinutes} minute${totalMinutes === 1 ? "" : "s"}`;
    }
    const hours = Math.round(totalMinutes / 60);
    return `today \xB7 in ${hours} hour${hours === 1 ? "" : "s"}`;
  }
  if (dayDiff === 1) return "tomorrow";
  if (dayDiff > 1) return `in ${dayDiff} days`;
  if (dayDiff === -1) return "yesterday";
  return `${Math.abs(dayDiff)} days ago`;
}
function emailButtonHtml(href, label, variant = "primary") {
  const bg = variant === "primary" ? BRAND_PRIMARY : "#e5e7eb";
  const color = variant === "primary" ? "#ffffff" : "#111827";
  return `<a href="${escapeHtml(href)}" style="background:${bg};color:${color};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${escapeHtml(label)}</a>`;
}
function emailFooterText() {
  return `This is an automated message from ABI Parent Care. For help, call ${SUPPORT_PHONE}.`;
}
function wrapEmailHtml(args) {
  const ref = displayValue(args.ref, "");
  const refHtml = ref ? `<td align="right" style="font-size:13px;color:${BRAND_MUTED};white-space:nowrap;">Ref <strong style="color:${BRAND_TEXT};">${escapeHtml(ref)}</strong></td>` : `<td></td>`;
  const preheader = args.preheader ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${escapeHtml(args.preheader)}</div>` : "";
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${preheader}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${BRAND_PRIMARY},${BRAND_ACCENT});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${LOGO_URL}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${ref ? `<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${escapeHtml(ref)}</strong></td>` : ""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${BRAND_TEXT};">
          ${args.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${BRAND_MUTED};">
          ${escapeHtml(emailFooterText())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`;
}
function wrapEmailText(args) {
  const lines = [
    "ABI Parent Care",
    args.ref ? `Ref ${displayValue(args.ref)}` : null,
    "",
    args.bodyText.trim(),
    "",
    emailFooterText()
  ].filter((line2) => line2 !== null);
  return lines.join("\n");
}
async function sendEmail(args) {
  const resendApiKey = Deno.env.get("RESEND_API_KEY");
  if (!resendApiKey) {
    throw new Error("Missing RESEND_API_KEY secret");
  }
  const testMode = Deno.env.get("EMAIL_TEST_MODE") === "true";
  const testTo = Deno.env.get("TEST_EMAIL_TO")?.trim() || "";
  const realRecipientLabel = (args.toName?.trim() || args.to).trim();
  const finalTo = testMode && testTo ? testTo : args.to;
  const finalSubject = testMode && testTo ? `[To: ${realRecipientLabel}] ${args.subject}` : args.subject;
  const payload = {
    from: "ABI Parent Care <onboarding@resend.dev>",
    to: [finalTo],
    subject: finalSubject,
    html: args.html
  };
  if (args.text && args.text.trim()) {
    payload.text = args.text;
  }
  const emailResponse = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${resendApiKey}`
    },
    body: JSON.stringify(payload)
  });
  const emailResult = await emailResponse.json();
  if (!emailResponse.ok) {
    console.error("Resend error:", emailResult);
    return {
      ok: false,
      status: emailResponse.status,
      to: finalTo,
      subject: finalSubject,
      testMode,
      error: emailResult
    };
  }
  return {
    ok: true,
    status: emailResponse.status,
    id: typeof emailResult?.id === "string" ? emailResult.id : void 0,
    to: finalTo,
    subject: finalSubject,
    testMode
  };
}

// ../../../tmp/fn-src/supabase/functions/_shared/templates.ts
function firstName(fullName) {
  const trimmed = String(fullName ?? "").trim();
  if (!trimmed) return "there";
  return trimmed.split(/\s+/)[0] ?? trimmed;
}
function timeLabel(appointmentTime) {
  return formatAppointmentTime(appointmentTime) ?? displayValue(appointmentTime);
}
function sectionHeading(label) {
  return `<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${escapeHtml(label)}</p>`;
}
function line(label, value) {
  return `<div style="margin:0 0 6px;"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</div>`;
}
function textLine(label, value) {
  return `${label}: ${value}`;
}
function joinAddress(parts) {
  return parts.map((p) => String(p ?? "").trim()).filter(Boolean).join(", ");
}
function build(id, subject, ref, bodyHtml, bodyText) {
  return {
    id,
    subject,
    html: wrapEmailHtml({ bodyHtml, ref, preheader: subject }),
    text: wrapEmailText({ bodyText, ref })
  };
}
function templateG4(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const subject = `Change of helper for ${v.parent_name} \u2013 ${dateShort} \xB7 Ref ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${escapeHtml(v.old_helper_first_name)} is unable to attend ${escapeHtml(v.parent_name)}'s appointment on ${escapeHtml(dateLong)} at ${escapeHtml(time)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${escapeHtml(SUPPORT_PHONE)} and quote Ref ${escapeHtml(v.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `We're sorry \u2013 ${v.old_helper_first_name} is unable to attend ${v.parent_name}'s appointment on ${dateLong} at ${time}.`,
    "",
    "Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.",
    "",
    `The appointment itself is unchanged. If you have concerns, call ${SUPPORT_PHONE} and quote Ref ${v.ref}.`,
    "",
    "Warm regards,",
    "The ABI Parent Care team"
  ].join("\n");
  return build("G4", subject, v.ref, bodyHtml, bodyText);
}
function templateH5(v) {
  const link = v.helper_app_link || HELPER_APP_LINK;
  const subject = "Welcome to ABI Parent Care \u2013 your helper app login";
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${line("App link", link)}
    ${line("Login email", v.helper_email)}
    ${line("Password", "the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${emailButtonHtml(link, "Open helper app", "primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${escapeHtml(SUPPORT_PHONE)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    "Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.",
    "",
    textLine("App link", link),
    textLine("Login email", v.helper_email),
    textLine("Password", "the temporary password given to you by your manager"),
    "",
    "You'll be asked to set your own password the first time you log in.",
    "",
    'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',
    "",
    `Questions? Call ${SUPPORT_PHONE}.`,
    "",
    "The ABI Parent Care team"
  ].join("\n");
  return build("H5", subject, null, bodyHtml, bodyText);
}
function templateM5(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const reason = displayOrNone(v.dropout_reason);
  const subject = `URGENT \u2013 ${v.helper_full_name} can't attend \xB7 ${v.parent_name} \xB7 ${time} (${relative}) \xB7 ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} has said they can't attend this visit.</p>
    ${line("Reason given", reason)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${sectionHeading("Visit details")}
    ${line("Patient", `${v.parent_name}, ${v.parent_age}`)}
    ${line("When", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013")}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`)}
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Assign a replacement", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name} has said they can't attend this visit.`,
    textLine("Reason given", reason),
    "",
    "The family has been told we're arranging a replacement. Please assign a new helper now.",
    "",
    "VISIT DETAILS",
    textLine("Patient", `${v.parent_name}, ${v.parent_age}`),
    textLine("When", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013"),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`
    ),
    "",
    `Assign a replacement: ${v.assign_url}`
  ].join("\n");
  return build("M5", subject, v.ref, bodyHtml, bodyText);
}

// ../../../tmp/fn-src/supabase/functions/_shared/senior.ts
var ADMIN_PAGE_BASE = "https://nandhini-17223.github.io/elderly-care/admin";
var MANAGER_FIRST_NAME = "Manager";
function seniorAssignUrl(requestId) {
  const next = `needs-action.html?request=${encodeURIComponent(requestId)}`;
  return `${ADMIN_PAGE_BASE}/login.html?next=${encodeURIComponent(next)}`;
}

// ../../../tmp/fn-src/supabase/functions/_shared/assignment.ts
function guardianReplacementArrangingEmail(request, helperFullName) {
  return templateG4({
    ref: String(request.ref_number ?? "\u2013"),
    booking_person_name: request.booking_person_name,
    parent_name: request.parent_name,
    old_helper_first_name: firstName(helperFullName),
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time
  });
}

// ../../../tmp/fn-src/supabase/functions/_shared/secrets.ts
async function resolveSecret(supabase, name) {
  const fromEnv = Deno.env.get(name)?.trim() || "";
  if (fromEnv) return fromEnv;
  const { data, error } = await supabase.rpc("get_app_secret", {
    p_name: name
  });
  if (error) {
    console.error(`get_app_secret(${name}) failed`, error);
    return null;
  }
  const value = typeof data === "string" ? data.trim() : "";
  return value || null;
}

// ../../../tmp/fn-src/supabase/functions/_shared/staff-auth.ts
import { createClient } from "jsr:@supabase/supabase-js@2";
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};
function authError(message, status) {
  return new Response(JSON.stringify({ ok: false, error: message }), {
    status,
    headers: corsHeaders
  });
}
function bearerToken(req) {
  const header = req.headers.get("Authorization") || "";
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : null;
}
async function requireStaff(req, serviceClient, options) {
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  if (!supabaseUrl || !anonKey) {
    return { error: authError("Server misconfigured", 500) };
  }
  const token = bearerToken(req);
  if (!token || token === anonKey) {
    return { error: authError("Unauthorized", 401) };
  }
  const userClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false }
  });
  const { data: userData, error: userError } = await userClient.auth.getUser();
  if (userError || !userData.user) {
    return { error: authError("Unauthorized", 401) };
  }
  const { data: profile, error: profileError } = await serviceClient.from("profiles").select("user_id, full_name, role, helper_id, is_active").eq("user_id", userData.user.id).maybeSingle();
  if (profileError || !profile || !profile.is_active) {
    return { error: authError("Unauthorized", 401) };
  }
  if (profile.role !== "super_admin" && profile.role !== "manager") {
    return { error: authError("Forbidden", 403) };
  }
  if (options?.superAdminOnly && profile.role !== "super_admin") {
    return { error: authError("Forbidden", 403) };
  }
  return {
    user: userData.user,
    profile,
    accessToken: token
  };
}
async function writeAudit(serviceClient, staff, action, entity, entityId, details) {
  const { error } = await serviceClient.rpc("write_audit_log", {
    p_actor_user_id: staff.user.id,
    p_actor_role: staff.profile.role,
    p_action: action,
    p_entity: entity,
    p_entity_id: entityId ?? null,
    p_details: details ?? {}
  });
  if (error) {
    console.error("write_audit_log failed", error);
  }
}

// ../../../tmp/fn-src/supabase/functions/helper-admin/index.ts
var corsHeaders2 = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
var HELPER_SELECT = [
  "id",
  "full_name",
  "gender",
  "email",
  "phone",
  "city",
  "languages",
  "is_active",
  "notes",
  "home_area",
  "home_pincode",
  "max_travel_km",
  "latitude",
  "longitude",
  "location_missing",
  "can_drive",
  "verification_status",
  "aadhaar_qr_verified",
  "aadhaar_last4",
  "aadhaar_verified_at",
  "aadhaar_verified_by",
  "second_id_type",
  "second_id_last4",
  "dl_last4",
  "dl_expiry",
  "bg_check_method",
  "bg_check_reference",
  "bg_check_notes",
  "bg_check_date",
  "photo_path",
  "photo_status",
  "references_checked",
  "references_notes",
  "verified_at",
  "verified_by",
  "rejection_reason",
  "dl_warn_30_sent_at",
  "dl_warn_7_sent_at",
  "dl_expired_notified_at",
  "created_at",
  "updated_at"
].join(", ");
var SECOND_ID_TYPES = /* @__PURE__ */ new Set([
  "pan",
  "voter_id",
  "passport",
  "driving_licence"
]);
var BG_METHODS = /* @__PURE__ */ new Set([
  "police_certificate",
  "vendor",
  "in_house"
]);
var PHOTO_CONTENT_TYPES = /* @__PURE__ */ new Set(["image/jpeg", "image/png"]);
var PNG_1X1 = new Uint8Array([
  137,
  80,
  78,
  71,
  13,
  10,
  26,
  10,
  0,
  0,
  0,
  13,
  73,
  72,
  68,
  82,
  0,
  0,
  0,
  1,
  0,
  0,
  0,
  1,
  8,
  6,
  0,
  0,
  0,
  31,
  21,
  196,
  137,
  0,
  0,
  0,
  10,
  73,
  68,
  65,
  84,
  120,
  156,
  99,
  0,
  1,
  0,
  0,
  5,
  0,
  1,
  13,
  10,
  45,
  180,
  0,
  0,
  0,
  0,
  73,
  69,
  78,
  68,
  174,
  66,
  96,
  130
]);
function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...corsHeaders2,
      "Content-Type": "application/json",
      Connection: "keep-alive"
    }
  });
}
function todayIst() {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(/* @__PURE__ */ new Date());
}
function isLast4(value) {
  return typeof value === "string" && /^\d{4}$/.test(value);
}
function looksLikeFullAadhaar(value) {
  if (typeof value !== "string") return false;
  const digits = value.replace(/\D/g, "");
  return digits.length === 12 || value.trim().length > 4;
}
function parseBool(value) {
  if (typeof value === "boolean") return value;
  if (value === "true" || value === "1") return true;
  if (value === "false" || value === "0") return false;
  return void 0;
}
function appointmentIsFuture(date, time) {
  const ms = Date.parse(
    `${date}T${String(time).slice(0, 8)}+05:30`
  );
  return Number.isFinite(ms) && ms >= Date.now();
}
function verificationProgress(helper) {
  const today = todayIst();
  const aadhaar = Boolean(helper.aadhaar_qr_verified) && isLast4(helper.aadhaar_last4);
  let secondId = Boolean(helper.second_id_type) && isLast4(helper.second_id_last4);
  if (helper.can_drive) {
    secondId = secondId && helper.second_id_type === "driving_licence" && typeof helper.dl_expiry === "string" && helper.dl_expiry > today;
  }
  const bgCheck = Boolean(helper.bg_check_method) && Boolean(helper.bg_check_date);
  const photo = helper.photo_status === "approved";
  const items = {
    aadhaar,
    second_id: secondId,
    bg_check: bgCheck,
    photo
  };
  const done = Object.values(items).filter(Boolean).length;
  return { done, total: 4, items };
}
async function loadHelper(admin, helperId) {
  const { data, error } = await admin.from("helpers").select(HELPER_SELECT).eq("id", helperId).maybeSingle();
  if (error) throw error;
  return data ?? null;
}
async function listUpcomingJobs(admin, helperId) {
  const { data, error } = await admin.rpc(
    "list_helper_upcoming_assigned_jobs",
    { p_helper_id: helperId }
  );
  if (error) throw error;
  return data ?? [];
}
async function upcomingJobCounts(admin, helperIds) {
  const counts = /* @__PURE__ */ new Map();
  for (const id of helperIds) counts.set(id, 0);
  if (!helperIds.length) return counts;
  const { data, error } = await admin.from("consultation_requests").select("id, assigned_helper_id, appointment_date, appointment_time, status").eq("status", "assigned").in("assigned_helper_id", helperIds);
  if (error) throw error;
  for (const row of data ?? []) {
    const helperId = row.assigned_helper_id;
    if (!helperId) continue;
    if (appointmentIsFuture(
      String(row.appointment_date),
      String(row.appointment_time)
    )) {
      counts.set(helperId, (counts.get(helperId) ?? 0) + 1);
    }
  }
  return counts;
}
async function notifyUnavailableEmails(supabase, requestId, helperId, reasonLabel) {
  const [{ data: request }, { data: helper }] = await Promise.all([
    supabase.from("consultation_requests").select(
      "id, ref_number, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason, booking_person_name, relationship, phone_country_code, phone, email, address_line1, street, landmark, city"
    ).eq("id", requestId).maybeSingle(),
    supabase.from("helpers").select("id, full_name, phone").eq("id", helperId).maybeSingle()
  ]);
  if (!request || !helper) return;
  const seniorEmail = await resolveSecret(supabase, "SENIOR_EMAIL");
  if (seniorEmail) {
    const email = templateM5({
      ref: String(request.ref_number ?? "\u2013"),
      manager_first_name: MANAGER_FIRST_NAME,
      helper_full_name: helper.full_name,
      parent_name: request.parent_name,
      parent_age: request.parent_age,
      appointment_date: request.appointment_date,
      appointment_time: request.appointment_time,
      area: request.area,
      city: request.city,
      pincode: request.pincode,
      doctor_hospital: request.doctor_hospital,
      booking_person_name: request.booking_person_name,
      relationship: String(request.relationship ?? ""),
      guardian_phone: `${request.phone_country_code ?? ""} ${request.phone ?? ""}`.trim(),
      dropout_reason: reasonLabel,
      assign_url: seniorAssignUrl(requestId)
    });
    await sendEmail({
      to: seniorEmail,
      toName: "Senior coordinator",
      subject: email.subject,
      html: email.html,
      text: email.text
    });
  }
  const guardianEmail = guardianReplacementArrangingEmail(
    {
      parent_name: request.parent_name,
      parent_age: request.parent_age,
      address_line1: request.address_line1,
      street: request.street,
      area: request.area,
      landmark: request.landmark,
      city: request.city,
      pincode: request.pincode,
      appointment_date: request.appointment_date,
      appointment_time: request.appointment_time,
      doctor_hospital: request.doctor_hospital,
      booking_person_name: request.booking_person_name,
      relationship: String(request.relationship ?? ""),
      phone_country_code: String(request.phone_country_code ?? ""),
      phone: String(request.phone ?? ""),
      ref_number: request.ref_number
    },
    helper.full_name
  );
  await sendEmail({
    to: request.email,
    toName: request.booking_person_name,
    subject: guardianEmail.subject,
    html: guardianEmail.html,
    text: guardianEmail.text
  });
}
async function releaseHelperJobs(admin, helperId, jobs, reasonLabel) {
  const released = [];
  for (const job of jobs) {
    const { data, error } = await admin.rpc("release_assigned_helper", {
      p_request_id: job.request_id,
      p_reason: "helper_unavailable",
      p_expected_helper_id: helperId
    });
    if (error) {
      console.error("release_assigned_helper", error);
      continue;
    }
    const result = data;
    if (result?.ok) {
      released.push({
        request_id: result.request_id ?? job.request_id,
        helper_id: result.helper_id ?? helperId
      });
      try {
        await notifyUnavailableEmails(
          admin,
          job.request_id,
          helperId,
          reasonLabel
        );
      } catch (emailError) {
        console.error("notifyUnavailableEmails", emailError);
      }
    }
  }
  await admin.rpc("withdraw_helper_open_offers", { p_helper_id: helperId });
  return released;
}
async function resolveCityFromPincode(admin, pincode) {
  const { data, error } = await admin.from("pincodes").select("district").eq("pincode", pincode).maybeSingle();
  if (error) {
    console.error("pincode lookup", error);
  }
  const district = data?.district ? String(data.district).trim() : "";
  return district || "Chennai";
}
function pickProfileFields(payload) {
  const fields = {};
  if (payload.full_name !== void 0) {
    const fullName = String(payload.full_name ?? "").trim();
    if (!fullName) return { fields, error: "full_name required" };
    fields.full_name = fullName;
  }
  if (payload.gender !== void 0) {
    const gender = String(payload.gender ?? "").trim().toLowerCase();
    if (gender !== "female" && gender !== "male") {
      return { fields, error: "gender must be female or male" };
    }
    fields.gender = gender;
  }
  if (payload.email !== void 0) {
    const email = String(payload.email ?? "").trim().toLowerCase();
    if (!email || !email.includes("@")) {
      return { fields, error: "valid email required" };
    }
    fields.email = email;
  }
  if (payload.phone !== void 0) {
    const phone = String(payload.phone ?? "").trim();
    if (!phone) return { fields, error: "phone required" };
    fields.phone = phone;
  }
  if (payload.home_area !== void 0) {
    fields.home_area = String(payload.home_area ?? "").trim() || null;
  }
  if (payload.home_pincode !== void 0) {
    const pin = String(payload.home_pincode ?? "").trim();
    if (!/^\d{6}$/.test(pin)) {
      return { fields, error: "home_pincode must be 6 digits" };
    }
    fields.home_pincode = pin;
  }
  if (payload.max_travel_km !== void 0) {
    const km = Number(payload.max_travel_km);
    if (!Number.isFinite(km) || km <= 0 || km > 200) {
      return { fields, error: "max_travel_km must be between 1 and 200" };
    }
    fields.max_travel_km = Math.round(km);
  }
  if (payload.languages !== void 0) {
    fields.languages = payload.languages == null ? null : String(payload.languages).trim() || null;
  }
  if (payload.can_drive !== void 0) {
    const canDrive = parseBool(payload.can_drive);
    if (canDrive === void 0) {
      return { fields, error: "can_drive must be boolean" };
    }
    fields.can_drive = canDrive;
  }
  if (payload.notes !== void 0) {
    fields.notes = payload.notes == null ? null : String(payload.notes).trim() || null;
  }
  return { fields };
}
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders2 });
  }
  if (req.method !== "POST") {
    return jsonResponse({ ok: false, error: "Method not allowed" }, 405);
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceRoleKey) {
      throw new Error("Missing Supabase environment configuration");
    }
    const admin = createClient2(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false }
    });
    const staffOrError = await requireStaff(req, admin);
    if ("error" in staffOrError) return staffOrError.error;
    const staff = staffOrError;
    const payload = await req.json().catch(() => ({}));
    const action = String(payload.action ?? "").trim().toLowerCase();
    if (action === "list") {
      let query = admin.from("helpers").select(HELPER_SELECT).order(
        "full_name",
        { ascending: true }
      );
      const search = String(payload.search ?? "").trim().replace(/[%_,]/g, " ");
      if (search) {
        const like = `%${search}%`;
        query = query.or(
          `full_name.ilike.${like},phone.ilike.${like},home_area.ilike.${like}`
        );
      }
      const verification = String(payload.verification_status ?? "").trim();
      if (verification) {
        query = query.eq("verification_status", verification);
      }
      const active = parseBool(payload.is_active);
      if (active !== void 0) {
        query = query.eq("is_active", active);
      }
      const gender = String(payload.gender ?? "").trim().toLowerCase();
      if (gender === "female" || gender === "male") {
        query = query.eq("gender", gender);
      }
      const area = String(payload.area ?? "").trim();
      if (area) {
        query = query.ilike("home_area", `%${area}%`);
      }
      const { data, error } = await query;
      if (error) throw error;
      const helpers = data ?? [];
      const counts = await upcomingJobCounts(
        admin,
        helpers.map((h) => h.id)
      );
      return jsonResponse({
        ok: true,
        helpers: helpers.map((h) => ({
          ...h,
          upcoming_assigned_jobs: counts.get(h.id) ?? 0,
          verification_progress: verificationProgress(h)
        }))
      });
    }
    if (action === "get") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      const [jobs, { data: profile, error: profileError }] = await Promise.all([
        listUpcomingJobs(admin, helperId),
        admin.from("profiles").select("user_id, full_name, role, helper_id, is_active, created_at").eq("helper_id", helperId).maybeSingle()
      ]);
      if (profileError) throw profileError;
      return jsonResponse({
        ok: true,
        helper: {
          ...helper,
          verification_progress: verificationProgress(helper)
        },
        upcoming_jobs: jobs,
        login: profile ?? null,
        profile: profile ?? null
      });
    }
    if (action === "create") {
      const required = pickProfileFields({
        ...payload,
        full_name: payload.full_name,
        gender: payload.gender,
        email: payload.email,
        phone: payload.phone,
        home_area: payload.home_area,
        home_pincode: payload.home_pincode,
        max_travel_km: payload.max_travel_km ?? 10,
        languages: payload.languages,
        can_drive: payload.can_drive ?? false,
        notes: payload.notes
      });
      if (required.error) {
        return jsonResponse({ ok: false, error: required.error }, 400);
      }
      for (const key of [
        "full_name",
        "gender",
        "email",
        "phone",
        "home_pincode"
      ]) {
        if (required.fields[key] == null) {
          return jsonResponse({
            ok: false,
            error: `${key} required`
          }, 400);
        }
      }
      const pin = String(required.fields.home_pincode);
      const city = await resolveCityFromPincode(admin, pin);
      const insertRow = {
        ...required.fields,
        city,
        verification_status: "pending",
        photo_status: "none",
        aadhaar_qr_verified: false,
        is_active: true
      };
      const { data: created, error: createError } = await admin.from("helpers").insert(insertRow).select(HELPER_SELECT).single();
      if (createError) {
        return jsonResponse({
          ok: false,
          error: createError.message.includes("unique") ? "Email already in use" : createError.message
        }, 400);
      }
      await writeAudit(admin, staff, "create_helper", "helper", created.id, {
        email: created.email,
        full_name: created.full_name
      });
      return jsonResponse({
        ok: true,
        helper_id: created.id,
        message: "Helper created.",
        helper: {
          ...created,
          verification_progress: verificationProgress(created)
        }
      });
    }
    if (action === "update") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const existing = await loadHelper(admin, helperId);
      if (!existing) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      const picked = pickProfileFields(payload);
      if (picked.error) {
        return jsonResponse({ ok: false, error: picked.error }, 400);
      }
      if (!Object.keys(picked.fields).length) {
        return jsonResponse({ ok: false, error: "No fields to update" }, 400);
      }
      if (typeof picked.fields.home_pincode === "string") {
        picked.fields.city = await resolveCityFromPincode(
          admin,
          picked.fields.home_pincode
        );
      }
      const nextCanDrive = picked.fields.can_drive === void 0 ? existing.can_drive : Boolean(picked.fields.can_drive);
      if (nextCanDrive && existing.second_id_type && existing.second_id_type !== "driving_licence" && picked.fields.can_drive === true) {
        return jsonResponse({
          ok: false,
          error: "Drivers must use driving_licence as second ID. Update second ID first."
        }, 400);
      }
      const { data: updated, error: updateError } = await admin.from("helpers").update(picked.fields).eq("id", helperId).select(HELPER_SELECT).single();
      if (updateError) {
        return jsonResponse({
          ok: false,
          error: updateError.message.includes("unique") ? "Email already in use" : updateError.message
        }, 400);
      }
      await writeAudit(admin, staff, "update_helper", "helper", helperId, {
        fields: Object.keys(picked.fields)
      });
      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated)
        }
      });
    }
    if (action === "save_aadhaar") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      if (payload.aadhaar_qr_verified !== true) {
        return jsonResponse({
          ok: false,
          error: "aadhaar_qr_verified must be true"
        }, 400);
      }
      if (payload.aadhaar !== void 0 || looksLikeFullAadhaar(payload.aadhaar_last4) || typeof payload.aadhaar_last4 === "string" && payload.aadhaar_last4.length !== 4) {
        return jsonResponse({
          ok: false,
          error: "Only aadhaar_last4 (exactly 4 digits) is accepted. Never send full Aadhaar."
        }, 400);
      }
      if (!isLast4(payload.aadhaar_last4)) {
        return jsonResponse({
          ok: false,
          error: "aadhaar_last4 must be exactly 4 digits"
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      const { data: updated, error } = await admin.from("helpers").update({
        aadhaar_qr_verified: true,
        aadhaar_last4: payload.aadhaar_last4,
        aadhaar_verified_at: (/* @__PURE__ */ new Date()).toISOString(),
        aadhaar_verified_by: staff.user.id
      }).eq("id", helperId).select(HELPER_SELECT).single();
      if (error) throw error;
      await writeAudit(admin, staff, "save_aadhaar", "helper", helperId, {
        aadhaar_last4: payload.aadhaar_last4
      });
      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated)
        }
      });
    }
    if (action === "save_second_id") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      const secondIdType = String(payload.second_id_type ?? "").trim();
      if (!SECOND_ID_TYPES.has(secondIdType)) {
        return jsonResponse({
          ok: false,
          error: "second_id_type must be pan|voter_id|passport|driving_licence"
        }, 400);
      }
      if (!isLast4(payload.second_id_last4)) {
        return jsonResponse({
          ok: false,
          error: "second_id_last4 must be exactly 4 digits"
        }, 400);
      }
      let dlLast4 = payload.dl_last4 !== void 0 ? String(payload.dl_last4) : void 0;
      let dlExpiry = payload.dl_expiry !== void 0 ? String(payload.dl_expiry).trim() : void 0;
      if (secondIdType === "driving_licence" && !dlLast4) {
        dlLast4 = payload.second_id_last4;
      }
      if (helper.can_drive) {
        if (secondIdType !== "driving_licence") {
          return jsonResponse({
            ok: false,
            error: "Drivers must use driving_licence as second ID"
          }, 400);
        }
        if (!dlExpiry || !/^\d{4}-\d{2}-\d{2}$/.test(dlExpiry)) {
          return jsonResponse({
            ok: false,
            error: "dl_expiry (YYYY-MM-DD) required for drivers"
          }, 400);
        }
        if (dlExpiry <= todayIst()) {
          return jsonResponse({
            ok: false,
            error: "dl_expiry must be a future date (Asia/Kolkata)"
          }, 400);
        }
      } else if (secondIdType === "driving_licence" || dlExpiry) {
        if (dlExpiry && !/^\d{4}-\d{2}-\d{2}$/.test(dlExpiry)) {
          return jsonResponse({
            ok: false,
            error: "dl_expiry must be YYYY-MM-DD"
          }, 400);
        }
        if (dlExpiry && helper.can_drive && dlExpiry <= todayIst()) {
          return jsonResponse({
            ok: false,
            error: "dl_expiry must be a future date"
          }, 400);
        }
      }
      if (dlLast4 !== void 0 && dlLast4 !== "" && !isLast4(dlLast4)) {
        return jsonResponse({
          ok: false,
          error: "dl_last4 must be exactly 4 digits"
        }, 400);
      }
      const patch = {
        second_id_type: secondIdType,
        second_id_last4: payload.second_id_last4
      };
      if (secondIdType === "driving_licence") {
        patch.dl_last4 = dlLast4 ?? payload.second_id_last4;
        if (dlExpiry) patch.dl_expiry = dlExpiry;
      } else if (!helper.can_drive) {
        patch.dl_last4 = null;
        patch.dl_expiry = null;
      }
      const { data: updated, error } = await admin.from("helpers").update(patch).eq("id", helperId).select(HELPER_SELECT).single();
      if (error) throw error;
      await writeAudit(admin, staff, "save_second_id", "helper", helperId, {
        second_id_type: secondIdType
      });
      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated)
        }
      });
    }
    if (action === "save_bg_check") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const method = String(payload.bg_check_method ?? "").trim();
      if (!BG_METHODS.has(method)) {
        return jsonResponse({
          ok: false,
          error: "bg_check_method must be police_certificate|vendor|in_house"
        }, 400);
      }
      const bgDate = String(payload.bg_check_date ?? "").trim();
      if (!/^\d{4}-\d{2}-\d{2}$/.test(bgDate)) {
        return jsonResponse({
          ok: false,
          error: "bg_check_date must be YYYY-MM-DD"
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      const { data: updated, error } = await admin.from("helpers").update({
        bg_check_method: method,
        bg_check_reference: payload.bg_check_reference == null ? null : String(payload.bg_check_reference).trim() || null,
        bg_check_notes: payload.bg_check_notes == null ? null : String(payload.bg_check_notes).trim() || null,
        bg_check_date: bgDate
      }).eq("id", helperId).select(HELPER_SELECT).single();
      if (error) throw error;
      await writeAudit(admin, staff, "save_bg_check", "helper", helperId, {
        bg_check_method: method,
        bg_check_date: bgDate
      });
      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated)
        }
      });
    }
    if (action === "save_references") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const checked = parseBool(payload.references_checked);
      if (checked === void 0) {
        return jsonResponse({
          ok: false,
          error: "references_checked boolean required"
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      const { data: updated, error } = await admin.from("helpers").update({
        references_checked: checked,
        references_notes: payload.references_notes == null ? null : String(payload.references_notes).trim() || null
      }).eq("id", helperId).select(HELPER_SELECT).single();
      if (error) throw error;
      await writeAudit(admin, staff, "save_references", "helper", helperId, {
        references_checked: checked
      });
      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated)
        }
      });
    }
    if (action === "photo_upload_url") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const contentType = String(payload.content_type ?? "").trim().toLowerCase();
      if (!PHOTO_CONTENT_TYPES.has(contentType)) {
        return jsonResponse({
          ok: false,
          error: "content_type must be image/jpeg or image/png"
        }, 400);
      }
      let ext = String(payload.file_ext ?? "").trim().toLowerCase().replace(/^\./, "");
      if (!ext) {
        ext = contentType === "image/png" ? "png" : "jpg";
      }
      if (ext !== "png" && ext !== "jpg" && ext !== "jpeg") {
        return jsonResponse({
          ok: false,
          error: "file_ext must be png, jpg, or jpeg"
        }, 400);
      }
      if (ext === "jpeg") ext = "jpg";
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      const path = `${helperId}/${Date.now()}.${ext}`;
      const { data, error } = await admin.storage.from("helper-photos").createSignedUploadUrl(path);
      if (error || !data) {
        return jsonResponse({
          ok: false,
          error: error?.message ?? "Could not create upload URL"
        }, 400);
      }
      await writeAudit(
        admin,
        staff,
        "request_photo_upload",
        "helper",
        helperId,
        { path, content_type: contentType }
      );
      return jsonResponse({
        ok: true,
        path: data.path ?? path,
        token: data.token,
        signedUrl: data.signedUrl
      });
    }
    if (action === "photo_confirm") {
      const helperId = String(payload.helper_id ?? "").trim();
      const path = String(payload.path ?? "").trim();
      if (!helperId || !path) {
        return jsonResponse({
          ok: false,
          error: "helper_id and path required"
        }, 400);
      }
      if (!path.startsWith(`${helperId}/`)) {
        return jsonResponse({
          ok: false,
          error: "path must start with helper_id/"
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      const { data: updated, error } = await admin.from("helpers").update({ photo_path: path, photo_status: "pending" }).eq("id", helperId).select(HELPER_SELECT).single();
      if (error) throw error;
      await writeAudit(admin, staff, "photo_confirm", "helper", helperId, {
        path
      });
      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated)
        }
      });
    }
    if (action === "photo_signed_url") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      if (!helper.photo_path) {
        return jsonResponse({
          ok: false,
          error: "No photo uploaded"
        }, 404);
      }
      const { data, error } = await admin.storage.from("helper-photos").createSignedUrl(helper.photo_path, 300);
      if (error || !data?.signedUrl) {
        return jsonResponse({
          ok: false,
          error: error?.message ?? "Could not create signed URL"
        }, 400);
      }
      return jsonResponse({
        ok: true,
        signedUrl: data.signedUrl,
        path: helper.photo_path,
        expires_in: 300
      });
    }
    if (action === "photo_review") {
      const helperId = String(payload.helper_id ?? "").trim();
      const decision = String(payload.decision ?? "").trim().toLowerCase();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      if (decision !== "approved" && decision !== "rejected") {
        return jsonResponse({
          ok: false,
          error: "decision must be approved or rejected"
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      if (!helper.photo_path) {
        return jsonResponse({
          ok: false,
          error: "No photo to review"
        }, 400);
      }
      const { data: updated, error } = await admin.from("helpers").update({ photo_status: decision }).eq("id", helperId).select(HELPER_SELECT).single();
      if (error) throw error;
      await writeAudit(admin, staff, "photo_review", "helper", helperId, {
        decision
      });
      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated)
        }
      });
    }
    if (action === "mark_verified") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      const progress = verificationProgress(helper);
      if (!progress.items.aadhaar) {
        return jsonResponse({
          ok: false,
          error: "Aadhaar QR verification and last4 required"
        }, 400);
      }
      if (!helper.second_id_type || !isLast4(helper.second_id_last4)) {
        return jsonResponse({
          ok: false,
          error: "Second ID type and last4 required"
        }, 400);
      }
      if (helper.can_drive) {
        if (helper.second_id_type !== "driving_licence") {
          return jsonResponse({
            ok: false,
            error: "Drivers require driving_licence as second ID"
          }, 400);
        }
        if (!helper.dl_expiry || helper.dl_expiry <= todayIst()) {
          return jsonResponse({
            ok: false,
            error: "Drivers require a future DL expiry date"
          }, 400);
        }
      }
      if (!helper.bg_check_method || !helper.bg_check_date) {
        return jsonResponse({
          ok: false,
          error: "Background check method and date required"
        }, 400);
      }
      if (helper.photo_status !== "approved") {
        return jsonResponse({
          ok: false,
          error: "Photo must be approved"
        }, 400);
      }
      const { data: updated, error } = await admin.from("helpers").update({
        verification_status: "verified",
        verified_at: (/* @__PURE__ */ new Date()).toISOString(),
        verified_by: staff.user.id,
        rejection_reason: null
      }).eq("id", helperId).select(HELPER_SELECT).single();
      if (error) throw error;
      await writeAudit(admin, staff, "mark_verified", "helper", helperId, {});
      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated)
        }
      });
    }
    if (action === "reject") {
      const helperId = String(payload.helper_id ?? "").trim();
      const reason = String(payload.rejection_reason ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      if (!reason) {
        return jsonResponse({
          ok: false,
          error: "rejection_reason required"
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      const jobs = await listUpcomingJobs(admin, helperId);
      if (jobs.length > 0 && payload.confirm !== true) {
        return jsonResponse({
          ok: false,
          code: "needs_confirmation",
          jobs,
          message: `${helper.full_name} has ${jobs.length} upcoming assigned job(s). Confirm to release and reject.`
        });
      }
      let released = [];
      if (jobs.length > 0) {
        released = await releaseHelperJobs(
          admin,
          helperId,
          jobs,
          "Helper verification rejected"
        );
      } else {
        await admin.rpc("withdraw_helper_open_offers", {
          p_helper_id: helperId
        });
      }
      const { data: updated, error } = await admin.from("helpers").update({
        verification_status: "rejected",
        rejection_reason: reason
      }).eq("id", helperId).select(HELPER_SELECT).single();
      if (error) throw error;
      await writeAudit(admin, staff, "reject_helper", "helper", helperId, {
        rejection_reason: reason,
        released_count: released.length
      });
      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated)
        },
        released
      });
    }
    if (action === "set_active") {
      const helperId = String(payload.helper_id ?? "").trim();
      const nextActive = parseBool(payload.is_active);
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      if (nextActive === void 0) {
        return jsonResponse({
          ok: false,
          error: "is_active boolean required"
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      let released = [];
      if (!nextActive) {
        const jobs = await listUpcomingJobs(admin, helperId);
        if (jobs.length > 0 && payload.confirm !== true) {
          return jsonResponse({
            ok: false,
            code: "needs_confirmation",
            jobs,
            message: `${helper.full_name} has ${jobs.length} upcoming assigned job(s). Confirm to release and deactivate.`
          });
        }
        if (jobs.length > 0) {
          released = await releaseHelperJobs(
            admin,
            helperId,
            jobs,
            "Helper deactivated"
          );
        } else {
          await admin.rpc("withdraw_helper_open_offers", {
            p_helper_id: helperId
          });
        }
      }
      const { data: updated, error } = await admin.from("helpers").update({ is_active: nextActive }).eq("id", helperId).select(HELPER_SELECT).single();
      if (error) throw error;
      await writeAudit(
        admin,
        staff,
        nextActive ? "activate_helper" : "deactivate_helper",
        "helper",
        helperId,
        { released_count: released.length }
      );
      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated)
        },
        released
      });
    }
    if (action === "create_login") {
      const helperId = String(payload.helper_id ?? "").trim();
      const password = String(payload.password ?? "");
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      if (password.length < 8) {
        return jsonResponse({
          ok: false,
          error: "password must be at least 8 characters"
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      if (helper.verification_status !== "verified") {
        return jsonResponse({
          ok: false,
          error: "Helper must be verified before creating a login"
        }, 400);
      }
      const { data: existingProfile, error: existingError } = await admin.from("profiles").select("user_id").eq("helper_id", helperId).maybeSingle();
      if (existingError) throw existingError;
      if (existingProfile) {
        return jsonResponse({
          ok: false,
          error: "Login profile already exists for this helper"
        }, 400);
      }
      const { data: created, error: createError } = await admin.auth.admin.createUser({
        email: helper.email,
        password,
        email_confirm: true,
        user_metadata: { full_name: helper.full_name, role: "helper" }
      });
      if (createError || !created.user) {
        return jsonResponse({
          ok: false,
          error: createError?.message ?? "Could not create auth user"
        }, 400);
      }
      const { error: profileError } = await admin.from("profiles").insert({
        user_id: created.user.id,
        full_name: helper.full_name,
        role: "helper",
        helper_id: helperId,
        is_active: true,
        created_by: staff.user.id
      });
      if (profileError) {
        await admin.auth.admin.deleteUser(created.user.id);
        return jsonResponse({
          ok: false,
          error: profileError.message
        }, 400);
      }
      await writeAudit(admin, staff, "create_helper_login", "helper", helperId, {
        user_id: created.user.id,
        email: helper.email
      });
      const loginEmail = templateH5({
        helper_first_name: firstName(helper.full_name),
        helper_email: helper.email,
        helper_app_link: HELPER_APP_LINK
      });
      let loginEmailResult = null;
      try {
        loginEmailResult = await sendEmail({
          to: helper.email,
          toName: helper.full_name,
          subject: loginEmail.subject,
          html: loginEmail.html,
          text: loginEmail.text
        });
      } catch (emailError) {
        console.error("H5 login email failed", emailError);
      }
      return jsonResponse({
        ok: true,
        user_id: created.user.id,
        email: helper.email,
        message: `Login created for ${helper.email}.`,
        login_email: loginEmailResult ? { ok: loginEmailResult.ok, id: loginEmailResult.id, subject: loginEmailResult.subject } : null
      });
    }
    if (action === "set_login_active") {
      const helperId = String(payload.helper_id ?? "").trim();
      const nextActive = parseBool(payload.is_active);
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      if (nextActive === void 0) {
        return jsonResponse({
          ok: false,
          error: "is_active boolean required"
        }, 400);
      }
      const { data: profile, error: loadError } = await admin.from("profiles").select("user_id, full_name, role, helper_id, is_active").eq("helper_id", helperId).maybeSingle();
      if (loadError) throw loadError;
      if (!profile) {
        return jsonResponse({
          ok: false,
          error: "No login profile for this helper"
        }, 404);
      }
      const { error: updateError } = await admin.from("profiles").update({ is_active: nextActive }).eq("helper_id", helperId);
      if (updateError) throw updateError;
      if (!nextActive) {
        try {
          await admin.auth.admin.signOut(profile.user_id, "global");
        } catch (signOutError) {
          console.error("signOut after set_login_active", signOutError);
        }
      }
      await writeAudit(
        admin,
        staff,
        nextActive ? "activate_helper_login" : "deactivate_helper_login",
        "helper",
        helperId,
        { user_id: profile.user_id }
      );
      return jsonResponse({
        ok: true,
        profile: { ...profile, is_active: nextActive }
      });
    }
    if (action === "seed_placeholder_photos") {
      const { data: helpers, error } = await admin.from("helpers").select("id, photo_path, notes").not("photo_path", "is", null);
      if (error) throw error;
      const results = [];
      for (const helper of helpers ?? []) {
        const path = String(helper.photo_path ?? "");
        if (!path) continue;
        const { data: existing, error: downloadError } = await admin.storage.from("helper-photos").download(path);
        if (!downloadError && existing) {
          results.push({ helper_id: helper.id, path, status: "exists" });
          continue;
        }
        const { error: uploadError } = await admin.storage.from("helper-photos").upload(path, PNG_1X1, {
          contentType: "image/png",
          upsert: true
        });
        if (uploadError) {
          results.push({
            helper_id: helper.id,
            path,
            status: "error",
            error: uploadError.message
          });
        } else {
          results.push({ helper_id: helper.id, path, status: "uploaded" });
        }
      }
      await writeAudit(
        admin,
        staff,
        "seed_placeholder_photos",
        "helper",
        null,
        { count: results.length }
      );
      return jsonResponse({ ok: true, results });
    }
    return jsonResponse({ ok: false, error: "Unknown action" }, 400);
  } catch (error) {
    console.error(error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return jsonResponse({ ok: false, error: message }, 500);
  }
});
export {
  verificationProgress
};
