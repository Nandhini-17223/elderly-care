const U=globalThis.__sb.createClient,A="+91 73399 11220",ie="https://nandhini-17223.github.io/elderly-care/helper/",oe="https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg",G="#1d6fd8",se="#4a9cf7",F="#1f2937",Y="#6b7280",M=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],le=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function i(e){return e.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;")}function l(e,n="\u2013"){if(e==null)return n;const t=String(e).trim();return!t||t.toLowerCase()==="null"||t.toLowerCase()==="undefined"?n:t}function O(e){return l(e,"None given")}function C(e){if(!e)return null;const n=/^(\d{4})-(\d{2})-(\d{2})$/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]),a=Number(n[3]);return!r||r<1||r>12||!a||a<1||a>31?null:{year:t,month:r,day:a}}function z(e){if(!e)return null;const n=/^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]);return!Number.isInteger(t)||!Number.isInteger(r)||t<0||t>23||r<0||r>59?null:{hour24:t,minute:r}}function pe(e,n){const t=C(e),r=z(n)??{hour24:0,minute:0};return t?Date.parse(`${String(t.year).padStart(4,"0")}-${String(t.month).padStart(2,"0")}-${String(t.day).padStart(2,"0")}T${String(r.hour24).padStart(2,"0")}:${String(r.minute).padStart(2,"0")}:00+05:30`):NaN}function K(e){const n=C(e);return n?`${n.day} ${M[n.month-1]} ${n.year}`:null}function T(e){const n=C(e);return n?`${n.day} ${M[n.month-1]}`:l(e)}function x(e){const n=C(e);if(!n)return l(e);const t=new Date(Date.UTC(n.year,n.month-1,n.day)).getUTCDay();return`${le[t]}, ${n.day} ${M[n.month-1]} ${n.year}`}function j(e){const n=z(e);if(!n)return null;const t=n.hour24%12||12,r=n.hour24<12?"AM":"PM";return`${t}:${String(n.minute).padStart(2,"0")} ${r}`}function Ne(e,n){const t=K(e),r=j(n);return!t||!r?null:`${t}, ${r}`}function J(e){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(e))}function w(e,n,t=Date.now()){const r=pe(e,n);if(!Number.isFinite(r))return"\u2013";const a=J(t),p=J(r),s=C(a),o=C(p),c=Math.round((Date.UTC(o.year,o.month-1,o.day)-Date.UTC(s.year,s.month-1,s.day))/864e5);if(c===0){const d=r-t;if(d<=0)return"today";const _=Math.round(d/6e4);if(_<60)return`today \xB7 in ${_} minute${_===1?"":"s"}`;const g=Math.round(_/60);return`today \xB7 in ${g} hour${g===1?"":"s"}`}return c===1?"tomorrow":c>1?`in ${c} days`:c===-1?"yesterday":`${Math.abs(c)} days ago`}function me(e){if(!e)return"\u2013";const n=Date.parse(e);if(!Number.isFinite(n))return l(e);const t=new Date(n),r=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Kolkata",weekday:"short",day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit",hour12:!0}).formatToParts(t),a=k=>r.find(E=>E.type===k)?.value??"",p=a("day"),s=a("month"),o=a("year"),c=a("weekday"),d=a("hour"),_=a("minute"),g=a("dayPeriod").toUpperCase();return`${c}, ${p} ${s} ${o} \xB7 ${d}:${_} ${g}`}function $(e,n,t="primary"){const r=t==="primary"?G:"#e5e7eb",a=t==="primary"?"#ffffff":"#111827";return`<a href="${i(e)}" style="background:${r};color:${a};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${i(n)}</a>`}function Q(){return`This is an automated message from ABI Parent Care. For help, call ${A}.`}function ue(e){const n=l(e.ref,""),t=n?`<td align="right" style="font-size:13px;color:${Y};white-space:nowrap;">Ref <strong style="color:${F};">${i(n)}</strong></td>`:"<td></td>";return`<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${e.preheader?`<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${i(e.preheader)}</div>`:""}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${G},${se});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${oe}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${n?`<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${i(n)}</strong></td>`:""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${F};">
          ${e.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${Y};">
          ${i(Q())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`}function ce(e){return["ABI Parent Care",e.ref?`Ref ${l(e.ref)}`:null,"",e.bodyText.trim(),"",Q()].filter(t=>t!==null).join(`
`)}async function X(e){const n=Deno.env.get("RESEND_API_KEY");if(!n)throw new Error("Missing RESEND_API_KEY secret");const t=Deno.env.get("EMAIL_TEST_MODE")==="true",r=Deno.env.get("TEST_EMAIL_TO")?.trim()||"",a=(e.toName?.trim()||e.to).trim(),p=t&&r?r:e.to,s=t&&r?`[To: ${a}] ${e.subject}`:e.subject,o={from:"ABI Parent Care <onboarding@resend.dev>",to:[p],subject:s,html:e.html};e.text&&e.text.trim()&&(o.text=e.text);const c=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify(o)}),d=await c.json();return c.ok?{ok:!0,status:c.status,id:typeof d?.id=="string"?d.id:void 0,to:p,subject:s,testMode:t}:(console.error("Resend error:",d),{ok:!1,status:c.status,to:p,subject:s,testMode:t,error:d})}function de(e){const n=String(e??"").trim();return n?n.split(/\s+/)[0]??n:"there"}function R(e){return e==="female"?"Female helper":e==="male"?"Male helper":e==="no_preference"||e==="none"||!e?"No preference":l(e,"No preference")}function W(e){switch(e){case"no_acceptance":return"No helper accepted within 2 hours";case"no_suitable_helpers":return"No suitable helper nearby";case"all_declined":return"All offered helpers declined";case"short_notice":return"Booked at short notice";case"helper_dropped":return"Helper dropped out";case"helper_not_confirmed":return"Helper didn't confirm";case"helper_unavailable":return"Helper no longer available";default:return e?e.replaceAll("_"," "):"Needs senior attention"}}function y(e){return j(e)??l(e)}function b(e){return`<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${i(e)}</p>`}function u(e,n){return`<div style="margin:0 0 6px;"><strong>${i(e)}:</strong> ${i(n)}</div>`}function m(e,n){return`${e}: ${n}`}function Z(e){return e?`<p style="margin:16px 0;"><img src="${i(e)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`:""}function H(e){return e.map(n=>String(n??"").trim()).filter(Boolean).join(", ")}function h(e,n,t,r,a){return{id:e,subject:n,html:ue({bodyHtml:r,ref:t,preheader:n}),text:ce({bodyText:a,ref:t})}}function Ee(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=y(e.appointment_time),a=H([e.area,e.city,e.pincode])||"\u2013",p=R(e.helper_preference),s=`We've received your request \u2013 ${e.parent_name}, ${n} \xB7 Ref ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Thank you for choosing ABI Parent Care. We've received your request for ${i(e.parent_name)}'s doctor appointment.</p>
    ${b("Appointment")}
    ${u("Date & time",`${t} \xB7 ${r}`)}
    ${u("Doctor/Hospital",l(e.doctor_hospital))}
    ${u("Pickup from",a)}
    ${u("Helper preference",p)}
    ${b("What happens next")}
    <p style="margin:0 0 12px;">We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.</p>
    <p style="margin:0 0 12px;">Need to change anything? Call us on ${i(A)} and quote Ref ${i(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`Thank you for choosing ABI Parent Care. We've received your request for ${e.parent_name}'s doctor appointment.`,"","APPOINTMENT",m("Date & time",`${t} \xB7 ${r}`),m("Doctor/Hospital",l(e.doctor_hospital)),m("Pickup from",a),m("Helper preference",p),"","WHAT HAPPENS NEXT","We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.","",`Need to change anything? Call us on ${A} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G1",s,e.ref,o,c)}function Ie(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=y(e.appointment_time),a=`Update on ${e.parent_name}'s appointment \u2013 ${n} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${i(e.parent_name)}'s appointment on ${i(t)} at ${i(r)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${i(A)} and quote Ref ${i(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,s=[`Dear ${e.booking_person_name},`,"",`A quick update: our care team is personally arranging a suitable helper for ${e.parent_name}'s appointment on ${t} at ${r}.`,"","You don't need to do anything. We'll email you the helper's details shortly.","",`If you'd like to speak to us, call ${A} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G2",a,e.ref,p,s)}function De(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=y(e.appointment_time),a=w(e.appointment_date,e.appointment_time),p=H([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",s=`Helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name}, ${n} \xB7 Ref ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news \u2013 ${i(e.helper_full_name)} will accompany ${i(e.parent_name)} to the appointment.</p>
    ${Z(e.helper_photo_url)}
    ${b("Your helper")}
    ${u("Name",e.helper_full_name)}
    ${u("Phone",l(e.helper_phone))}
    ${u("Verified","ID and background checked by ABI Parent Care")}
    ${b("Appointment")}
    ${u("Date & time",`${t} \xB7 ${r} (${a})`)}
    ${u("Doctor/Hospital",l(e.doctor_hospital))}
    ${u("Pickup from",p)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${i(e.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`Good news \u2013 ${e.helper_full_name} will accompany ${e.parent_name} to the appointment.`,"","YOUR HELPER",m("Name",e.helper_full_name),m("Phone",l(e.helper_phone)),m("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT",m("Date & time",`${t} \xB7 ${r} (${a})`),m("Doctor/Hospital",l(e.doctor_hospital)),m("Pickup from",p),"",`For safety, please share this with ${e.parent_name} so they know who to expect.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G3",s,e.ref,o,c)}function Me(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=y(e.appointment_time),a=`Change of helper for ${e.parent_name} \u2013 ${n} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${i(e.old_helper_first_name)} is unable to attend ${i(e.parent_name)}'s appointment on ${i(t)} at ${i(r)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${i(A)} and quote Ref ${i(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,s=[`Dear ${e.booking_person_name},`,"",`We're sorry \u2013 ${e.old_helper_first_name} is unable to attend ${e.parent_name}'s appointment on ${t} at ${r}.`,"","Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.","",`The appointment itself is unchanged. If you have concerns, call ${A} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G4",a,e.ref,p,s)}function Oe(e){const n=x(e.appointment_date),t=y(e.appointment_time),r=w(e.appointment_date,e.appointment_time),a=`New helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} will now accompany ${i(e.parent_name)} to the appointment, in place of ${i(e.old_helper_first_name)}.</p>
    ${Z(e.helper_photo_url)}
    ${b("Your new helper")}
    ${u("Name",e.helper_full_name)}
    ${u("Phone",l(e.helper_phone))}
    ${u("Verified","ID and background checked by ABI Parent Care")}
    ${b("Appointment (unchanged)")}
    ${u("Date & time",`${n} \xB7 ${t} (${r})`)}
    ${u("Doctor/Hospital",l(e.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,s=[`Dear ${e.booking_person_name},`,"",`${e.helper_full_name} will now accompany ${e.parent_name} to the appointment, in place of ${e.old_helper_first_name}.`,"","YOUR NEW HELPER",m("Name",e.helper_full_name),m("Phone",l(e.helper_phone)),m("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT (unchanged)",m("Date & time",`${n} \xB7 ${t} (${r})`),m("Doctor/Hospital",l(e.doctor_hospital)),"","Thank you for your patience.","","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G5",a,e.ref,p,s)}function _e(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=y(e.appointment_time),a=w(e.appointment_date,e.appointment_time),p=e.distance_km==null||Number.isNaN(Number(e.distance_km))?"\u2013":String(Math.round(Number(e.distance_km)*10)/10),s=l(e.area),o=`New visit near you \u2013 ${n}, ${r} \xB7 ${s} (${p} km)`,c=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${u("When",`${t} \xB7 ${r} (${a})`)}
    ${u("Pickup area",`${s}, ${l(e.pincode)} \xB7 about ${p} km from you`)}
    ${u("Hospital",l(e.doctor_hospital))}
    ${u("Patient",`Age ${e.parent_age}`)}
    <p style="margin:22px 0;">
      ${$(e.accept_url,"Accept","primary")}
      ${$(e.decline_url,"Decline","secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,d=[`Hi ${e.helper_first_name},`,"","A new hospital visit is available near you. The first helper to accept gets it.","",m("When",`${t} \xB7 ${r} (${a})`),m("Pickup area",`${s}, ${l(e.pincode)} \xB7 about ${p} km from you`),m("Hospital",l(e.doctor_hospital)),m("Patient",`Age ${e.parent_age}`),"",`Accept: ${e.accept_url}`,`Decline: ${e.decline_url}`,"","The patient's name, full address and family contact are shared after you accept.","",`Ref ${e.ref}`].join(`
`);return h("H1",o,e.ref,c,d)}function je(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=y(e.appointment_time),a=w(e.appointment_date,e.appointment_time),p=H([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",s=`Confirmed: ${e.parent_name}, ${n} ${r} \xB7 Ref ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${b("Patient")}
    ${u("Name",`${e.parent_name}, ${e.parent_age}`)}
    ${u("Pickup",p)}
    ${u("Landmark",l(e.landmark))}
    <p style="margin:10px 0 16px;">${$(e.maps_url,"Open in Google Maps","secondary")}</p>
    ${b("Appointment")}
    ${u("When",`${t} \xB7 ${r} (${a})`)}
    ${u("Hospital",l(e.doctor_hospital))}
    ${b("Family contact")}
    <p style="margin:0 0 12px;">${i(e.booking_person_name)} (${i(l(e.relationship))}) \xB7 ${i(l(e.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${$(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,c=[`Hi ${e.helper_first_name},`,"","This visit is yours. Thank you!","","PATIENT",m("Name",`${e.parent_name}, ${e.parent_age}`),m("Pickup",p),m("Landmark",l(e.landmark)),`Open in Google Maps: ${e.maps_url}`,"","APPOINTMENT",m("When",`${t} \xB7 ${r} (${a})`),m("Hospital",l(e.doctor_hospital)),"","FAMILY CONTACT",`${e.booking_person_name} (${l(e.relationship)}) \xB7 ${l(e.guardian_phone)}`,"","We'll remind you 12 hours and 6 hours before.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return h("H2",s,e.ref,o,c)}function We(e){const n=x(e.appointment_date),t=y(e.appointment_time),r=w(e.appointment_date,e.appointment_time),a=`Reminder: visit ${r} ${t} \u2013 ${e.parent_name}, ${l(e.area)}`,p=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${i(e.parent_name)} ${i(r)}.</p>
    ${u("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${i(l(e.full_address))} \xB7 <a href="${i(e.maps_url)}">Open in Google Maps</a></div>
    ${u("Hospital",l(e.doctor_hospital))}
    ${u("Family",`${e.booking_person_name} (${l(e.relationship)}) \xB7 ${l(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${$(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,s=[`Hi ${e.helper_first_name},`,"",`A reminder that you're accompanying ${e.parent_name} ${r}.`,"",m("When",`${n} \xB7 ${t}`),m("Pickup",`${l(e.full_address)} \xB7 ${e.maps_url}`),m("Hospital",l(e.doctor_hospital)),m("Family",`${e.booking_person_name} (${l(e.relationship)}) \xB7 ${l(e.guardian_phone)}`),"","Plan to reach the pickup address 15 minutes early.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return h("H3",a,e.ref,p,s)}function qe(e){const n=x(e.appointment_date),t=y(e.appointment_time),r=w(e.appointment_date,e.appointment_time),a=`Please confirm: ${e.parent_name} at ${t} \u2013 ${r}`,p=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${i(e.parent_name)} is ${i(r)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${$(e.confirm_url,"I'll be there","primary")}
      ${$(e.cant_make_it_url,"Can't make it","secondary")}
    </p>
    ${u("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${i(l(e.full_address))} \xB7 <a href="${i(e.maps_url)}">Open in Google Maps</a></div>
    ${u("Hospital",l(e.doctor_hospital))}
    ${u("Family",`${e.booking_person_name} (${l(e.relationship)}) \xB7 ${l(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,s=[`Hi ${e.helper_first_name},`,"",`Your visit with ${e.parent_name} is ${r}. Please confirm you'll be there.`,"",`I'll be there: ${e.confirm_url}`,`Can't make it: ${e.cant_make_it_url}`,"",m("When",`${n} \xB7 ${t}`),m("Pickup",`${l(e.full_address)} \xB7 ${e.maps_url}`),m("Hospital",l(e.doctor_hospital)),m("Family",`${e.booking_person_name} (${l(e.relationship)}) \xB7 ${l(e.guardian_phone)}`),"","If we don't hear from you, our care team will call you.","",`Ref ${e.ref}`].join(`
`);return h("H4",a,e.ref,p,s)}function Be(e){const n=e.helper_app_link||ie,t="Welcome to ABI Parent Care \u2013 your helper app login",r=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${u("App link",n)}
    ${u("Login email",e.helper_email)}
    ${u("Password","the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${$(n,"Open helper app","primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${i(A)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `,a=[`Hi ${e.helper_first_name},`,"","Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.","",m("App link",n),m("Login email",e.helper_email),m("Password","the temporary password given to you by your manager"),"","You'll be asked to set your own password the first time you log in.","",'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',"",`Questions? Call ${A}.`,"","The ABI Parent Care team"].join(`
`);return h("H5",t,null,r,a)}function Ve(e){const n=x(e.appointment_date),t=y(e.appointment_time),r=w(e.appointment_date,e.appointment_time),a=`URGENT \u2013 Helper needed in ${e.time_remaining} \xB7 ${e.parent_name} (${e.parent_age}) \xB7 ${t} \xB7 ${l(e.area)} \xB7 ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${i(r)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${b("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${b("Visit details")}
    ${u("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${u("When",`${n} \xB7 ${t} (${r})`)}
    ${u("Pickup",H([e.area,e.city,e.pincode])||"\u2013")}
    ${u("Hospital",l(e.doctor_hospital))}
    ${u("Preference",R(e.helper_preference))}
    ${u("Family",`${e.booking_person_name} (${l(e.relationship)}) \xB7 ${l(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${$(e.assign_url,"Assign a helper","primary")}</p>
  `,s=[`Hi ${e.manager_first_name},`,"",`A booking has come in for ${r}. There isn't time to send offers automatically, so please assign a helper now.`,"","WHAT TO DO NOW","Open the request, pick an available helper and send them an offer.","","VISIT DETAILS",m("Patient",`${e.parent_name}, ${e.parent_age}`),m("When",`${n} \xB7 ${t} (${r})`),m("Pickup",H([e.area,e.city,e.pincode])||"\u2013"),m("Hospital",l(e.doctor_hospital)),m("Preference",R(e.helper_preference)),m("Family",`${e.booking_person_name} (${l(e.relationship)}) \xB7 ${l(e.guardian_phone)}`),"",`Assign a helper: ${e.assign_url}`].join(`
`);return h("M1",a,e.ref,p,s)}function Le(e){const t=`${e.items.length} request(s) need a helper \u2013 ${e.digest_time}`,r=e.items.map((o,c)=>{const d=T(o.appointment_date),_=y(o.appointment_time),g=w(o.appointment_date,o.appointment_time);return`
      <div style="margin:0 0 16px;padding:12px 0;border-bottom:1px solid #e5e7eb;">
        <p style="margin:0 0 6px;"><strong>${c+1}. ${i(o.ref)}</strong> \xB7 ${i(o.parent_name)} (${o.parent_age}) \xB7 ${i(d)} ${i(_)} (${i(g)})</p>
        <p style="margin:0 0 6px;">${i(l(o.area))} ${i(l(o.pincode))} \xB7 Preference: ${i(R(o.helper_preference))}</p>
        <p style="margin:0 0 10px;">Why: ${i(W(o.reason))}</p>
        <p style="margin:0;">${$(o.assign_url,"Assign","primary")}</p>
      </div>
    `}).join(""),a=e.items.map((o,c)=>{const d=T(o.appointment_date),_=y(o.appointment_time),g=w(o.appointment_date,o.appointment_time);return[`${c+1}. ${o.ref} \xB7 ${o.parent_name} (${o.parent_age}) \xB7 ${d} ${_} (${g})`,`   ${l(o.area)} ${l(o.pincode)} \xB7 Preference: ${R(o.helper_preference)}`,`   Why: ${W(o.reason)}`,`   Assign: ${o.assign_url}`].join(`
`)}).join(`

`),p=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">These requests still need a helper. The soonest appointment is first.</p>
    ${r}
    <p style="margin:22px 0;">${$(e.open_all_url,"Open all in the portal","primary")}</p>
  `,s=[`Hi ${e.manager_first_name},`,"","These requests still need a helper. The soonest appointment is first.","",a,"",`Open all in the portal: ${e.open_all_url}`].join(`
`);return h("M2",t,null,p,s)}function Ue(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=y(e.appointment_time),a=w(e.appointment_date,e.appointment_time),p=O(e.decline_reason),s=`${e.helper_full_name} declined \u2013 please assign another \xB7 ${e.parent_name}, ${n} ${r} \xB7 ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} declined the visit you offered.</p>
    ${u("Reason given",p)}
    <p style="margin:12px 0;">Appointment: ${i(t)} \xB7 ${i(r)} (${i(a)}) \xB7 ${i(l(e.area))}</p>
    <p style="margin:22px 0;">${$(e.assign_url,"Choose another helper","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} declined the visit you offered.`,m("Reason given",p),"",`Appointment: ${t} \xB7 ${r} (${a}) \xB7 ${l(e.area)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return h("M3",s,e.ref,o,c)}function ge(e){const n=x(e.appointment_date),t=y(e.appointment_time),r=w(e.appointment_date,e.appointment_time),a=`No response from ${e.helper_full_name} \u2013 please assign another \xB7 ${e.parent_name} \xB7 ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} didn't respond within ${i(e.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${i(n)} \xB7 ${i(t)} (${i(r)}) \xB7 ${i(l(e.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${i(l(e.helper_phone))}</p>
    <p style="margin:22px 0;">${$(e.assign_url,"Choose another helper","primary")}</p>
  `,s=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} didn't respond within ${e.expiry_window}, so the offer has been withdrawn.`,"",`Appointment: ${n} \xB7 ${t} (${r}) \xB7 ${l(e.area)}`,`Helper phone (if you'd like to call): ${l(e.helper_phone)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return h("M4",a,e.ref,p,s)}function Ge(e){const n=x(e.appointment_date),t=y(e.appointment_time),r=w(e.appointment_date,e.appointment_time),a=O(e.dropout_reason),p=`URGENT \u2013 ${e.helper_full_name} can't attend \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} has said they can't attend this visit.</p>
    ${u("Reason given",a)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${b("Visit details")}
    ${u("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${u("When",`${n} \xB7 ${t} (${r})`)}
    ${u("Pickup",H([e.area,e.city,e.pincode])||"\u2013")}
    ${u("Hospital",l(e.doctor_hospital))}
    ${u("Family",`${e.booking_person_name} (${l(e.relationship)}) \xB7 ${l(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${$(e.assign_url,"Assign a replacement","primary")}</p>
  `,o=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has said they can't attend this visit.`,m("Reason given",a),"","The family has been told we're arranging a replacement. Please assign a new helper now.","","VISIT DETAILS",m("Patient",`${e.parent_name}, ${e.parent_age}`),m("When",`${n} \xB7 ${t} (${r})`),m("Pickup",H([e.area,e.city,e.pincode])||"\u2013"),m("Hospital",l(e.doctor_hospital)),m("Family",`${e.booking_person_name} (${l(e.relationship)}) \xB7 ${l(e.guardian_phone)}`),"",`Assign a replacement: ${e.assign_url}`].join(`
`);return h("M5",p,e.ref,s,o)}function fe(e){const n=x(e.appointment_date),t=y(e.appointment_time),r=w(e.appointment_date,e.appointment_time),a=me(e.assigned_at),p=e.urgent?`URGENT \u2013 visit in 1 hour, ${e.helper_full_name} still not confirmed \xB7 ${e.parent_name} \xB7 ${e.ref}`:`Action needed \u2013 ${e.helper_full_name} hasn't confirmed \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,s=e.urgent?`The visit starts in about 1 hour and ${i(e.helper_full_name)} still hasn't confirmed. Please resolve this now.`:`${i(e.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,o=e.urgent?`The visit starts in about 1 hour and ${e.helper_full_name} still hasn't confirmed. Please resolve this now.`:`${e.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,c=e.urgent?`<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${i(e.helper_first_name)}: ${i(l(e.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".</li>
      </ol>`:`${b("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${i(e.helper_first_name)}: ${i(l(e.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone \u2013 nothing else happens, or</li>
            <li>Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`,d=e.urgent?[`1. Call ${e.helper_first_name}: ${l(e.helper_phone)}`,'2. Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".'].join(`
`):["WHAT TO DO NOW",`1. Call ${e.helper_first_name}: ${l(e.helper_phone)}`,"2. Then in the portal, choose:","   \u2022 Helper confirmed by phone \u2013 nothing else happens, or","   \u2022 Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper"].join(`
`),_=`
    ${b("Visit details")}
    ${u("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${u("When",`${n} \xB7 ${t} (${r})`)}
    ${u("Pickup",H([e.area,e.city,e.pincode])||"\u2013")}
    ${u("Hospital",l(e.doctor_hospital))}
    ${b("Helper status")}
    ${u("Assigned",a)}
    ${u("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`)}
    ${u("Confirmed","Not yet")}
  `,g=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${s}</p>
    ${c}
    ${_}
    <p style="margin:22px 0;">${$(e.open_url,"Open request","primary")}</p>
  `,k=[`Hi ${e.manager_first_name},`,"",o,"",d,"","VISIT DETAILS",m("Patient",`${e.parent_name}, ${e.parent_age}`),m("When",`${n} \xB7 ${t} (${r})`),m("Pickup",H([e.area,e.city,e.pincode])||"\u2013"),m("Hospital",l(e.doctor_hospital)),"","HELPER STATUS",m("Assigned",a),m("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`),m("Confirmed","Not yet"),"",`Open request: ${e.open_url}`].join(`
`);return h(e.urgent?"M7":"M6",p,e.ref,g,k)}function Fe(e){return fe({...e,urgent:!0})}function Ye(e){const n=`Driving licence ${e.expiry_phrase} \u2013 ${e.helper_full_name}`,t=e.expired?`<p style="margin:0 0 12px;">If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).</p>`:'<p style="margin:0 0 12px;">If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.</p>',r=e.expired?`If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).`:"If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.",a=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)}'s driving licence ${i(e.expiry_phrase)} (${i(e.dl_expiry)}).</p>
    ${t}
    <p style="margin:22px 0;">${$(e.open_url,"Open helper profile","primary")}</p>
  `,p=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name}'s driving licence ${e.expiry_phrase} (${e.dl_expiry}).`,"",r,"",`Open helper profile: ${e.open_url}`].join(`
`);return h("M8",n,null,a,p)}function ze(e){const n=`Profile change request \u2013 ${e.helper_full_name}`,t=O(e.request_note),r=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} has asked to update their profile:</p>
    <p style="margin:0 0 12px;padding:12px 14px;background:#f3f6fb;border-radius:8px;font-style:italic;">"${i(t)}"</p>
    <p style="margin:0 0 12px;">Please review and update their details in the portal if appropriate.</p>
    <p style="margin:22px 0;">${$(e.open_url,"Open helper profile","primary")}</p>
  `,a=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has asked to update their profile:`,"",`"${t}"`,"","Please review and update their details in the portal if appropriate.","",`Open helper profile: ${e.open_url}`].join(`
`);return h("M9",n,null,r,a)}const Ke={accept_confirm:{title:"Accept this visit?",message:"{{appointment_date_short}} \xB7 {{appointment_time}} \xB7 {{area}}. Tap Confirm to take this visit.",button:"Confirm"},accepted:{title:"This visit is yours!",message:"We've emailed you the full details. Thank you, {{helper_first_name}}."},already_taken:{title:"Already taken",message:"Another helper accepted this visit first. Thank you for responding quickly."},helper_engaged:{title:"You're already booked",message:"You have another visit around this time, so we can't assign this one to you."},declined:{title:"Thanks for letting us know",message:"We've offered this visit to another helper."},confirmed:{title:"See you there!",message:"Thanks for confirming. The family is counting on you."},cant_make_it_confirm:{title:"Can't make this visit?",message:"Tell us why (optional), then tap Confirm. We'll arrange a replacement.",button:"Confirm"},cant_make_it_done:{title:"Thanks for telling us",message:"Our care team will arrange a replacement."},link_inactive:{title:"This link is no longer active",message:"The visit may have been assigned, cancelled or already passed. Please contact your manager if you need help."}};function Je(e,n){return e.replace(/\{\{(\w+)\}\}/g,(t,r)=>l(n[r],""))}async function he(e,n){const t=Deno.env.get(n)?.trim()||"";if(t)return t;const{data:r,error:a}=await e.rpc("get_app_secret",{p_name:n});return a?(console.error(`get_app_secret(${n}) failed`,a),null):(typeof r=="string"?r.trim():"")||null}function Qe(e,n){const t=new TextEncoder,r=t.encode(e),a=t.encode(n),p=Math.max(r.length,a.length);let s=r.length===a.length?0:1;for(let o=0;o<p;o++)s|=(r[o]??0)^(a[o]??0);return s===0}const q="https://nandhini-17223.github.io/elderly-care/admin",v="https://nandhini-17223.github.io/elderly-care/respond.html",Xe="https://nandhini-17223.github.io/elderly-care/admin/helper.html",$e="Manager";function ye(e){const n=`needs-action.html?request=${encodeURIComponent(e)}`;return`${q}/login.html?next=${encodeURIComponent(n)}`}function Ze(){return`${q}/login.html?next=${encodeURIComponent("needs-action.html")}`}function ve(e){const n=`helper.html?id=${encodeURIComponent(e)}`;return`${q}/login.html?next=${encodeURIComponent(n)}`}function en(e,n="Assign helper"){return`<a href="${e}" style="background:#1d6fd8;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;">${i(n)}</a>`}function nn(e){const n=K(e.appointmentDate)??e.appointmentDate,t=j(e.appointmentTime)??e.appointmentTime,r=[e.area,e.pincode].filter(Boolean).join(" \xB7 ")||"Area on file";return`
    <p>
      ${e.refNumber?`<strong>Ref:</strong> ${i(e.refNumber)}<br />`:""}
      <strong>Patient:</strong> ${i(e.parentName)} (age ${i(String(e.parentAge))})<br />
      <strong>Date:</strong> ${i(n)}<br />
      <strong>Time:</strong> ${i(t)}<br />
      <strong>Area:</strong> ${i(r)}<br />
      ${e.doctorHospital?`<strong>Doctor / Hospital:</strong> ${i(e.doctorHospital)}<br />`:""}
      ${e.helperPreference?`<strong>Helper preference:</strong> ${i(R(e.helperPreference))}<br />`:""}
      ${e.reason?`<strong>Reason:</strong> ${i(W(e.reason))}<br />`:""}
      ${e.address?`<strong>Address:</strong> ${i(e.address)}<br />`:""}
    </p>
  `}function tn(e){return e==null||Number.isNaN(Number(e))?"Nearby":`~${Math.round(Number(e)*10)/10} km`}function rn(e){return e?"sent":"not sent"}const be={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS","Content-Type":"application/json"};function N(e,n){return new Response(JSON.stringify({ok:!1,error:e}),{status:n,headers:be})}function xe(e){const t=(e.headers.get("Authorization")||"").match(/^Bearer\s+(.+)$/i);return t?t[1].trim():null}async function an(e,n,t){const r=Deno.env.get("SUPABASE_URL"),a=Deno.env.get("SUPABASE_ANON_KEY");if(!r||!a)return{error:N("Server misconfigured",500)};const p=xe(e);if(!p||p===a)return{error:N("Unauthorized",401)};const s=U(r,a,{global:{headers:{Authorization:`Bearer ${p}`}},auth:{persistSession:!1,autoRefreshToken:!1}}),{data:o,error:c}=await s.auth.getUser();if(c||!o.user)return{error:N("Unauthorized",401)};const{data:d,error:_}=await n.from("profiles").select("user_id, full_name, role, helper_id, is_active").eq("user_id",o.user.id).maybeSingle();return _||!d||!d.is_active?{error:N("Unauthorized",401)}:d.role!=="super_admin"&&d.role!=="manager"?{error:N("Forbidden",403)}:t?.superAdminOnly&&d.role!=="super_admin"?{error:N("Forbidden",403)}:{user:o.user,profile:d,accessToken:p}}async function on(e,n,t,r,a,p){const{error:s}=await e.rpc("write_audit_log",{p_actor_user_id:n.user.id,p_actor_role:n.profile.role,p_action:t,p_entity:r,p_entity_id:a??null,p_details:p??{}});s&&console.error("write_audit_log failed",s)}async function we(e){const{data:n,error:t}=await e.from("app_settings").select("key, value");if(t)return console.error("loadAppSettings",t),{};const r={};for(const a of n??[])r[a.key]=String(a.value);return r}function I(e,n,t){const r=e[n],a=Number(r);return Number.isFinite(a)?a:t}function D(e,n=200){return new Response(JSON.stringify(e),{status:n,headers:{"Content-Type":"application/json",Connection:"keep-alive"}})}function ee(e){return Array.from(e).map(n=>n.toString(16).padStart(2,"0")).join("")}async function ke(e){const n=new TextEncoder().encode(e),t=await crypto.subtle.digest("SHA-256",n);return ee(new Uint8Array(t))}async function Ae(){const e=crypto.getRandomValues(new Uint8Array(32)),n=ee(e),t=await ke(n);return{token:n,hash:t}}async function Te(e,n,t,r){const a=`${v}?token=${encodeURIComponent(t)}&action=accept`,p=`${v}?token=${encodeURIComponent(t)}&action=decline`,s=_e({ref:String(e.ref_number??"\u2013"),helper_first_name:de(n.full_name),appointment_date:e.appointment_date,appointment_time:e.appointment_time,area:e.area,pincode:e.pincode,distance_km:r,doctor_hospital:e.doctor_hospital,parent_age:e.parent_age,accept_url:a,decline_url:p});return(await X({to:n.email,toName:n.full_name,subject:s.subject,html:s.html,text:s.text})).ok}async function B(e,n,t){const{error:r}=await e.rpc("mark_request_needs_senior",{p_request_id:n,p_reason:t});r&&console.error("mark_request_needs_senior failed",n,r)}async function He(e,n,t,r=60,a=null){const p=await he(e,"SENIOR_EMAIL");if(!p){console.error("Missing SENIOR_EMAIL for expiry alert");return}const s=await ne(e,n);if(!s)return;const o=ye(n),c=r===15?"15 minutes":"1 hour",d=ge({ref:String(s.ref_number??"\u2013"),manager_first_name:$e,helper_full_name:t,helper_phone:a,parent_name:s.parent_name,appointment_date:s.appointment_date,appointment_time:s.appointment_time,area:s.area,expiry_window:c,assign_url:o});await X({to:p,toName:"Senior coordinator",subject:d.subject,html:d.html,text:d.text})}async function Pe(e,n){const t=I(n,"engaged_window_hours",3),r=I(n,"urgent_offer_expiry_minutes",15),a=I(n,"senior_offer_expiry_minutes",60),{data:p,error:s}=await e.from("helper_offers").select("id, request_id, helper_id, sent_at, helpers(full_name, phone), consultation_requests(appointment_date, appointment_time)").eq("source","senior").eq("status","sent");if(s)return console.error("expireStaleSeniorOffers query",s),[{error:s.message}];const o=[],c=Date.now();for(const d of p??[]){const _=d.consultation_requests,g=Date.parse(d.sent_at);if(!Number.isFinite(g)||!_?.appointment_date||!_?.appointment_time)continue;const k=Date.parse(`${_.appointment_date}T${String(_.appointment_time).slice(0,8)}+05:30`);if(!Number.isFinite(k))continue;const f=(k-g)/36e5<t?r:a;if(c-g<f*60*1e3)continue;const{data:P,error:V}=await e.rpc("expire_senior_offer",{p_offer_id:d.id});if(V){o.push({offer_id:d.id,ok:!1,error:V.message});continue}const S=P;if(S?.ok&&S.request_id){const L=d.helpers,ae=S.helper_name||L?.full_name||"Helper";await He(e,S.request_id,ae,f,L?.phone??null)}o.push({offer_id:d.id,request_id:d.request_id,expired:!!S?.ok,helper_name:S?.helper_name,expiry_minutes:f})}return o}async function ne(e,n){const{data:t,error:r}=await e.from("consultation_requests").select("id, ref_number, status, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, offer_window_ends_at, location_missing").eq("id",n).maybeSingle();return r?(console.error("loadRequest",r),null):t}async function te(e,n){const{data:t,error:r}=await e.from("helper_offers").select("wave_number, status, sent_at").eq("request_id",n);if(r)return console.error("getOfferStats",r),{maxWave:0,lastSentAt:null,sentCount:0,declinedCount:0,totalOffers:0};const a=t??[];let p=0,s=null,o=0,c=0;for(const d of a)p=Math.max(p,Number(d.wave_number)||0),(!s||String(d.sent_at)>s)&&(s=String(d.sent_at)),d.status==="sent"&&(o+=1),d.status==="declined"&&(c+=1);return{maxWave:p,lastSentAt:s,sentCount:o,declinedCount:c,totalOffers:a.length}}async function Se(e,n,t){const{data:r,error:a}=await e.rpc("find_suitable_helpers",{p_request_id:n,p_limit:t});return a?(console.error("find_suitable_helpers",a),[]):r??[]}async function Ce(e,n,t,r){if(t.length===0)return{created:0,emailed:0};const a=[];for(const o of t){const{token:c,hash:d}=await Ae();a.push({request_id:n.id,helper_id:o.helper_id,wave_number:r,status:"sent",token_hash:d,distance_km:o.distance_km??null,raw_token:c,helper:o})}const{error:p}=await e.from("helper_offers").insert(a.map(o=>({request_id:o.request_id,helper_id:o.helper_id,wave_number:o.wave_number,status:o.status,token_hash:o.token_hash,distance_km:o.distance_km})));if(p)return console.error("insert helper_offers",p),{created:0,emailed:0};let s=0;for(const o of a)await Te(n,o.helper,o.raw_token,o.distance_km)&&(s+=1);return{created:a.length,emailed:s}}function Re(e,n){return(Date.parse(n)-Date.parse(e))/6e4}async function re(e,n,t,r={}){if(n.status!=="offered")return{request_id:n.id,skipped:!0,reason:"not_offered"};const a=I(r,"wave_gap_minutes",15),p=I(r,"wave_size",10),s=new Date;if(n.offer_window_ends_at&&Date.parse(n.offer_window_ends_at)<=s.getTime()){const f=await te(e,n.id),P=f.totalOffers>0&&f.declinedCount===f.totalOffers&&f.sentCount===0?"all_declined":"no_acceptance";return await B(e,n.id,P),{request_id:n.id,expired:!0,reason:P}}if(!t.force&&!t.offerNext){const{data:f,error:P}=await e.rpc("is_within_active_hours",{p_ts:s.toISOString()});if(P)return console.error("is_within_active_hours",P),{request_id:n.id,skipped:!0,reason:"active_hours_check_failed"};if(f===!1)return{request_id:n.id,skipped:!0,reason:"night_pause"}}const o=await te(e,n.id),c=!!t.offerNext,d=!!t.force;if(!c&&!d&&o.maxWave>0&&o.lastSentAt){const f=Re(o.lastSentAt,s.toISOString());if(f<a)return{request_id:n.id,skipped:!0,reason:"wave_interval",elapsed_minutes:f}}const _=c?1:t.limit??p,g=await Se(e,n.id,_);if(g.length===0){if(o.totalOffers===0)return await B(e,n.id,"no_suitable_helpers"),{request_id:n.id,needs_senior:!0,reason:"no_suitable_helpers"};if(o.sentCount===0){const f=o.declinedCount===o.totalOffers?"all_declined":"no_suitable_helpers";return await B(e,n.id,f),{request_id:n.id,needs_senior:!0,reason:f}}return{request_id:n.id,skipped:!0,reason:"waiting_on_open_offers",open_offers:o.sentCount}}const k=t.waveNumber??(c?Math.max(o.maxWave,1):o.maxWave+1),E=await Ce(e,n,g,k);return{request_id:n.id,wave_number:k,offered:E.created,emailed:E.emailed,helper_ids:g.map(f=>f.helper_id)}}Deno.serve(async e=>{if(e.method==="OPTIONS")return new Response(null,{status:204,headers:{"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"}});if(e.method!=="POST")return D({error:"Method not allowed"},405);try{const n=Deno.env.get("SUPABASE_URL"),t=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");if(!n||!t)throw new Error("Missing Supabase environment configuration");const r=U(n,t);let a={};try{a=await e.json()}catch{a={}}const p=await we(r),s=[],o=await Pe(r,p);if(a.request_id){const c=await ne(r,a.request_id);if(!c)return D({error:"Request not found"},404);s.push(await re(r,c,{force:a.force,offerNext:a.offer_next,limit:a.limit,waveNumber:a.wave_number},p))}else{const{data:c,error:d}=await r.from("consultation_requests").select("id, ref_number, status, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, offer_window_ends_at, location_missing").eq("status","offered");if(d)throw d;for(const _ of c??[])s.push(await re(r,_,{force:a.force},p))}return D({ok:!0,reason:a.reason??"manual",results:s,senior_expiry:o})}catch(n){console.error(n);const t=n instanceof Error?n.message:"Unknown error";return D({error:t},500)}});
