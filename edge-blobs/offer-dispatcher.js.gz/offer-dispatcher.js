// ../../../tmp/fn-src/supabase/functions/offer-dispatcher/index.ts
import { createClient as createClient2 } from "jsr:@supabase/supabase-js@2";

// ../../../tmp/fn-src/supabase/functions/_shared/email.ts
var SUPPORT_PHONE = "+91 73399 11220";
var LOGO_URL = "https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg";
var BRAND_PRIMARY = "#1d6fd8";
var BRAND_ACCENT = "#4a9cf7";
var BRAND_TEXT = "#1f2937";
var BRAND_MUTED = "#6b7280";
var MONTHS_SHORT = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
];
var WEEKDAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
function escapeHtml(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}
function displayValue(value, fallback = "\u2013") {
  if (value === null || value === void 0) return fallback;
  const text = String(value).trim();
  if (!text || text.toLowerCase() === "null" || text.toLowerCase() === "undefined") {
    return fallback;
  }
  return text;
}
function parseDateParts(appointmentDate) {
  if (!appointmentDate) return null;
  const dateMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(appointmentDate.trim());
  if (!dateMatch) return null;
  const year = Number(dateMatch[1]);
  const month = Number(dateMatch[2]);
  const day = Number(dateMatch[3]);
  if (!month || month < 1 || month > 12 || !day || day < 1 || day > 31) {
    return null;
  }
  return { year, month, day };
}
function parseTimeParts(appointmentTime) {
  if (!appointmentTime) return null;
  const timeMatch = /^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(
    appointmentTime.trim()
  );
  if (!timeMatch) return null;
  const hour24 = Number(timeMatch[1]);
  const minute = Number(timeMatch[2]);
  if (!Number.isInteger(hour24) || !Number.isInteger(minute) || hour24 < 0 || hour24 > 23 || minute < 0 || minute > 59) {
    return null;
  }
  return { hour24, minute };
}
function appointmentMsIst(appointmentDate, appointmentTime) {
  const d = parseDateParts(appointmentDate);
  const t = parseTimeParts(appointmentTime) ?? { hour24: 0, minute: 0 };
  if (!d) return NaN;
  return Date.parse(
    `${String(d.year).padStart(4, "0")}-${String(d.month).padStart(2, "0")}-${String(d.day).padStart(2, "0")}T${String(t.hour24).padStart(2, "0")}:${String(t.minute).padStart(2, "0")}:00+05:30`
  );
}
function formatAppointmentDateShort(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  return `${d.day} ${MONTHS_SHORT[d.month - 1]}`;
}
function formatAppointmentDateLong(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  const weekday = new Date(Date.UTC(d.year, d.month - 1, d.day)).getUTCDay();
  return `${WEEKDAYS_SHORT[weekday]}, ${d.day} ${MONTHS_SHORT[d.month - 1]} ${d.year}`;
}
function formatAppointmentTime(appointmentTime) {
  const t = parseTimeParts(appointmentTime);
  if (!t) return null;
  const hour12 = t.hour24 % 12 || 12;
  const ampm = t.hour24 < 12 ? "AM" : "PM";
  return `${hour12}:${String(t.minute).padStart(2, "0")} ${ampm}`;
}
function istYmd(ms) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date(ms));
}
function formatRelativeTime(appointmentDate, appointmentTime, nowMs = Date.now()) {
  const appt = appointmentMsIst(appointmentDate, appointmentTime);
  if (!Number.isFinite(appt)) return "\u2013";
  const today = istYmd(nowMs);
  const apptDay = istYmd(appt);
  const todayParts = parseDateParts(today);
  const apptParts = parseDateParts(apptDay);
  const dayDiff = Math.round(
    (Date.UTC(apptParts.year, apptParts.month - 1, apptParts.day) - Date.UTC(todayParts.year, todayParts.month - 1, todayParts.day)) / 864e5
  );
  if (dayDiff === 0) {
    const deltaMs = appt - nowMs;
    if (deltaMs <= 0) return "today";
    const totalMinutes = Math.round(deltaMs / 6e4);
    if (totalMinutes < 60) {
      return `today \xB7 in ${totalMinutes} minute${totalMinutes === 1 ? "" : "s"}`;
    }
    const hours = Math.round(totalMinutes / 60);
    return `today \xB7 in ${hours} hour${hours === 1 ? "" : "s"}`;
  }
  if (dayDiff === 1) return "tomorrow";
  if (dayDiff > 1) return `in ${dayDiff} days`;
  if (dayDiff === -1) return "yesterday";
  return `${Math.abs(dayDiff)} days ago`;
}
function emailButtonHtml(href, label, variant = "primary") {
  const bg = variant === "primary" ? BRAND_PRIMARY : "#e5e7eb";
  const color = variant === "primary" ? "#ffffff" : "#111827";
  return `<a href="${escapeHtml(href)}" style="background:${bg};color:${color};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${escapeHtml(label)}</a>`;
}
function emailFooterText() {
  return `This is an automated message from ABI Parent Care. For help, call ${SUPPORT_PHONE}.`;
}
function wrapEmailHtml(args) {
  const ref = displayValue(args.ref, "");
  const refHtml = ref ? `<td align="right" style="font-size:13px;color:${BRAND_MUTED};white-space:nowrap;">Ref <strong style="color:${BRAND_TEXT};">${escapeHtml(ref)}</strong></td>` : `<td></td>`;
  const preheader = args.preheader ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${escapeHtml(args.preheader)}</div>` : "";
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${preheader}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${BRAND_PRIMARY},${BRAND_ACCENT});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${LOGO_URL}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${ref ? `<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${escapeHtml(ref)}</strong></td>` : ""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${BRAND_TEXT};">
          ${args.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${BRAND_MUTED};">
          ${escapeHtml(emailFooterText())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`;
}
function wrapEmailText(args) {
  const lines = [
    "ABI Parent Care",
    args.ref ? `Ref ${displayValue(args.ref)}` : null,
    "",
    args.bodyText.trim(),
    "",
    emailFooterText()
  ].filter((line2) => line2 !== null);
  return lines.join("\n");
}
async function sendEmail(args) {
  const resendApiKey = Deno.env.get("RESEND_API_KEY");
  if (!resendApiKey) {
    throw new Error("Missing RESEND_API_KEY secret");
  }
  const testMode = Deno.env.get("EMAIL_TEST_MODE") === "true";
  const testTo = Deno.env.get("TEST_EMAIL_TO")?.trim() || "";
  const realRecipientLabel = (args.toName?.trim() || args.to).trim();
  const finalTo = testMode && testTo ? testTo : args.to;
  const finalSubject = testMode && testTo ? `[To: ${realRecipientLabel}] ${args.subject}` : args.subject;
  const payload = {
    from: "ABI Parent Care <onboarding@resend.dev>",
    to: [finalTo],
    subject: finalSubject,
    html: args.html
  };
  if (args.text && args.text.trim()) {
    payload.text = args.text;
  }
  const emailResponse = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${resendApiKey}`
    },
    body: JSON.stringify(payload)
  });
  const emailResult = await emailResponse.json();
  if (!emailResponse.ok) {
    console.error("Resend error:", emailResult);
    return {
      ok: false,
      status: emailResponse.status,
      to: finalTo,
      subject: finalSubject,
      testMode,
      error: emailResult
    };
  }
  return {
    ok: true,
    status: emailResponse.status,
    id: typeof emailResult?.id === "string" ? emailResult.id : void 0,
    to: finalTo,
    subject: finalSubject,
    testMode
  };
}

// ../../../tmp/fn-src/supabase/functions/_shared/secrets.ts
async function resolveSecret(supabase, name) {
  const fromEnv = Deno.env.get(name)?.trim() || "";
  if (fromEnv) return fromEnv;
  const { data, error } = await supabase.rpc("get_app_secret", {
    p_name: name
  });
  if (error) {
    console.error(`get_app_secret(${name}) failed`, error);
    return null;
  }
  const value = typeof data === "string" ? data.trim() : "";
  return value || null;
}

// ../../../tmp/fn-src/supabase/functions/_shared/templates.ts
function firstName(fullName) {
  const trimmed = String(fullName ?? "").trim();
  if (!trimmed) return "there";
  return trimmed.split(/\s+/)[0] ?? trimmed;
}
function timeLabel(appointmentTime) {
  return formatAppointmentTime(appointmentTime) ?? displayValue(appointmentTime);
}
function line(label, value) {
  return `<div style="margin:0 0 6px;"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</div>`;
}
function textLine(label, value) {
  return `${label}: ${value}`;
}
function build(id, subject, ref, bodyHtml, bodyText) {
  return {
    id,
    subject,
    html: wrapEmailHtml({ bodyHtml, ref, preheader: subject }),
    text: wrapEmailText({ bodyText, ref })
  };
}
function templateH1(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const dist = v.distance_km == null || Number.isNaN(Number(v.distance_km)) ? "\u2013" : String(Math.round(Number(v.distance_km) * 10) / 10);
  const area = displayValue(v.area);
  const subject = `New visit near you \u2013 ${dateShort}, ${time} \xB7 ${area} (${dist} km)`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${line("When", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Pickup area", `${area}, ${displayValue(v.pincode)} \xB7 about ${dist} km from you`)}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Patient", `Age ${v.parent_age}`)}
    <p style="margin:22px 0;">
      ${emailButtonHtml(v.accept_url, "Accept", "primary")}
      ${emailButtonHtml(v.decline_url, "Decline", "secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    "A new hospital visit is available near you. The first helper to accept gets it.",
    "",
    textLine("When", `${dateLong} \xB7 ${time} (${relative})`),
    textLine(
      "Pickup area",
      `${area}, ${displayValue(v.pincode)} \xB7 about ${dist} km from you`
    ),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine("Patient", `Age ${v.parent_age}`),
    "",
    `Accept: ${v.accept_url}`,
    `Decline: ${v.decline_url}`,
    "",
    "The patient's name, full address and family contact are shared after you accept.",
    "",
    `Ref ${v.ref}`
  ].join("\n");
  return build("H1", subject, v.ref, bodyHtml, bodyText);
}
function templateM4(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject = `No response from ${v.helper_full_name} \u2013 please assign another \xB7 ${v.parent_name} \xB7 ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} didn't respond within ${escapeHtml(v.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${escapeHtml(dateLong)} \xB7 ${escapeHtml(time)} (${escapeHtml(relative)}) \xB7 ${escapeHtml(displayValue(v.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${escapeHtml(displayValue(v.helper_phone))}</p>
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Choose another helper", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name} didn't respond within ${v.expiry_window}, so the offer has been withdrawn.`,
    "",
    `Appointment: ${dateLong} \xB7 ${time} (${relative}) \xB7 ${displayValue(v.area)}`,
    `Helper phone (if you'd like to call): ${displayValue(v.helper_phone)}`,
    "",
    `Choose another helper: ${v.assign_url}`
  ].join("\n");
  return build("M4", subject, v.ref, bodyHtml, bodyText);
}

// ../../../tmp/fn-src/supabase/functions/_shared/senior.ts
var ADMIN_PAGE_BASE = "https://nandhini-17223.github.io/elderly-care/admin";
var RESPOND_BASE = "https://nandhini-17223.github.io/elderly-care/respond.html";
var MANAGER_FIRST_NAME = "Manager";
function seniorAssignUrl(requestId) {
  const next = `needs-action.html?request=${encodeURIComponent(requestId)}`;
  return `${ADMIN_PAGE_BASE}/login.html?next=${encodeURIComponent(next)}`;
}

// ../../../tmp/fn-src/supabase/functions/_shared/staff-auth.ts
import { createClient } from "jsr:@supabase/supabase-js@2";
async function loadAppSettings(serviceClient) {
  const { data, error } = await serviceClient.from("app_settings").select("key, value");
  if (error) {
    console.error("loadAppSettings", error);
    return {};
  }
  const map = {};
  for (const row of data ?? []) {
    map[row.key] = String(row.value);
  }
  return map;
}
function settingInt(settings, key, fallback) {
  const raw = settings[key];
  const n = Number(raw);
  return Number.isFinite(n) ? n : fallback;
}

// ../../../tmp/fn-src/supabase/functions/offer-dispatcher/index.ts
function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json",
      Connection: "keep-alive"
    }
  });
}
function bytesToHex(bytes) {
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function sha256Hex(value) {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return bytesToHex(new Uint8Array(digest));
}
async function createOfferToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  const token = bytesToHex(bytes);
  const hash = await sha256Hex(token);
  return { token, hash };
}
async function sendOfferEmail(request, helper, token, distanceKm) {
  const acceptUrl = `${RESPOND_BASE}?token=${encodeURIComponent(token)}&action=accept`;
  const declineUrl = `${RESPOND_BASE}?token=${encodeURIComponent(token)}&action=decline`;
  const email = templateH1({
    ref: String(request.ref_number ?? "\u2013"),
    helper_first_name: firstName(helper.full_name),
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    area: request.area,
    pincode: request.pincode,
    distance_km: distanceKm,
    doctor_hospital: request.doctor_hospital,
    parent_age: request.parent_age,
    accept_url: acceptUrl,
    decline_url: declineUrl
  });
  const result = await sendEmail({
    to: helper.email,
    toName: helper.full_name,
    subject: email.subject,
    html: email.html,
    text: email.text
  });
  return result.ok;
}
async function markNeedsSenior(supabase, requestId, reason) {
  const { error } = await supabase.rpc("mark_request_needs_senior", {
    p_request_id: requestId,
    p_reason: reason
  });
  if (error) {
    console.error("mark_request_needs_senior failed", requestId, error);
  }
}
async function notifySeniorOfExpiry(supabase, requestId, helperName, expiryMinutes = 60, helperPhone = null) {
  const seniorEmail = await resolveSecret(supabase, "SENIOR_EMAIL");
  if (!seniorEmail) {
    console.error("Missing SENIOR_EMAIL for expiry alert");
    return;
  }
  const request = await loadRequest(supabase, requestId);
  if (!request) return;
  const assignUrl = seniorAssignUrl(requestId);
  const windowLabel = expiryMinutes === 15 ? "15 minutes" : "1 hour";
  const email = templateM4({
    ref: String(request.ref_number ?? "\u2013"),
    manager_first_name: MANAGER_FIRST_NAME,
    helper_full_name: helperName,
    helper_phone: helperPhone,
    parent_name: request.parent_name,
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    area: request.area,
    expiry_window: windowLabel,
    assign_url: assignUrl
  });
  await sendEmail({
    to: seniorEmail,
    toName: "Senior coordinator",
    subject: email.subject,
    html: email.html,
    text: email.text
  });
}
async function expireStaleSeniorOffers(supabase, settings) {
  const engagedHours = settingInt(settings, "engaged_window_hours", 3);
  const urgentExpiry = settingInt(settings, "urgent_offer_expiry_minutes", 15);
  const normalExpiry = settingInt(settings, "senior_offer_expiry_minutes", 60);
  const { data, error } = await supabase.from("helper_offers").select(
    "id, request_id, helper_id, sent_at, helpers(full_name, phone), consultation_requests(appointment_date, appointment_time)"
  ).eq("source", "senior").eq("status", "sent");
  if (error) {
    console.error("expireStaleSeniorOffers query", error);
    return [{ error: error.message }];
  }
  const results = [];
  const now = Date.now();
  for (const row of data ?? []) {
    const req = row.consultation_requests;
    const sentAt = Date.parse(row.sent_at);
    if (!Number.isFinite(sentAt) || !req?.appointment_date || !req?.appointment_time) {
      continue;
    }
    const apptMs = Date.parse(
      `${req.appointment_date}T${String(req.appointment_time).slice(0, 8)}+05:30`
    );
    if (!Number.isFinite(apptMs)) continue;
    const hoursToApptAtSend = (apptMs - sentAt) / 36e5;
    const expiryMinutes = hoursToApptAtSend < engagedHours ? urgentExpiry : normalExpiry;
    if (now - sentAt < expiryMinutes * 60 * 1e3) {
      continue;
    }
    const { data: expired, error: expireError } = await supabase.rpc(
      "expire_senior_offer",
      { p_offer_id: row.id }
    );
    if (expireError) {
      results.push({ offer_id: row.id, ok: false, error: expireError.message });
      continue;
    }
    const payload = expired;
    if (payload?.ok && payload.request_id) {
      const helperMeta = row.helpers;
      const helperName = payload.helper_name || helperMeta?.full_name || "Helper";
      await notifySeniorOfExpiry(
        supabase,
        payload.request_id,
        helperName,
        expiryMinutes,
        helperMeta?.phone ?? null
      );
    }
    results.push({
      offer_id: row.id,
      request_id: row.request_id,
      expired: Boolean(payload?.ok),
      helper_name: payload?.helper_name,
      expiry_minutes: expiryMinutes
    });
  }
  return results;
}
async function loadRequest(supabase, requestId) {
  const { data, error } = await supabase.from("consultation_requests").select(
    "id, ref_number, status, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, offer_window_ends_at, location_missing"
  ).eq("id", requestId).maybeSingle();
  if (error) {
    console.error("loadRequest", error);
    return null;
  }
  return data;
}
async function getOfferStats(supabase, requestId) {
  const { data, error } = await supabase.from("helper_offers").select("wave_number, status, sent_at").eq("request_id", requestId);
  if (error) {
    console.error("getOfferStats", error);
    return {
      maxWave: 0,
      lastSentAt: null,
      sentCount: 0,
      declinedCount: 0,
      totalOffers: 0
    };
  }
  const rows = data ?? [];
  let maxWave = 0;
  let lastSentAt = null;
  let sentCount = 0;
  let declinedCount = 0;
  for (const row of rows) {
    maxWave = Math.max(maxWave, Number(row.wave_number) || 0);
    if (!lastSentAt || String(row.sent_at) > lastSentAt) {
      lastSentAt = String(row.sent_at);
    }
    if (row.status === "sent") sentCount += 1;
    if (row.status === "declined") declinedCount += 1;
  }
  return {
    maxWave,
    lastSentAt,
    sentCount,
    declinedCount,
    totalOffers: rows.length
  };
}
async function findSuitableHelpers(supabase, requestId, limit) {
  const { data, error } = await supabase.rpc("find_suitable_helpers", {
    p_request_id: requestId,
    p_limit: limit
  });
  if (error) {
    console.error("find_suitable_helpers", error);
    return [];
  }
  return data ?? [];
}
async function createAndSendOffers(supabase, request, helpers, waveNumber) {
  if (helpers.length === 0) {
    return { created: 0, emailed: 0 };
  }
  const prepared = [];
  for (const helper of helpers) {
    const { token, hash } = await createOfferToken();
    prepared.push({
      request_id: request.id,
      helper_id: helper.helper_id,
      wave_number: waveNumber,
      status: "sent",
      token_hash: hash,
      distance_km: helper.distance_km ?? null,
      raw_token: token,
      helper
    });
  }
  const { error } = await supabase.from("helper_offers").insert(
    prepared.map((row) => ({
      request_id: row.request_id,
      helper_id: row.helper_id,
      wave_number: row.wave_number,
      status: row.status,
      token_hash: row.token_hash,
      distance_km: row.distance_km
    }))
  );
  if (error) {
    console.error("insert helper_offers", error);
    return { created: 0, emailed: 0 };
  }
  let emailed = 0;
  for (const row of prepared) {
    const ok = await sendOfferEmail(
      request,
      row.helper,
      row.raw_token,
      row.distance_km
    );
    if (ok) emailed += 1;
  }
  return { created: prepared.length, emailed };
}
function minutesBetween(isoA, isoB) {
  return (Date.parse(isoB) - Date.parse(isoA)) / 6e4;
}
async function processRequest(supabase, request, options, settings = {}) {
  if (request.status !== "offered") {
    return { request_id: request.id, skipped: true, reason: "not_offered" };
  }
  const waveGap = settingInt(settings, "wave_gap_minutes", 15);
  const waveSize = settingInt(settings, "wave_size", 10);
  const now = /* @__PURE__ */ new Date();
  if (request.offer_window_ends_at && Date.parse(request.offer_window_ends_at) <= now.getTime()) {
    const stats2 = await getOfferStats(supabase, request.id);
    const reason = stats2.totalOffers > 0 && stats2.declinedCount === stats2.totalOffers && stats2.sentCount === 0 ? "all_declined" : "no_acceptance";
    await markNeedsSenior(supabase, request.id, reason);
    return { request_id: request.id, expired: true, reason };
  }
  if (!options.force && !options.offerNext) {
    const { data: active, error } = await supabase.rpc(
      "is_within_active_hours",
      { p_ts: now.toISOString() }
    );
    if (error) {
      console.error("is_within_active_hours", error);
      return {
        request_id: request.id,
        skipped: true,
        reason: "active_hours_check_failed"
      };
    }
    if (active === false) {
      return { request_id: request.id, skipped: true, reason: "night_pause" };
    }
  }
  const stats = await getOfferStats(supabase, request.id);
  const offerNext = Boolean(options.offerNext);
  const force = Boolean(options.force);
  if (!offerNext && !force && stats.maxWave > 0 && stats.lastSentAt) {
    const elapsed = minutesBetween(stats.lastSentAt, now.toISOString());
    if (elapsed < waveGap) {
      return {
        request_id: request.id,
        skipped: true,
        reason: "wave_interval",
        elapsed_minutes: elapsed
      };
    }
  }
  const limit = offerNext ? 1 : options.limit ?? waveSize;
  const helpers = await findSuitableHelpers(supabase, request.id, limit);
  if (helpers.length === 0) {
    if (stats.totalOffers === 0) {
      await markNeedsSenior(supabase, request.id, "no_suitable_helpers");
      return {
        request_id: request.id,
        needs_senior: true,
        reason: "no_suitable_helpers"
      };
    }
    if (stats.sentCount === 0) {
      const reason = stats.declinedCount === stats.totalOffers ? "all_declined" : "no_suitable_helpers";
      await markNeedsSenior(supabase, request.id, reason);
      return { request_id: request.id, needs_senior: true, reason };
    }
    return {
      request_id: request.id,
      skipped: true,
      reason: "waiting_on_open_offers",
      open_offers: stats.sentCount
    };
  }
  const waveNumber = options.waveNumber ?? (offerNext ? Math.max(stats.maxWave, 1) : stats.maxWave + 1);
  const sendResult = await createAndSendOffers(
    supabase,
    request,
    helpers,
    waveNumber
  );
  return {
    request_id: request.id,
    wave_number: waveNumber,
    offered: sendResult.created,
    emailed: sendResult.emailed,
    helper_ids: helpers.map((h) => h.helper_id)
  };
}
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      }
    });
  }
  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceRoleKey) {
      throw new Error("Missing Supabase environment configuration");
    }
    const supabase = createClient2(supabaseUrl, serviceRoleKey);
    let payload = {};
    try {
      payload = await req.json();
    } catch {
      payload = {};
    }
    const settings = await loadAppSettings(supabase);
    const results = [];
    const seniorExpiry = await expireStaleSeniorOffers(supabase, settings);
    if (payload.request_id) {
      const request = await loadRequest(supabase, payload.request_id);
      if (!request) {
        return jsonResponse({ error: "Request not found" }, 404);
      }
      results.push(
        await processRequest(supabase, request, {
          force: payload.force,
          offerNext: payload.offer_next,
          limit: payload.limit,
          waveNumber: payload.wave_number
        }, settings)
      );
    } else {
      const { data: offeredRows, error } = await supabase.from("consultation_requests").select(
        "id, ref_number, status, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, offer_window_ends_at, location_missing"
      ).eq("status", "offered");
      if (error) {
        throw error;
      }
      for (const row of offeredRows ?? []) {
        results.push(
          await processRequest(supabase, row, {
            force: payload.force
          }, settings)
        );
      }
    }
    return jsonResponse({
      ok: true,
      reason: payload.reason ?? "manual",
      results,
      senior_expiry: seniorExpiry
    });
  } catch (error) {
    console.error(error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return jsonResponse({ error: message }, 500);
  }
});
