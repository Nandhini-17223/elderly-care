const L=globalThis.__sb.createClient,k="+91 73399 11220",B="https://nandhini-17223.github.io/elderly-care/helper/",G="https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg",N="#1d6fd8",q="#4a9cf7",R="#1f2937",S="#6b7280",C=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],F=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function a(e){return e.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;")}function o(e,n="\u2013"){if(e==null)return n;const t=String(e).trim();return!t||t.toLowerCase()==="null"||t.toLowerCase()==="undefined"?n:t}function E(e){return o(e,"None given")}function w(e){if(!e)return null;const n=/^(\d{4})-(\d{2})-(\d{2})$/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]),i=Number(n[3]);return!r||r<1||r>12||!i||i<1||i>31?null:{year:t,month:r,day:i}}function I(e){if(!e)return null;const n=/^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]);return!Number.isInteger(t)||!Number.isInteger(r)||t<0||t>23||r<0||r>59?null:{hour24:t,minute:r}}function Y(e,n){const t=w(e),r=I(n)??{hour24:0,minute:0};return t?Date.parse(`${String(t.year).padStart(4,"0")}-${String(t.month).padStart(2,"0")}-${String(t.day).padStart(2,"0")}T${String(r.hour24).padStart(2,"0")}:${String(r.minute).padStart(2,"0")}:00+05:30`):NaN}function U(e){const n=w(e);return n?`${n.day} ${C[n.month-1]} ${n.year}`:null}function T(e){const n=w(e);return n?`${n.day} ${C[n.month-1]}`:o(e)}function y(e){const n=w(e);if(!n)return o(e);const t=new Date(Date.UTC(n.year,n.month-1,n.day)).getUTCDay();return`${F[t]}, ${n.day} ${C[n.month-1]} ${n.year}`}function M(e){const n=I(e);if(!n)return null;const t=n.hour24%12||12,r=n.hour24<12?"AM":"PM";return`${t}:${String(n.minute).padStart(2,"0")} ${r}`}function v(e,n){const t=U(e),r=M(n);return!t||!r?null:`${t}, ${r}`}function D(e){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(e))}function b(e,n,t=Date.now()){const r=Y(e,n);if(!Number.isFinite(r))return"\u2013";const i=D(t),m=D(r),d=w(i),l=w(m),c=Math.round((Date.UTC(l.year,l.month-1,l.day)-Date.UTC(d.year,d.month-1,d.day))/864e5);if(c===0){const u=r-t;if(u<=0)return"today";const h=Math.round(u/6e4);if(h<60)return`today \xB7 in ${h} minute${h===1?"":"s"}`;const x=Math.round(h/60);return`today \xB7 in ${x} hour${x===1?"":"s"}`}return c===1?"tomorrow":c>1?`in ${c} days`:c===-1?"yesterday":`${Math.abs(c)} days ago`}function J(e){if(!e)return"\u2013";const n=Date.parse(e);if(!Number.isFinite(n))return o(e);const t=new Date(n),r=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Kolkata",weekday:"short",day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit",hour12:!0}).formatToParts(t),i=P=>r.find(V=>V.type===P)?.value??"",m=i("day"),d=i("month"),l=i("year"),c=i("weekday"),u=i("hour"),h=i("minute"),x=i("dayPeriod").toUpperCase();return`${c}, ${m} ${d} ${l} \xB7 ${u}:${h} ${x}`}function _(e,n,t="primary"){const r=t==="primary"?N:"#e5e7eb",i=t==="primary"?"#ffffff":"#111827";return`<a href="${a(e)}" style="background:${r};color:${i};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${a(n)}</a>`}function j(){return`This is an automated message from ABI Parent Care. For help, call ${k}.`}function K(e){const n=o(e.ref,""),t=n?`<td align="right" style="font-size:13px;color:${S};white-space:nowrap;">Ref <strong style="color:${R};">${a(n)}</strong></td>`:"<td></td>";return`<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${e.preheader?`<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${a(e.preheader)}</div>`:""}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${N},${q});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${G}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${n?`<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${a(n)}</strong></td>`:""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${R};">
          ${e.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${S};">
          ${a(j())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`}function z(e){return["ABI Parent Care",e.ref?`Ref ${o(e.ref)}`:null,"",e.bodyText.trim(),"",j()].filter(t=>t!==null).join(`
`)}async function Q(e){const n=Deno.env.get("RESEND_API_KEY");if(!n)throw new Error("Missing RESEND_API_KEY secret");const t=Deno.env.get("EMAIL_TEST_MODE")==="true",r=Deno.env.get("TEST_EMAIL_TO")?.trim()||"",i=(e.toName?.trim()||e.to).trim(),m=t&&r?r:e.to,d=t&&r?`[To: ${i}] ${e.subject}`:e.subject,l={from:"ABI Parent Care <onboarding@resend.dev>",to:[m],subject:d,html:e.html};e.text&&e.text.trim()&&(l.text=e.text);const c=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify(l)}),u=await c.json();return c.ok?{ok:!0,status:c.status,id:typeof u?.id=="string"?u.id:void 0,to:m,subject:d,testMode:t}:(console.error("Resend error:",u),{ok:!1,status:c.status,to:m,subject:d,testMode:t,error:u})}function ee(e){const n=String(e??"").trim();return n?n.split(/\s+/)[0]??n:"there"}function A(e){return e==="female"?"Female helper":e==="male"?"Male helper":e==="no_preference"||e==="none"||!e?"No preference":o(e,"No preference")}function W(e){switch(e){case"no_acceptance":return"No helper accepted within 2 hours";case"no_suitable_helpers":return"No suitable helper nearby";case"all_declined":return"All offered helpers declined";case"short_notice":return"Booked at short notice";case"helper_dropped":return"Helper dropped out";case"helper_not_confirmed":return"Helper didn't confirm";case"helper_unavailable":return"Helper no longer available";default:return e?e.replaceAll("_"," "):"Needs senior attention"}}function f(e){return M(e)??o(e)}function $(e){return`<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${a(e)}</p>`}function p(e,n){return`<div style="margin:0 0 6px;"><strong>${a(e)}:</strong> ${a(n)}</div>`}function s(e,n){return`${e}: ${n}`}function O(e){return e?`<p style="margin:16px 0;"><img src="${a(e)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`:""}function H(e){return e.map(n=>String(n??"").trim()).filter(Boolean).join(", ")}function g(e,n,t,r,i){return{id:e,subject:n,html:K({bodyHtml:r,ref:t,preheader:n}),text:z({bodyText:i,ref:t})}}function X(e){const n=T(e.appointment_date),t=y(e.appointment_date),r=f(e.appointment_time),i=H([e.area,e.city,e.pincode])||"\u2013",m=A(e.helper_preference),d=`We've received your request \u2013 ${e.parent_name}, ${n} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Thank you for choosing ABI Parent Care. We've received your request for ${a(e.parent_name)}'s doctor appointment.</p>
    ${$("Appointment")}
    ${p("Date & time",`${t} \xB7 ${r}`)}
    ${p("Doctor/Hospital",o(e.doctor_hospital))}
    ${p("Pickup from",i)}
    ${p("Helper preference",m)}
    ${$("What happens next")}
    <p style="margin:0 0 12px;">We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.</p>
    <p style="margin:0 0 12px;">Need to change anything? Call us on ${a(k)} and quote Ref ${a(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`Thank you for choosing ABI Parent Care. We've received your request for ${e.parent_name}'s doctor appointment.`,"","APPOINTMENT",s("Date & time",`${t} \xB7 ${r}`),s("Doctor/Hospital",o(e.doctor_hospital)),s("Pickup from",i),s("Helper preference",m),"","WHAT HAPPENS NEXT","We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.","",`Need to change anything? Call us on ${k} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return g("G1",d,e.ref,l,c)}function ne(e){const n=T(e.appointment_date),t=y(e.appointment_date),r=f(e.appointment_time),i=`Update on ${e.parent_name}'s appointment \u2013 ${n} \xB7 Ref ${e.ref}`,m=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${a(e.parent_name)}'s appointment on ${a(t)} at ${a(r)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${a(k)} and quote Ref ${a(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,d=[`Dear ${e.booking_person_name},`,"",`A quick update: our care team is personally arranging a suitable helper for ${e.parent_name}'s appointment on ${t} at ${r}.`,"","You don't need to do anything. We'll email you the helper's details shortly.","",`If you'd like to speak to us, call ${k} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return g("G2",i,e.ref,m,d)}function te(e){const n=T(e.appointment_date),t=y(e.appointment_date),r=f(e.appointment_time),i=b(e.appointment_date,e.appointment_time),m=H([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",d=`Helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name}, ${n} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news \u2013 ${a(e.helper_full_name)} will accompany ${a(e.parent_name)} to the appointment.</p>
    ${O(e.helper_photo_url)}
    ${$("Your helper")}
    ${p("Name",e.helper_full_name)}
    ${p("Phone",o(e.helper_phone))}
    ${p("Verified","ID and background checked by ABI Parent Care")}
    ${$("Appointment")}
    ${p("Date & time",`${t} \xB7 ${r} (${i})`)}
    ${p("Doctor/Hospital",o(e.doctor_hospital))}
    ${p("Pickup from",m)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${a(e.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`Good news \u2013 ${e.helper_full_name} will accompany ${e.parent_name} to the appointment.`,"","YOUR HELPER",s("Name",e.helper_full_name),s("Phone",o(e.helper_phone)),s("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT",s("Date & time",`${t} \xB7 ${r} (${i})`),s("Doctor/Hospital",o(e.doctor_hospital)),s("Pickup from",m),"",`For safety, please share this with ${e.parent_name} so they know who to expect.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return g("G3",d,e.ref,l,c)}function re(e){const n=T(e.appointment_date),t=y(e.appointment_date),r=f(e.appointment_time),i=`Change of helper for ${e.parent_name} \u2013 ${n} \xB7 Ref ${e.ref}`,m=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${a(e.old_helper_first_name)} is unable to attend ${a(e.parent_name)}'s appointment on ${a(t)} at ${a(r)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${a(k)} and quote Ref ${a(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,d=[`Dear ${e.booking_person_name},`,"",`We're sorry \u2013 ${e.old_helper_first_name} is unable to attend ${e.parent_name}'s appointment on ${t} at ${r}.`,"","Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.","",`The appointment itself is unchanged. If you have concerns, call ${k} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return g("G4",i,e.ref,m,d)}function ae(e){const n=y(e.appointment_date),t=f(e.appointment_time),r=b(e.appointment_date,e.appointment_time),i=`New helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name} \xB7 Ref ${e.ref}`,m=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} will now accompany ${a(e.parent_name)} to the appointment, in place of ${a(e.old_helper_first_name)}.</p>
    ${O(e.helper_photo_url)}
    ${$("Your new helper")}
    ${p("Name",e.helper_full_name)}
    ${p("Phone",o(e.helper_phone))}
    ${p("Verified","ID and background checked by ABI Parent Care")}
    ${$("Appointment (unchanged)")}
    ${p("Date & time",`${n} \xB7 ${t} (${r})`)}
    ${p("Doctor/Hospital",o(e.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,d=[`Dear ${e.booking_person_name},`,"",`${e.helper_full_name} will now accompany ${e.parent_name} to the appointment, in place of ${e.old_helper_first_name}.`,"","YOUR NEW HELPER",s("Name",e.helper_full_name),s("Phone",o(e.helper_phone)),s("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT (unchanged)",s("Date & time",`${n} \xB7 ${t} (${r})`),s("Doctor/Hospital",o(e.doctor_hospital)),"","Thank you for your patience.","","Warm regards,","The ABI Parent Care team"].join(`
`);return g("G5",i,e.ref,m,d)}function ie(e){const n=T(e.appointment_date),t=y(e.appointment_date),r=f(e.appointment_time),i=b(e.appointment_date,e.appointment_time),m=e.distance_km==null||Number.isNaN(Number(e.distance_km))?"\u2013":String(Math.round(Number(e.distance_km)*10)/10),d=o(e.area),l=`New visit near you \u2013 ${n}, ${r} \xB7 ${d} (${m} km)`,c=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${p("When",`${t} \xB7 ${r} (${i})`)}
    ${p("Pickup area",`${d}, ${o(e.pincode)} \xB7 about ${m} km from you`)}
    ${p("Hospital",o(e.doctor_hospital))}
    ${p("Patient",`Age ${e.parent_age}`)}
    <p style="margin:22px 0;">
      ${_(e.accept_url,"Accept","primary")}
      ${_(e.decline_url,"Decline","secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,u=[`Hi ${e.helper_first_name},`,"","A new hospital visit is available near you. The first helper to accept gets it.","",s("When",`${t} \xB7 ${r} (${i})`),s("Pickup area",`${d}, ${o(e.pincode)} \xB7 about ${m} km from you`),s("Hospital",o(e.doctor_hospital)),s("Patient",`Age ${e.parent_age}`),"",`Accept: ${e.accept_url}`,`Decline: ${e.decline_url}`,"","The patient's name, full address and family contact are shared after you accept.","",`Ref ${e.ref}`].join(`
`);return g("H1",l,e.ref,c,u)}function oe(e){const n=T(e.appointment_date),t=y(e.appointment_date),r=f(e.appointment_time),i=b(e.appointment_date,e.appointment_time),m=H([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",d=`Confirmed: ${e.parent_name}, ${n} ${r} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${$("Patient")}
    ${p("Name",`${e.parent_name}, ${e.parent_age}`)}
    ${p("Pickup",m)}
    ${p("Landmark",o(e.landmark))}
    <p style="margin:10px 0 16px;">${_(e.maps_url,"Open in Google Maps","secondary")}</p>
    ${$("Appointment")}
    ${p("When",`${t} \xB7 ${r} (${i})`)}
    ${p("Hospital",o(e.doctor_hospital))}
    ${$("Family contact")}
    <p style="margin:0 0 12px;">${a(e.booking_person_name)} (${a(o(e.relationship))}) \xB7 ${a(o(e.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${_(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,c=[`Hi ${e.helper_first_name},`,"","This visit is yours. Thank you!","","PATIENT",s("Name",`${e.parent_name}, ${e.parent_age}`),s("Pickup",m),s("Landmark",o(e.landmark)),`Open in Google Maps: ${e.maps_url}`,"","APPOINTMENT",s("When",`${t} \xB7 ${r} (${i})`),s("Hospital",o(e.doctor_hospital)),"","FAMILY CONTACT",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`,"","We'll remind you 12 hours and 6 hours before.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return g("H2",d,e.ref,l,c)}function se(e){const n=y(e.appointment_date),t=f(e.appointment_time),r=b(e.appointment_date,e.appointment_time),i=`Reminder: visit ${r} ${t} \u2013 ${e.parent_name}, ${o(e.area)}`,m=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${a(e.parent_name)} ${a(r)}.</p>
    ${p("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${a(o(e.full_address))} \xB7 <a href="${a(e.maps_url)}">Open in Google Maps</a></div>
    ${p("Hospital",o(e.doctor_hospital))}
    ${p("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${_(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,d=[`Hi ${e.helper_first_name},`,"",`A reminder that you're accompanying ${e.parent_name} ${r}.`,"",s("When",`${n} \xB7 ${t}`),s("Pickup",`${o(e.full_address)} \xB7 ${e.maps_url}`),s("Hospital",o(e.doctor_hospital)),s("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"","Plan to reach the pickup address 15 minutes early.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return g("H3",i,e.ref,m,d)}function pe(e){const n=y(e.appointment_date),t=f(e.appointment_time),r=b(e.appointment_date,e.appointment_time),i=`Please confirm: ${e.parent_name} at ${t} \u2013 ${r}`,m=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${a(e.parent_name)} is ${a(r)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${_(e.confirm_url,"I'll be there","primary")}
      ${_(e.cant_make_it_url,"Can't make it","secondary")}
    </p>
    ${p("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${a(o(e.full_address))} \xB7 <a href="${a(e.maps_url)}">Open in Google Maps</a></div>
    ${p("Hospital",o(e.doctor_hospital))}
    ${p("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,d=[`Hi ${e.helper_first_name},`,"",`Your visit with ${e.parent_name} is ${r}. Please confirm you'll be there.`,"",`I'll be there: ${e.confirm_url}`,`Can't make it: ${e.cant_make_it_url}`,"",s("When",`${n} \xB7 ${t}`),s("Pickup",`${o(e.full_address)} \xB7 ${e.maps_url}`),s("Hospital",o(e.doctor_hospital)),s("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"","If we don't hear from you, our care team will call you.","",`Ref ${e.ref}`].join(`
`);return g("H4",i,e.ref,m,d)}function le(e){const n=e.helper_app_link||B,t="Welcome to ABI Parent Care \u2013 your helper app login",r=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${p("App link",n)}
    ${p("Login email",e.helper_email)}
    ${p("Password","the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${_(n,"Open helper app","primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${a(k)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `,i=[`Hi ${e.helper_first_name},`,"","Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.","",s("App link",n),s("Login email",e.helper_email),s("Password","the temporary password given to you by your manager"),"","You'll be asked to set your own password the first time you log in.","",'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',"",`Questions? Call ${k}.`,"","The ABI Parent Care team"].join(`
`);return g("H5",t,null,r,i)}function me(e){const n=y(e.appointment_date),t=f(e.appointment_time),r=b(e.appointment_date,e.appointment_time),i=`URGENT \u2013 Helper needed in ${e.time_remaining} \xB7 ${e.parent_name} (${e.parent_age}) \xB7 ${t} \xB7 ${o(e.area)} \xB7 ${e.ref}`,m=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${a(r)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${$("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${$("Visit details")}
    ${p("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${p("When",`${n} \xB7 ${t} (${r})`)}
    ${p("Pickup",H([e.area,e.city,e.pincode])||"\u2013")}
    ${p("Hospital",o(e.doctor_hospital))}
    ${p("Preference",A(e.helper_preference))}
    ${p("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${_(e.assign_url,"Assign a helper","primary")}</p>
  `,d=[`Hi ${e.manager_first_name},`,"",`A booking has come in for ${r}. There isn't time to send offers automatically, so please assign a helper now.`,"","WHAT TO DO NOW","Open the request, pick an available helper and send them an offer.","","VISIT DETAILS",s("Patient",`${e.parent_name}, ${e.parent_age}`),s("When",`${n} \xB7 ${t} (${r})`),s("Pickup",H([e.area,e.city,e.pincode])||"\u2013"),s("Hospital",o(e.doctor_hospital)),s("Preference",A(e.helper_preference)),s("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"",`Assign a helper: ${e.assign_url}`].join(`
`);return g("M1",i,e.ref,m,d)}function de(e){const t=`${e.items.length} request(s) need a helper \u2013 ${e.digest_time}`,r=e.items.map((l,c)=>{const u=T(l.appointment_date),h=f(l.appointment_time),x=b(l.appointment_date,l.appointment_time);return`
      <div style="margin:0 0 16px;padding:12px 0;border-bottom:1px solid #e5e7eb;">
        <p style="margin:0 0 6px;"><strong>${c+1}. ${a(l.ref)}</strong> \xB7 ${a(l.parent_name)} (${l.parent_age}) \xB7 ${a(u)} ${a(h)} (${a(x)})</p>
        <p style="margin:0 0 6px;">${a(o(l.area))} ${a(o(l.pincode))} \xB7 Preference: ${a(A(l.helper_preference))}</p>
        <p style="margin:0 0 10px;">Why: ${a(W(l.reason))}</p>
        <p style="margin:0;">${_(l.assign_url,"Assign","primary")}</p>
      </div>
    `}).join(""),i=e.items.map((l,c)=>{const u=T(l.appointment_date),h=f(l.appointment_time),x=b(l.appointment_date,l.appointment_time);return[`${c+1}. ${l.ref} \xB7 ${l.parent_name} (${l.parent_age}) \xB7 ${u} ${h} (${x})`,`   ${o(l.area)} ${o(l.pincode)} \xB7 Preference: ${A(l.helper_preference)}`,`   Why: ${W(l.reason)}`,`   Assign: ${l.assign_url}`].join(`
`)}).join(`

`),m=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">These requests still need a helper. The soonest appointment is first.</p>
    ${r}
    <p style="margin:22px 0;">${_(e.open_all_url,"Open all in the portal","primary")}</p>
  `,d=[`Hi ${e.manager_first_name},`,"","These requests still need a helper. The soonest appointment is first.","",i,"",`Open all in the portal: ${e.open_all_url}`].join(`
`);return g("M2",t,null,m,d)}function ce(e){const n=T(e.appointment_date),t=y(e.appointment_date),r=f(e.appointment_time),i=b(e.appointment_date,e.appointment_time),m=E(e.decline_reason),d=`${e.helper_full_name} declined \u2013 please assign another \xB7 ${e.parent_name}, ${n} ${r} \xB7 ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} declined the visit you offered.</p>
    ${p("Reason given",m)}
    <p style="margin:12px 0;">Appointment: ${a(t)} \xB7 ${a(r)} (${a(i)}) \xB7 ${a(o(e.area))}</p>
    <p style="margin:22px 0;">${_(e.assign_url,"Choose another helper","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} declined the visit you offered.`,s("Reason given",m),"",`Appointment: ${t} \xB7 ${r} (${i}) \xB7 ${o(e.area)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return g("M3",d,e.ref,l,c)}function ue(e){const n=y(e.appointment_date),t=f(e.appointment_time),r=b(e.appointment_date,e.appointment_time),i=`No response from ${e.helper_full_name} \u2013 please assign another \xB7 ${e.parent_name} \xB7 ${e.ref}`,m=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} didn't respond within ${a(e.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${a(n)} \xB7 ${a(t)} (${a(r)}) \xB7 ${a(o(e.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${a(o(e.helper_phone))}</p>
    <p style="margin:22px 0;">${_(e.assign_url,"Choose another helper","primary")}</p>
  `,d=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} didn't respond within ${e.expiry_window}, so the offer has been withdrawn.`,"",`Appointment: ${n} \xB7 ${t} (${r}) \xB7 ${o(e.area)}`,`Helper phone (if you'd like to call): ${o(e.helper_phone)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return g("M4",i,e.ref,m,d)}function ge(e){const n=y(e.appointment_date),t=f(e.appointment_time),r=b(e.appointment_date,e.appointment_time),i=E(e.dropout_reason),m=`URGENT \u2013 ${e.helper_full_name} can't attend \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,d=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} has said they can't attend this visit.</p>
    ${p("Reason given",i)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${$("Visit details")}
    ${p("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${p("When",`${n} \xB7 ${t} (${r})`)}
    ${p("Pickup",H([e.area,e.city,e.pincode])||"\u2013")}
    ${p("Hospital",o(e.doctor_hospital))}
    ${p("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${_(e.assign_url,"Assign a replacement","primary")}</p>
  `,l=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has said they can't attend this visit.`,s("Reason given",i),"","The family has been told we're arranging a replacement. Please assign a new helper now.","","VISIT DETAILS",s("Patient",`${e.parent_name}, ${e.parent_age}`),s("When",`${n} \xB7 ${t} (${r})`),s("Pickup",H([e.area,e.city,e.pincode])||"\u2013"),s("Hospital",o(e.doctor_hospital)),s("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"",`Assign a replacement: ${e.assign_url}`].join(`
`);return g("M5",m,e.ref,d,l)}function Z(e){const n=y(e.appointment_date),t=f(e.appointment_time),r=b(e.appointment_date,e.appointment_time),i=J(e.assigned_at),m=e.urgent?`URGENT \u2013 visit in 1 hour, ${e.helper_full_name} still not confirmed \xB7 ${e.parent_name} \xB7 ${e.ref}`:`Action needed \u2013 ${e.helper_full_name} hasn't confirmed \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,d=e.urgent?`The visit starts in about 1 hour and ${a(e.helper_full_name)} still hasn't confirmed. Please resolve this now.`:`${a(e.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,l=e.urgent?`The visit starts in about 1 hour and ${e.helper_full_name} still hasn't confirmed. Please resolve this now.`:`${e.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,c=e.urgent?`<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${a(e.helper_first_name)}: ${a(o(e.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".</li>
      </ol>`:`${$("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${a(e.helper_first_name)}: ${a(o(e.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone \u2013 nothing else happens, or</li>
            <li>Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`,u=e.urgent?[`1. Call ${e.helper_first_name}: ${o(e.helper_phone)}`,'2. Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".'].join(`
`):["WHAT TO DO NOW",`1. Call ${e.helper_first_name}: ${o(e.helper_phone)}`,"2. Then in the portal, choose:","   \u2022 Helper confirmed by phone \u2013 nothing else happens, or","   \u2022 Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper"].join(`
`),h=`
    ${$("Visit details")}
    ${p("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${p("When",`${n} \xB7 ${t} (${r})`)}
    ${p("Pickup",H([e.area,e.city,e.pincode])||"\u2013")}
    ${p("Hospital",o(e.doctor_hospital))}
    ${$("Helper status")}
    ${p("Assigned",i)}
    ${p("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`)}
    ${p("Confirmed","Not yet")}
  `,x=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${d}</p>
    ${c}
    ${h}
    <p style="margin:22px 0;">${_(e.open_url,"Open request","primary")}</p>
  `,P=[`Hi ${e.manager_first_name},`,"",l,"",u,"","VISIT DETAILS",s("Patient",`${e.parent_name}, ${e.parent_age}`),s("When",`${n} \xB7 ${t} (${r})`),s("Pickup",H([e.area,e.city,e.pincode])||"\u2013"),s("Hospital",o(e.doctor_hospital)),"","HELPER STATUS",s("Assigned",i),s("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`),s("Confirmed","Not yet"),"",`Open request: ${e.open_url}`].join(`
`);return g(e.urgent?"M7":"M6",m,e.ref,x,P)}function _e(e){return Z({...e,urgent:!0})}function he(e){const n=`Driving licence ${e.expiry_phrase} \u2013 ${e.helper_full_name}`,t=e.expired?`<p style="margin:0 0 12px;">If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).</p>`:'<p style="margin:0 0 12px;">If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.</p>',r=e.expired?`If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).`:"If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.",i=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)}'s driving licence ${a(e.expiry_phrase)} (${a(e.dl_expiry)}).</p>
    ${t}
    <p style="margin:22px 0;">${_(e.open_url,"Open helper profile","primary")}</p>
  `,m=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name}'s driving licence ${e.expiry_phrase} (${e.dl_expiry}).`,"",r,"",`Open helper profile: ${e.open_url}`].join(`
`);return g("M8",n,null,i,m)}function fe(e){const n=`Profile change request \u2013 ${e.helper_full_name}`,t=E(e.request_note),r=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} has asked to update their profile:</p>
    <p style="margin:0 0 12px;padding:12px 14px;background:#f3f6fb;border-radius:8px;font-style:italic;">"${a(t)}"</p>
    <p style="margin:0 0 12px;">Please review and update their details in the portal if appropriate.</p>
    <p style="margin:22px 0;">${_(e.open_url,"Open helper profile","primary")}</p>
  `,i=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has asked to update their profile:`,"",`"${t}"`,"","Please review and update their details in the portal if appropriate.","",`Open helper profile: ${e.open_url}`].join(`
`);return g("M9",n,null,r,i)}const $e={accept_confirm:{title:"Accept this visit?",message:"{{appointment_date_short}} \xB7 {{appointment_time}} \xB7 {{area}}. Tap Confirm to take this visit.",button:"Confirm"},accepted:{title:"This visit is yours!",message:"We've emailed you the full details. Thank you, {{helper_first_name}}."},already_taken:{title:"Already taken",message:"Another helper accepted this visit first. Thank you for responding quickly."},helper_engaged:{title:"You're already booked",message:"You have another visit around this time, so we can't assign this one to you."},declined:{title:"Thanks for letting us know",message:"We've offered this visit to another helper."},confirmed:{title:"See you there!",message:"Thanks for confirming. The family is counting on you."},cant_make_it_confirm:{title:"Can't make this visit?",message:"Tell us why (optional), then tap Confirm. We'll arrange a replacement.",button:"Confirm"},cant_make_it_done:{title:"Thanks for telling us",message:"Our care team will arrange a replacement."},link_inactive:{title:"This link is no longer active",message:"The visit may have been assigned, cancelled or already passed. Please contact your manager if you need help."}};function ye(e,n){return e.replace(/\{\{(\w+)\}\}/g,(t,r)=>o(n[r],""))}Deno.serve(async e=>{if(e.method!=="POST")return new Response(JSON.stringify({error:"Method not allowed"}),{status:405,headers:{"Content-Type":"application/json"}});try{const n=Deno.env.get("SUPABASE_URL"),t=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");if(!n||!t)throw new Error("Missing Supabase environment configuration");const r=await e.json();let i="record"in r&&r.record?r.record:"email"in r&&"id"in r?r:void 0;if(!i?.id||!i.email||!i.booking_person_name)return new Response(JSON.stringify({error:"Invalid consultation payload"}),{status:400,headers:{"Content-Type":"application/json"}});const m=L(n,t),{data:d,error:l}=await m.from("consultation_requests").select("id, ref_number, parent_name, parent_age, city, area, pincode, booking_person_name, email, appointment_date, appointment_time, doctor_hospital, helper_preference").eq("id",i.id).maybeSingle();if(l)throw l;d&&(i={...i,...d});const c=X({ref:String(i.ref_number??"\u2013"),booking_person_name:i.booking_person_name,parent_name:i.parent_name,appointment_date:String(i.appointment_date??""),appointment_time:String(i.appointment_time??""),doctor_hospital:String(i.doctor_hospital??""),area:i.area,city:i.city,pincode:i.pincode,helper_preference:i.helper_preference}),u=await Q({to:i.email,toName:i.booking_person_name,subject:c.subject,html:c.html,text:c.text});if(!u.ok)return new Response(JSON.stringify({error:"Failed to send email",details:u.error}),{status:502,headers:{"Content-Type":"application/json"}});const{error:h}=await m.from("consultation_requests").update({email_sent_at:new Date().toISOString()}).eq("id",i.id);return h?(console.error("Failed to update email_sent_at:",h),new Response(JSON.stringify({error:"Email sent but failed to update email_sent_at",details:h.message,email:u}),{status:500,headers:{"Content-Type":"application/json"}})):new Response(JSON.stringify({ok:!0,email:u}),{status:200,headers:{"Content-Type":"application/json"}})}catch(n){console.error(n);const t=n instanceof Error?n.message:"Unknown error";return new Response(JSON.stringify({error:t}),{status:500,headers:{"Content-Type":"application/json"}})}});
