// auto-bundled for deploy
import { createClient, type SupabaseClient } from "jsr:@supabase/supabase-js@2";
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import type { SupabaseClient } from "jsr:@supabase/supabase-js@2";
import { createClient, type SupabaseClient, type User } from "jsr:@supabase/supabase-js@2";

// ---- _shared/email.ts ----
type SendEmailArgs = {
  to: string;
  toName?: string | null;
  subject: string;
  html: string;
  text?: string;
};

type SendEmailResult = {
  ok: boolean;
  status: number;
  id?: string;
  to: string;
  subject: string;
  testMode: boolean;
  error?: unknown;
};

const SUPPORT_PHONE = "+91 73399 11220";
const HELPER_APP_LINK =
  "https://nandhini-17223.github.io/elderly-care/helper/";
const LOGO_URL =
  "https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg";
const BRAND_PRIMARY = "#1d6fd8";
const BRAND_ACCENT = "#4a9cf7";
const BRAND_TEXT = "#1f2937";
const BRAND_MUTED = "#6b7280";

const MONTHS_SHORT = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];
const WEEKDAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

/** Show a dash (or custom fallback) instead of blank/null/undefined. */
function displayValue(
  value: string | number | null | undefined,
  fallback = "–",
): string {
  if (value === null || value === undefined) return fallback;
  const text = String(value).trim();
  if (!text || text.toLowerCase() === "null" || text.toLowerCase() === "undefined") {
    return fallback;
  }
  return text;
}

function displayOrNone(
  value: string | number | null | undefined,
): string {
  return displayValue(value, "None given");
}

function parseDateParts(appointmentDate?: string | null): {
  year: number;
  month: number;
  day: number;
} | null {
  if (!appointmentDate) return null;
  const dateMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(appointmentDate.trim());
  if (!dateMatch) return null;
  const year = Number(dateMatch[1]);
  const month = Number(dateMatch[2]);
  const day = Number(dateMatch[3]);
  if (!month || month < 1 || month > 12 || !day || day < 1 || day > 31) {
    return null;
  }
  return { year, month, day };
}

function parseTimeParts(appointmentTime?: string | null): {
  hour24: number;
  minute: number;
} | null {
  if (!appointmentTime) return null;
  const timeMatch = /^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(
    appointmentTime.trim(),
  );
  if (!timeMatch) return null;
  const hour24 = Number(timeMatch[1]);
  const minute = Number(timeMatch[2]);
  if (
    !Number.isInteger(hour24) ||
    !Number.isInteger(minute) ||
    hour24 < 0 ||
    hour24 > 23 ||
    minute < 0 ||
    minute > 59
  ) {
    return null;
  }
  return { hour24, minute };
}

/** Appointment instant as UTC ms interpreting wall time in Asia/Kolkata. */
function appointmentMsIst(
  appointmentDate?: string | null,
  appointmentTime?: string | null,
): number {
  const d = parseDateParts(appointmentDate);
  const t = parseTimeParts(appointmentTime) ?? { hour24: 0, minute: 0 };
  if (!d) return NaN;
  return Date.parse(
    `${String(d.year).padStart(4, "0")}-${String(d.month).padStart(2, "0")}-${
      String(d.day).padStart(2, "0")
    }T${String(t.hour24).padStart(2, "0")}:${
      String(t.minute).padStart(2, "0")
    }:00+05:30`,
  );
}

/** "13 Nov 2026" — kept for older callers; prefer formatAppointmentDateShort. */
function formatAppointmentDate(
  appointmentDate?: string | null,
): string | null {
  const d = parseDateParts(appointmentDate);
  if (!d) return null;
  return `${d.day} ${MONTHS_SHORT[d.month - 1]} ${d.year}`;
}

/** {{appointment_date_short}} → "13 Nov" */
function formatAppointmentDateShort(
  appointmentDate?: string | null,
): string {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  return `${d.day} ${MONTHS_SHORT[d.month - 1]}`;
}

/** {{appointment_date_long}} → "Thu, 13 Nov 2026" */
function formatAppointmentDateLong(
  appointmentDate?: string | null,
): string {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  const weekday = new Date(Date.UTC(d.year, d.month - 1, d.day)).getUTCDay();
  return `${WEEKDAYS_SHORT[weekday]}, ${d.day} ${MONTHS_SHORT[d.month - 1]} ${d.year}`;
}

/** {{appointment_time}} → "10:00 AM" */
function formatAppointmentTime(
  appointmentTime?: string | null,
): string | null {
  const t = parseTimeParts(appointmentTime);
  if (!t) return null;
  const hour12 = t.hour24 % 12 || 12;
  const ampm = t.hour24 < 12 ? "AM" : "PM";
  return `${hour12}:${String(t.minute).padStart(2, "0")} ${ampm}`;
}

function formatAppointmentDateTime(
  appointmentDate?: string | null,
  appointmentTime?: string | null,
): string | null {
  const datePart = formatAppointmentDate(appointmentDate);
  const timePart = formatAppointmentTime(appointmentTime);
  if (!datePart || !timePart) return null;
  return `${datePart}, ${timePart}`;
}

function istYmd(ms: number): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(ms));
}

/**
 * {{relative_time}} examples:
 * "today · in 1 hour", "tomorrow", "in 3 days"
 */
function formatRelativeTime(
  appointmentDate?: string | null,
  appointmentTime?: string | null,
  nowMs: number = Date.now(),
): string {
  const appt = appointmentMsIst(appointmentDate, appointmentTime);
  if (!Number.isFinite(appt)) return "–";

  const today = istYmd(nowMs);
  const apptDay = istYmd(appt);
  const todayParts = parseDateParts(today)!;
  const apptParts = parseDateParts(apptDay)!;
  const dayDiff = Math.round(
    (Date.UTC(apptParts.year, apptParts.month - 1, apptParts.day) -
      Date.UTC(todayParts.year, todayParts.month - 1, todayParts.day)) /
      86400000,
  );

  if (dayDiff === 0) {
    const deltaMs = appt - nowMs;
    if (deltaMs <= 0) return "today";
    const totalMinutes = Math.round(deltaMs / 60000);
    if (totalMinutes < 60) {
      return `today · in ${totalMinutes} minute${totalMinutes === 1 ? "" : "s"}`;
    }
    const hours = Math.round(totalMinutes / 60);
    return `today · in ${hours} hour${hours === 1 ? "" : "s"}`;
  }
  if (dayDiff === 1) return "tomorrow";
  if (dayDiff > 1) return `in ${dayDiff} days`;
  if (dayDiff === -1) return "yesterday";
  return `${Math.abs(dayDiff)} days ago`;
}

function formatIstDateTime(iso?: string | null): string {
  if (!iso) return "–";
  const ms = Date.parse(iso);
  if (!Number.isFinite(ms)) return displayValue(iso);
  const d = new Date(ms);
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata",
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).formatToParts(d);
  const get = (type: string) =>
    parts.find((p) => p.type === type)?.value ?? "";
  const day = get("day");
  const month = get("month");
  const year = get("year");
  const weekday = get("weekday");
  const hour = get("hour");
  const minute = get("minute");
  const dayPeriod = get("dayPeriod").toUpperCase();
  return `${weekday}, ${day} ${month} ${year} · ${hour}:${minute} ${dayPeriod}`;
}

function emailButtonHtml(
  href: string,
  label: string,
  variant: "primary" | "secondary" = "primary",
): string {
  const bg = variant === "primary" ? BRAND_PRIMARY : "#e5e7eb";
  const color = variant === "primary" ? "#ffffff" : "#111827";
  return `<a href="${escapeHtml(href)}" style="background:${bg};color:${color};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${escapeHtml(label)}</a>`;
}

function emailFooterText(): string {
  return `This is an automated message from ABI Parent Care. For help, call ${SUPPORT_PHONE}.`;
}

function wrapEmailHtml(args: {
  bodyHtml: string;
  ref?: string | null;
  preheader?: string;
}): string {
  const ref = displayValue(args.ref, "");
  const refHtml = ref
    ? `<td align="right" style="font-size:13px;color:${BRAND_MUTED};white-space:nowrap;">Ref <strong style="color:${BRAND_TEXT};">${escapeHtml(ref)}</strong></td>`
    : `<td></td>`;
  const preheader = args.preheader
    ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${escapeHtml(args.preheader)}</div>`
    : "";

  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${preheader}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${BRAND_PRIMARY},${BRAND_ACCENT});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${LOGO_URL}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${
    ref
      ? `<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${escapeHtml(ref)}</strong></td>`
      : ""
  }
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${BRAND_TEXT};">
          ${args.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${BRAND_MUTED};">
          ${escapeHtml(emailFooterText())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`;
}

function wrapEmailText(args: {
  bodyText: string;
  ref?: string | null;
}): string {
  const lines = [
    "ABI Parent Care",
    args.ref ? `Ref ${displayValue(args.ref)}` : null,
    "",
    args.bodyText.trim(),
    "",
    emailFooterText(),
  ].filter((line) => line !== null);
  return lines.join("\n");
}

/**
 * Shared Resend sender used by all edge functions.
 * If EMAIL_TEST_MODE === 'true', every email goes to TEST_EMAIL_TO with
 * subject prefixed "[To: <real recipient name/email>]".
 */
async function sendEmail(args: SendEmailArgs): Promise<SendEmailResult> {
  const resendApiKey = Deno.env.get("RESEND_API_KEY");
  if (!resendApiKey) {
    throw new Error("Missing RESEND_API_KEY secret");
  }

  const testMode = Deno.env.get("EMAIL_TEST_MODE") === "true";
  const testTo = Deno.env.get("TEST_EMAIL_TO")?.trim() || "";
  const realRecipientLabel = (args.toName?.trim() || args.to).trim();

  const finalTo = testMode && testTo ? testTo : args.to;
  const finalSubject =
    testMode && testTo
      ? `[To: ${realRecipientLabel}] ${args.subject}`
      : args.subject;

  const payload: Record<string, unknown> = {
    from: "ABI Parent Care <onboarding@resend.dev>",
    to: [finalTo],
    subject: finalSubject,
    html: args.html,
  };
  if (args.text && args.text.trim()) {
    payload.text = args.text;
  }

  const emailResponse = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${resendApiKey}`,
    },
    body: JSON.stringify(payload),
  });

  const emailResult = await emailResponse.json();
  if (!emailResponse.ok) {
    console.error("Resend error:", emailResult);
    return {
      ok: false,
      status: emailResponse.status,
      to: finalTo,
      subject: finalSubject,
      testMode,
      error: emailResult,
    };
  }

  return {
    ok: true,
    status: emailResponse.status,
    id: typeof emailResult?.id === "string" ? emailResult.id : undefined,
    to: finalTo,
    subject: finalSubject,
    testMode,
  };
}

// ---- _shared/secrets.ts ----
/**
 * Prefer Deno env secrets; fall back to vault via get_app_secret RPC
 * so local/test deploys work before dashboard secrets are set.
 */
async function resolveSecret(
  supabase: SupabaseClient,
  name: string,
): Promise<string | null> {
  const fromEnv = Deno.env.get(name)?.trim() || "";
  if (fromEnv) return fromEnv;

  const { data, error } = await supabase.rpc("get_app_secret", {
    p_name: name,
  });
  if (error) {
    console.error(`get_app_secret(${name}) failed`, error);
    return null;
  }
  const value = typeof data === "string" ? data.trim() : "";
  return value || null;
}

/** Constant-time string compare (length-leaking only on mismatch length). */
function timingSafeEqual(a: string, b: string): boolean {
  const enc = new TextEncoder();
  const aa = enc.encode(a);
  const bb = enc.encode(b);
  const len = Math.max(aa.length, bb.length);
  let mismatch = aa.length === bb.length ? 0 : 1;
  for (let i = 0; i < len; i++) {
    mismatch |= (aa[i] ?? 0) ^ (bb[i] ?? 0);
  }
  return mismatch === 0;
}

// ---- _shared/templates.ts ----
/**
 * Approved ABI Parent Care email templates (G1–G5, H1–H5, M1–M9).
 * Wording matches email-templates.md — edit here to change copy.
 */
type EmailContent = {
  id: string;
  subject: string;
  html: string;
  text: string;
};

function firstName(fullName: string | null | undefined): string {
  const trimmed = String(fullName ?? "").trim();
  if (!trimmed) return "there";
  return trimmed.split(/\s+/)[0] ?? trimmed;
}

function preferenceLabel(value: string | null | undefined): string {
  if (value === "female") return "Female helper";
  if (value === "male") return "Male helper";
  if (value === "no_preference" || value === "none" || !value) {
    return "No preference";
  }
  return displayValue(value, "No preference");
}

/** Plain-language reasons for M2 (and portal). */
function reasonPlain(reason: string | null | undefined): string {
  switch (reason) {
    case "no_acceptance":
      return "No helper accepted within 2 hours";
    case "no_suitable_helpers":
      return "No suitable helper nearby";
    case "all_declined":
      return "All offered helpers declined";
    case "short_notice":
      return "Booked at short notice";
    case "helper_dropped":
      return "Helper dropped out";
    case "helper_not_confirmed":
      return "Helper didn't confirm";
    case "helper_unavailable":
      return "Helper no longer available";
    default:
      return reason ? reason.replaceAll("_", " ") : "Needs senior attention";
  }
}

function timeLabel(appointmentTime?: string | null): string {
  return formatAppointmentTime(appointmentTime) ?? displayValue(appointmentTime);
}

function sectionHeading(label: string): string {
  return `<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${escapeHtml(label)}</p>`;
}

function line(label: string, value: string): string {
  return `<div style="margin:0 0 6px;"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</div>`;
}

function textLine(label: string, value: string): string {
  return `${label}: ${value}`;
}

function helperPhotoBlock(photoUrl?: string | null): string {
  if (!photoUrl) return "";
  return `<p style="margin:16px 0;"><img src="${escapeHtml(photoUrl)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`;
}

function joinAddress(parts: Array<string | null | undefined>): string {
  return parts.map((p) => String(p ?? "").trim()).filter(Boolean).join(", ");
}

function build(
  id: string,
  subject: string,
  ref: string | null | undefined,
  bodyHtml: string,
  bodyText: string,
): EmailContent {
  return {
    id,
    subject,
    html: wrapEmailHtml({ bodyHtml, ref, preheader: subject }),
    text: wrapEmailText({ bodyText, ref }),
  };
}

// ---------------------------------------------------------------------------
// Guardian emails
// ---------------------------------------------------------------------------

type G1Vars = {
  ref: string;
  booking_person_name: string;
  parent_name: string;
  appointment_date: string;
  appointment_time: string;
  doctor_hospital: string;
  area?: string | null;
  city?: string | null;
  pincode?: string | null;
  helper_preference?: string | null;
};

function templateG1(v: G1Vars): EmailContent {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const pickup = joinAddress([v.area, v.city, v.pincode]) || "–";
  const pref = preferenceLabel(v.helper_preference);
  const subject =
    `We've received your request – ${v.parent_name}, ${dateShort} · Ref ${v.ref}`;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Thank you for choosing ABI Parent Care. We've received your request for ${escapeHtml(v.parent_name)}'s doctor appointment.</p>
    ${sectionHeading("Appointment")}
    ${line("Date & time", `${dateLong} · ${time}`)}
    ${line("Doctor/Hospital", displayValue(v.doctor_hospital))}
    ${line("Pickup from", pickup)}
    ${line("Helper preference", pref)}
    ${sectionHeading("What happens next")}
    <p style="margin:0 0 12px;">We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.</p>
    <p style="margin:0 0 12px;">Need to change anything? Call us on ${escapeHtml(SUPPORT_PHONE)} and quote Ref ${escapeHtml(v.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;

  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `Thank you for choosing ABI Parent Care. We've received your request for ${v.parent_name}'s doctor appointment.`,
    "",
    "APPOINTMENT",
    textLine("Date & time", `${dateLong} · ${time}`),
    textLine("Doctor/Hospital", displayValue(v.doctor_hospital)),
    textLine("Pickup from", pickup),
    textLine("Helper preference", pref),
    "",
    "WHAT HAPPENS NEXT",
    "We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.",
    "",
    `Need to change anything? Call us on ${SUPPORT_PHONE} and quote Ref ${v.ref}.`,
    "",
    "Warm regards,",
    "The ABI Parent Care team",
  ].join("\n");

  return build("G1", subject, v.ref, bodyHtml, bodyText);
}

type G2Vars = {
  ref: string;
  booking_person_name: string;
  parent_name: string;
  appointment_date: string;
  appointment_time: string;
};

function templateG2(v: G2Vars): EmailContent {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const subject =
    `Update on ${v.parent_name}'s appointment – ${dateShort} · Ref ${v.ref}`;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${escapeHtml(v.parent_name)}'s appointment on ${escapeHtml(dateLong)} at ${escapeHtml(time)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${escapeHtml(SUPPORT_PHONE)} and quote Ref ${escapeHtml(v.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `A quick update: our care team is personally arranging a suitable helper for ${v.parent_name}'s appointment on ${dateLong} at ${time}.`,
    "",
    "You don't need to do anything. We'll email you the helper's details shortly.",
    "",
    `If you'd like to speak to us, call ${SUPPORT_PHONE} and quote Ref ${v.ref}.`,
    "",
    "Warm regards,",
    "The ABI Parent Care team",
  ].join("\n");

  return build("G2", subject, v.ref, bodyHtml, bodyText);
}

type G3Vars = {
  ref: string;
  booking_person_name: string;
  parent_name: string;
  helper_full_name: string;
  helper_phone: string;
  helper_photo_url?: string | null;
  appointment_date: string;
  appointment_time: string;
  doctor_hospital: string;
  address_line1?: string | null;
  street?: string | null;
  area?: string | null;
  city?: string | null;
  pincode?: string | null;
};

function templateG3(v: G3Vars): EmailContent {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const pickup = joinAddress([
    v.address_line1,
    v.street,
    v.area,
    v.city,
    v.pincode,
  ]) || "–";
  const subject =
    `Helper confirmed for ${v.parent_name} – ${v.helper_full_name}, ${dateShort} · Ref ${v.ref}`;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news – ${escapeHtml(v.helper_full_name)} will accompany ${escapeHtml(v.parent_name)} to the appointment.</p>
    ${helperPhotoBlock(v.helper_photo_url)}
    ${sectionHeading("Your helper")}
    ${line("Name", v.helper_full_name)}
    ${line("Phone", displayValue(v.helper_phone))}
    ${line("Verified", "ID and background checked by ABI Parent Care")}
    ${sectionHeading("Appointment")}
    ${line("Date & time", `${dateLong} · ${time} (${relative})`)}
    ${line("Doctor/Hospital", displayValue(v.doctor_hospital))}
    ${line("Pickup from", pickup)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${escapeHtml(v.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `Good news – ${v.helper_full_name} will accompany ${v.parent_name} to the appointment.`,
    "",
    "YOUR HELPER",
    textLine("Name", v.helper_full_name),
    textLine("Phone", displayValue(v.helper_phone)),
    textLine("Verified", "ID and background checked by ABI Parent Care"),
    "",
    "APPOINTMENT",
    textLine("Date & time", `${dateLong} · ${time} (${relative})`),
    textLine("Doctor/Hospital", displayValue(v.doctor_hospital)),
    textLine("Pickup from", pickup),
    "",
    `For safety, please share this with ${v.parent_name} so they know who to expect.`,
    "",
    "Warm regards,",
    "The ABI Parent Care team",
  ].join("\n");

  return build("G3", subject, v.ref, bodyHtml, bodyText);
}

type G4Vars = {
  ref: string;
  booking_person_name: string;
  parent_name: string;
  old_helper_first_name: string;
  appointment_date: string;
  appointment_time: string;
};

function templateG4(v: G4Vars): EmailContent {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const subject =
    `Change of helper for ${v.parent_name} – ${dateShort} · Ref ${v.ref}`;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry – ${escapeHtml(v.old_helper_first_name)} is unable to attend ${escapeHtml(v.parent_name)}'s appointment on ${escapeHtml(dateLong)} at ${escapeHtml(time)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${escapeHtml(SUPPORT_PHONE)} and quote Ref ${escapeHtml(v.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `We're sorry – ${v.old_helper_first_name} is unable to attend ${v.parent_name}'s appointment on ${dateLong} at ${time}.`,
    "",
    "Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.",
    "",
    `The appointment itself is unchanged. If you have concerns, call ${SUPPORT_PHONE} and quote Ref ${v.ref}.`,
    "",
    "Warm regards,",
    "The ABI Parent Care team",
  ].join("\n");

  return build("G4", subject, v.ref, bodyHtml, bodyText);
}

type G5Vars = {
  ref: string;
  booking_person_name: string;
  parent_name: string;
  helper_full_name: string;
  helper_phone: string;
  helper_photo_url?: string | null;
  old_helper_first_name: string;
  appointment_date: string;
  appointment_time: string;
  doctor_hospital: string;
};

function templateG5(v: G5Vars): EmailContent {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject =
    `New helper confirmed for ${v.parent_name} – ${v.helper_full_name} · Ref ${v.ref}`;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} will now accompany ${escapeHtml(v.parent_name)} to the appointment, in place of ${escapeHtml(v.old_helper_first_name)}.</p>
    ${helperPhotoBlock(v.helper_photo_url)}
    ${sectionHeading("Your new helper")}
    ${line("Name", v.helper_full_name)}
    ${line("Phone", displayValue(v.helper_phone))}
    ${line("Verified", "ID and background checked by ABI Parent Care")}
    ${sectionHeading("Appointment (unchanged)")}
    ${line("Date & time", `${dateLong} · ${time} (${relative})`)}
    ${line("Doctor/Hospital", displayValue(v.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `${v.helper_full_name} will now accompany ${v.parent_name} to the appointment, in place of ${v.old_helper_first_name}.`,
    "",
    "YOUR NEW HELPER",
    textLine("Name", v.helper_full_name),
    textLine("Phone", displayValue(v.helper_phone)),
    textLine("Verified", "ID and background checked by ABI Parent Care"),
    "",
    "APPOINTMENT (unchanged)",
    textLine("Date & time", `${dateLong} · ${time} (${relative})`),
    textLine("Doctor/Hospital", displayValue(v.doctor_hospital)),
    "",
    "Thank you for your patience.",
    "",
    "Warm regards,",
    "The ABI Parent Care team",
  ].join("\n");

  return build("G5", subject, v.ref, bodyHtml, bodyText);
}

// ---------------------------------------------------------------------------
// Helper emails
// ---------------------------------------------------------------------------

type H1Vars = {
  ref: string;
  helper_first_name: string;
  appointment_date: string;
  appointment_time: string;
  area?: string | null;
  pincode?: string | null;
  distance_km?: number | null;
  doctor_hospital: string;
  parent_age: number;
  accept_url: string;
  decline_url: string;
};

function templateH1(v: H1Vars): EmailContent {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const dist = v.distance_km == null || Number.isNaN(Number(v.distance_km))
    ? "–"
    : String(Math.round(Number(v.distance_km) * 10) / 10);
  const area = displayValue(v.area);
  const subject =
    `New visit near you – ${dateShort}, ${time} · ${area} (${dist} km)`;

  // H1 must NEVER include patient name, address or family contact.
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${line("When", `${dateLong} · ${time} (${relative})`)}
    ${line("Pickup area", `${area}, ${displayValue(v.pincode)} · about ${dist} km from you`)}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Patient", `Age ${v.parent_age}`)}
    <p style="margin:22px 0;">
      ${emailButtonHtml(v.accept_url, "Accept", "primary")}
      ${emailButtonHtml(v.decline_url, "Decline", "secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    "A new hospital visit is available near you. The first helper to accept gets it.",
    "",
    textLine("When", `${dateLong} · ${time} (${relative})`),
    textLine(
      "Pickup area",
      `${area}, ${displayValue(v.pincode)} · about ${dist} km from you`,
    ),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine("Patient", `Age ${v.parent_age}`),
    "",
    `Accept: ${v.accept_url}`,
    `Decline: ${v.decline_url}`,
    "",
    "The patient's name, full address and family contact are shared after you accept.",
    "",
    `Ref ${v.ref}`,
  ].join("\n");

  return build("H1", subject, v.ref, bodyHtml, bodyText);
}

type H2Vars = {
  ref: string;
  helper_first_name: string;
  parent_name: string;
  parent_age: number;
  address_line1?: string | null;
  street?: string | null;
  area?: string | null;
  city?: string | null;
  pincode?: string | null;
  landmark?: string | null;
  maps_url: string;
  appointment_date: string;
  appointment_time: string;
  doctor_hospital: string;
  booking_person_name: string;
  relationship: string;
  guardian_phone: string;
  cant_make_it_url: string;
};

function templateH2(v: H2Vars): EmailContent {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const pickup = joinAddress([
    v.address_line1,
    v.street,
    v.area,
    v.city,
    v.pincode,
  ]) || "–";
  const subject =
    `Confirmed: ${v.parent_name}, ${dateShort} ${time} · Ref ${v.ref}`;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${sectionHeading("Patient")}
    ${line("Name", `${v.parent_name}, ${v.parent_age}`)}
    ${line("Pickup", pickup)}
    ${line("Landmark", displayValue(v.landmark))}
    <p style="margin:10px 0 16px;">${emailButtonHtml(v.maps_url, "Open in Google Maps", "secondary")}</p>
    ${sectionHeading("Appointment")}
    ${line("When", `${dateLong} · ${time} (${relative})`)}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${sectionHeading("Family contact")}
    <p style="margin:0 0 12px;">${escapeHtml(v.booking_person_name)} (${escapeHtml(displayValue(v.relationship))}) · ${escapeHtml(displayValue(v.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${emailButtonHtml(v.cant_make_it_url, "Can't make it", "secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    "This visit is yours. Thank you!",
    "",
    "PATIENT",
    textLine("Name", `${v.parent_name}, ${v.parent_age}`),
    textLine("Pickup", pickup),
    textLine("Landmark", displayValue(v.landmark)),
    `Open in Google Maps: ${v.maps_url}`,
    "",
    "APPOINTMENT",
    textLine("When", `${dateLong} · ${time} (${relative})`),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    "",
    "FAMILY CONTACT",
    `${v.booking_person_name} (${displayValue(v.relationship)}) · ${displayValue(v.guardian_phone)}`,
    "",
    "We'll remind you 12 hours and 6 hours before.",
    "",
    `Can't make it? ${v.cant_make_it_url}`,
    "",
    `Ref ${v.ref}`,
  ].join("\n");

  return build("H2", subject, v.ref, bodyHtml, bodyText);
}

type H3Vars = {
  ref: string;
  helper_first_name: string;
  parent_name: string;
  area?: string | null;
  appointment_date: string;
  appointment_time: string;
  full_address: string;
  maps_url: string;
  doctor_hospital: string;
  booking_person_name: string;
  relationship: string;
  guardian_phone: string;
  cant_make_it_url: string;
};

function templateH3(v: H3Vars): EmailContent {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject =
    `Reminder: visit ${relative} ${time} – ${v.parent_name}, ${displayValue(v.area)}`;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${escapeHtml(v.parent_name)} ${escapeHtml(relative)}.</p>
    ${line("When", `${dateLong} · ${time}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${escapeHtml(displayValue(v.full_address))} · <a href="${escapeHtml(v.maps_url)}">Open in Google Maps</a></div>
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) · ${displayValue(v.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${emailButtonHtml(v.cant_make_it_url, "Can't make it", "secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    `A reminder that you're accompanying ${v.parent_name} ${relative}.`,
    "",
    textLine("When", `${dateLong} · ${time}`),
    textLine("Pickup", `${displayValue(v.full_address)} · ${v.maps_url}`),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) · ${displayValue(v.guardian_phone)}`,
    ),
    "",
    "Plan to reach the pickup address 15 minutes early.",
    "",
    `Can't make it? ${v.cant_make_it_url}`,
    "",
    `Ref ${v.ref}`,
  ].join("\n");

  return build("H3", subject, v.ref, bodyHtml, bodyText);
}

type H4Vars = H3Vars & {
  confirm_url: string;
};

function templateH4(v: H4Vars): EmailContent {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject =
    `Please confirm: ${v.parent_name} at ${time} – ${relative}`;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${escapeHtml(v.parent_name)} is ${escapeHtml(relative)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${emailButtonHtml(v.confirm_url, "I'll be there", "primary")}
      ${emailButtonHtml(v.cant_make_it_url, "Can't make it", "secondary")}
    </p>
    ${line("When", `${dateLong} · ${time}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${escapeHtml(displayValue(v.full_address))} · <a href="${escapeHtml(v.maps_url)}">Open in Google Maps</a></div>
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) · ${displayValue(v.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    `Your visit with ${v.parent_name} is ${relative}. Please confirm you'll be there.`,
    "",
    `I'll be there: ${v.confirm_url}`,
    `Can't make it: ${v.cant_make_it_url}`,
    "",
    textLine("When", `${dateLong} · ${time}`),
    textLine("Pickup", `${displayValue(v.full_address)} · ${v.maps_url}`),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) · ${displayValue(v.guardian_phone)}`,
    ),
    "",
    "If we don't hear from you, our care team will call you.",
    "",
    `Ref ${v.ref}`,
  ].join("\n");

  return build("H4", subject, v.ref, bodyHtml, bodyText);
}

type H5Vars = {
  helper_first_name: string;
  helper_email: string;
  helper_app_link?: string;
};

function templateH5(v: H5Vars): EmailContent {
  const link = v.helper_app_link || HELPER_APP_LINK;
  const subject = "Welcome to ABI Parent Care – your helper app login";

  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${line("App link", link)}
    ${line("Login email", v.helper_email)}
    ${line("Password", "the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${emailButtonHtml(link, "Open helper app", "primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${escapeHtml(SUPPORT_PHONE)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    "Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.",
    "",
    textLine("App link", link),
    textLine("Login email", v.helper_email),
    textLine("Password", "the temporary password given to you by your manager"),
    "",
    "You'll be asked to set your own password the first time you log in.",
    "",
    'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',
    "",
    `Questions? Call ${SUPPORT_PHONE}.`,
    "",
    "The ABI Parent Care team",
  ].join("\n");

  return build("H5", subject, null, bodyHtml, bodyText);
}

// ---------------------------------------------------------------------------
// Manager emails
// ---------------------------------------------------------------------------

type M1Vars = {
  ref: string;
  manager_first_name: string;
  parent_name: string;
  parent_age: number;
  appointment_date: string;
  appointment_time: string;
  area?: string | null;
  city?: string | null;
  pincode?: string | null;
  doctor_hospital: string;
  helper_preference?: string | null;
  booking_person_name: string;
  relationship: string;
  guardian_phone: string;
  time_remaining: string;
  assign_url: string;
};

function templateM1(v: M1Vars): EmailContent {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject =
    `URGENT – Helper needed in ${v.time_remaining} · ${v.parent_name} (${v.parent_age}) · ${time} · ${displayValue(v.area)} · ${v.ref}`;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${escapeHtml(relative)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${sectionHeading("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${sectionHeading("Visit details")}
    ${line("Patient", `${v.parent_name}, ${v.parent_age}`)}
    ${line("When", `${dateLong} · ${time} (${relative})`)}
    ${line("Pickup", joinAddress([v.area, v.city, v.pincode]) || "–")}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Preference", preferenceLabel(v.helper_preference))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) · ${displayValue(v.guardian_phone)}`)}
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Assign a helper", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `A booking has come in for ${relative}. There isn't time to send offers automatically, so please assign a helper now.`,
    "",
    "WHAT TO DO NOW",
    "Open the request, pick an available helper and send them an offer.",
    "",
    "VISIT DETAILS",
    textLine("Patient", `${v.parent_name}, ${v.parent_age}`),
    textLine("When", `${dateLong} · ${time} (${relative})`),
    textLine("Pickup", joinAddress([v.area, v.city, v.pincode]) || "–"),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine("Preference", preferenceLabel(v.helper_preference)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) · ${displayValue(v.guardian_phone)}`,
    ),
    "",
    `Assign a helper: ${v.assign_url}`,
  ].join("\n");

  return build("M1", subject, v.ref, bodyHtml, bodyText);
}

type M2Item = {
  ref: string;
  parent_name: string;
  parent_age: number;
  appointment_date: string;
  appointment_time: string;
  area?: string | null;
  pincode?: string | null;
  helper_preference?: string | null;
  reason?: string | null;
  assign_url: string;
};

type M2Vars = {
  manager_first_name: string;
  digest_time: string;
  open_all_url: string;
  items: M2Item[];
};

function templateM2(v: M2Vars): EmailContent {
  const count = v.items.length;
  const subject = `${count} request(s) need a helper – ${v.digest_time}`;

  const itemsHtml = v.items.map((item, i) => {
    const dateShort = formatAppointmentDateShort(item.appointment_date);
    const time = timeLabel(item.appointment_time);
    const relative = formatRelativeTime(
      item.appointment_date,
      item.appointment_time,
    );
    return `
      <div style="margin:0 0 16px;padding:12px 0;border-bottom:1px solid #e5e7eb;">
        <p style="margin:0 0 6px;"><strong>${i + 1}. ${escapeHtml(item.ref)}</strong> · ${escapeHtml(item.parent_name)} (${item.parent_age}) · ${escapeHtml(dateShort)} ${escapeHtml(time)} (${escapeHtml(relative)})</p>
        <p style="margin:0 0 6px;">${escapeHtml(displayValue(item.area))} ${escapeHtml(displayValue(item.pincode))} · Preference: ${escapeHtml(preferenceLabel(item.helper_preference))}</p>
        <p style="margin:0 0 10px;">Why: ${escapeHtml(reasonPlain(item.reason))}</p>
        <p style="margin:0;">${emailButtonHtml(item.assign_url, "Assign", "primary")}</p>
      </div>
    `;
  }).join("");

  const itemsText = v.items.map((item, i) => {
    const dateShort = formatAppointmentDateShort(item.appointment_date);
    const time = timeLabel(item.appointment_time);
    const relative = formatRelativeTime(
      item.appointment_date,
      item.appointment_time,
    );
    return [
      `${i + 1}. ${item.ref} · ${item.parent_name} (${item.parent_age}) · ${dateShort} ${time} (${relative})`,
      `   ${displayValue(item.area)} ${displayValue(item.pincode)} · Preference: ${preferenceLabel(item.helper_preference)}`,
      `   Why: ${reasonPlain(item.reason)}`,
      `   Assign: ${item.assign_url}`,
    ].join("\n");
  }).join("\n\n");

  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">These requests still need a helper. The soonest appointment is first.</p>
    ${itemsHtml}
    <p style="margin:22px 0;">${emailButtonHtml(v.open_all_url, "Open all in the portal", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    "These requests still need a helper. The soonest appointment is first.",
    "",
    itemsText,
    "",
    `Open all in the portal: ${v.open_all_url}`,
  ].join("\n");

  return build("M2", subject, null, bodyHtml, bodyText);
}

type M3Vars = {
  ref: string;
  manager_first_name: string;
  helper_full_name: string;
  parent_name: string;
  appointment_date: string;
  appointment_time: string;
  area?: string | null;
  decline_reason?: string | null;
  assign_url: string;
};

function templateM3(v: M3Vars): EmailContent {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const reason = displayOrNone(v.decline_reason);
  const subject =
    `${v.helper_full_name} declined – please assign another · ${v.parent_name}, ${dateShort} ${time} · ${v.ref}`;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} declined the visit you offered.</p>
    ${line("Reason given", reason)}
    <p style="margin:12px 0;">Appointment: ${escapeHtml(dateLong)} · ${escapeHtml(time)} (${escapeHtml(relative)}) · ${escapeHtml(displayValue(v.area))}</p>
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Choose another helper", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name} declined the visit you offered.`,
    textLine("Reason given", reason),
    "",
    `Appointment: ${dateLong} · ${time} (${relative}) · ${displayValue(v.area)}`,
    "",
    `Choose another helper: ${v.assign_url}`,
  ].join("\n");

  return build("M3", subject, v.ref, bodyHtml, bodyText);
}

type M4Vars = {
  ref: string;
  manager_first_name: string;
  helper_full_name: string;
  helper_phone?: string | null;
  parent_name: string;
  appointment_date: string;
  appointment_time: string;
  area?: string | null;
  expiry_window: string;
  assign_url: string;
};

function templateM4(v: M4Vars): EmailContent {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject =
    `No response from ${v.helper_full_name} – please assign another · ${v.parent_name} · ${v.ref}`;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} didn't respond within ${escapeHtml(v.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${escapeHtml(dateLong)} · ${escapeHtml(time)} (${escapeHtml(relative)}) · ${escapeHtml(displayValue(v.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${escapeHtml(displayValue(v.helper_phone))}</p>
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Choose another helper", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name} didn't respond within ${v.expiry_window}, so the offer has been withdrawn.`,
    "",
    `Appointment: ${dateLong} · ${time} (${relative}) · ${displayValue(v.area)}`,
    `Helper phone (if you'd like to call): ${displayValue(v.helper_phone)}`,
    "",
    `Choose another helper: ${v.assign_url}`,
  ].join("\n");

  return build("M4", subject, v.ref, bodyHtml, bodyText);
}

type M5Vars = {
  ref: string;
  manager_first_name: string;
  helper_full_name: string;
  parent_name: string;
  parent_age: number;
  appointment_date: string;
  appointment_time: string;
  area?: string | null;
  city?: string | null;
  pincode?: string | null;
  doctor_hospital: string;
  booking_person_name: string;
  relationship: string;
  guardian_phone: string;
  dropout_reason?: string | null;
  assign_url: string;
};

function templateM5(v: M5Vars): EmailContent {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const reason = displayOrNone(v.dropout_reason);
  const subject =
    `URGENT – ${v.helper_full_name} can't attend · ${v.parent_name} · ${time} (${relative}) · ${v.ref}`;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} has said they can't attend this visit.</p>
    ${line("Reason given", reason)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${sectionHeading("Visit details")}
    ${line("Patient", `${v.parent_name}, ${v.parent_age}`)}
    ${line("When", `${dateLong} · ${time} (${relative})`)}
    ${line("Pickup", joinAddress([v.area, v.city, v.pincode]) || "–")}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) · ${displayValue(v.guardian_phone)}`)}
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Assign a replacement", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name} has said they can't attend this visit.`,
    textLine("Reason given", reason),
    "",
    "The family has been told we're arranging a replacement. Please assign a new helper now.",
    "",
    "VISIT DETAILS",
    textLine("Patient", `${v.parent_name}, ${v.parent_age}`),
    textLine("When", `${dateLong} · ${time} (${relative})`),
    textLine("Pickup", joinAddress([v.area, v.city, v.pincode]) || "–"),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) · ${displayValue(v.guardian_phone)}`,
    ),
    "",
    `Assign a replacement: ${v.assign_url}`,
  ].join("\n");

  return build("M5", subject, v.ref, bodyHtml, bodyText);
}

type M6Vars = {
  ref: string;
  manager_first_name: string;
  helper_full_name: string;
  helper_first_name: string;
  helper_phone: string;
  parent_name: string;
  parent_age: number;
  appointment_date: string;
  appointment_time: string;
  area?: string | null;
  city?: string | null;
  pincode?: string | null;
  doctor_hospital: string;
  assigned_at?: string | null;
  r12_status: string;
  r6_status: string;
  open_url: string;
  urgent?: boolean;
};

function templateM6(v: M6Vars): EmailContent {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const assigned = formatIstDateTime(v.assigned_at);
  const subject = v.urgent
    ? `URGENT – visit in 1 hour, ${v.helper_full_name} still not confirmed · ${v.parent_name} · ${v.ref}`
    : `Action needed – ${v.helper_full_name} hasn't confirmed · ${v.parent_name} · ${time} (${relative}) · ${v.ref}`;

  const lead = v.urgent
    ? `The visit starts in about 1 hour and ${escapeHtml(v.helper_full_name)} still hasn't confirmed. Please resolve this now.`
    : `${escapeHtml(v.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`;

  const leadText = v.urgent
    ? `The visit starts in about 1 hour and ${v.helper_full_name} still hasn't confirmed. Please resolve this now.`
    : `${v.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`;

  const stepsHtml = v.urgent
    ? `<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${escapeHtml(v.helper_first_name)}: ${escapeHtml(displayValue(v.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable – reassign".</li>
      </ol>`
    : `${sectionHeading("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${escapeHtml(v.helper_first_name)}: ${escapeHtml(displayValue(v.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone – nothing else happens, or</li>
            <li>Helper unable – reassign – we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`;

  const stepsText = v.urgent
    ? [
      `1. Call ${v.helper_first_name}: ${displayValue(v.helper_phone)}`,
      `2. Mark "Helper confirmed by phone", or choose "Helper unable – reassign".`,
    ].join("\n")
    : [
      "WHAT TO DO NOW",
      `1. Call ${v.helper_first_name}: ${displayValue(v.helper_phone)}`,
      "2. Then in the portal, choose:",
      "   • Helper confirmed by phone – nothing else happens, or",
      "   • Helper unable – reassign – we'll inform the family and you can pick a new helper",
    ].join("\n");

  const detailsHtml = `
    ${sectionHeading("Visit details")}
    ${line("Patient", `${v.parent_name}, ${v.parent_age}`)}
    ${line("When", `${dateLong} · ${time} (${relative})`)}
    ${line("Pickup", joinAddress([v.area, v.city, v.pincode]) || "–")}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${sectionHeading("Helper status")}
    ${line("Assigned", assigned)}
    ${line("Reminders", `12-hour ${v.r12_status} · 6-hour ${v.r6_status}`)}
    ${line("Confirmed", "Not yet")}
  `;

  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${lead}</p>
    ${stepsHtml}
    ${detailsHtml}
    <p style="margin:22px 0;">${emailButtonHtml(v.open_url, "Open request", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    leadText,
    "",
    stepsText,
    "",
    "VISIT DETAILS",
    textLine("Patient", `${v.parent_name}, ${v.parent_age}`),
    textLine("When", `${dateLong} · ${time} (${relative})`),
    textLine("Pickup", joinAddress([v.area, v.city, v.pincode]) || "–"),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    "",
    "HELPER STATUS",
    textLine("Assigned", assigned),
    textLine("Reminders", `12-hour ${v.r12_status} · 6-hour ${v.r6_status}`),
    textLine("Confirmed", "Not yet"),
    "",
    `Open request: ${v.open_url}`,
  ].join("\n");

  return build(v.urgent ? "M7" : "M6", subject, v.ref, bodyHtml, bodyText);
}

function templateM7(v: M6Vars): EmailContent {
  return templateM6({ ...v, urgent: true });
}

type M8Vars = {
  manager_first_name: string;
  helper_full_name: string;
  expiry_phrase: string;
  dl_expiry: string;
  upcoming_count: number;
  open_url: string;
  expired: boolean;
};

function templateM8(v: M8Vars): EmailContent {
  const subject =
    `Driving licence ${v.expiry_phrase} – ${v.helper_full_name}`;

  const statusHtml = v.expired
    ? `<p style="margin:0 0 12px;">If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${v.upcoming_count} (moved to Needs action).</p>`
    : `<p style="margin:0 0 12px;">If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.</p>`;

  const statusText = v.expired
    ? `If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${v.upcoming_count} (moved to Needs action).`
    : "If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.";

  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)}'s driving licence ${escapeHtml(v.expiry_phrase)} (${escapeHtml(v.dl_expiry)}).</p>
    ${statusHtml}
    <p style="margin:22px 0;">${emailButtonHtml(v.open_url, "Open helper profile", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name}'s driving licence ${v.expiry_phrase} (${v.dl_expiry}).`,
    "",
    statusText,
    "",
    `Open helper profile: ${v.open_url}`,
  ].join("\n");

  return build("M8", subject, null, bodyHtml, bodyText);
}

type M9Vars = {
  manager_first_name: string;
  helper_full_name: string;
  request_note: string;
  open_url: string;
};

function templateM9(v: M9Vars): EmailContent {
  const subject = `Profile change request – ${v.helper_full_name}`;
  const note = displayOrNone(v.request_note);

  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} has asked to update their profile:</p>
    <p style="margin:0 0 12px;padding:12px 14px;background:#f3f6fb;border-radius:8px;font-style:italic;">"${escapeHtml(note)}"</p>
    <p style="margin:0 0 12px;">Please review and update their details in the portal if appropriate.</p>
    <p style="margin:22px 0;">${emailButtonHtml(v.open_url, "Open helper profile", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name} has asked to update their profile:`,
    "",
    `"${note}"`,
    "",
    "Please review and update their details in the portal if appropriate.",
    "",
    `Open helper profile: ${v.open_url}`,
  ].join("\n");

  return build("M9", subject, null, bodyHtml, bodyText);
}

/** On-screen messages for respond.html / action pages. */
const ON_SCREEN = {
  accept_confirm: {
    title: "Accept this visit?",
    message:
      "{{appointment_date_short}} · {{appointment_time}} · {{area}}. Tap Confirm to take this visit.",
    button: "Confirm",
  },
  accepted: {
    title: "This visit is yours!",
    message:
      "We've emailed you the full details. Thank you, {{helper_first_name}}.",
  },
  already_taken: {
    title: "Already taken",
    message:
      "Another helper accepted this visit first. Thank you for responding quickly.",
  },
  helper_engaged: {
    title: "You're already booked",
    message:
      "You have another visit around this time, so we can't assign this one to you.",
  },
  declined: {
    title: "Thanks for letting us know",
    message: "We've offered this visit to another helper.",
  },
  confirmed: {
    title: "See you there!",
    message: "Thanks for confirming. The family is counting on you.",
  },
  cant_make_it_confirm: {
    title: "Can't make this visit?",
    message:
      "Tell us why (optional), then tap Confirm. We'll arrange a replacement.",
    button: "Confirm",
  },
  cant_make_it_done: {
    title: "Thanks for telling us",
    message: "Our care team will arrange a replacement.",
  },
  link_inactive: {
    title: "This link is no longer active",
    message:
      "The visit may have been assigned, cancelled or already passed. Please contact your manager if you need help.",
  },
} as const;

function fillOnScreen(
  template: string,
  vars: Record<string, string>,
): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_m, key: string) =>
    displayValue(vars[key], "")
  );
}

// ---- _shared/senior.ts ----
const ADMIN_PAGE_BASE =
  "https://nandhini-17223.github.io/elderly-care/admin";

const RESPOND_BASE =
  "https://nandhini-17223.github.io/elderly-care/respond.html";

const HELPER_PORTAL_BASE =
  "https://nandhini-17223.github.io/elderly-care/admin/helper.html";


const MANAGER_FIRST_NAME = "Manager";

/** Portal deep link: login first, then return to the request. */
function seniorAssignUrl(requestId: string): string {
  const next = `needs-action.html?request=${encodeURIComponent(requestId)}`;
  return `${ADMIN_PAGE_BASE}/login.html?next=${encodeURIComponent(next)}`;
}

function needsActionUrl(): string {
  return `${ADMIN_PAGE_BASE}/login.html?next=${
    encodeURIComponent("needs-action.html")
  }`;
}

function helperProfileUrl(helperId: string): string {
  const next = `helper.html?id=${encodeURIComponent(helperId)}`;
  return `${ADMIN_PAGE_BASE}/login.html?next=${encodeURIComponent(next)}`;
}

function assignButtonHtml(url: string, label = "Assign helper"): string {
  return `<a href="${url}" style="background:#1d6fd8;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;">${escapeHtml(label)}</a>`;
}

function formatRequestSummaryHtml(args: {
  parentName: string;
  parentAge: number;
  appointmentDate: string;
  appointmentTime: string;
  area?: string | null;
  pincode?: string | null;
  doctorHospital?: string | null;
  helperPreference?: string | null;
  reason?: string | null;
  address?: string | null;
  refNumber?: string | null;
}): string {
  const dateLabel = formatAppointmentDate(args.appointmentDate) ??
    args.appointmentDate;
  const timeLabel = formatAppointmentTime(args.appointmentTime) ??
    args.appointmentTime;
  const area = [args.area, args.pincode].filter(Boolean).join(" · ") ||
    "Area on file";

  return `
    <p>
      ${args.refNumber ? `<strong>Ref:</strong> ${escapeHtml(args.refNumber)}<br />` : ""}
      <strong>Patient:</strong> ${escapeHtml(args.parentName)} (age ${escapeHtml(String(args.parentAge))})<br />
      <strong>Date:</strong> ${escapeHtml(dateLabel)}<br />
      <strong>Time:</strong> ${escapeHtml(timeLabel)}<br />
      <strong>Area:</strong> ${escapeHtml(area)}<br />
      ${args.doctorHospital ? `<strong>Doctor / Hospital:</strong> ${escapeHtml(args.doctorHospital)}<br />` : ""}
      ${args.helperPreference ? `<strong>Helper preference:</strong> ${escapeHtml(preferenceLabel(args.helperPreference))}<br />` : ""}
      ${args.reason ? `<strong>Reason:</strong> ${escapeHtml(reasonPlain(args.reason))}<br />` : ""}
      ${args.address ? `<strong>Address:</strong> ${escapeHtml(args.address)}<br />` : ""}
    </p>
  `;
}

function approxDistanceLabel(km: number | null | undefined): string {
  if (km == null || Number.isNaN(Number(km))) return "Nearby";
  const rounded = Math.round(Number(km) * 10) / 10;
  return `~${rounded} km`;
}

function reminderStatusLabel(sentAt: string | null | undefined): string {
  return sentAt ? "sent" : "not sent";
}

// ---- _shared/assignment.ts ----
type RequestContact = {
  parent_name: string;
  parent_age: number;
  address_line1: string | null;
  street: string | null;
  area: string | null;
  landmark: string | null;
  city: string;
  pincode: string | null;
  appointment_date: string;
  appointment_time: string;
  doctor_hospital: string;
  booking_person_name: string;
  relationship: string;
  phone_country_code: string;
  phone: string;
  email?: string;
  ref_number?: string | null;
};

function fullPickupAddress(request: RequestContact): string {
  return [
    request.address_line1,
    request.street,
    request.area,
    request.city,
    request.pincode,
  ]
    .map((part) => (part ? String(part).trim() : ""))
    .filter(Boolean)
    .join(", ");
}

function mapsSearchUrl(address: string): string {
  return `https://www.google.com/maps/search/?api=1&query=${
    encodeURIComponent(address)
  }`;
}

function familyPhone(request: RequestContact): string {
  return `${request.phone_country_code} ${request.phone}`.trim();
}

function appointmentLabels(request: {
  appointment_date: string;
  appointment_time: string;
}): { dateLabel: string; timeLabel: string } {
  return {
    dateLabel: formatAppointmentDate(request.appointment_date) ??
      request.appointment_date,
    timeLabel: formatAppointmentTime(request.appointment_time) ??
      request.appointment_time,
  };
}

function actionUrl(token: string, action: string): string {
  return `${RESPOND_BASE}?token=${encodeURIComponent(token)}&action=${
    encodeURIComponent(action)
  }`;
}

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

async function sha256Hex(value: string): Promise<string> {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return bytesToHex(new Uint8Array(digest));
}

async function createRawToken(): Promise<{ token: string; hash: string }> {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  const token = bytesToHex(bytes);
  const hash = await sha256Hex(token);
  return { token, hash };
}

type GuardianHelperInfo = {
  full_name: string;
  phone: string;
  photo_url?: string | null;
};

function appointmentConfirmedEmail(
  request: RequestContact,
  helperName: string,
  token: string,
): EmailContent {
  const address = fullPickupAddress(request);
  return templateH2({
    ref: String(request.ref_number ?? "–"),
    helper_first_name: firstName(helperName),
    parent_name: request.parent_name,
    parent_age: request.parent_age,
    address_line1: request.address_line1,
    street: request.street,
    area: request.area,
    city: request.city,
    pincode: request.pincode,
    landmark: request.landmark,
    maps_url: mapsSearchUrl(address),
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    doctor_hospital: request.doctor_hospital,
    booking_person_name: request.booking_person_name,
    relationship: request.relationship,
    guardian_phone: familyPhone(request),
    cant_make_it_url: actionUrl(token, "cant_make_it"),
  });
}

/** @deprecated use appointmentConfirmedEmail */
function appointmentConfirmedEmailHtml(
  request: RequestContact,
  helperName: string,
  token: string,
): string {
  return appointmentConfirmedEmail(request, helperName, token).html;
}

function reminderEmail(
  request: RequestContact,
  helperName: string,
  token: string,
  kind: "12h" | "6h",
): EmailContent {
  const address = fullPickupAddress(request);
  const base = {
    ref: String(request.ref_number ?? "–"),
    helper_first_name: firstName(helperName),
    parent_name: request.parent_name,
    area: request.area,
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    full_address: address,
    maps_url: mapsSearchUrl(address),
    doctor_hospital: request.doctor_hospital,
    booking_person_name: request.booking_person_name,
    relationship: request.relationship,
    guardian_phone: familyPhone(request),
    cant_make_it_url: actionUrl(token, "cant_make_it"),
  };
  if (kind === "6h") {
    return templateH4({
      ...base,
      confirm_url: actionUrl(token, "confirm_attendance"),
    });
  }
  return templateH3(base);
}

/** @deprecated use reminderEmail */
function reminderEmailHtml(
  request: RequestContact,
  helperName: string,
  token: string,
  kind: "12h" | "6h",
): string {
  return reminderEmail(request, helperName, token, kind).html;
}

function guardianNewHelperEmail(
  request: RequestContact,
  helper: GuardianHelperInfo,
  oldHelperFirstName: string,
): EmailContent {
  return templateG5({
    ref: String(request.ref_number ?? "–"),
    booking_person_name: request.booking_person_name,
    parent_name: request.parent_name,
    helper_full_name: helper.full_name,
    helper_phone: helper.phone,
    helper_photo_url: helper.photo_url,
    old_helper_first_name: oldHelperFirstName || "the previous helper",
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    doctor_hospital: request.doctor_hospital,
  });
}

/** @deprecated use guardianNewHelperEmail */
function guardianNewHelperEmailHtml(
  request: RequestContact,
  helper: GuardianHelperInfo,
  oldHelperFirstName = "the previous helper",
): string {
  return guardianNewHelperEmail(request, helper, oldHelperFirstName).html;
}

function guardianHelperAssignedEmail(
  request: RequestContact,
  helper: GuardianHelperInfo,
): EmailContent {
  return templateG3({
    ref: String(request.ref_number ?? "–"),
    booking_person_name: request.booking_person_name,
    parent_name: request.parent_name,
    helper_full_name: helper.full_name,
    helper_phone: helper.phone,
    helper_photo_url: helper.photo_url,
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    doctor_hospital: request.doctor_hospital,
    address_line1: request.address_line1,
    street: request.street,
    area: request.area,
    city: request.city,
    pincode: request.pincode,
  });
}

/** @deprecated use guardianHelperAssignedEmail */
function guardianHelperAssignedEmailHtml(
  request: RequestContact,
  helper: GuardianHelperInfo,
): string {
  return guardianHelperAssignedEmail(request, helper).html;
}

function guardianReplacementArrangingEmail(
  request: RequestContact,
  helperFullName: string,
): EmailContent {
  return templateG4({
    ref: String(request.ref_number ?? "–"),
    booking_person_name: request.booking_person_name,
    parent_name: request.parent_name,
    old_helper_first_name: firstName(helperFullName),
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
  });
}

/** @deprecated use guardianReplacementArrangingEmail */
function guardianReplacementArrangingHtml(
  request: RequestContact,
  helperFullName: string,
): string {
  return guardianReplacementArrangingEmail(request, helperFullName).html;
}

function formatRemaining(ms: number): string {
  if (ms <= 0) return "less than 1 minute";
  const totalMinutes = Math.round(ms / 60000);
  if (totalMinutes < 60) {
    return `${totalMinutes} minute${totalMinutes === 1 ? "" : "s"}`;
  }
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (minutes === 0) return `${hours} hour${hours === 1 ? "" : "s"}`;
  return `${hours}h ${minutes}m`;
}

// ---- _shared/staff-auth.ts ----
type StaffProfile = {
  user_id: string;
  full_name: string;
  role: "super_admin" | "manager" | "helper";
  helper_id: string | null;
  is_active: boolean;
};

type StaffContext = {
  user: User;
  profile: StaffProfile;
  accessToken: string;
};

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json",
};

function authError(message: string, status: number): Response {
  return new Response(JSON.stringify({ ok: false, error: message }), {
    status,
    headers: corsHeaders,
  });
}

function bearerToken(req: Request): string | null {
  const header = req.headers.get("Authorization") || "";
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : null;
}

async function requireStaff(
  req: Request,
  serviceClient: SupabaseClient,
  options?: { superAdminOnly?: boolean },
): Promise<StaffContext | { error: Response }> {
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  if (!supabaseUrl || !anonKey) {
    return { error: authError("Server misconfigured", 500) };
  }

  const token = bearerToken(req);
  if (!token || token === anonKey) {
    return { error: authError("Unauthorized", 401) };
  }

  const userClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: userData, error: userError } = await userClient.auth.getUser();
  if (userError || !userData.user) {
    return { error: authError("Unauthorized", 401) };
  }

  const { data: profile, error: profileError } = await serviceClient
    .from("profiles")
    .select("user_id, full_name, role, helper_id, is_active")
    .eq("user_id", userData.user.id)
    .maybeSingle();

  if (profileError || !profile || !profile.is_active) {
    return { error: authError("Unauthorized", 401) };
  }

  if (profile.role !== "super_admin" && profile.role !== "manager") {
    return { error: authError("Forbidden", 403) };
  }

  if (options?.superAdminOnly && profile.role !== "super_admin") {
    return { error: authError("Forbidden", 403) };
  }

  return {
    user: userData.user,
    profile: profile as StaffProfile,
    accessToken: token,
  };
}

async function writeAudit(
  serviceClient: SupabaseClient,
  staff: StaffContext,
  action: string,
  entity: string,
  entityId?: string | null,
  details?: Record<string, unknown>,
): Promise<void> {
  const { error } = await serviceClient.rpc("write_audit_log", {
    p_actor_user_id: staff.user.id,
    p_actor_role: staff.profile.role,
    p_action: action,
    p_entity: entity,
    p_entity_id: entityId ?? null,
    p_details: details ?? {},
  });
  if (error) {
    console.error("write_audit_log failed", error);
  }
}

async function loadAppSettings(
  serviceClient: SupabaseClient,
): Promise<Record<string, string>> {
  const { data, error } = await serviceClient.from("app_settings").select("key, value");
  if (error) {
    console.error("loadAppSettings", error);
    return {};
  }
  const map: Record<string, string> = {};
  for (const row of data ?? []) {
    map[row.key] = String(row.value);
  }
  return map;
}

function settingInt(
  settings: Record<string, string>,
  key: string,
  fallback: number,
): number {
  const raw = settings[key];
  const n = Number(raw);
  return Number.isFinite(n) ? n : fallback;
}

// ---- helper-admin/index.ts ----
type Payload = {
  action?: string;
  helper_id?: string;
  search?: string;
  verification_status?: string;
  is_active?: boolean | string;
  gender?: string;
  area?: string;
  full_name?: string;
  email?: string;
  phone?: string;
  home_area?: string;
  home_pincode?: string;
  max_travel_km?: number | string;
  languages?: string | null;
  can_drive?: boolean;
  notes?: string | null;
  aadhaar_qr_verified?: boolean;
  aadhaar_last4?: string;
  aadhaar?: string;
  second_id_type?: string;
  second_id_last4?: string;
  dl_last4?: string;
  dl_expiry?: string;
  bg_check_method?: string;
  bg_check_reference?: string | null;
  bg_check_notes?: string | null;
  bg_check_date?: string;
  references_checked?: boolean;
  references_notes?: string | null;
  content_type?: string;
  file_ext?: string;
  path?: string;
  decision?: string;
  rejection_reason?: string;
  confirm?: boolean;
  password?: string;
};

type HelperRow = Record<string, unknown> & {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  gender: string;
  can_drive: boolean;
  verification_status: string;
  aadhaar_qr_verified: boolean;
  aadhaar_last4: string | null;
  second_id_type: string | null;
  second_id_last4: string | null;
  dl_last4: string | null;
  dl_expiry: string | null;
  bg_check_method: string | null;
  bg_check_date: string | null;
  photo_path: string | null;
  photo_status: string;
  is_active: boolean;
};

type UpcomingJob = {
  request_id: string;
  parent_name: string;
  appointment_date: string;
  appointment_time: string;
  doctor_hospital: string;
  area: string | null;
  status: string;
};

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const HELPER_SELECT = [
  "id",
  "full_name",
  "gender",
  "email",
  "phone",
  "city",
  "languages",
  "is_active",
  "notes",
  "home_area",
  "home_pincode",
  "max_travel_km",
  "latitude",
  "longitude",
  "location_missing",
  "can_drive",
  "verification_status",
  "aadhaar_qr_verified",
  "aadhaar_last4",
  "aadhaar_verified_at",
  "aadhaar_verified_by",
  "second_id_type",
  "second_id_last4",
  "dl_last4",
  "dl_expiry",
  "bg_check_method",
  "bg_check_reference",
  "bg_check_notes",
  "bg_check_date",
  "photo_path",
  "photo_status",
  "references_checked",
  "references_notes",
  "verified_at",
  "verified_by",
  "rejection_reason",
  "dl_warn_30_sent_at",
  "dl_warn_7_sent_at",
  "dl_expired_notified_at",
  "created_at",
  "updated_at",
].join(", ");

const SECOND_ID_TYPES = new Set([
  "pan",
  "voter_id",
  "passport",
  "driving_licence",
]);

const BG_METHODS = new Set([
  "police_certificate",
  "vendor",
  "in_house",
]);

const PHOTO_CONTENT_TYPES = new Set(["image/jpeg", "image/png"]);

/** Tiny 1×1 transparent PNG for TEST helper placeholders. */
const PNG_1X1 = new Uint8Array([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
  0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
  0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0x15, 0xc4, 0x89, 0x00, 0x00, 0x00,
  0x0a, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9c, 0x63, 0x00, 0x01, 0x00, 0x00,
  0x05, 0x00, 0x01, 0x0d, 0x0a, 0x2d, 0xb4, 0x00, 0x00, 0x00, 0x00, 0x49,
  0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82,
]);

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json",
      Connection: "keep-alive",
    },
  });
}

function todayIst(): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

function isLast4(value: unknown): value is string {
  return typeof value === "string" && /^\d{4}$/.test(value);
}

function looksLikeFullAadhaar(value: unknown): boolean {
  if (typeof value !== "string") return false;
  const digits = value.replace(/\D/g, "");
  return digits.length === 12 || value.trim().length > 4;
}

function parseBool(value: unknown): boolean | undefined {
  if (typeof value === "boolean") return value;
  if (value === "true" || value === "1") return true;
  if (value === "false" || value === "0") return false;
  return undefined;
}

function appointmentIsFuture(date: string, time: string): boolean {
  const ms = Date.parse(
    `${date}T${String(time).slice(0, 8)}+05:30`,
  );
  return Number.isFinite(ms) && ms >= Date.now();
}

export function verificationProgress(helper: {
  aadhaar_qr_verified?: boolean | null;
  aadhaar_last4?: string | null;
  second_id_type?: string | null;
  second_id_last4?: string | null;
  can_drive?: boolean | null;
  dl_expiry?: string | null;
  bg_check_method?: string | null;
  bg_check_date?: string | null;
  photo_status?: string | null;
}): {
  done: number;
  total: 4;
  items: {
    aadhaar: boolean;
    second_id: boolean;
    bg_check: boolean;
    photo: boolean;
  };
} {
  const today = todayIst();
  const aadhaar = Boolean(helper.aadhaar_qr_verified) &&
    isLast4(helper.aadhaar_last4);
  let secondId = Boolean(helper.second_id_type) && isLast4(helper.second_id_last4);
  if (helper.can_drive) {
    secondId = secondId &&
      helper.second_id_type === "driving_licence" &&
      typeof helper.dl_expiry === "string" &&
      helper.dl_expiry > today;
  }
  const bgCheck = Boolean(helper.bg_check_method) &&
    Boolean(helper.bg_check_date);
  const photo = helper.photo_status === "approved";
  const items = {
    aadhaar,
    second_id: secondId,
    bg_check: bgCheck,
    photo,
  };
  const done = Object.values(items).filter(Boolean).length;
  return { done, total: 4, items };
}

async function loadHelper(
  admin: SupabaseClient,
  helperId: string,
): Promise<HelperRow | null> {
  const { data, error } = await admin
    .from("helpers")
    .select(HELPER_SELECT)
    .eq("id", helperId)
    .maybeSingle();
  if (error) throw error;
  return (data as HelperRow | null) ?? null;
}

async function listUpcomingJobs(
  admin: SupabaseClient,
  helperId: string,
): Promise<UpcomingJob[]> {
  const { data, error } = await admin.rpc(
    "list_helper_upcoming_assigned_jobs",
    { p_helper_id: helperId },
  );
  if (error) throw error;
  return (data ?? []) as UpcomingJob[];
}

async function upcomingJobCounts(
  admin: SupabaseClient,
  helperIds: string[],
): Promise<Map<string, number>> {
  const counts = new Map<string, number>();
  for (const id of helperIds) counts.set(id, 0);
  if (!helperIds.length) return counts;

  const { data, error } = await admin
    .from("consultation_requests")
    .select("id, assigned_helper_id, appointment_date, appointment_time, status")
    .eq("status", "assigned")
    .in("assigned_helper_id", helperIds);
  if (error) throw error;

  for (const row of data ?? []) {
    const helperId = row.assigned_helper_id as string | null;
    if (!helperId) continue;
    if (
      appointmentIsFuture(
        String(row.appointment_date),
        String(row.appointment_time),
      )
    ) {
      counts.set(helperId, (counts.get(helperId) ?? 0) + 1);
    }
  }
  return counts;
}

async function notifyUnavailableEmails(
  supabase: SupabaseClient,
  requestId: string,
  helperId: string,
  reasonLabel: string,
) {
  const [{ data: request }, { data: helper }] = await Promise.all([
    supabase
      .from("consultation_requests")
      .select(
        "id, ref_number, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason, booking_person_name, relationship, phone_country_code, phone, email, address_line1, street, landmark, city",
      )
      .eq("id", requestId)
      .maybeSingle(),
    supabase
      .from("helpers")
      .select("id, full_name, phone")
      .eq("id", helperId)
      .maybeSingle(),
  ]);
  if (!request || !helper) return;

  const seniorEmail = await resolveSecret(supabase, "SENIOR_EMAIL");

  if (seniorEmail) {
    const email = templateM5({
      ref: String(request.ref_number ?? "–"),
      manager_first_name: MANAGER_FIRST_NAME,
      helper_full_name: helper.full_name,
      parent_name: request.parent_name,
      parent_age: request.parent_age,
      appointment_date: request.appointment_date,
      appointment_time: request.appointment_time,
      area: request.area,
      city: request.city,
      pincode: request.pincode,
      doctor_hospital: request.doctor_hospital,
      booking_person_name: request.booking_person_name,
      relationship: String(request.relationship ?? ""),
      guardian_phone: `${request.phone_country_code ?? ""} ${request.phone ?? ""}`.trim(),
      dropout_reason: reasonLabel,
      assign_url: seniorAssignUrl(requestId),
    });
    await sendEmail({
      to: seniorEmail,
      toName: "Senior coordinator",
      subject: email.subject,
      html: email.html,
      text: email.text,
    });
  }

  const guardianEmail = guardianReplacementArrangingEmail(
    {
      parent_name: request.parent_name,
      parent_age: request.parent_age,
      address_line1: request.address_line1,
      street: request.street,
      area: request.area,
      landmark: request.landmark,
      city: request.city,
      pincode: request.pincode,
      appointment_date: request.appointment_date,
      appointment_time: request.appointment_time,
      doctor_hospital: request.doctor_hospital,
      booking_person_name: request.booking_person_name,
      relationship: String(request.relationship ?? ""),
      phone_country_code: String(request.phone_country_code ?? ""),
      phone: String(request.phone ?? ""),
      ref_number: request.ref_number,
    },
    helper.full_name,
  );
  await sendEmail({
    to: request.email,
    toName: request.booking_person_name,
    subject: guardianEmail.subject,
    html: guardianEmail.html,
    text: guardianEmail.text,
  });
}

async function releaseHelperJobs(
  admin: SupabaseClient,
  helperId: string,
  jobs: UpcomingJob[],
  reasonLabel: string,
): Promise<{ request_id: string; helper_id: string }[]> {
  const released: { request_id: string; helper_id: string }[] = [];
  for (const job of jobs) {
    const { data, error } = await admin.rpc("release_assigned_helper", {
      p_request_id: job.request_id,
      p_reason: "helper_unavailable",
      p_expected_helper_id: helperId,
    });
    if (error) {
      console.error("release_assigned_helper", error);
      continue;
    }
    const result = data as { ok?: boolean; request_id?: string; helper_id?: string };
    if (result?.ok) {
      released.push({
        request_id: result.request_id ?? job.request_id,
        helper_id: result.helper_id ?? helperId,
      });
      try {
        await notifyUnavailableEmails(
          admin,
          job.request_id,
          helperId,
          reasonLabel,
        );
      } catch (emailError) {
        console.error("notifyUnavailableEmails", emailError);
      }
    }
  }
  await admin.rpc("withdraw_helper_open_offers", { p_helper_id: helperId });
  return released;
}

async function resolveCityFromPincode(
  admin: SupabaseClient,
  pincode: string,
): Promise<string> {
  const { data, error } = await admin
    .from("pincodes")
    .select("district")
    .eq("pincode", pincode)
    .maybeSingle();
  if (error) {
    console.error("pincode lookup", error);
  }
  const district = data?.district ? String(data.district).trim() : "";
  return district || "Chennai";
}

function pickProfileFields(payload: Payload): {
  fields: Record<string, unknown>;
  error?: string;
} {
  const fields: Record<string, unknown> = {};

  if (payload.full_name !== undefined) {
    const fullName = String(payload.full_name ?? "").trim();
    if (!fullName) return { fields, error: "full_name required" };
    fields.full_name = fullName;
  }
  if (payload.gender !== undefined) {
    const gender = String(payload.gender ?? "").trim().toLowerCase();
    if (gender !== "female" && gender !== "male") {
      return { fields, error: "gender must be female or male" };
    }
    fields.gender = gender;
  }
  if (payload.email !== undefined) {
    const email = String(payload.email ?? "").trim().toLowerCase();
    if (!email || !email.includes("@")) {
      return { fields, error: "valid email required" };
    }
    fields.email = email;
  }
  if (payload.phone !== undefined) {
    const phone = String(payload.phone ?? "").trim();
    if (!phone) return { fields, error: "phone required" };
    fields.phone = phone;
  }
  if (payload.home_area !== undefined) {
    fields.home_area = String(payload.home_area ?? "").trim() || null;
  }
  if (payload.home_pincode !== undefined) {
    const pin = String(payload.home_pincode ?? "").trim();
    if (!/^\d{6}$/.test(pin)) {
      return { fields, error: "home_pincode must be 6 digits" };
    }
    fields.home_pincode = pin;
  }
  if (payload.max_travel_km !== undefined) {
    const km = Number(payload.max_travel_km);
    if (!Number.isFinite(km) || km <= 0 || km > 200) {
      return { fields, error: "max_travel_km must be between 1 and 200" };
    }
    fields.max_travel_km = Math.round(km);
  }
  if (payload.languages !== undefined) {
    fields.languages = payload.languages == null
      ? null
      : String(payload.languages).trim() || null;
  }
  if (payload.can_drive !== undefined) {
    const canDrive = parseBool(payload.can_drive);
    if (canDrive === undefined) {
      return { fields, error: "can_drive must be boolean" };
    }
    fields.can_drive = canDrive;
  }
  if (payload.notes !== undefined) {
    fields.notes = payload.notes == null
      ? null
      : String(payload.notes).trim() || null;
  }

  return { fields };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return jsonResponse({ ok: false, error: "Method not allowed" }, 405);
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceRoleKey) {
      throw new Error("Missing Supabase environment configuration");
    }

    const admin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const staffOrError = await requireStaff(req, admin);
    if ("error" in staffOrError) return staffOrError.error;
    const staff: StaffContext = staffOrError;

    const payload = (await req.json().catch(() => ({}))) as Payload;
    const action = String(payload.action ?? "").trim().toLowerCase();

    // ------------------------------------------------------------------ list
    if (action === "list") {
      let query = admin.from("helpers").select(HELPER_SELECT).order(
        "full_name",
        { ascending: true },
      );

      const search = String(payload.search ?? "").trim().replace(/[%_,]/g, " ");
      if (search) {
        const like = `%${search}%`;
        query = query.or(
          `full_name.ilike.${like},phone.ilike.${like},home_area.ilike.${like}`,
        );
      }
      const verification = String(payload.verification_status ?? "").trim();
      if (verification) {
        query = query.eq("verification_status", verification);
      }
      const active = parseBool(payload.is_active);
      if (active !== undefined) {
        query = query.eq("is_active", active);
      }
      const gender = String(payload.gender ?? "").trim().toLowerCase();
      if (gender === "female" || gender === "male") {
        query = query.eq("gender", gender);
      }
      const area = String(payload.area ?? "").trim();
      if (area) {
        query = query.ilike("home_area", `%${area}%`);
      }

      const { data, error } = await query;
      if (error) throw error;
      const helpers = (data ?? []) as HelperRow[];
      const counts = await upcomingJobCounts(
        admin,
        helpers.map((h) => h.id),
      );

      return jsonResponse({
        ok: true,
        helpers: helpers.map((h) => ({
          ...h,
          upcoming_assigned_jobs: counts.get(h.id) ?? 0,
          verification_progress: verificationProgress(h),
        })),
      });
    }

    // ------------------------------------------------------------------- get
    if (action === "get") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      const [jobs, { data: profile, error: profileError }] = await Promise.all([
        listUpcomingJobs(admin, helperId),
        admin
          .from("profiles")
          .select("user_id, full_name, role, helper_id, is_active, created_at")
          .eq("helper_id", helperId)
          .maybeSingle(),
      ]);
      if (profileError) throw profileError;

      return jsonResponse({
        ok: true,
        helper: {
          ...helper,
          verification_progress: verificationProgress(helper),
        },
        upcoming_jobs: jobs,
        login: profile ?? null,
        profile: profile ?? null,
      });
    }

    // ---------------------------------------------------------------- create
    if (action === "create") {
      const required = pickProfileFields({
        ...payload,
        full_name: payload.full_name,
        gender: payload.gender,
        email: payload.email,
        phone: payload.phone,
        home_area: payload.home_area,
        home_pincode: payload.home_pincode,
        max_travel_km: payload.max_travel_km ?? 10,
        languages: payload.languages,
        can_drive: payload.can_drive ?? false,
        notes: payload.notes,
      });
      if (required.error) {
        return jsonResponse({ ok: false, error: required.error }, 400);
      }
      for (
        const key of [
          "full_name",
          "gender",
          "email",
          "phone",
          "home_pincode",
        ] as const
      ) {
        if (required.fields[key] == null) {
          return jsonResponse({
            ok: false,
            error: `${key} required`,
          }, 400);
        }
      }

      const pin = String(required.fields.home_pincode);
      const city = await resolveCityFromPincode(admin, pin);
      const insertRow = {
        ...required.fields,
        city,
        verification_status: "pending",
        photo_status: "none",
        aadhaar_qr_verified: false,
        is_active: true,
      };

      const { data: created, error: createError } = await admin
        .from("helpers")
        .insert(insertRow)
        .select(HELPER_SELECT)
        .single();
      if (createError) {
        return jsonResponse({
          ok: false,
          error: createError.message.includes("unique")
            ? "Email already in use"
            : createError.message,
        }, 400);
      }

      await writeAudit(admin, staff, "create_helper", "helper", created.id, {
        email: created.email,
        full_name: created.full_name,
      });

      return jsonResponse({
        ok: true,
        helper_id: created.id,
        message: "Helper created.",
        helper: {
          ...created,
          verification_progress: verificationProgress(created as HelperRow),
        },
      });
    }

    // ---------------------------------------------------------------- update
    if (action === "update") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const existing = await loadHelper(admin, helperId);
      if (!existing) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }

      const picked = pickProfileFields(payload);
      if (picked.error) {
        return jsonResponse({ ok: false, error: picked.error }, 400);
      }
      if (!Object.keys(picked.fields).length) {
        return jsonResponse({ ok: false, error: "No fields to update" }, 400);
      }

      if (typeof picked.fields.home_pincode === "string") {
        picked.fields.city = await resolveCityFromPincode(
          admin,
          picked.fields.home_pincode,
        );
      }

      // Drivers must keep driving_licence as second ID when both are set
      const nextCanDrive = picked.fields.can_drive === undefined
        ? existing.can_drive
        : Boolean(picked.fields.can_drive);
      if (
        nextCanDrive &&
        existing.second_id_type &&
        existing.second_id_type !== "driving_licence" &&
        picked.fields.can_drive === true
      ) {
        return jsonResponse({
          ok: false,
          error:
            "Drivers must use driving_licence as second ID. Update second ID first.",
        }, 400);
      }

      const { data: updated, error: updateError } = await admin
        .from("helpers")
        .update(picked.fields)
        .eq("id", helperId)
        .select(HELPER_SELECT)
        .single();
      if (updateError) {
        return jsonResponse({
          ok: false,
          error: updateError.message.includes("unique")
            ? "Email already in use"
            : updateError.message,
        }, 400);
      }

      await writeAudit(admin, staff, "update_helper", "helper", helperId, {
        fields: Object.keys(picked.fields),
      });

      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated as HelperRow),
        },
      });
    }

    // ---------------------------------------------------------- save_aadhaar
    if (action === "save_aadhaar") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      if (payload.aadhaar_qr_verified !== true) {
        return jsonResponse({
          ok: false,
          error: "aadhaar_qr_verified must be true",
        }, 400);
      }

      // Never accept full Aadhaar
      if (
        payload.aadhaar !== undefined ||
        looksLikeFullAadhaar(payload.aadhaar_last4) ||
        (typeof payload.aadhaar_last4 === "string" &&
          payload.aadhaar_last4.length !== 4)
      ) {
        return jsonResponse({
          ok: false,
          error: "Only aadhaar_last4 (exactly 4 digits) is accepted. Never send full Aadhaar.",
        }, 400);
      }
      if (!isLast4(payload.aadhaar_last4)) {
        return jsonResponse({
          ok: false,
          error: "aadhaar_last4 must be exactly 4 digits",
        }, 400);
      }

      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }

      // Leave verification_status alone for rejected/expired (completing flow later)
      const { data: updated, error } = await admin
        .from("helpers")
        .update({
          aadhaar_qr_verified: true,
          aadhaar_last4: payload.aadhaar_last4,
          aadhaar_verified_at: new Date().toISOString(),
          aadhaar_verified_by: staff.user.id,
        })
        .eq("id", helperId)
        .select(HELPER_SELECT)
        .single();
      if (error) throw error;

      await writeAudit(admin, staff, "save_aadhaar", "helper", helperId, {
        aadhaar_last4: payload.aadhaar_last4,
      });

      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated as HelperRow),
        },
      });
    }

    // -------------------------------------------------------- save_second_id
    if (action === "save_second_id") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }

      const secondIdType = String(payload.second_id_type ?? "").trim();
      if (!SECOND_ID_TYPES.has(secondIdType)) {
        return jsonResponse({
          ok: false,
          error: "second_id_type must be pan|voter_id|passport|driving_licence",
        }, 400);
      }
      if (!isLast4(payload.second_id_last4)) {
        return jsonResponse({
          ok: false,
          error: "second_id_last4 must be exactly 4 digits",
        }, 400);
      }

      let dlLast4 = payload.dl_last4 !== undefined
        ? String(payload.dl_last4)
        : undefined;
      let dlExpiry = payload.dl_expiry !== undefined
        ? String(payload.dl_expiry).trim()
        : undefined;

      if (secondIdType === "driving_licence" && !dlLast4) {
        dlLast4 = payload.second_id_last4;
      }

      if (helper.can_drive) {
        if (secondIdType !== "driving_licence") {
          return jsonResponse({
            ok: false,
            error: "Drivers must use driving_licence as second ID",
          }, 400);
        }
        if (!dlExpiry || !/^\d{4}-\d{2}-\d{2}$/.test(dlExpiry)) {
          return jsonResponse({
            ok: false,
            error: "dl_expiry (YYYY-MM-DD) required for drivers",
          }, 400);
        }
        if (dlExpiry <= todayIst()) {
          return jsonResponse({
            ok: false,
            error: "dl_expiry must be a future date (Asia/Kolkata)",
          }, 400);
        }
      } else if (secondIdType === "driving_licence" || dlExpiry) {
        if (dlExpiry && !/^\d{4}-\d{2}-\d{2}$/.test(dlExpiry)) {
          return jsonResponse({
            ok: false,
            error: "dl_expiry must be YYYY-MM-DD",
          }, 400);
        }
        if (dlExpiry && helper.can_drive && dlExpiry <= todayIst()) {
          return jsonResponse({
            ok: false,
            error: "dl_expiry must be a future date",
          }, 400);
        }
      }

      if (dlLast4 !== undefined && dlLast4 !== "" && !isLast4(dlLast4)) {
        return jsonResponse({
          ok: false,
          error: "dl_last4 must be exactly 4 digits",
        }, 400);
      }

      const patch: Record<string, unknown> = {
        second_id_type: secondIdType,
        second_id_last4: payload.second_id_last4,
      };
      if (secondIdType === "driving_licence") {
        patch.dl_last4 = dlLast4 ?? payload.second_id_last4;
        if (dlExpiry) patch.dl_expiry = dlExpiry;
      } else if (!helper.can_drive) {
        // Clear DL fields when switching away from licence for non-drivers
        patch.dl_last4 = null;
        patch.dl_expiry = null;
      }

      const { data: updated, error } = await admin
        .from("helpers")
        .update(patch)
        .eq("id", helperId)
        .select(HELPER_SELECT)
        .single();
      if (error) throw error;

      await writeAudit(admin, staff, "save_second_id", "helper", helperId, {
        second_id_type: secondIdType,
      });

      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated as HelperRow),
        },
      });
    }

    // -------------------------------------------------------- save_bg_check
    if (action === "save_bg_check") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const method = String(payload.bg_check_method ?? "").trim();
      if (!BG_METHODS.has(method)) {
        return jsonResponse({
          ok: false,
          error: "bg_check_method must be police_certificate|vendor|in_house",
        }, 400);
      }
      const bgDate = String(payload.bg_check_date ?? "").trim();
      if (!/^\d{4}-\d{2}-\d{2}$/.test(bgDate)) {
        return jsonResponse({
          ok: false,
          error: "bg_check_date must be YYYY-MM-DD",
        }, 400);
      }

      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }

      const { data: updated, error } = await admin
        .from("helpers")
        .update({
          bg_check_method: method,
          bg_check_reference: payload.bg_check_reference == null
            ? null
            : String(payload.bg_check_reference).trim() || null,
          bg_check_notes: payload.bg_check_notes == null
            ? null
            : String(payload.bg_check_notes).trim() || null,
          bg_check_date: bgDate,
        })
        .eq("id", helperId)
        .select(HELPER_SELECT)
        .single();
      if (error) throw error;

      await writeAudit(admin, staff, "save_bg_check", "helper", helperId, {
        bg_check_method: method,
        bg_check_date: bgDate,
      });

      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated as HelperRow),
        },
      });
    }

    // ------------------------------------------------------ save_references
    if (action === "save_references") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const checked = parseBool(payload.references_checked);
      if (checked === undefined) {
        return jsonResponse({
          ok: false,
          error: "references_checked boolean required",
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }

      const { data: updated, error } = await admin
        .from("helpers")
        .update({
          references_checked: checked,
          references_notes: payload.references_notes == null
            ? null
            : String(payload.references_notes).trim() || null,
        })
        .eq("id", helperId)
        .select(HELPER_SELECT)
        .single();
      if (error) throw error;

      await writeAudit(admin, staff, "save_references", "helper", helperId, {
        references_checked: checked,
      });

      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated as HelperRow),
        },
      });
    }

    // ---------------------------------------------------- photo_upload_url
    if (action === "photo_upload_url") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const contentType = String(payload.content_type ?? "").trim()
        .toLowerCase();
      if (!PHOTO_CONTENT_TYPES.has(contentType)) {
        return jsonResponse({
          ok: false,
          error: "content_type must be image/jpeg or image/png",
        }, 400);
      }
      let ext = String(payload.file_ext ?? "").trim().toLowerCase()
        .replace(/^\./, "");
      if (!ext) {
        ext = contentType === "image/png" ? "png" : "jpg";
      }
      if (ext !== "png" && ext !== "jpg" && ext !== "jpeg") {
        return jsonResponse({
          ok: false,
          error: "file_ext must be png, jpg, or jpeg",
        }, 400);
      }
      if (ext === "jpeg") ext = "jpg";

      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }

      const path = `${helperId}/${Date.now()}.${ext}`;
      const { data, error } = await admin.storage
        .from("helper-photos")
        .createSignedUploadUrl(path);
      if (error || !data) {
        return jsonResponse({
          ok: false,
          error: error?.message ?? "Could not create upload URL",
        }, 400);
      }

      await writeAudit(
        admin,
        staff,
        "request_photo_upload",
        "helper",
        helperId,
        { path, content_type: contentType },
      );

      return jsonResponse({
        ok: true,
        path: data.path ?? path,
        token: data.token,
        signedUrl: data.signedUrl,
      });
    }

    // ------------------------------------------------------ photo_confirm
    if (action === "photo_confirm") {
      const helperId = String(payload.helper_id ?? "").trim();
      const path = String(payload.path ?? "").trim();
      if (!helperId || !path) {
        return jsonResponse({
          ok: false,
          error: "helper_id and path required",
        }, 400);
      }
      if (!path.startsWith(`${helperId}/`)) {
        return jsonResponse({
          ok: false,
          error: "path must start with helper_id/",
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }

      const { data: updated, error } = await admin
        .from("helpers")
        .update({ photo_path: path, photo_status: "pending" })
        .eq("id", helperId)
        .select(HELPER_SELECT)
        .single();
      if (error) throw error;

      await writeAudit(admin, staff, "photo_confirm", "helper", helperId, {
        path,
      });

      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated as HelperRow),
        },
      });
    }

    // --------------------------------------------------- photo_signed_url
    if (action === "photo_signed_url") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      if (!helper.photo_path) {
        return jsonResponse({
          ok: false,
          error: "No photo uploaded",
        }, 404);
      }

      const { data, error } = await admin.storage
        .from("helper-photos")
        .createSignedUrl(helper.photo_path, 300);
      if (error || !data?.signedUrl) {
        return jsonResponse({
          ok: false,
          error: error?.message ?? "Could not create signed URL",
        }, 400);
      }

      return jsonResponse({
        ok: true,
        signedUrl: data.signedUrl,
        path: helper.photo_path,
        expires_in: 300,
      });
    }

    // ------------------------------------------------------- photo_review
    if (action === "photo_review") {
      const helperId = String(payload.helper_id ?? "").trim();
      const decision = String(payload.decision ?? "").trim().toLowerCase();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      if (decision !== "approved" && decision !== "rejected") {
        return jsonResponse({
          ok: false,
          error: "decision must be approved or rejected",
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      if (!helper.photo_path) {
        return jsonResponse({
          ok: false,
          error: "No photo to review",
        }, 400);
      }

      const { data: updated, error } = await admin
        .from("helpers")
        .update({ photo_status: decision })
        .eq("id", helperId)
        .select(HELPER_SELECT)
        .single();
      if (error) throw error;

      await writeAudit(admin, staff, "photo_review", "helper", helperId, {
        decision,
      });

      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated as HelperRow),
        },
      });
    }

    // ------------------------------------------------------- mark_verified
    if (action === "mark_verified") {
      const helperId = String(payload.helper_id ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }

      const progress = verificationProgress(helper);
      if (!progress.items.aadhaar) {
        return jsonResponse({
          ok: false,
          error: "Aadhaar QR verification and last4 required",
        }, 400);
      }
      if (!helper.second_id_type || !isLast4(helper.second_id_last4)) {
        return jsonResponse({
          ok: false,
          error: "Second ID type and last4 required",
        }, 400);
      }
      if (helper.can_drive) {
        if (helper.second_id_type !== "driving_licence") {
          return jsonResponse({
            ok: false,
            error: "Drivers require driving_licence as second ID",
          }, 400);
        }
        if (!helper.dl_expiry || helper.dl_expiry <= todayIst()) {
          return jsonResponse({
            ok: false,
            error: "Drivers require a future DL expiry date",
          }, 400);
        }
      }
      if (!helper.bg_check_method || !helper.bg_check_date) {
        return jsonResponse({
          ok: false,
          error: "Background check method and date required",
        }, 400);
      }
      if (helper.photo_status !== "approved") {
        return jsonResponse({
          ok: false,
          error: "Photo must be approved",
        }, 400);
      }

      const { data: updated, error } = await admin
        .from("helpers")
        .update({
          verification_status: "verified",
          verified_at: new Date().toISOString(),
          verified_by: staff.user.id,
          rejection_reason: null,
        })
        .eq("id", helperId)
        .select(HELPER_SELECT)
        .single();
      if (error) throw error;

      await writeAudit(admin, staff, "mark_verified", "helper", helperId, {});

      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated as HelperRow),
        },
      });
    }

    // ----------------------------------------------------------------- reject
    if (action === "reject") {
      const helperId = String(payload.helper_id ?? "").trim();
      const reason = String(payload.rejection_reason ?? "").trim();
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      if (!reason) {
        return jsonResponse({
          ok: false,
          error: "rejection_reason required",
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }

      const jobs = await listUpcomingJobs(admin, helperId);
      if (jobs.length > 0 && payload.confirm !== true) {
        return jsonResponse({
          ok: false,
          code: "needs_confirmation",
          jobs,
          message:
            `${helper.full_name} has ${jobs.length} upcoming assigned job(s). Confirm to release and reject.`,
        });
      }

      let released: { request_id: string; helper_id: string }[] = [];
      if (jobs.length > 0) {
        released = await releaseHelperJobs(
          admin,
          helperId,
          jobs,
          "Helper verification rejected",
        );
      } else {
        await admin.rpc("withdraw_helper_open_offers", {
          p_helper_id: helperId,
        });
      }

      const { data: updated, error } = await admin
        .from("helpers")
        .update({
          verification_status: "rejected",
          rejection_reason: reason,
        })
        .eq("id", helperId)
        .select(HELPER_SELECT)
        .single();
      if (error) throw error;

      await writeAudit(admin, staff, "reject_helper", "helper", helperId, {
        rejection_reason: reason,
        released_count: released.length,
      });

      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated as HelperRow),
        },
        released,
      });
    }

    // ------------------------------------------------------------- set_active
    if (action === "set_active") {
      const helperId = String(payload.helper_id ?? "").trim();
      const nextActive = parseBool(payload.is_active);
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      if (nextActive === undefined) {
        return jsonResponse({
          ok: false,
          error: "is_active boolean required",
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }

      let released: { request_id: string; helper_id: string }[] = [];
      if (!nextActive) {
        const jobs = await listUpcomingJobs(admin, helperId);
        if (jobs.length > 0 && payload.confirm !== true) {
          return jsonResponse({
            ok: false,
            code: "needs_confirmation",
            jobs,
            message:
              `${helper.full_name} has ${jobs.length} upcoming assigned job(s). Confirm to release and deactivate.`,
          });
        }
        if (jobs.length > 0) {
          released = await releaseHelperJobs(
            admin,
            helperId,
            jobs,
            "Helper deactivated",
          );
        } else {
          await admin.rpc("withdraw_helper_open_offers", {
            p_helper_id: helperId,
          });
        }
      }

      const { data: updated, error } = await admin
        .from("helpers")
        .update({ is_active: nextActive })
        .eq("id", helperId)
        .select(HELPER_SELECT)
        .single();
      if (error) throw error;

      await writeAudit(
        admin,
        staff,
        nextActive ? "activate_helper" : "deactivate_helper",
        "helper",
        helperId,
        { released_count: released.length },
      );

      return jsonResponse({
        ok: true,
        helper: {
          ...updated,
          verification_progress: verificationProgress(updated as HelperRow),
        },
        released,
      });
    }

    // ---------------------------------------------------------- create_login
    if (action === "create_login") {
      const helperId = String(payload.helper_id ?? "").trim();
      const password = String(payload.password ?? "");
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      if (password.length < 8) {
        return jsonResponse({
          ok: false,
          error: "password must be at least 8 characters",
        }, 400);
      }
      const helper = await loadHelper(admin, helperId);
      if (!helper) {
        return jsonResponse({ ok: false, error: "Helper not found" }, 404);
      }
      if (helper.verification_status !== "verified") {
        return jsonResponse({
          ok: false,
          error: "Helper must be verified before creating a login",
        }, 400);
      }

      const { data: existingProfile, error: existingError } = await admin
        .from("profiles")
        .select("user_id")
        .eq("helper_id", helperId)
        .maybeSingle();
      if (existingError) throw existingError;
      if (existingProfile) {
        return jsonResponse({
          ok: false,
          error: "Login profile already exists for this helper",
        }, 400);
      }

      const { data: created, error: createError } = await admin.auth.admin
        .createUser({
          email: helper.email,
          password,
          email_confirm: true,
          user_metadata: { full_name: helper.full_name, role: "helper" },
        });
      if (createError || !created.user) {
        return jsonResponse({
          ok: false,
          error: createError?.message ?? "Could not create auth user",
        }, 400);
      }

      const { error: profileError } = await admin.from("profiles").insert({
        user_id: created.user.id,
        full_name: helper.full_name,
        role: "helper",
        helper_id: helperId,
        is_active: true,
        created_by: staff.user.id,
      });
      if (profileError) {
        await admin.auth.admin.deleteUser(created.user.id);
        return jsonResponse({
          ok: false,
          error: profileError.message,
        }, 400);
      }

      await writeAudit(admin, staff, "create_helper_login", "helper", helperId, {
        user_id: created.user.id,
        email: helper.email,
      });

      
      const loginEmail = templateH5({
        helper_first_name: firstName(helper.full_name),
        helper_email: helper.email,
        helper_app_link: HELPER_APP_LINK,
      });
      let loginEmailResult = null;
      try {
        loginEmailResult = await sendEmail({
          to: helper.email,
          toName: helper.full_name,
          subject: loginEmail.subject,
          html: loginEmail.html,
          text: loginEmail.text,
        });
      } catch (emailError) {
        console.error("H5 login email failed", emailError);
      }

      return jsonResponse({
        ok: true,
        user_id: created.user.id,
        email: helper.email,
        message: `Login created for ${helper.email}.`,
        login_email: loginEmailResult
          ? { ok: loginEmailResult.ok, id: loginEmailResult.id, subject: loginEmailResult.subject }
          : null,
      });
    }

    // ----------------------------------------------------- set_login_active
    if (action === "set_login_active") {
      const helperId = String(payload.helper_id ?? "").trim();
      const nextActive = parseBool(payload.is_active);
      if (!helperId) {
        return jsonResponse({ ok: false, error: "helper_id required" }, 400);
      }
      if (nextActive === undefined) {
        return jsonResponse({
          ok: false,
          error: "is_active boolean required",
        }, 400);
      }

      const { data: profile, error: loadError } = await admin
        .from("profiles")
        .select("user_id, full_name, role, helper_id, is_active")
        .eq("helper_id", helperId)
        .maybeSingle();
      if (loadError) throw loadError;
      if (!profile) {
        return jsonResponse({
          ok: false,
          error: "No login profile for this helper",
        }, 404);
      }

      const { error: updateError } = await admin
        .from("profiles")
        .update({ is_active: nextActive })
        .eq("helper_id", helperId);
      if (updateError) throw updateError;

      if (!nextActive) {
        try {
          await admin.auth.admin.signOut(profile.user_id, "global");
        } catch (signOutError) {
          console.error("signOut after set_login_active", signOutError);
        }
      }

      await writeAudit(
        admin,
        staff,
        nextActive ? "activate_helper_login" : "deactivate_helper_login",
        "helper",
        helperId,
        { user_id: profile.user_id },
      );

      return jsonResponse({
        ok: true,
        profile: { ...profile, is_active: nextActive },
      });
    }

    // --------------------------------------------- seed_placeholder_photos
    if (action === "seed_placeholder_photos") {
      const { data: helpers, error } = await admin
        .from("helpers")
        .select("id, photo_path, notes")
        .not("photo_path", "is", null);
      if (error) throw error;

      const results: Record<string, unknown>[] = [];
      for (const helper of helpers ?? []) {
        const path = String(helper.photo_path ?? "");
        if (!path) continue;

        const { data: existing, error: downloadError } = await admin.storage
          .from("helper-photos")
          .download(path);

        if (!downloadError && existing) {
          results.push({ helper_id: helper.id, path, status: "exists" });
          continue;
        }

        const { error: uploadError } = await admin.storage
          .from("helper-photos")
          .upload(path, PNG_1X1, {
            contentType: "image/png",
            upsert: true,
          });
        if (uploadError) {
          results.push({
            helper_id: helper.id,
            path,
            status: "error",
            error: uploadError.message,
          });
        } else {
          results.push({ helper_id: helper.id, path, status: "uploaded" });
        }
      }

      await writeAudit(
        admin,
        staff,
        "seed_placeholder_photos",
        "helper",
        null,
        { count: results.length },
      );

      return jsonResponse({ ok: true, results });
    }

    return jsonResponse({ ok: false, error: "Unknown action" }, 400);
  } catch (error) {
    console.error(error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return jsonResponse({ ok: false, error: message }, 500);
  }
});
