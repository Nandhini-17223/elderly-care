// ../../../tmp/fn-src/supabase/functions/senior-api/index.ts
import { createClient as createClient2 } from "jsr:@supabase/supabase-js@2";

// ../../../tmp/fn-src/supabase/functions/_shared/email.ts
var SUPPORT_PHONE = "+91 73399 11220";
var LOGO_URL = "https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg";
var BRAND_PRIMARY = "#1d6fd8";
var BRAND_ACCENT = "#4a9cf7";
var BRAND_TEXT = "#1f2937";
var BRAND_MUTED = "#6b7280";
var MONTHS_SHORT = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
];
var WEEKDAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
function escapeHtml(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}
function displayValue(value, fallback = "\u2013") {
  if (value === null || value === void 0) return fallback;
  const text = String(value).trim();
  if (!text || text.toLowerCase() === "null" || text.toLowerCase() === "undefined") {
    return fallback;
  }
  return text;
}
function displayOrNone(value) {
  return displayValue(value, "None given");
}
function parseDateParts(appointmentDate) {
  if (!appointmentDate) return null;
  const dateMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(appointmentDate.trim());
  if (!dateMatch) return null;
  const year = Number(dateMatch[1]);
  const month = Number(dateMatch[2]);
  const day = Number(dateMatch[3]);
  if (!month || month < 1 || month > 12 || !day || day < 1 || day > 31) {
    return null;
  }
  return { year, month, day };
}
function parseTimeParts(appointmentTime) {
  if (!appointmentTime) return null;
  const timeMatch = /^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(
    appointmentTime.trim()
  );
  if (!timeMatch) return null;
  const hour24 = Number(timeMatch[1]);
  const minute = Number(timeMatch[2]);
  if (!Number.isInteger(hour24) || !Number.isInteger(minute) || hour24 < 0 || hour24 > 23 || minute < 0 || minute > 59) {
    return null;
  }
  return { hour24, minute };
}
function appointmentMsIst(appointmentDate, appointmentTime) {
  const d = parseDateParts(appointmentDate);
  const t = parseTimeParts(appointmentTime) ?? { hour24: 0, minute: 0 };
  if (!d) return NaN;
  return Date.parse(
    `${String(d.year).padStart(4, "0")}-${String(d.month).padStart(2, "0")}-${String(d.day).padStart(2, "0")}T${String(t.hour24).padStart(2, "0")}:${String(t.minute).padStart(2, "0")}:00+05:30`
  );
}
function formatAppointmentDate(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return null;
  return `${d.day} ${MONTHS_SHORT[d.month - 1]} ${d.year}`;
}
function formatAppointmentDateShort(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  return `${d.day} ${MONTHS_SHORT[d.month - 1]}`;
}
function formatAppointmentDateLong(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  const weekday = new Date(Date.UTC(d.year, d.month - 1, d.day)).getUTCDay();
  return `${WEEKDAYS_SHORT[weekday]}, ${d.day} ${MONTHS_SHORT[d.month - 1]} ${d.year}`;
}
function formatAppointmentTime(appointmentTime) {
  const t = parseTimeParts(appointmentTime);
  if (!t) return null;
  const hour12 = t.hour24 % 12 || 12;
  const ampm = t.hour24 < 12 ? "AM" : "PM";
  return `${hour12}:${String(t.minute).padStart(2, "0")} ${ampm}`;
}
function istYmd(ms) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date(ms));
}
function formatRelativeTime(appointmentDate, appointmentTime, nowMs = Date.now()) {
  const appt = appointmentMsIst(appointmentDate, appointmentTime);
  if (!Number.isFinite(appt)) return "\u2013";
  const today = istYmd(nowMs);
  const apptDay = istYmd(appt);
  const todayParts = parseDateParts(today);
  const apptParts = parseDateParts(apptDay);
  const dayDiff = Math.round(
    (Date.UTC(apptParts.year, apptParts.month - 1, apptParts.day) - Date.UTC(todayParts.year, todayParts.month - 1, todayParts.day)) / 864e5
  );
  if (dayDiff === 0) {
    const deltaMs = appt - nowMs;
    if (deltaMs <= 0) return "today";
    const totalMinutes = Math.round(deltaMs / 6e4);
    if (totalMinutes < 60) {
      return `today \xB7 in ${totalMinutes} minute${totalMinutes === 1 ? "" : "s"}`;
    }
    const hours = Math.round(totalMinutes / 60);
    return `today \xB7 in ${hours} hour${hours === 1 ? "" : "s"}`;
  }
  if (dayDiff === 1) return "tomorrow";
  if (dayDiff > 1) return `in ${dayDiff} days`;
  if (dayDiff === -1) return "yesterday";
  return `${Math.abs(dayDiff)} days ago`;
}
function emailButtonHtml(href, label, variant = "primary") {
  const bg = variant === "primary" ? BRAND_PRIMARY : "#e5e7eb";
  const color = variant === "primary" ? "#ffffff" : "#111827";
  return `<a href="${escapeHtml(href)}" style="background:${bg};color:${color};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${escapeHtml(label)}</a>`;
}
function emailFooterText() {
  return `This is an automated message from ABI Parent Care. For help, call ${SUPPORT_PHONE}.`;
}
function wrapEmailHtml(args) {
  const ref = displayValue(args.ref, "");
  const refHtml = ref ? `<td align="right" style="font-size:13px;color:${BRAND_MUTED};white-space:nowrap;">Ref <strong style="color:${BRAND_TEXT};">${escapeHtml(ref)}</strong></td>` : `<td></td>`;
  const preheader = args.preheader ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${escapeHtml(args.preheader)}</div>` : "";
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${preheader}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${BRAND_PRIMARY},${BRAND_ACCENT});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${LOGO_URL}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${ref ? `<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${escapeHtml(ref)}</strong></td>` : ""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${BRAND_TEXT};">
          ${args.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${BRAND_MUTED};">
          ${escapeHtml(emailFooterText())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`;
}
function wrapEmailText(args) {
  const lines = [
    "ABI Parent Care",
    args.ref ? `Ref ${displayValue(args.ref)}` : null,
    "",
    args.bodyText.trim(),
    "",
    emailFooterText()
  ].filter((line2) => line2 !== null);
  return lines.join("\n");
}
async function sendEmail(args) {
  const resendApiKey = Deno.env.get("RESEND_API_KEY");
  if (!resendApiKey) {
    throw new Error("Missing RESEND_API_KEY secret");
  }
  const testMode = Deno.env.get("EMAIL_TEST_MODE") === "true";
  const testTo = Deno.env.get("TEST_EMAIL_TO")?.trim() || "";
  const realRecipientLabel = (args.toName?.trim() || args.to).trim();
  const finalTo = testMode && testTo ? testTo : args.to;
  const finalSubject = testMode && testTo ? `[To: ${realRecipientLabel}] ${args.subject}` : args.subject;
  const payload = {
    from: "ABI Parent Care <onboarding@resend.dev>",
    to: [finalTo],
    subject: finalSubject,
    html: args.html
  };
  if (args.text && args.text.trim()) {
    payload.text = args.text;
  }
  const emailResponse = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${resendApiKey}`
    },
    body: JSON.stringify(payload)
  });
  const emailResult = await emailResponse.json();
  if (!emailResponse.ok) {
    console.error("Resend error:", emailResult);
    return {
      ok: false,
      status: emailResponse.status,
      to: finalTo,
      subject: finalSubject,
      testMode,
      error: emailResult
    };
  }
  return {
    ok: true,
    status: emailResponse.status,
    id: typeof emailResult?.id === "string" ? emailResult.id : void 0,
    to: finalTo,
    subject: finalSubject,
    testMode
  };
}

// ../../../tmp/fn-src/supabase/functions/_shared/templates.ts
function firstName(fullName) {
  const trimmed = String(fullName ?? "").trim();
  if (!trimmed) return "there";
  return trimmed.split(/\s+/)[0] ?? trimmed;
}
function preferenceLabel(value) {
  if (value === "female") return "Female helper";
  if (value === "male") return "Male helper";
  if (value === "no_preference" || value === "none" || !value) {
    return "No preference";
  }
  return displayValue(value, "No preference");
}
function reasonPlain(reason) {
  switch (reason) {
    case "no_acceptance":
      return "No helper accepted within 2 hours";
    case "no_suitable_helpers":
      return "No suitable helper nearby";
    case "all_declined":
      return "All offered helpers declined";
    case "short_notice":
      return "Booked at short notice";
    case "helper_dropped":
      return "Helper dropped out";
    case "helper_not_confirmed":
      return "Helper didn't confirm";
    case "helper_unavailable":
      return "Helper no longer available";
    default:
      return reason ? reason.replaceAll("_", " ") : "Needs senior attention";
  }
}
function timeLabel(appointmentTime) {
  return formatAppointmentTime(appointmentTime) ?? displayValue(appointmentTime);
}
function sectionHeading(label) {
  return `<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${escapeHtml(label)}</p>`;
}
function line(label, value) {
  return `<div style="margin:0 0 6px;"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</div>`;
}
function textLine(label, value) {
  return `${label}: ${value}`;
}
function joinAddress(parts) {
  return parts.map((p) => String(p ?? "").trim()).filter(Boolean).join(", ");
}
function build(id, subject, ref, bodyHtml, bodyText) {
  return {
    id,
    subject,
    html: wrapEmailHtml({ bodyHtml, ref, preheader: subject }),
    text: wrapEmailText({ bodyText, ref })
  };
}
function templateG4(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const subject = `Change of helper for ${v.parent_name} \u2013 ${dateShort} \xB7 Ref ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${escapeHtml(v.old_helper_first_name)} is unable to attend ${escapeHtml(v.parent_name)}'s appointment on ${escapeHtml(dateLong)} at ${escapeHtml(time)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${escapeHtml(SUPPORT_PHONE)} and quote Ref ${escapeHtml(v.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `We're sorry \u2013 ${v.old_helper_first_name} is unable to attend ${v.parent_name}'s appointment on ${dateLong} at ${time}.`,
    "",
    "Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.",
    "",
    `The appointment itself is unchanged. If you have concerns, call ${SUPPORT_PHONE} and quote Ref ${v.ref}.`,
    "",
    "Warm regards,",
    "The ABI Parent Care team"
  ].join("\n");
  return build("G4", subject, v.ref, bodyHtml, bodyText);
}
function templateH1(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const dist = v.distance_km == null || Number.isNaN(Number(v.distance_km)) ? "\u2013" : String(Math.round(Number(v.distance_km) * 10) / 10);
  const area = displayValue(v.area);
  const subject = `New visit near you \u2013 ${dateShort}, ${time} \xB7 ${area} (${dist} km)`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${line("When", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Pickup area", `${area}, ${displayValue(v.pincode)} \xB7 about ${dist} km from you`)}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Patient", `Age ${v.parent_age}`)}
    <p style="margin:22px 0;">
      ${emailButtonHtml(v.accept_url, "Accept", "primary")}
      ${emailButtonHtml(v.decline_url, "Decline", "secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    "A new hospital visit is available near you. The first helper to accept gets it.",
    "",
    textLine("When", `${dateLong} \xB7 ${time} (${relative})`),
    textLine(
      "Pickup area",
      `${area}, ${displayValue(v.pincode)} \xB7 about ${dist} km from you`
    ),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine("Patient", `Age ${v.parent_age}`),
    "",
    `Accept: ${v.accept_url}`,
    `Decline: ${v.decline_url}`,
    "",
    "The patient's name, full address and family contact are shared after you accept.",
    "",
    `Ref ${v.ref}`
  ].join("\n");
  return build("H1", subject, v.ref, bodyHtml, bodyText);
}
function templateM5(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const reason = displayOrNone(v.dropout_reason);
  const subject = `URGENT \u2013 ${v.helper_full_name} can't attend \xB7 ${v.parent_name} \xB7 ${time} (${relative}) \xB7 ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} has said they can't attend this visit.</p>
    ${line("Reason given", reason)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${sectionHeading("Visit details")}
    ${line("Patient", `${v.parent_name}, ${v.parent_age}`)}
    ${line("When", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013")}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`)}
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Assign a replacement", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name} has said they can't attend this visit.`,
    textLine("Reason given", reason),
    "",
    "The family has been told we're arranging a replacement. Please assign a new helper now.",
    "",
    "VISIT DETAILS",
    textLine("Patient", `${v.parent_name}, ${v.parent_age}`),
    textLine("When", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013"),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`
    ),
    "",
    `Assign a replacement: ${v.assign_url}`
  ].join("\n");
  return build("M5", subject, v.ref, bodyHtml, bodyText);
}

// ../../../tmp/fn-src/supabase/functions/_shared/senior.ts
var ADMIN_PAGE_BASE = "https://nandhini-17223.github.io/elderly-care/admin";
var RESPOND_BASE = "https://nandhini-17223.github.io/elderly-care/respond.html";
var MANAGER_FIRST_NAME = "Manager";
function seniorAssignUrl(requestId) {
  const next = `needs-action.html?request=${encodeURIComponent(requestId)}`;
  return `${ADMIN_PAGE_BASE}/login.html?next=${encodeURIComponent(next)}`;
}
function approxDistanceLabel(km) {
  if (km == null || Number.isNaN(Number(km))) return "Nearby";
  const rounded = Math.round(Number(km) * 10) / 10;
  return `~${rounded} km`;
}

// ../../../tmp/fn-src/supabase/functions/_shared/assignment.ts
function guardianReplacementArrangingEmail(request, helperFullName) {
  return templateG4({
    ref: String(request.ref_number ?? "\u2013"),
    booking_person_name: request.booking_person_name,
    parent_name: request.parent_name,
    old_helper_first_name: firstName(helperFullName),
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time
  });
}

// ../../../tmp/fn-src/supabase/functions/_shared/secrets.ts
async function resolveSecret(supabase, name) {
  const fromEnv = Deno.env.get(name)?.trim() || "";
  if (fromEnv) return fromEnv;
  const { data, error } = await supabase.rpc("get_app_secret", {
    p_name: name
  });
  if (error) {
    console.error(`get_app_secret(${name}) failed`, error);
    return null;
  }
  const value = typeof data === "string" ? data.trim() : "";
  return value || null;
}

// ../../../tmp/fn-src/supabase/functions/_shared/staff-auth.ts
import { createClient } from "jsr:@supabase/supabase-js@2";
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};
function authError(message, status) {
  return new Response(JSON.stringify({ ok: false, error: message }), {
    status,
    headers: corsHeaders
  });
}
function bearerToken(req) {
  const header = req.headers.get("Authorization") || "";
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : null;
}
async function requireStaff(req, serviceClient, options) {
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  if (!supabaseUrl || !anonKey) {
    return { error: authError("Server misconfigured", 500) };
  }
  const token = bearerToken(req);
  if (!token || token === anonKey) {
    return { error: authError("Unauthorized", 401) };
  }
  const userClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false }
  });
  const { data: userData, error: userError } = await userClient.auth.getUser();
  if (userError || !userData.user) {
    return { error: authError("Unauthorized", 401) };
  }
  const { data: profile, error: profileError } = await serviceClient.from("profiles").select("user_id, full_name, role, helper_id, is_active").eq("user_id", userData.user.id).maybeSingle();
  if (profileError || !profile || !profile.is_active) {
    return { error: authError("Unauthorized", 401) };
  }
  if (profile.role !== "super_admin" && profile.role !== "manager") {
    return { error: authError("Forbidden", 403) };
  }
  if (options?.superAdminOnly && profile.role !== "super_admin") {
    return { error: authError("Forbidden", 403) };
  }
  return {
    user: userData.user,
    profile,
    accessToken: token
  };
}
async function writeAudit(serviceClient, staff, action, entity, entityId, details) {
  const { error } = await serviceClient.rpc("write_audit_log", {
    p_actor_user_id: staff.user.id,
    p_actor_role: staff.profile.role,
    p_action: action,
    p_entity: entity,
    p_entity_id: entityId ?? null,
    p_details: details ?? {}
  });
  if (error) {
    console.error("write_audit_log failed", error);
  }
}

// ../../../tmp/fn-src/supabase/functions/senior-api/index.ts
var corsHeaders2 = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...corsHeaders2,
      "Content-Type": "application/json",
      Connection: "keep-alive"
    }
  });
}
function bytesToHex(bytes) {
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function sha256Hex(value) {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return bytesToHex(new Uint8Array(digest));
}
async function createOfferToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  const token = bytesToHex(bytes);
  const hash = await sha256Hex(token);
  return { token, hash };
}
function fullAddress(request) {
  return [
    request.address_line1,
    request.street,
    request.area,
    request.landmark ? `Landmark: ${request.landmark}` : null,
    request.city,
    request.pincode
  ].map((part) => part ? String(part).trim() : "").filter(Boolean).join(", ");
}
function formatBusyAt(busyAt) {
  if (!busyAt) return null;
  return formatAppointmentTime(String(busyAt).slice(0, 8)) ?? String(busyAt).slice(0, 5);
}
function buildWarnings(helper, preference) {
  const warnings = [];
  if (helper.dropped_before) {
    warnings.push("\u26A0 Dropped out of this request");
  }
  if (!helper.gender_match) {
    const asked = preference === "female" ? "Female" : preference === "male" ? "Male" : "Any";
    const actual = helper.gender === "female" ? "Female" : "Male";
    warnings.push(`\u26A0 ${actual} \u2013 family asked for ${asked}`);
  }
  if (helper.distance_km != null && !helper.within_range && helper.max_travel_km != null) {
    const dist = Math.round(Number(helper.distance_km) * 10) / 10;
    const limit = Math.round(Number(helper.max_travel_km) * 10) / 10;
    warnings.push(`\u26A0 ${dist} km away (limit ${limit} km)`);
  }
  if (helper.declined_before) {
    warnings.push("\u26A0 Already declined this request");
  }
  return warnings;
}
async function sendOfferEmail(request, helper, token, distanceKm) {
  const acceptUrl = `${RESPOND_BASE}?token=${encodeURIComponent(token)}&action=accept`;
  const declineUrl = `${RESPOND_BASE}?token=${encodeURIComponent(token)}&action=decline`;
  const email = templateH1({
    ref: String(request.ref_number ?? "\u2013"),
    helper_first_name: firstName(helper.full_name),
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    area: request.area,
    pincode: request.pincode,
    distance_km: distanceKm,
    doctor_hospital: request.doctor_hospital,
    parent_age: request.parent_age,
    accept_url: acceptUrl,
    decline_url: declineUrl
  });
  const result = await sendEmail({
    to: helper.email,
    toName: helper.full_name,
    subject: email.subject,
    html: email.html,
    text: email.text
  });
  return result.ok;
}
async function listNeedsSenior(supabase) {
  const { data, error } = await supabase.from("consultation_requests").select(
    "id, ref_number, status, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason, created_at"
  ).eq("status", "needs_senior").order("appointment_date", { ascending: true }).order("appointment_time", { ascending: true });
  if (error) throw error;
  return (data ?? []).map((row) => ({
    ...row,
    reason_label: reasonPlain(row.needs_senior_reason),
    preference_label: preferenceLabel(row.helper_preference),
    appointment_date_label: formatAppointmentDate(row.appointment_date),
    appointment_time_label: formatAppointmentTime(row.appointment_time)
  }));
}
async function getRequestDetail(supabase, requestId) {
  const { data: request, error } = await supabase.from("consultation_requests").select(
    "id, ref_number, status, parent_name, parent_age, address_line1, street, area, landmark, city, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason, booking_person_name, relationship, email, phone_country_code, phone, created_at, assigned_helper_id, assigned_at, senior_notified_at, guardian_arranging_sent_at, helper_confirmed_at, confirmed_by, helper_dropped_at, previous_helper_ids"
  ).eq("id", requestId).maybeSingle();
  if (error) throw error;
  if (!request) return null;
  const req = request;
  const [{ data: helpersRaw, error: helpersError }, { data: offers, error: offersError }] = await Promise.all([
    supabase.rpc("list_helpers_for_senior", { p_request_id: requestId }),
    supabase.from("helper_offers").select(
      "id, helper_id, status, source, wave_number, sent_at, responded_at, distance_km, helpers(full_name, gender)"
    ).eq("request_id", requestId).order("sent_at", { ascending: true })
  ]);
  if (helpersError) throw helpersError;
  if (offersError) throw offersError;
  let assignedHelper = null;
  if (req.assigned_helper_id) {
    const { data: helperRow } = await supabase.from("helpers").select("id, full_name, phone, email").eq("id", req.assigned_helper_id).maybeSingle();
    if (helperRow) assignedHelper = helperRow;
  }
  const helpers = (helpersRaw ?? []).map((helper) => {
    const busyLabel = formatBusyAt(helper.busy_at);
    const dropped = Boolean(helper.dropped_before);
    const verified = helper.is_verified !== false && (helper.verification_status == null || helper.verification_status === "verified");
    return {
      id: helper.helper_id,
      full_name: helper.full_name,
      gender: helper.gender,
      home_area: helper.home_area,
      home_pincode: helper.home_pincode,
      distance_km: helper.distance_km,
      distance_label: approxDistanceLabel(helper.distance_km),
      max_travel_km: helper.max_travel_km,
      within_range: helper.within_range,
      gender_match: helper.gender_match,
      declined_before: helper.declined_before,
      dropped_before: dropped,
      is_busy: helper.is_busy,
      busy_at: helper.busy_at,
      busy_label: busyLabel ? `Busy at ${busyLabel}` : null,
      upcoming_assigned_jobs: Number(helper.upcoming_assigned_jobs) || 0,
      verification_status: helper.verification_status ?? null,
      is_verified: verified,
      warnings: buildWarnings(helper, req.helper_preference),
      selectable: verified && !helper.is_busy && !dropped
    };
  });
  const history = (offers ?? []).map((offer) => ({
    id: offer.id,
    helper_id: offer.helper_id,
    helper_name: offer.helpers?.full_name ?? "Helper",
    helper_gender: offer.helpers?.gender ?? null,
    status: offer.status,
    source: offer.source,
    wave_number: offer.wave_number,
    sent_at: offer.sent_at,
    responded_at: offer.responded_at,
    distance_km: offer.distance_km
  }));
  return {
    request: {
      id: req.id,
      status: req.status,
      parent_name: req.parent_name,
      parent_age: req.parent_age,
      address: fullAddress(req),
      area: req.area,
      pincode: req.pincode,
      city: req.city,
      appointment_date: req.appointment_date,
      appointment_time: req.appointment_time,
      appointment_date_label: formatAppointmentDate(req.appointment_date),
      appointment_time_label: formatAppointmentTime(req.appointment_time),
      doctor_hospital: req.doctor_hospital,
      helper_preference: req.helper_preference,
      preference_label: preferenceLabel(req.helper_preference),
      needs_senior_reason: req.needs_senior_reason,
      reason_label: reasonPlain(req.needs_senior_reason),
      booking_person_name: req.booking_person_name,
      relationship: req.relationship,
      phone: `${req.phone_country_code} ${req.phone}`.trim(),
      created_at: req.created_at,
      assigned_helper_id: req.assigned_helper_id,
      assigned_at: req.assigned_at,
      helper_confirmed_at: req.helper_confirmed_at,
      confirmed_by: req.confirmed_by,
      helper_dropped_at: req.helper_dropped_at,
      previous_helper_ids: req.previous_helper_ids ?? [],
      assigned_helper: assignedHelper
    },
    helpers,
    offer_history: history
  };
}
async function notifyDropoutEmails(supabase, requestId, helperId, reasonLabel) {
  const [{ data: request }, { data: helper }] = await Promise.all([
    supabase.from("consultation_requests").select(
      "id, ref_number, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason, booking_person_name, relationship, phone_country_code, phone, email, address_line1, street, landmark, city"
    ).eq("id", requestId).maybeSingle(),
    supabase.from("helpers").select("id, full_name, phone").eq("id", helperId).maybeSingle()
  ]);
  if (!request || !helper) return;
  const seniorEmail = await resolveSecret(supabase, "SENIOR_EMAIL");
  if (seniorEmail) {
    const email = templateM5({
      ref: String(request.ref_number ?? "\u2013"),
      manager_first_name: MANAGER_FIRST_NAME,
      helper_full_name: helper.full_name,
      parent_name: request.parent_name,
      parent_age: request.parent_age,
      appointment_date: request.appointment_date,
      appointment_time: request.appointment_time,
      area: request.area,
      city: request.city,
      pincode: request.pincode,
      doctor_hospital: request.doctor_hospital,
      booking_person_name: request.booking_person_name,
      relationship: String(request.relationship ?? ""),
      guardian_phone: `${request.phone_country_code ?? ""} ${request.phone ?? ""}`.trim(),
      dropout_reason: reasonLabel,
      assign_url: seniorAssignUrl(requestId)
    });
    await sendEmail({
      to: seniorEmail,
      toName: "Senior coordinator",
      subject: email.subject,
      html: email.html,
      text: email.text
    });
  }
  const guardianEmail = guardianReplacementArrangingEmail(
    {
      parent_name: request.parent_name,
      parent_age: request.parent_age,
      address_line1: request.address_line1,
      street: request.street,
      area: request.area,
      landmark: request.landmark,
      city: request.city,
      pincode: request.pincode,
      appointment_date: request.appointment_date,
      appointment_time: request.appointment_time,
      doctor_hospital: request.doctor_hospital,
      booking_person_name: request.booking_person_name,
      relationship: String(request.relationship ?? ""),
      phone_country_code: String(request.phone_country_code ?? ""),
      phone: String(request.phone ?? ""),
      email: request.email,
      ref_number: request.ref_number
    },
    helper.full_name
  );
  await sendEmail({
    to: request.email,
    toName: request.booking_person_name,
    subject: guardianEmail.subject,
    html: guardianEmail.html,
    text: guardianEmail.text
  });
}
async function sendSeniorOffer(supabase, requestId, helperId) {
  const detail = await getRequestDetail(supabase, requestId);
  if (!detail) {
    return { ok: false, code: "request_not_found", message: "Request not found." };
  }
  const request = detail.request;
  if (request.status !== "needs_senior" && request.status !== "senior_offered") {
    return {
      ok: false,
      code: "invalid_status",
      message: "Request is not awaiting senior assignment."
    };
  }
  const helper = detail.helpers.find((h) => h.id === helperId);
  if (!helper) {
    return { ok: false, code: "helper_not_found", message: "Helper not found." };
  }
  if (!helper.selectable) {
    const code = !helper.is_verified ? "helper_not_verified" : helper.dropped_before ? "helper_dropped_before" : "helper_busy";
    return {
      ok: false,
      code,
      message: !helper.is_verified ? "Not verified" : helper.dropped_before ? "This helper previously dropped out of this request." : helper.busy_label || "Helper is busy at this time."
    };
  }
  const { data: helperRow, error: helperError } = await supabase.from("helpers").select("id, full_name, email").eq("id", helperId).maybeSingle();
  if (helperError) throw helperError;
  if (!helperRow) {
    return { ok: false, code: "helper_not_found", message: "Helper not found." };
  }
  const { token, hash } = await createOfferToken();
  const { data: created, error: createError } = await supabase.rpc(
    "create_senior_offer",
    {
      p_request_id: requestId,
      p_helper_id: helperId,
      p_token_hash: hash,
      p_distance_km: helper.distance_km
    }
  );
  if (createError) throw createError;
  const result = created;
  if (!result?.ok) {
    return {
      ok: false,
      code: result?.code ?? "offer_failed",
      message: result?.message ?? "Could not create senior offer."
    };
  }
  const requestForEmail = {
    id: request.id,
    status: "senior_offered",
    parent_name: request.parent_name,
    parent_age: request.parent_age,
    address_line1: null,
    street: null,
    area: request.area,
    landmark: null,
    city: request.city,
    pincode: request.pincode,
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    doctor_hospital: request.doctor_hospital,
    helper_preference: request.helper_preference,
    needs_senior_reason: request.needs_senior_reason,
    booking_person_name: request.booking_person_name,
    relationship: request.relationship,
    email: "",
    phone_country_code: "",
    phone: "",
    created_at: request.created_at,
    assigned_helper_id: null,
    assigned_at: null,
    senior_notified_at: null,
    guardian_arranging_sent_at: null,
    helper_confirmed_at: null,
    confirmed_by: null,
    helper_dropped_at: null,
    previous_helper_ids: request.previous_helper_ids
  };
  const emailed = await sendOfferEmail(
    requestForEmail,
    helperRow,
    token,
    helper.distance_km
  );
  return {
    ok: true,
    code: "offered",
    message: `Offer sent to ${helperRow.full_name}.`,
    offer_id: result.offer_id,
    emailed,
    helper_id: helperId,
    request_id: requestId,
    expiry_minutes: result.expiry_minutes ?? 60,
    urgent: Boolean(result.urgent)
  };
}
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders2 });
  }
  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceRoleKey) {
      throw new Error("Missing Supabase environment configuration");
    }
    const payload = await req.json().catch(() => ({}));
    const action = String(payload.action ?? "list").trim().toLowerCase();
    const supabase = createClient2(supabaseUrl, serviceRoleKey);
    const staffOrError = await requireStaff(req, supabase);
    if ("error" in staffOrError) {
      return staffOrError.error;
    }
    const staff = staffOrError;
    if (action === "list") {
      const requests = await listNeedsSenior(supabase);
      return jsonResponse({ ok: true, action: "list", requests });
    }
    if (action === "detail") {
      const requestId = String(payload.request_id ?? "").trim();
      if (!requestId) {
        return jsonResponse({ ok: false, error: "request_id required" }, 400);
      }
      const detail = await getRequestDetail(supabase, requestId);
      if (!detail) {
        return jsonResponse({ ok: false, error: "Request not found" }, 404);
      }
      return jsonResponse({ ok: true, action: "detail", ...detail });
    }
    if (action === "send_offer") {
      const requestId = String(payload.request_id ?? "").trim();
      const helperId = String(payload.helper_id ?? "").trim();
      if (!requestId || !helperId) {
        return jsonResponse(
          { ok: false, error: "request_id and helper_id required" },
          400
        );
      }
      const result = await sendSeniorOffer(supabase, requestId, helperId);
      if (result.ok) {
        await writeAudit(supabase, staff, "send_offer", "consultation_request", requestId, {
          helper_id: helperId,
          offer_id: result.offer_id
        });
      }
      const status = result.ok ? 200 : result.code === "helper_busy" || result.code === "helper_dropped_before" ? 409 : 400;
      return jsonResponse(result, status);
    }
    if (action === "confirm_by_phone") {
      const requestId = String(payload.request_id ?? "").trim();
      if (!requestId) {
        return jsonResponse({ ok: false, error: "request_id required" }, 400);
      }
      const { data, error } = await supabase.rpc("senior_confirm_helper", {
        p_request_id: requestId
      });
      if (error) throw error;
      const result = data;
      if (result?.ok) {
        await writeAudit(
          supabase,
          staff,
          "confirm_by_phone",
          "consultation_request",
          requestId,
          {}
        );
      }
      return jsonResponse({
        ok: Boolean(result?.ok),
        code: result?.code,
        message: result?.message ?? "Unable to confirm."
      });
    }
    if (action === "helper_unable_reassign") {
      const requestId = String(payload.request_id ?? "").trim();
      if (!requestId) {
        return jsonResponse({ ok: false, error: "request_id required" }, 400);
      }
      const { data: before } = await supabase.from("consultation_requests").select("assigned_helper_id").eq("id", requestId).maybeSingle();
      const helperId = before?.assigned_helper_id;
      if (!helperId) {
        return jsonResponse({
          ok: false,
          code: "not_assigned",
          message: "Request is not currently assigned."
        }, 400);
      }
      const { data, error } = await supabase.rpc("release_assigned_helper", {
        p_request_id: requestId,
        p_reason: "helper_not_confirmed",
        p_expected_helper_id: helperId
      });
      if (error) throw error;
      const result = data;
      if (result?.ok && result.helper_id) {
        await notifyDropoutEmails(
          supabase,
          requestId,
          result.helper_id,
          "helper_not_confirmed"
        );
        await writeAudit(
          supabase,
          staff,
          "helper_unable_reassign",
          "consultation_request",
          requestId,
          { helper_id: result.helper_id }
        );
      }
      return jsonResponse({
        ok: Boolean(result?.ok),
        code: result?.code,
        message: result?.ok ? "Helper released. Select a replacement below." : result?.message ?? "Unable to release helper.",
        request_id: requestId
      });
    }
    return jsonResponse({ ok: false, error: "Unknown action" }, 400);
  } catch (error) {
    console.error(error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return jsonResponse({ ok: false, error: message }, 500);
  }
});
