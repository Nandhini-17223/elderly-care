const z=globalThis.__sb.createClient,H="+91 73399 11220",oe="https://nandhini-17223.github.io/elderly-care/helper/",se="https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg",K="#1d6fd8",le="#4a9cf7",J="#1f2937",Q="#6b7280",W=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],pe=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function i(e){return e.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;")}function s(e,n="\u2013"){if(e==null)return n;const r=String(e).trim();return!r||r.toLowerCase()==="null"||r.toLowerCase()==="undefined"?n:r}function L(e){return s(e,"None given")}function R(e){if(!e)return null;const n=/^(\d{4})-(\d{2})-(\d{2})$/.exec(e.trim());if(!n)return null;const r=Number(n[1]),a=Number(n[2]),t=Number(n[3]);return!a||a<1||a>12||!t||t<1||t>31?null:{year:r,month:a,day:t}}function X(e){if(!e)return null;const n=/^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(e.trim());if(!n)return null;const r=Number(n[1]),a=Number(n[2]);return!Number.isInteger(r)||!Number.isInteger(a)||r<0||r>23||a<0||a>59?null:{hour24:r,minute:a}}function me(e,n){const r=R(e),a=X(n)??{hour24:0,minute:0};return r?Date.parse(`${String(r.year).padStart(4,"0")}-${String(r.month).padStart(2,"0")}-${String(r.day).padStart(2,"0")}T${String(a.hour24).padStart(2,"0")}:${String(a.minute).padStart(2,"0")}:00+05:30`):NaN}function I(e){const n=R(e);return n?`${n.day} ${W[n.month-1]} ${n.year}`:null}function T(e){const n=R(e);return n?`${n.day} ${W[n.month-1]}`:s(e)}function x(e){const n=R(e);if(!n)return s(e);const r=new Date(Date.UTC(n.year,n.month-1,n.day)).getUTCDay();return`${pe[r]}, ${n.day} ${W[n.month-1]} ${n.year}`}function S(e){const n=X(e);if(!n)return null;const r=n.hour24%12||12,a=n.hour24<12?"AM":"PM";return`${r}:${String(n.minute).padStart(2,"0")} ${a}`}function Be(e,n){const r=I(e),a=S(n);return!r||!a?null:`${r}, ${a}`}function Z(e){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(e))}function A(e,n,r=Date.now()){const a=me(e,n);if(!Number.isFinite(a))return"\u2013";const t=Z(r),o=Z(a),p=R(t),l=R(o),m=Math.round((Date.UTC(l.year,l.month-1,l.day)-Date.UTC(p.year,p.month-1,p.day))/864e5);if(m===0){const u=a-r;if(u<=0)return"today";const g=Math.round(u/6e4);if(g<60)return`today \xB7 in ${g} minute${g===1?"":"s"}`;const f=Math.round(g/60);return`today \xB7 in ${f} hour${f===1?"":"s"}`}return m===1?"tomorrow":m>1?`in ${m} days`:m===-1?"yesterday":`${Math.abs(m)} days ago`}function de(e){if(!e)return"\u2013";const n=Date.parse(e);if(!Number.isFinite(n))return s(e);const r=new Date(n),a=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Kolkata",weekday:"short",day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit",hour12:!0}).formatToParts(r),t=c=>a.find(b=>b.type===c)?.value??"",o=t("day"),p=t("month"),l=t("year"),m=t("weekday"),u=t("hour"),g=t("minute"),f=t("dayPeriod").toUpperCase();return`${m}, ${o} ${p} ${l} \xB7 ${u}:${g} ${f}`}function y(e,n,r="primary"){const a=r==="primary"?K:"#e5e7eb",t=r==="primary"?"#ffffff":"#111827";return`<a href="${i(e)}" style="background:${a};color:${t};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${i(n)}</a>`}function v(){return`This is an automated message from ABI Parent Care. For help, call ${H}.`}function _e(e){const n=s(e.ref,""),r=n?`<td align="right" style="font-size:13px;color:${Q};white-space:nowrap;">Ref <strong style="color:${J};">${i(n)}</strong></td>`:"<td></td>";return`<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${e.preheader?`<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${i(e.preheader)}</div>`:""}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${K},${le});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${se}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${n?`<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${i(n)}</strong></td>`:""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${J};">
          ${e.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${Q};">
          ${i(v())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`}function ce(e){return["ABI Parent Care",e.ref?`Ref ${s(e.ref)}`:null,"",e.bodyText.trim(),"",v()].filter(r=>r!==null).join(`
`)}async function U(e){const n=Deno.env.get("RESEND_API_KEY");if(!n)throw new Error("Missing RESEND_API_KEY secret");const r=Deno.env.get("EMAIL_TEST_MODE")==="true",a=Deno.env.get("TEST_EMAIL_TO")?.trim()||"",t=(e.toName?.trim()||e.to).trim(),o=r&&a?a:e.to,p=r&&a?`[To: ${t}] ${e.subject}`:e.subject,l={from:"ABI Parent Care <onboarding@resend.dev>",to:[o],subject:p,html:e.html};e.text&&e.text.trim()&&(l.text=e.text);const m=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify(l)}),u=await m.json();return m.ok?{ok:!0,status:m.status,id:typeof u?.id=="string"?u.id:void 0,to:o,subject:p,testMode:r}:(console.error("Resend error:",u),{ok:!1,status:m.status,to:o,subject:p,testMode:r,error:u})}function j(e){const n=String(e??"").trim();return n?n.split(/\s+/)[0]??n:"there"}function C(e){return e==="female"?"Female helper":e==="male"?"Male helper":e==="no_preference"||e==="none"||!e?"No preference":s(e,"No preference")}function M(e){switch(e){case"no_acceptance":return"No helper accepted within 2 hours";case"no_suitable_helpers":return"No suitable helper nearby";case"all_declined":return"All offered helpers declined";case"short_notice":return"Booked at short notice";case"helper_dropped":return"Helper dropped out";case"helper_not_confirmed":return"Helper didn't confirm";case"helper_unavailable":return"Helper no longer available";default:return e?e.replaceAll("_"," "):"Needs senior attention"}}function $(e){return S(e)??s(e)}function k(e){return`<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${i(e)}</p>`}function _(e,n){return`<div style="margin:0 0 6px;"><strong>${i(e)}:</strong> ${i(n)}</div>`}function d(e,n){return`${e}: ${n}`}function ee(e){return e?`<p style="margin:16px 0;"><img src="${i(e)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`:""}function P(e){return e.map(n=>String(n??"").trim()).filter(Boolean).join(", ")}function h(e,n,r,a,t){return{id:e,subject:n,html:_e({bodyHtml:a,ref:r,preheader:n}),text:ce({bodyText:t,ref:r})}}function Ve(e){const n=T(e.appointment_date),r=x(e.appointment_date),a=$(e.appointment_time),t=P([e.area,e.city,e.pincode])||"\u2013",o=C(e.helper_preference),p=`We've received your request \u2013 ${e.parent_name}, ${n} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Thank you for choosing ABI Parent Care. We've received your request for ${i(e.parent_name)}'s doctor appointment.</p>
    ${k("Appointment")}
    ${_("Date & time",`${r} \xB7 ${a}`)}
    ${_("Doctor/Hospital",s(e.doctor_hospital))}
    ${_("Pickup from",t)}
    ${_("Helper preference",o)}
    ${k("What happens next")}
    <p style="margin:0 0 12px;">We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.</p>
    <p style="margin:0 0 12px;">Need to change anything? Call us on ${i(H)} and quote Ref ${i(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,m=[`Dear ${e.booking_person_name},`,"",`Thank you for choosing ABI Parent Care. We've received your request for ${e.parent_name}'s doctor appointment.`,"","APPOINTMENT",d("Date & time",`${r} \xB7 ${a}`),d("Doctor/Hospital",s(e.doctor_hospital)),d("Pickup from",t),d("Helper preference",o),"","WHAT HAPPENS NEXT","We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.","",`Need to change anything? Call us on ${H} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G1",p,e.ref,l,m)}function Ge(e){const n=T(e.appointment_date),r=x(e.appointment_date),a=$(e.appointment_time),t=`Update on ${e.parent_name}'s appointment \u2013 ${n} \xB7 Ref ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${i(e.parent_name)}'s appointment on ${i(r)} at ${i(a)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${i(H)} and quote Ref ${i(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,p=[`Dear ${e.booking_person_name},`,"",`A quick update: our care team is personally arranging a suitable helper for ${e.parent_name}'s appointment on ${r} at ${a}.`,"","You don't need to do anything. We'll email you the helper's details shortly.","",`If you'd like to speak to us, call ${H} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G2",t,e.ref,o,p)}function ue(e){const n=T(e.appointment_date),r=x(e.appointment_date),a=$(e.appointment_time),t=A(e.appointment_date,e.appointment_time),o=P([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",p=`Helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name}, ${n} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news \u2013 ${i(e.helper_full_name)} will accompany ${i(e.parent_name)} to the appointment.</p>
    ${ee(e.helper_photo_url)}
    ${k("Your helper")}
    ${_("Name",e.helper_full_name)}
    ${_("Phone",s(e.helper_phone))}
    ${_("Verified","ID and background checked by ABI Parent Care")}
    ${k("Appointment")}
    ${_("Date & time",`${r} \xB7 ${a} (${t})`)}
    ${_("Doctor/Hospital",s(e.doctor_hospital))}
    ${_("Pickup from",o)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${i(e.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,m=[`Dear ${e.booking_person_name},`,"",`Good news \u2013 ${e.helper_full_name} will accompany ${e.parent_name} to the appointment.`,"","YOUR HELPER",d("Name",e.helper_full_name),d("Phone",s(e.helper_phone)),d("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT",d("Date & time",`${r} \xB7 ${a} (${t})`),d("Doctor/Hospital",s(e.doctor_hospital)),d("Pickup from",o),"",`For safety, please share this with ${e.parent_name} so they know who to expect.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G3",p,e.ref,l,m)}function ge(e){const n=T(e.appointment_date),r=x(e.appointment_date),a=$(e.appointment_time),t=`Change of helper for ${e.parent_name} \u2013 ${n} \xB7 Ref ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${i(e.old_helper_first_name)} is unable to attend ${i(e.parent_name)}'s appointment on ${i(r)} at ${i(a)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${i(H)} and quote Ref ${i(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,p=[`Dear ${e.booking_person_name},`,"",`We're sorry \u2013 ${e.old_helper_first_name} is unable to attend ${e.parent_name}'s appointment on ${r} at ${a}.`,"","Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.","",`The appointment itself is unchanged. If you have concerns, call ${H} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G4",t,e.ref,o,p)}function fe(e){const n=x(e.appointment_date),r=$(e.appointment_time),a=A(e.appointment_date,e.appointment_time),t=`New helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name} \xB7 Ref ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} will now accompany ${i(e.parent_name)} to the appointment, in place of ${i(e.old_helper_first_name)}.</p>
    ${ee(e.helper_photo_url)}
    ${k("Your new helper")}
    ${_("Name",e.helper_full_name)}
    ${_("Phone",s(e.helper_phone))}
    ${_("Verified","ID and background checked by ABI Parent Care")}
    ${k("Appointment (unchanged)")}
    ${_("Date & time",`${n} \xB7 ${r} (${a})`)}
    ${_("Doctor/Hospital",s(e.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,p=[`Dear ${e.booking_person_name},`,"",`${e.helper_full_name} will now accompany ${e.parent_name} to the appointment, in place of ${e.old_helper_first_name}.`,"","YOUR NEW HELPER",d("Name",e.helper_full_name),d("Phone",s(e.helper_phone)),d("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT (unchanged)",d("Date & time",`${n} \xB7 ${r} (${a})`),d("Doctor/Hospital",s(e.doctor_hospital)),"","Thank you for your patience.","","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G5",t,e.ref,o,p)}function he(e){const n=T(e.appointment_date),r=x(e.appointment_date),a=$(e.appointment_time),t=A(e.appointment_date,e.appointment_time),o=e.distance_km==null||Number.isNaN(Number(e.distance_km))?"\u2013":String(Math.round(Number(e.distance_km)*10)/10),p=s(e.area),l=`New visit near you \u2013 ${n}, ${a} \xB7 ${p} (${o} km)`,m=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${_("When",`${r} \xB7 ${a} (${t})`)}
    ${_("Pickup area",`${p}, ${s(e.pincode)} \xB7 about ${o} km from you`)}
    ${_("Hospital",s(e.doctor_hospital))}
    ${_("Patient",`Age ${e.parent_age}`)}
    <p style="margin:22px 0;">
      ${y(e.accept_url,"Accept","primary")}
      ${y(e.decline_url,"Decline","secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,u=[`Hi ${e.helper_first_name},`,"","A new hospital visit is available near you. The first helper to accept gets it.","",d("When",`${r} \xB7 ${a} (${t})`),d("Pickup area",`${p}, ${s(e.pincode)} \xB7 about ${o} km from you`),d("Hospital",s(e.doctor_hospital)),d("Patient",`Age ${e.parent_age}`),"",`Accept: ${e.accept_url}`,`Decline: ${e.decline_url}`,"","The patient's name, full address and family contact are shared after you accept.","",`Ref ${e.ref}`].join(`
`);return h("H1",l,e.ref,m,u)}function ye(e){const n=T(e.appointment_date),r=x(e.appointment_date),a=$(e.appointment_time),t=A(e.appointment_date,e.appointment_time),o=P([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",p=`Confirmed: ${e.parent_name}, ${n} ${a} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${k("Patient")}
    ${_("Name",`${e.parent_name}, ${e.parent_age}`)}
    ${_("Pickup",o)}
    ${_("Landmark",s(e.landmark))}
    <p style="margin:10px 0 16px;">${y(e.maps_url,"Open in Google Maps","secondary")}</p>
    ${k("Appointment")}
    ${_("When",`${r} \xB7 ${a} (${t})`)}
    ${_("Hospital",s(e.doctor_hospital))}
    ${k("Family contact")}
    <p style="margin:0 0 12px;">${i(e.booking_person_name)} (${i(s(e.relationship))}) \xB7 ${i(s(e.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${y(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,m=[`Hi ${e.helper_first_name},`,"","This visit is yours. Thank you!","","PATIENT",d("Name",`${e.parent_name}, ${e.parent_age}`),d("Pickup",o),d("Landmark",s(e.landmark)),`Open in Google Maps: ${e.maps_url}`,"","APPOINTMENT",d("When",`${r} \xB7 ${a} (${t})`),d("Hospital",s(e.doctor_hospital)),"","FAMILY CONTACT",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`,"","We'll remind you 12 hours and 6 hours before.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return h("H2",p,e.ref,l,m)}function $e(e){const n=x(e.appointment_date),r=$(e.appointment_time),a=A(e.appointment_date,e.appointment_time),t=`Reminder: visit ${a} ${r} \u2013 ${e.parent_name}, ${s(e.area)}`,o=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${i(e.parent_name)} ${i(a)}.</p>
    ${_("When",`${n} \xB7 ${r}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${i(s(e.full_address))} \xB7 <a href="${i(e.maps_url)}">Open in Google Maps</a></div>
    ${_("Hospital",s(e.doctor_hospital))}
    ${_("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${y(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,p=[`Hi ${e.helper_first_name},`,"",`A reminder that you're accompanying ${e.parent_name} ${a}.`,"",d("When",`${n} \xB7 ${r}`),d("Pickup",`${s(e.full_address)} \xB7 ${e.maps_url}`),d("Hospital",s(e.doctor_hospital)),d("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`),"","Plan to reach the pickup address 15 minutes early.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return h("H3",t,e.ref,o,p)}function be(e){const n=x(e.appointment_date),r=$(e.appointment_time),a=A(e.appointment_date,e.appointment_time),t=`Please confirm: ${e.parent_name} at ${r} \u2013 ${a}`,o=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${i(e.parent_name)} is ${i(a)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${y(e.confirm_url,"I'll be there","primary")}
      ${y(e.cant_make_it_url,"Can't make it","secondary")}
    </p>
    ${_("When",`${n} \xB7 ${r}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${i(s(e.full_address))} \xB7 <a href="${i(e.maps_url)}">Open in Google Maps</a></div>
    ${_("Hospital",s(e.doctor_hospital))}
    ${_("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,p=[`Hi ${e.helper_first_name},`,"",`Your visit with ${e.parent_name} is ${a}. Please confirm you'll be there.`,"",`I'll be there: ${e.confirm_url}`,`Can't make it: ${e.cant_make_it_url}`,"",d("When",`${n} \xB7 ${r}`),d("Pickup",`${s(e.full_address)} \xB7 ${e.maps_url}`),d("Hospital",s(e.doctor_hospital)),d("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`),"","If we don't hear from you, our care team will call you.","",`Ref ${e.ref}`].join(`
`);return h("H4",t,e.ref,o,p)}function qe(e){const n=e.helper_app_link||oe,r="Welcome to ABI Parent Care \u2013 your helper app login",a=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${_("App link",n)}
    ${_("Login email",e.helper_email)}
    ${_("Password","the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${y(n,"Open helper app","primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${i(H)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `,t=[`Hi ${e.helper_first_name},`,"","Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.","",d("App link",n),d("Login email",e.helper_email),d("Password","the temporary password given to you by your manager"),"","You'll be asked to set your own password the first time you log in.","",'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',"",`Questions? Call ${H}.`,"","The ABI Parent Care team"].join(`
`);return h("H5",r,null,a,t)}function Fe(e){const n=x(e.appointment_date),r=$(e.appointment_time),a=A(e.appointment_date,e.appointment_time),t=`URGENT \u2013 Helper needed in ${e.time_remaining} \xB7 ${e.parent_name} (${e.parent_age}) \xB7 ${r} \xB7 ${s(e.area)} \xB7 ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${i(a)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${k("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${k("Visit details")}
    ${_("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${_("When",`${n} \xB7 ${r} (${a})`)}
    ${_("Pickup",P([e.area,e.city,e.pincode])||"\u2013")}
    ${_("Hospital",s(e.doctor_hospital))}
    ${_("Preference",C(e.helper_preference))}
    ${_("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${y(e.assign_url,"Assign a helper","primary")}</p>
  `,p=[`Hi ${e.manager_first_name},`,"",`A booking has come in for ${a}. There isn't time to send offers automatically, so please assign a helper now.`,"","WHAT TO DO NOW","Open the request, pick an available helper and send them an offer.","","VISIT DETAILS",d("Patient",`${e.parent_name}, ${e.parent_age}`),d("When",`${n} \xB7 ${r} (${a})`),d("Pickup",P([e.area,e.city,e.pincode])||"\u2013"),d("Hospital",s(e.doctor_hospital)),d("Preference",C(e.helper_preference)),d("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`),"",`Assign a helper: ${e.assign_url}`].join(`
`);return h("M1",t,e.ref,o,p)}function Ye(e){const r=`${e.items.length} request(s) need a helper \u2013 ${e.digest_time}`,a=e.items.map((l,m)=>{const u=T(l.appointment_date),g=$(l.appointment_time),f=A(l.appointment_date,l.appointment_time);return`
      <div style="margin:0 0 16px;padding:12px 0;border-bottom:1px solid #e5e7eb;">
        <p style="margin:0 0 6px;"><strong>${m+1}. ${i(l.ref)}</strong> \xB7 ${i(l.parent_name)} (${l.parent_age}) \xB7 ${i(u)} ${i(g)} (${i(f)})</p>
        <p style="margin:0 0 6px;">${i(s(l.area))} ${i(s(l.pincode))} \xB7 Preference: ${i(C(l.helper_preference))}</p>
        <p style="margin:0 0 10px;">Why: ${i(M(l.reason))}</p>
        <p style="margin:0;">${y(l.assign_url,"Assign","primary")}</p>
      </div>
    `}).join(""),t=e.items.map((l,m)=>{const u=T(l.appointment_date),g=$(l.appointment_time),f=A(l.appointment_date,l.appointment_time);return[`${m+1}. ${l.ref} \xB7 ${l.parent_name} (${l.parent_age}) \xB7 ${u} ${g} (${f})`,`   ${s(l.area)} ${s(l.pincode)} \xB7 Preference: ${C(l.helper_preference)}`,`   Why: ${M(l.reason)}`,`   Assign: ${l.assign_url}`].join(`
`)}).join(`

`),o=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">These requests still need a helper. The soonest appointment is first.</p>
    ${a}
    <p style="margin:22px 0;">${y(e.open_all_url,"Open all in the portal","primary")}</p>
  `,p=[`Hi ${e.manager_first_name},`,"","These requests still need a helper. The soonest appointment is first.","",t,"",`Open all in the portal: ${e.open_all_url}`].join(`
`);return h("M2",r,null,o,p)}function ze(e){const n=T(e.appointment_date),r=x(e.appointment_date),a=$(e.appointment_time),t=A(e.appointment_date,e.appointment_time),o=L(e.decline_reason),p=`${e.helper_full_name} declined \u2013 please assign another \xB7 ${e.parent_name}, ${n} ${a} \xB7 ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} declined the visit you offered.</p>
    ${_("Reason given",o)}
    <p style="margin:12px 0;">Appointment: ${i(r)} \xB7 ${i(a)} (${i(t)}) \xB7 ${i(s(e.area))}</p>
    <p style="margin:22px 0;">${y(e.assign_url,"Choose another helper","primary")}</p>
  `,m=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} declined the visit you offered.`,d("Reason given",o),"",`Appointment: ${r} \xB7 ${a} (${t}) \xB7 ${s(e.area)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return h("M3",p,e.ref,l,m)}function Ke(e){const n=x(e.appointment_date),r=$(e.appointment_time),a=A(e.appointment_date,e.appointment_time),t=`No response from ${e.helper_full_name} \u2013 please assign another \xB7 ${e.parent_name} \xB7 ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} didn't respond within ${i(e.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${i(n)} \xB7 ${i(r)} (${i(a)}) \xB7 ${i(s(e.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${i(s(e.helper_phone))}</p>
    <p style="margin:22px 0;">${y(e.assign_url,"Choose another helper","primary")}</p>
  `,p=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} didn't respond within ${e.expiry_window}, so the offer has been withdrawn.`,"",`Appointment: ${n} \xB7 ${r} (${a}) \xB7 ${s(e.area)}`,`Helper phone (if you'd like to call): ${s(e.helper_phone)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return h("M4",t,e.ref,o,p)}function ke(e){const n=x(e.appointment_date),r=$(e.appointment_time),a=A(e.appointment_date,e.appointment_time),t=L(e.dropout_reason),o=`URGENT \u2013 ${e.helper_full_name} can't attend \xB7 ${e.parent_name} \xB7 ${r} (${a}) \xB7 ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} has said they can't attend this visit.</p>
    ${_("Reason given",t)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${k("Visit details")}
    ${_("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${_("When",`${n} \xB7 ${r} (${a})`)}
    ${_("Pickup",P([e.area,e.city,e.pincode])||"\u2013")}
    ${_("Hospital",s(e.doctor_hospital))}
    ${_("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${y(e.assign_url,"Assign a replacement","primary")}</p>
  `,l=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has said they can't attend this visit.`,d("Reason given",t),"","The family has been told we're arranging a replacement. Please assign a new helper now.","","VISIT DETAILS",d("Patient",`${e.parent_name}, ${e.parent_age}`),d("When",`${n} \xB7 ${r} (${a})`),d("Pickup",P([e.area,e.city,e.pincode])||"\u2013"),d("Hospital",s(e.doctor_hospital)),d("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`),"",`Assign a replacement: ${e.assign_url}`].join(`
`);return h("M5",o,e.ref,p,l)}function xe(e){const n=x(e.appointment_date),r=$(e.appointment_time),a=A(e.appointment_date,e.appointment_time),t=de(e.assigned_at),o=e.urgent?`URGENT \u2013 visit in 1 hour, ${e.helper_full_name} still not confirmed \xB7 ${e.parent_name} \xB7 ${e.ref}`:`Action needed \u2013 ${e.helper_full_name} hasn't confirmed \xB7 ${e.parent_name} \xB7 ${r} (${a}) \xB7 ${e.ref}`,p=e.urgent?`The visit starts in about 1 hour and ${i(e.helper_full_name)} still hasn't confirmed. Please resolve this now.`:`${i(e.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,l=e.urgent?`The visit starts in about 1 hour and ${e.helper_full_name} still hasn't confirmed. Please resolve this now.`:`${e.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,m=e.urgent?`<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${i(e.helper_first_name)}: ${i(s(e.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".</li>
      </ol>`:`${k("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${i(e.helper_first_name)}: ${i(s(e.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone \u2013 nothing else happens, or</li>
            <li>Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`,u=e.urgent?[`1. Call ${e.helper_first_name}: ${s(e.helper_phone)}`,'2. Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".'].join(`
`):["WHAT TO DO NOW",`1. Call ${e.helper_first_name}: ${s(e.helper_phone)}`,"2. Then in the portal, choose:","   \u2022 Helper confirmed by phone \u2013 nothing else happens, or","   \u2022 Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper"].join(`
`),g=`
    ${k("Visit details")}
    ${_("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${_("When",`${n} \xB7 ${r} (${a})`)}
    ${_("Pickup",P([e.area,e.city,e.pincode])||"\u2013")}
    ${_("Hospital",s(e.doctor_hospital))}
    ${k("Helper status")}
    ${_("Assigned",t)}
    ${_("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`)}
    ${_("Confirmed","Not yet")}
  `,f=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${p}</p>
    ${m}
    ${g}
    <p style="margin:22px 0;">${y(e.open_url,"Open request","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"",l,"",u,"","VISIT DETAILS",d("Patient",`${e.parent_name}, ${e.parent_age}`),d("When",`${n} \xB7 ${r} (${a})`),d("Pickup",P([e.area,e.city,e.pincode])||"\u2013"),d("Hospital",s(e.doctor_hospital)),"","HELPER STATUS",d("Assigned",t),d("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`),d("Confirmed","Not yet"),"",`Open request: ${e.open_url}`].join(`
`);return h(e.urgent?"M7":"M6",o,e.ref,f,c)}function Je(e){return xe({...e,urgent:!0})}function Qe(e){const n=`Driving licence ${e.expiry_phrase} \u2013 ${e.helper_full_name}`,r=e.expired?`<p style="margin:0 0 12px;">If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).</p>`:'<p style="margin:0 0 12px;">If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.</p>',a=e.expired?`If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).`:"If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.",t=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)}'s driving licence ${i(e.expiry_phrase)} (${i(e.dl_expiry)}).</p>
    ${r}
    <p style="margin:22px 0;">${y(e.open_url,"Open helper profile","primary")}</p>
  `,o=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name}'s driving licence ${e.expiry_phrase} (${e.dl_expiry}).`,"",a,"",`Open helper profile: ${e.open_url}`].join(`
`);return h("M8",n,null,t,o)}function Xe(e){const n=`Profile change request \u2013 ${e.helper_full_name}`,r=L(e.request_note),a=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} has asked to update their profile:</p>
    <p style="margin:0 0 12px;padding:12px 14px;background:#f3f6fb;border-radius:8px;font-style:italic;">"${i(r)}"</p>
    <p style="margin:0 0 12px;">Please review and update their details in the portal if appropriate.</p>
    <p style="margin:22px 0;">${y(e.open_url,"Open helper profile","primary")}</p>
  `,t=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has asked to update their profile:`,"",`"${r}"`,"","Please review and update their details in the portal if appropriate.","",`Open helper profile: ${e.open_url}`].join(`
`);return h("M9",n,null,a,t)}const Ze={accept_confirm:{title:"Accept this visit?",message:"{{appointment_date_short}} \xB7 {{appointment_time}} \xB7 {{area}}. Tap Confirm to take this visit.",button:"Confirm"},accepted:{title:"This visit is yours!",message:"We've emailed you the full details. Thank you, {{helper_first_name}}."},already_taken:{title:"Already taken",message:"Another helper accepted this visit first. Thank you for responding quickly."},helper_engaged:{title:"You're already booked",message:"You have another visit around this time, so we can't assign this one to you."},declined:{title:"Thanks for letting us know",message:"We've offered this visit to another helper."},confirmed:{title:"See you there!",message:"Thanks for confirming. The family is counting on you."},cant_make_it_confirm:{title:"Can't make this visit?",message:"Tell us why (optional), then tap Confirm. We'll arrange a replacement.",button:"Confirm"},cant_make_it_done:{title:"Thanks for telling us",message:"Our care team will arrange a replacement."},link_inactive:{title:"This link is no longer active",message:"The visit may have been assigned, cancelled or already passed. Please contact your manager if you need help."}};function ve(e,n){return e.replace(/\{\{(\w+)\}\}/g,(r,a)=>s(n[a],""))}async function we(e,n){const r=Deno.env.get(n)?.trim()||"";if(r)return r;const{data:a,error:t}=await e.rpc("get_app_secret",{p_name:n});return t?(console.error(`get_app_secret(${n}) failed`,t),null):(typeof a=="string"?a.trim():"")||null}function en(e,n){const r=new TextEncoder,a=r.encode(e),t=r.encode(n),o=Math.max(a.length,t.length);let p=a.length===t.length?0:1;for(let l=0;l<o;l++)p|=(a[l]??0)^(t[l]??0);return p===0}const B="https://nandhini-17223.github.io/elderly-care/admin",V="https://nandhini-17223.github.io/elderly-care/respond.html",nn="https://nandhini-17223.github.io/elderly-care/admin/helper.html",Ae="Manager";function He(e){const n=`needs-action.html?request=${encodeURIComponent(e)}`;return`${B}/login.html?next=${encodeURIComponent(n)}`}function tn(){return`${B}/login.html?next=${encodeURIComponent("needs-action.html")}`}function rn(e){const n=`helper.html?id=${encodeURIComponent(e)}`;return`${B}/login.html?next=${encodeURIComponent(n)}`}function an(e,n="Assign helper"){return`<a href="${e}" style="background:#1d6fd8;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;">${i(n)}</a>`}function on(e){const n=I(e.appointmentDate)??e.appointmentDate,r=S(e.appointmentTime)??e.appointmentTime,a=[e.area,e.pincode].filter(Boolean).join(" \xB7 ")||"Area on file";return`
    <p>
      ${e.refNumber?`<strong>Ref:</strong> ${i(e.refNumber)}<br />`:""}
      <strong>Patient:</strong> ${i(e.parentName)} (age ${i(String(e.parentAge))})<br />
      <strong>Date:</strong> ${i(n)}<br />
      <strong>Time:</strong> ${i(r)}<br />
      <strong>Area:</strong> ${i(a)}<br />
      ${e.doctorHospital?`<strong>Doctor / Hospital:</strong> ${i(e.doctorHospital)}<br />`:""}
      ${e.helperPreference?`<strong>Helper preference:</strong> ${i(C(e.helperPreference))}<br />`:""}
      ${e.reason?`<strong>Reason:</strong> ${i(M(e.reason))}<br />`:""}
      ${e.address?`<strong>Address:</strong> ${i(e.address)}<br />`:""}
    </p>
  `}function Te(e){return e==null||Number.isNaN(Number(e))?"Nearby":`~${Math.round(Number(e)*10)/10} km`}function sn(e){return e?"sent":"not sent"}function ne(e){return[e.address_line1,e.street,e.area,e.city,e.pincode].map(n=>n?String(n).trim():"").filter(Boolean).join(", ")}function te(e){return`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e)}`}function re(e){return`${e.phone_country_code} ${e.phone}`.trim()}function ln(e){return{dateLabel:I(e.appointment_date)??e.appointment_date,timeLabel:S(e.appointment_time)??e.appointment_time}}function G(e,n){return`${V}?token=${encodeURIComponent(e)}&action=${encodeURIComponent(n)}`}async function pn(){const e=crypto.getRandomValues(new Uint8Array(32)),n=D(e),r=await Y(n);return{token:n,hash:r}}function Pe(e,n,r){const a=ne(e);return ye({ref:String(e.ref_number??"\u2013"),helper_first_name:j(n),parent_name:e.parent_name,parent_age:e.parent_age,address_line1:e.address_line1,street:e.street,area:e.area,city:e.city,pincode:e.pincode,landmark:e.landmark,maps_url:te(a),appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,guardian_phone:re(e),cant_make_it_url:G(r,"cant_make_it")})}function mn(e,n,r){return Pe(e,n,r).html}function Ce(e,n,r,a){const t=ne(e),o={ref:String(e.ref_number??"\u2013"),helper_first_name:j(n),parent_name:e.parent_name,area:e.area,appointment_date:e.appointment_date,appointment_time:e.appointment_time,full_address:t,maps_url:te(t),doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,guardian_phone:re(e),cant_make_it_url:G(r,"cant_make_it")};return a==="6h"?be({...o,confirm_url:G(r,"confirm_attendance")}):$e(o)}function dn(e,n,r,a){return Ce(e,n,r,a).html}function Se(e,n,r){return fe({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,helper_full_name:n.full_name,helper_phone:n.phone,helper_photo_url:n.photo_url,old_helper_first_name:r||"the previous helper",appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital})}function _n(e,n,r="the previous helper"){return Se(e,n,r).html}function Re(e,n){return ue({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,helper_full_name:n.full_name,helper_phone:n.phone,helper_photo_url:n.photo_url,appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,address_line1:e.address_line1,street:e.street,area:e.area,city:e.city,pincode:e.pincode})}function cn(e,n){return Re(e,n).html}function ae(e,n){return ge({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,old_helper_first_name:j(n),appointment_date:e.appointment_date,appointment_time:e.appointment_time})}function un(e,n){return ae(e,n).html}function gn(e){if(e<=0)return"less than 1 minute";const n=Math.round(e/6e4);if(n<60)return`${n} minute${n===1?"":"s"}`;const r=Math.floor(n/60),a=n%60;return a===0?`${r} hour${r===1?"":"s"}`:`${r}h ${a}m`}const q={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS","Content-Type":"application/json"};function E(e,n){return new Response(JSON.stringify({ok:!1,error:e}),{status:n,headers:q})}function Ee(e){const r=(e.headers.get("Authorization")||"").match(/^Bearer\s+(.+)$/i);return r?r[1].trim():null}async function Ne(e,n,r){const a=Deno.env.get("SUPABASE_URL"),t=Deno.env.get("SUPABASE_ANON_KEY");if(!a||!t)return{error:E("Server misconfigured",500)};const o=Ee(e);if(!o||o===t)return{error:E("Unauthorized",401)};const p=z(a,t,{global:{headers:{Authorization:`Bearer ${o}`}},auth:{persistSession:!1,autoRefreshToken:!1}}),{data:l,error:m}=await p.auth.getUser();if(m||!l.user)return{error:E("Unauthorized",401)};const{data:u,error:g}=await n.from("profiles").select("user_id, full_name, role, helper_id, is_active").eq("user_id",l.user.id).maybeSingle();return g||!u||!u.is_active?{error:E("Unauthorized",401)}:u.role!=="super_admin"&&u.role!=="manager"?{error:E("Forbidden",403)}:r?.superAdminOnly&&u.role!=="super_admin"?{error:E("Forbidden",403)}:{user:l.user,profile:u,accessToken:o}}async function F(e,n,r,a,t,o){const{error:p}=await e.rpc("write_audit_log",{p_actor_user_id:n.user.id,p_actor_role:n.profile.role,p_action:r,p_entity:a,p_entity_id:t??null,p_details:o??{}});p&&console.error("write_audit_log failed",p)}async function fn(e){const{data:n,error:r}=await e.from("app_settings").select("key, value");if(r)return console.error("loadAppSettings",r),{};const a={};for(const t of n??[])a[t.key]=String(t.value);return a}function hn(e,n,r){const a=e[n],t=Number(a);return Number.isFinite(t)?t:r}const yn={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};function w(e,n=200){return new Response(JSON.stringify(e),{status:n,headers:{...q,"Content-Type":"application/json",Connection:"keep-alive"}})}function D(e){return Array.from(e).map(n=>n.toString(16).padStart(2,"0")).join("")}async function Y(e){const n=new TextEncoder().encode(e),r=await crypto.subtle.digest("SHA-256",n);return D(new Uint8Array(r))}async function Ie(){const e=crypto.getRandomValues(new Uint8Array(32)),n=D(e),r=await Y(n);return{token:n,hash:r}}function Me(e){return[e.address_line1,e.street,e.area,e.landmark?`Landmark: ${e.landmark}`:null,e.city,e.pincode].map(n=>n?String(n).trim():"").filter(Boolean).join(", ")}function De(e){return e?S(String(e).slice(0,8))??String(e).slice(0,5):null}function Oe(e,n){const r=[];if(e.dropped_before&&r.push("\u26A0 Dropped out of this request"),!e.gender_match){const a=n==="female"?"Female":n==="male"?"Male":"Any",t=e.gender==="female"?"Female":"Male";r.push(`\u26A0 ${t} \u2013 family asked for ${a}`)}if(e.distance_km!=null&&!e.within_range&&e.max_travel_km!=null){const a=Math.round(Number(e.distance_km)*10)/10,t=Math.round(Number(e.max_travel_km)*10)/10;r.push(`\u26A0 ${a} km away (limit ${t} km)`)}return e.declined_before&&r.push("\u26A0 Already declined this request"),r}async function je(e,n,r,a){const t=`${V}?token=${encodeURIComponent(r)}&action=accept`,o=`${V}?token=${encodeURIComponent(r)}&action=decline`,p=he({ref:String(e.ref_number??"\u2013"),helper_first_name:j(n.full_name),appointment_date:e.appointment_date,appointment_time:e.appointment_time,area:e.area,pincode:e.pincode,distance_km:a,doctor_hospital:e.doctor_hospital,parent_age:e.parent_age,accept_url:t,decline_url:o});return(await U({to:n.email,toName:n.full_name,subject:p.subject,html:p.html,text:p.text})).ok}async function We(e){const{data:n,error:r}=await e.from("consultation_requests").select("id, ref_number, status, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason, created_at").eq("status","needs_senior").order("appointment_date",{ascending:!0}).order("appointment_time",{ascending:!0});if(r)throw r;return(n??[]).map(a=>({...a,reason_label:M(a.needs_senior_reason),preference_label:C(a.helper_preference),appointment_date_label:I(a.appointment_date),appointment_time_label:S(a.appointment_time)}))}async function ie(e,n){const{data:r,error:a}=await e.from("consultation_requests").select("id, ref_number, status, parent_name, parent_age, address_line1, street, area, landmark, city, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason, booking_person_name, relationship, email, phone_country_code, phone, created_at, assigned_helper_id, assigned_at, senior_notified_at, guardian_arranging_sent_at, helper_confirmed_at, confirmed_by, helper_dropped_at, previous_helper_ids").eq("id",n).maybeSingle();if(a)throw a;if(!r)return null;const t=r,[{data:o,error:p},{data:l,error:m}]=await Promise.all([e.rpc("list_helpers_for_senior",{p_request_id:n}),e.from("helper_offers").select("id, helper_id, status, source, wave_number, sent_at, responded_at, distance_km, helpers(full_name, gender)").eq("request_id",n).order("sent_at",{ascending:!0})]);if(p)throw p;if(m)throw m;let u=null;if(t.assigned_helper_id){const{data:c}=await e.from("helpers").select("id, full_name, phone, email").eq("id",t.assigned_helper_id).maybeSingle();c&&(u=c)}const g=(o??[]).map(c=>{const b=De(c.busy_at),O=!!c.dropped_before,N=c.is_verified!==!1&&(c.verification_status==null||c.verification_status==="verified");return{id:c.helper_id,full_name:c.full_name,gender:c.gender,home_area:c.home_area,home_pincode:c.home_pincode,distance_km:c.distance_km,distance_label:Te(c.distance_km),max_travel_km:c.max_travel_km,within_range:c.within_range,gender_match:c.gender_match,declined_before:c.declined_before,dropped_before:O,is_busy:c.is_busy,busy_at:c.busy_at,busy_label:b?`Busy at ${b}`:null,upcoming_assigned_jobs:Number(c.upcoming_assigned_jobs)||0,verification_status:c.verification_status??null,is_verified:N,warnings:Oe(c,t.helper_preference),selectable:N&&!c.is_busy&&!O}}),f=(l??[]).map(c=>({id:c.id,helper_id:c.helper_id,helper_name:c.helpers?.full_name??"Helper",helper_gender:c.helpers?.gender??null,status:c.status,source:c.source,wave_number:c.wave_number,sent_at:c.sent_at,responded_at:c.responded_at,distance_km:c.distance_km}));return{request:{id:t.id,status:t.status,parent_name:t.parent_name,parent_age:t.parent_age,address:Me(t),area:t.area,pincode:t.pincode,city:t.city,appointment_date:t.appointment_date,appointment_time:t.appointment_time,appointment_date_label:I(t.appointment_date),appointment_time_label:S(t.appointment_time),doctor_hospital:t.doctor_hospital,helper_preference:t.helper_preference,preference_label:C(t.helper_preference),needs_senior_reason:t.needs_senior_reason,reason_label:M(t.needs_senior_reason),booking_person_name:t.booking_person_name,relationship:t.relationship,phone:`${t.phone_country_code} ${t.phone}`.trim(),created_at:t.created_at,assigned_helper_id:t.assigned_helper_id,assigned_at:t.assigned_at,helper_confirmed_at:t.helper_confirmed_at,confirmed_by:t.confirmed_by,helper_dropped_at:t.helper_dropped_at,previous_helper_ids:t.previous_helper_ids??[],assigned_helper:u},helpers:g,offer_history:f}}async function Le(e,n,r,a){const[{data:t},{data:o}]=await Promise.all([e.from("consultation_requests").select("id, ref_number, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason, booking_person_name, relationship, phone_country_code, phone, email, address_line1, street, landmark, city").eq("id",n).maybeSingle(),e.from("helpers").select("id, full_name, phone").eq("id",r).maybeSingle()]);if(!t||!o)return;const p=await we(e,"SENIOR_EMAIL");if(p){const m=ke({ref:String(t.ref_number??"\u2013"),manager_first_name:Ae,helper_full_name:o.full_name,parent_name:t.parent_name,parent_age:t.parent_age,appointment_date:t.appointment_date,appointment_time:t.appointment_time,area:t.area,city:t.city,pincode:t.pincode,doctor_hospital:t.doctor_hospital,booking_person_name:t.booking_person_name,relationship:String(t.relationship??""),guardian_phone:`${t.phone_country_code??""} ${t.phone??""}`.trim(),dropout_reason:a,assign_url:He(n)});await U({to:p,toName:"Senior coordinator",subject:m.subject,html:m.html,text:m.text})}const l=ae({parent_name:t.parent_name,parent_age:t.parent_age,address_line1:t.address_line1,street:t.street,area:t.area,landmark:t.landmark,city:t.city,pincode:t.pincode,appointment_date:t.appointment_date,appointment_time:t.appointment_time,doctor_hospital:t.doctor_hospital,booking_person_name:t.booking_person_name,relationship:String(t.relationship??""),phone_country_code:String(t.phone_country_code??""),phone:String(t.phone??""),email:t.email,ref_number:t.ref_number},o.full_name);await U({to:t.email,toName:t.booking_person_name,subject:l.subject,html:l.html,text:l.text})}async function Ue(e,n,r){const a=await ie(e,n);if(!a)return{ok:!1,code:"request_not_found",message:"Request not found."};const t=a.request;if(t.status!=="needs_senior"&&t.status!=="senior_offered")return{ok:!1,code:"invalid_status",message:"Request is not awaiting senior assignment."};const o=a.helpers.find(N=>N.id===r);if(!o)return{ok:!1,code:"helper_not_found",message:"Helper not found."};if(!o.selectable)return{ok:!1,code:o.is_verified?o.dropped_before?"helper_dropped_before":"helper_busy":"helper_not_verified",message:o.is_verified?o.dropped_before?"This helper previously dropped out of this request.":o.busy_label||"Helper is busy at this time.":"Not verified"};const{data:p,error:l}=await e.from("helpers").select("id, full_name, email").eq("id",r).maybeSingle();if(l)throw l;if(!p)return{ok:!1,code:"helper_not_found",message:"Helper not found."};const{token:m,hash:u}=await Ie(),{data:g,error:f}=await e.rpc("create_senior_offer",{p_request_id:n,p_helper_id:r,p_token_hash:u,p_distance_km:o.distance_km});if(f)throw f;const c=g;if(!c?.ok)return{ok:!1,code:c?.code??"offer_failed",message:c?.message??"Could not create senior offer."};const b={id:t.id,status:"senior_offered",parent_name:t.parent_name,parent_age:t.parent_age,address_line1:null,street:null,area:t.area,landmark:null,city:t.city,pincode:t.pincode,appointment_date:t.appointment_date,appointment_time:t.appointment_time,doctor_hospital:t.doctor_hospital,helper_preference:t.helper_preference,needs_senior_reason:t.needs_senior_reason,booking_person_name:t.booking_person_name,relationship:t.relationship,email:"",phone_country_code:"",phone:"",created_at:t.created_at,assigned_helper_id:null,assigned_at:null,senior_notified_at:null,guardian_arranging_sent_at:null,helper_confirmed_at:null,confirmed_by:null,helper_dropped_at:null,previous_helper_ids:t.previous_helper_ids},O=await je(b,p,m,o.distance_km);return{ok:!0,code:"offered",message:`Offer sent to ${p.full_name}.`,offer_id:c.offer_id,emailed:O,helper_id:r,request_id:n,expiry_minutes:c.expiry_minutes??60,urgent:!!c.urgent}}Deno.serve(async e=>{if(e.method==="OPTIONS")return new Response(null,{status:204,headers:q});if(e.method!=="POST")return w({error:"Method not allowed"},405);try{const n=Deno.env.get("SUPABASE_URL"),r=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");if(!n||!r)throw new Error("Missing Supabase environment configuration");const a=await e.json().catch(()=>({})),t=String(a.action??"list").trim().toLowerCase(),o=z(n,r),p=await Ne(e,o);if("error"in p)return p.error;const l=p;if(t==="list"){const m=await We(o);return w({ok:!0,action:"list",requests:m})}if(t==="detail"){const m=String(a.request_id??"").trim();if(!m)return w({ok:!1,error:"request_id required"},400);const u=await ie(o,m);return u?w({ok:!0,action:"detail",...u}):w({ok:!1,error:"Request not found"},404)}if(t==="send_offer"){const m=String(a.request_id??"").trim(),u=String(a.helper_id??"").trim();if(!m||!u)return w({ok:!1,error:"request_id and helper_id required"},400);const g=await Ue(o,m,u);g.ok&&await F(o,l,"send_offer","consultation_request",m,{helper_id:u,offer_id:g.offer_id});const f=g.ok?200:g.code==="helper_busy"||g.code==="helper_dropped_before"?409:400;return w(g,f)}if(t==="confirm_by_phone"){const m=String(a.request_id??"").trim();if(!m)return w({ok:!1,error:"request_id required"},400);const{data:u,error:g}=await o.rpc("senior_confirm_helper",{p_request_id:m});if(g)throw g;const f=u;return f?.ok&&await F(o,l,"confirm_by_phone","consultation_request",m,{}),w({ok:!!f?.ok,code:f?.code,message:f?.message??"Unable to confirm."})}if(t==="helper_unable_reassign"){const m=String(a.request_id??"").trim();if(!m)return w({ok:!1,error:"request_id required"},400);const{data:u}=await o.from("consultation_requests").select("assigned_helper_id").eq("id",m).maybeSingle(),g=u?.assigned_helper_id;if(!g)return w({ok:!1,code:"not_assigned",message:"Request is not currently assigned."},400);const{data:f,error:c}=await o.rpc("release_assigned_helper",{p_request_id:m,p_reason:"helper_not_confirmed",p_expected_helper_id:g});if(c)throw c;const b=f;return b?.ok&&b.helper_id&&(await Le(o,m,b.helper_id,"helper_not_confirmed"),await F(o,l,"helper_unable_reassign","consultation_request",m,{helper_id:b.helper_id})),w({ok:!!b?.ok,code:b?.code,message:b?.ok?"Helper released. Select a replacement below.":b?.message??"Unable to release helper.",request_id:m})}return w({ok:!1,error:"Unknown action"},400)}catch(n){console.error(n);const r=n instanceof Error?n.message:"Unknown error";return w({ok:!1,error:r},500)}});
