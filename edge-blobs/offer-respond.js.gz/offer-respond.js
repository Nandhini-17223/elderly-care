// ../../../tmp/fn-src/supabase/functions/offer-respond/index.ts
import { createClient } from "jsr:@supabase/supabase-js@2";

// ../../../tmp/fn-src/supabase/functions/_shared/email.ts
var SUPPORT_PHONE = "+91 73399 11220";
var LOGO_URL = "https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg";
var BRAND_PRIMARY = "#1d6fd8";
var BRAND_ACCENT = "#4a9cf7";
var BRAND_TEXT = "#1f2937";
var BRAND_MUTED = "#6b7280";
var MONTHS_SHORT = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
];
var WEEKDAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
function escapeHtml(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}
function displayValue(value, fallback = "\u2013") {
  if (value === null || value === void 0) return fallback;
  const text = String(value).trim();
  if (!text || text.toLowerCase() === "null" || text.toLowerCase() === "undefined") {
    return fallback;
  }
  return text;
}
function displayOrNone(value) {
  return displayValue(value, "None given");
}
function parseDateParts(appointmentDate) {
  if (!appointmentDate) return null;
  const dateMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(appointmentDate.trim());
  if (!dateMatch) return null;
  const year = Number(dateMatch[1]);
  const month = Number(dateMatch[2]);
  const day = Number(dateMatch[3]);
  if (!month || month < 1 || month > 12 || !day || day < 1 || day > 31) {
    return null;
  }
  return { year, month, day };
}
function parseTimeParts(appointmentTime) {
  if (!appointmentTime) return null;
  const timeMatch = /^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(
    appointmentTime.trim()
  );
  if (!timeMatch) return null;
  const hour24 = Number(timeMatch[1]);
  const minute = Number(timeMatch[2]);
  if (!Number.isInteger(hour24) || !Number.isInteger(minute) || hour24 < 0 || hour24 > 23 || minute < 0 || minute > 59) {
    return null;
  }
  return { hour24, minute };
}
function appointmentMsIst(appointmentDate, appointmentTime) {
  const d = parseDateParts(appointmentDate);
  const t = parseTimeParts(appointmentTime) ?? { hour24: 0, minute: 0 };
  if (!d) return NaN;
  return Date.parse(
    `${String(d.year).padStart(4, "0")}-${String(d.month).padStart(2, "0")}-${String(d.day).padStart(2, "0")}T${String(t.hour24).padStart(2, "0")}:${String(t.minute).padStart(2, "0")}:00+05:30`
  );
}
function formatAppointmentDateShort(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  return `${d.day} ${MONTHS_SHORT[d.month - 1]}`;
}
function formatAppointmentDateLong(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  const weekday = new Date(Date.UTC(d.year, d.month - 1, d.day)).getUTCDay();
  return `${WEEKDAYS_SHORT[weekday]}, ${d.day} ${MONTHS_SHORT[d.month - 1]} ${d.year}`;
}
function formatAppointmentTime(appointmentTime) {
  const t = parseTimeParts(appointmentTime);
  if (!t) return null;
  const hour12 = t.hour24 % 12 || 12;
  const ampm = t.hour24 < 12 ? "AM" : "PM";
  return `${hour12}:${String(t.minute).padStart(2, "0")} ${ampm}`;
}
function istYmd(ms) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date(ms));
}
function formatRelativeTime(appointmentDate, appointmentTime, nowMs = Date.now()) {
  const appt = appointmentMsIst(appointmentDate, appointmentTime);
  if (!Number.isFinite(appt)) return "\u2013";
  const today = istYmd(nowMs);
  const apptDay = istYmd(appt);
  const todayParts = parseDateParts(today);
  const apptParts = parseDateParts(apptDay);
  const dayDiff = Math.round(
    (Date.UTC(apptParts.year, apptParts.month - 1, apptParts.day) - Date.UTC(todayParts.year, todayParts.month - 1, todayParts.day)) / 864e5
  );
  if (dayDiff === 0) {
    const deltaMs = appt - nowMs;
    if (deltaMs <= 0) return "today";
    const totalMinutes = Math.round(deltaMs / 6e4);
    if (totalMinutes < 60) {
      return `today \xB7 in ${totalMinutes} minute${totalMinutes === 1 ? "" : "s"}`;
    }
    const hours = Math.round(totalMinutes / 60);
    return `today \xB7 in ${hours} hour${hours === 1 ? "" : "s"}`;
  }
  if (dayDiff === 1) return "tomorrow";
  if (dayDiff > 1) return `in ${dayDiff} days`;
  if (dayDiff === -1) return "yesterday";
  return `${Math.abs(dayDiff)} days ago`;
}
function emailButtonHtml(href, label, variant = "primary") {
  const bg = variant === "primary" ? BRAND_PRIMARY : "#e5e7eb";
  const color = variant === "primary" ? "#ffffff" : "#111827";
  return `<a href="${escapeHtml(href)}" style="background:${bg};color:${color};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${escapeHtml(label)}</a>`;
}
function emailFooterText() {
  return `This is an automated message from ABI Parent Care. For help, call ${SUPPORT_PHONE}.`;
}
function wrapEmailHtml(args) {
  const ref = displayValue(args.ref, "");
  const refHtml = ref ? `<td align="right" style="font-size:13px;color:${BRAND_MUTED};white-space:nowrap;">Ref <strong style="color:${BRAND_TEXT};">${escapeHtml(ref)}</strong></td>` : `<td></td>`;
  const preheader = args.preheader ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${escapeHtml(args.preheader)}</div>` : "";
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${preheader}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${BRAND_PRIMARY},${BRAND_ACCENT});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${LOGO_URL}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${ref ? `<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${escapeHtml(ref)}</strong></td>` : ""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${BRAND_TEXT};">
          ${args.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${BRAND_MUTED};">
          ${escapeHtml(emailFooterText())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`;
}
function wrapEmailText(args) {
  const lines = [
    "ABI Parent Care",
    args.ref ? `Ref ${displayValue(args.ref)}` : null,
    "",
    args.bodyText.trim(),
    "",
    emailFooterText()
  ].filter((line2) => line2 !== null);
  return lines.join("\n");
}
async function sendEmail(args) {
  const resendApiKey = Deno.env.get("RESEND_API_KEY");
  if (!resendApiKey) {
    throw new Error("Missing RESEND_API_KEY secret");
  }
  const testMode = Deno.env.get("EMAIL_TEST_MODE") === "true";
  const testTo = Deno.env.get("TEST_EMAIL_TO")?.trim() || "";
  const realRecipientLabel = (args.toName?.trim() || args.to).trim();
  const finalTo = testMode && testTo ? testTo : args.to;
  const finalSubject = testMode && testTo ? `[To: ${realRecipientLabel}] ${args.subject}` : args.subject;
  const payload = {
    from: "ABI Parent Care <onboarding@resend.dev>",
    to: [finalTo],
    subject: finalSubject,
    html: args.html
  };
  if (args.text && args.text.trim()) {
    payload.text = args.text;
  }
  const emailResponse = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${resendApiKey}`
    },
    body: JSON.stringify(payload)
  });
  const emailResult = await emailResponse.json();
  if (!emailResponse.ok) {
    console.error("Resend error:", emailResult);
    return {
      ok: false,
      status: emailResponse.status,
      to: finalTo,
      subject: finalSubject,
      testMode,
      error: emailResult
    };
  }
  return {
    ok: true,
    status: emailResponse.status,
    id: typeof emailResult?.id === "string" ? emailResult.id : void 0,
    to: finalTo,
    subject: finalSubject,
    testMode
  };
}

// ../../../tmp/fn-src/supabase/functions/_shared/templates.ts
function firstName(fullName) {
  const trimmed = String(fullName ?? "").trim();
  if (!trimmed) return "there";
  return trimmed.split(/\s+/)[0] ?? trimmed;
}
function timeLabel(appointmentTime) {
  return formatAppointmentTime(appointmentTime) ?? displayValue(appointmentTime);
}
function sectionHeading(label) {
  return `<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${escapeHtml(label)}</p>`;
}
function line(label, value) {
  return `<div style="margin:0 0 6px;"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</div>`;
}
function textLine(label, value) {
  return `${label}: ${value}`;
}
function helperPhotoBlock(photoUrl) {
  if (!photoUrl) return "";
  return `<p style="margin:16px 0;"><img src="${escapeHtml(photoUrl)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`;
}
function joinAddress(parts) {
  return parts.map((p) => String(p ?? "").trim()).filter(Boolean).join(", ");
}
function build(id, subject, ref, bodyHtml, bodyText) {
  return {
    id,
    subject,
    html: wrapEmailHtml({ bodyHtml, ref, preheader: subject }),
    text: wrapEmailText({ bodyText, ref })
  };
}
function templateG3(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const pickup = joinAddress([
    v.address_line1,
    v.street,
    v.area,
    v.city,
    v.pincode
  ]) || "\u2013";
  const subject = `Helper confirmed for ${v.parent_name} \u2013 ${v.helper_full_name}, ${dateShort} \xB7 Ref ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news \u2013 ${escapeHtml(v.helper_full_name)} will accompany ${escapeHtml(v.parent_name)} to the appointment.</p>
    ${helperPhotoBlock(v.helper_photo_url)}
    ${sectionHeading("Your helper")}
    ${line("Name", v.helper_full_name)}
    ${line("Phone", displayValue(v.helper_phone))}
    ${line("Verified", "ID and background checked by ABI Parent Care")}
    ${sectionHeading("Appointment")}
    ${line("Date & time", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Doctor/Hospital", displayValue(v.doctor_hospital))}
    ${line("Pickup from", pickup)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${escapeHtml(v.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `Good news \u2013 ${v.helper_full_name} will accompany ${v.parent_name} to the appointment.`,
    "",
    "YOUR HELPER",
    textLine("Name", v.helper_full_name),
    textLine("Phone", displayValue(v.helper_phone)),
    textLine("Verified", "ID and background checked by ABI Parent Care"),
    "",
    "APPOINTMENT",
    textLine("Date & time", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Doctor/Hospital", displayValue(v.doctor_hospital)),
    textLine("Pickup from", pickup),
    "",
    `For safety, please share this with ${v.parent_name} so they know who to expect.`,
    "",
    "Warm regards,",
    "The ABI Parent Care team"
  ].join("\n");
  return build("G3", subject, v.ref, bodyHtml, bodyText);
}
function templateG5(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject = `New helper confirmed for ${v.parent_name} \u2013 ${v.helper_full_name} \xB7 Ref ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} will now accompany ${escapeHtml(v.parent_name)} to the appointment, in place of ${escapeHtml(v.old_helper_first_name)}.</p>
    ${helperPhotoBlock(v.helper_photo_url)}
    ${sectionHeading("Your new helper")}
    ${line("Name", v.helper_full_name)}
    ${line("Phone", displayValue(v.helper_phone))}
    ${line("Verified", "ID and background checked by ABI Parent Care")}
    ${sectionHeading("Appointment (unchanged)")}
    ${line("Date & time", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Doctor/Hospital", displayValue(v.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `${v.helper_full_name} will now accompany ${v.parent_name} to the appointment, in place of ${v.old_helper_first_name}.`,
    "",
    "YOUR NEW HELPER",
    textLine("Name", v.helper_full_name),
    textLine("Phone", displayValue(v.helper_phone)),
    textLine("Verified", "ID and background checked by ABI Parent Care"),
    "",
    "APPOINTMENT (unchanged)",
    textLine("Date & time", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Doctor/Hospital", displayValue(v.doctor_hospital)),
    "",
    "Thank you for your patience.",
    "",
    "Warm regards,",
    "The ABI Parent Care team"
  ].join("\n");
  return build("G5", subject, v.ref, bodyHtml, bodyText);
}
function templateH2(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const pickup = joinAddress([
    v.address_line1,
    v.street,
    v.area,
    v.city,
    v.pincode
  ]) || "\u2013";
  const subject = `Confirmed: ${v.parent_name}, ${dateShort} ${time} \xB7 Ref ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${sectionHeading("Patient")}
    ${line("Name", `${v.parent_name}, ${v.parent_age}`)}
    ${line("Pickup", pickup)}
    ${line("Landmark", displayValue(v.landmark))}
    <p style="margin:10px 0 16px;">${emailButtonHtml(v.maps_url, "Open in Google Maps", "secondary")}</p>
    ${sectionHeading("Appointment")}
    ${line("When", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${sectionHeading("Family contact")}
    <p style="margin:0 0 12px;">${escapeHtml(v.booking_person_name)} (${escapeHtml(displayValue(v.relationship))}) \xB7 ${escapeHtml(displayValue(v.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${emailButtonHtml(v.cant_make_it_url, "Can't make it", "secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    "This visit is yours. Thank you!",
    "",
    "PATIENT",
    textLine("Name", `${v.parent_name}, ${v.parent_age}`),
    textLine("Pickup", pickup),
    textLine("Landmark", displayValue(v.landmark)),
    `Open in Google Maps: ${v.maps_url}`,
    "",
    "APPOINTMENT",
    textLine("When", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    "",
    "FAMILY CONTACT",
    `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`,
    "",
    "We'll remind you 12 hours and 6 hours before.",
    "",
    `Can't make it? ${v.cant_make_it_url}`,
    "",
    `Ref ${v.ref}`
  ].join("\n");
  return build("H2", subject, v.ref, bodyHtml, bodyText);
}
function templateM3(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const reason = displayOrNone(v.decline_reason);
  const subject = `${v.helper_full_name} declined \u2013 please assign another \xB7 ${v.parent_name}, ${dateShort} ${time} \xB7 ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${escapeHtml(v.helper_full_name)} declined the visit you offered.</p>
    ${line("Reason given", reason)}
    <p style="margin:12px 0;">Appointment: ${escapeHtml(dateLong)} \xB7 ${escapeHtml(time)} (${escapeHtml(relative)}) \xB7 ${escapeHtml(displayValue(v.area))}</p>
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Choose another helper", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `${v.helper_full_name} declined the visit you offered.`,
    textLine("Reason given", reason),
    "",
    `Appointment: ${dateLong} \xB7 ${time} (${relative}) \xB7 ${displayValue(v.area)}`,
    "",
    `Choose another helper: ${v.assign_url}`
  ].join("\n");
  return build("M3", subject, v.ref, bodyHtml, bodyText);
}
var ON_SCREEN = {
  accept_confirm: {
    title: "Accept this visit?",
    message: "{{appointment_date_short}} \xB7 {{appointment_time}} \xB7 {{area}}. Tap Confirm to take this visit.",
    button: "Confirm"
  },
  accepted: {
    title: "This visit is yours!",
    message: "We've emailed you the full details. Thank you, {{helper_first_name}}."
  },
  already_taken: {
    title: "Already taken",
    message: "Another helper accepted this visit first. Thank you for responding quickly."
  },
  helper_engaged: {
    title: "You're already booked",
    message: "You have another visit around this time, so we can't assign this one to you."
  },
  declined: {
    title: "Thanks for letting us know",
    message: "We've offered this visit to another helper."
  },
  confirmed: {
    title: "See you there!",
    message: "Thanks for confirming. The family is counting on you."
  },
  cant_make_it_confirm: {
    title: "Can't make this visit?",
    message: "Tell us why (optional), then tap Confirm. We'll arrange a replacement.",
    button: "Confirm"
  },
  cant_make_it_done: {
    title: "Thanks for telling us",
    message: "Our care team will arrange a replacement."
  },
  link_inactive: {
    title: "This link is no longer active",
    message: "The visit may have been assigned, cancelled or already passed. Please contact your manager if you need help."
  }
};
function fillOnScreen(template, vars) {
  return template.replace(
    /\{\{(\w+)\}\}/g,
    (_m, key) => displayValue(vars[key], "")
  );
}

// ../../../tmp/fn-src/supabase/functions/_shared/senior.ts
var ADMIN_PAGE_BASE = "https://nandhini-17223.github.io/elderly-care/admin";
var RESPOND_BASE = "https://nandhini-17223.github.io/elderly-care/respond.html";
var MANAGER_FIRST_NAME = "Manager";
function seniorAssignUrl(requestId) {
  const next = `needs-action.html?request=${encodeURIComponent(requestId)}`;
  return `${ADMIN_PAGE_BASE}/login.html?next=${encodeURIComponent(next)}`;
}

// ../../../tmp/fn-src/supabase/functions/_shared/assignment.ts
function fullPickupAddress(request) {
  return [
    request.address_line1,
    request.street,
    request.area,
    request.city,
    request.pincode
  ].map((part) => part ? String(part).trim() : "").filter(Boolean).join(", ");
}
function mapsSearchUrl(address) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
}
function familyPhone(request) {
  return `${request.phone_country_code} ${request.phone}`.trim();
}
function actionUrl(token, action) {
  return `${RESPOND_BASE}?token=${encodeURIComponent(token)}&action=${encodeURIComponent(action)}`;
}
function bytesToHex(bytes) {
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function sha256Hex(value) {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return bytesToHex(new Uint8Array(digest));
}
async function createRawToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  const token = bytesToHex(bytes);
  const hash = await sha256Hex(token);
  return { token, hash };
}
function appointmentConfirmedEmail(request, helperName, token) {
  const address = fullPickupAddress(request);
  return templateH2({
    ref: String(request.ref_number ?? "\u2013"),
    helper_first_name: firstName(helperName),
    parent_name: request.parent_name,
    parent_age: request.parent_age,
    address_line1: request.address_line1,
    street: request.street,
    area: request.area,
    city: request.city,
    pincode: request.pincode,
    landmark: request.landmark,
    maps_url: mapsSearchUrl(address),
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    doctor_hospital: request.doctor_hospital,
    booking_person_name: request.booking_person_name,
    relationship: request.relationship,
    guardian_phone: familyPhone(request),
    cant_make_it_url: actionUrl(token, "cant_make_it")
  });
}
function guardianNewHelperEmail(request, helper, oldHelperFirstName) {
  return templateG5({
    ref: String(request.ref_number ?? "\u2013"),
    booking_person_name: request.booking_person_name,
    parent_name: request.parent_name,
    helper_full_name: helper.full_name,
    helper_phone: helper.phone,
    helper_photo_url: helper.photo_url,
    old_helper_first_name: oldHelperFirstName || "the previous helper",
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    doctor_hospital: request.doctor_hospital
  });
}
function guardianHelperAssignedEmail(request, helper) {
  return templateG3({
    ref: String(request.ref_number ?? "\u2013"),
    booking_person_name: request.booking_person_name,
    parent_name: request.parent_name,
    helper_full_name: helper.full_name,
    helper_phone: helper.phone,
    helper_photo_url: helper.photo_url,
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    doctor_hospital: request.doctor_hospital,
    address_line1: request.address_line1,
    street: request.street,
    area: request.area,
    city: request.city,
    pincode: request.pincode
  });
}

// ../../../tmp/fn-src/supabase/functions/_shared/secrets.ts
async function resolveSecret(supabase, name) {
  const fromEnv = Deno.env.get(name)?.trim() || "";
  if (fromEnv) return fromEnv;
  const { data, error } = await supabase.rpc("get_app_secret", {
    p_name: name
  });
  if (error) {
    console.error(`get_app_secret(${name}) failed`, error);
    return null;
  }
  const value = typeof data === "string" ? data.trim() : "";
  return value || null;
}

// ../../../tmp/fn-src/supabase/functions/offer-respond/index.ts
async function helperPhotoSignedUrl(supabase, helper, appointmentDate) {
  if (helper.photo_status !== "approved" || !helper.photo_path) return null;
  const dayAfter = /* @__PURE__ */ new Date(`${appointmentDate}T23:59:59+05:30`);
  if (Number.isNaN(dayAfter.getTime())) return null;
  dayAfter.setDate(dayAfter.getDate() + 1);
  const expiresIn = Math.max(
    60,
    Math.floor((dayAfter.getTime() - Date.now()) / 1e3)
  );
  const { data, error } = await supabase.storage.from("helper-photos").createSignedUrl(helper.photo_path, expiresIn);
  if (error) {
    console.error("helper photo signed url", error);
    return null;
  }
  return data?.signedUrl ?? null;
}
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json",
      Connection: "keep-alive"
    }
  });
}
async function sha256Hex2(value) {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function loadPreviousHelperFirstName(supabase, previousHelperIds) {
  const ids = previousHelperIds ?? [];
  if (!ids.length) return "the previous helper";
  const lastId = ids[ids.length - 1];
  const { data } = await supabase.from("helpers").select("full_name").eq("id", lastId).maybeSingle();
  return firstName(data?.full_name) || "the previous helper";
}
async function sendAcceptanceEmails(supabase, request, helper, isReplacement) {
  const { token, hash } = await createRawToken();
  const { data: tokenResult, error: tokenError } = await supabase.rpc(
    "create_assignment_token",
    {
      p_request_id: request.id,
      p_helper_id: helper.id,
      p_token_hash: hash
    }
  );
  if (tokenError) {
    console.error("create_assignment_token", tokenError);
  }
  const tokenOk = Boolean(tokenResult?.ok);
  const photoUrl = await helperPhotoSignedUrl(
    supabase,
    helper,
    request.appointment_date
  );
  const helperForGuardian = { ...helper, photo_url: photoUrl };
  const helperEmail = appointmentConfirmedEmail(
    request,
    helper.full_name,
    token
  );
  const oldHelperFirst = isReplacement ? await loadPreviousHelperFirstName(supabase, request.previous_helper_ids) : "";
  const guardianEmail = isReplacement ? guardianNewHelperEmail(request, helperForGuardian, oldHelperFirst) : guardianHelperAssignedEmail(request, helperForGuardian);
  const helperResult = await sendEmail({
    to: helper.email,
    toName: helper.full_name,
    subject: helperEmail.subject,
    html: helperEmail.html,
    text: helperEmail.text
  });
  const guardianResult = await sendEmail({
    to: request.email,
    toName: request.booking_person_name,
    subject: guardianEmail.subject,
    html: guardianEmail.html,
    text: guardianEmail.text
  });
  return {
    helper: helperResult.ok,
    guardian: guardianResult.ok,
    token_ok: tokenOk
  };
}
async function triggerNextOffer(requestId, waveNumber) {
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceRoleKey) return;
  try {
    await fetch(`${supabaseUrl}/functions/v1/offer-dispatcher`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${serviceRoleKey}`,
        apikey: serviceRoleKey
      },
      body: JSON.stringify({
        request_id: requestId,
        reason: "decline_backfill",
        offer_next: true,
        force: true,
        wave_number: waveNumber
      })
    });
  } catch (error) {
    console.error("Failed to trigger next offer after decline", error);
  }
}
async function triggerReminders(requestId) {
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceRoleKey) return;
  try {
    await fetch(`${supabaseUrl}/functions/v1/helper-reminders`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${serviceRoleKey}`,
        apikey: serviceRoleKey
      },
      body: JSON.stringify({
        request_id: requestId,
        reason: "post_accept"
      })
    });
  } catch (error) {
    console.error("Failed to trigger helper-reminders after accept", error);
  }
}
async function notifySeniorOfDecline(supabase, requestId, helperName) {
  const seniorEmail = await resolveSecret(supabase, "SENIOR_EMAIL");
  if (!seniorEmail) {
    console.error("Missing SENIOR_EMAIL for decline alert");
    return;
  }
  const { data: request } = await supabase.from("consultation_requests").select(
    "id, ref_number, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason"
  ).eq("id", requestId).maybeSingle();
  if (!request) return;
  const email = templateM3({
    ref: String(request.ref_number ?? "\u2013"),
    manager_first_name: MANAGER_FIRST_NAME,
    helper_full_name: helperName,
    parent_name: request.parent_name,
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    area: request.area,
    decline_reason: null,
    assign_url: seniorAssignUrl(requestId)
  });
  await sendEmail({
    to: seniorEmail,
    toName: "Senior coordinator",
    subject: email.subject,
    html: email.html,
    text: email.text
  });
}
async function previewOffer(supabase, tokenHash) {
  const { data: offer } = await supabase.from("helper_offers").select(
    "id, status, helper_id, request_id, helpers(full_name), consultation_requests(ref_number, appointment_date, appointment_time, area, pincode, parent_name, status)"
  ).eq("token_hash", tokenHash).maybeSingle();
  if (!offer) {
    return {
      ok: false,
      code: "invalid_token",
      title: ON_SCREEN.link_inactive.title,
      message: ON_SCREEN.link_inactive.message
    };
  }
  const request = offer.consultation_requests;
  if (!request || offer.status !== "sent" || request.status === "assigned") {
    return {
      ok: false,
      code: "token_invalid",
      title: ON_SCREEN.link_inactive.title,
      message: ON_SCREEN.link_inactive.message
    };
  }
  const vars = {
    appointment_date_short: formatAppointmentDateShort(
      request.appointment_date
    ),
    appointment_time: formatAppointmentTime(request.appointment_time) ?? String(request.appointment_time ?? ""),
    area: String(request.area ?? request.pincode ?? "\u2013"),
    helper_first_name: firstName(
      offer.helpers?.full_name
    ),
    ref: String(request.ref_number ?? "\u2013")
  };
  return {
    ok: true,
    code: "preview",
    ref_number: request.ref_number,
    title: ON_SCREEN.accept_confirm.title,
    message: fillOnScreen(ON_SCREEN.accept_confirm.message, vars),
    button: ON_SCREEN.accept_confirm.button,
    helper_first_name: vars.helper_first_name
  };
}
function mapAcceptScreen(code, helperFirstName) {
  if (code === "accepted") {
    return {
      title: ON_SCREEN.accepted.title,
      message: fillOnScreen(ON_SCREEN.accepted.message, {
        helper_first_name: helperFirstName
      })
    };
  }
  if (code === "already_taken") {
    return {
      title: ON_SCREEN.already_taken.title,
      message: ON_SCREEN.already_taken.message
    };
  }
  if (code === "helper_engaged") {
    return {
      title: ON_SCREEN.helper_engaged.title,
      message: ON_SCREEN.helper_engaged.message
    };
  }
  return {
    title: ON_SCREEN.link_inactive.title,
    message: ON_SCREEN.link_inactive.message
  };
}
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceRoleKey) {
      throw new Error("Missing Supabase environment configuration");
    }
    const payload = await req.json();
    const token = String(payload.token ?? "").trim();
    const action = String(payload.action ?? "").trim().toLowerCase();
    if (!token || action !== "accept" && action !== "decline") {
      return jsonResponse(
        { ok: false, message: "Missing token or action." },
        400
      );
    }
    const tokenHash = await sha256Hex2(token);
    const supabase = createClient(supabaseUrl, serviceRoleKey);
    if (payload.preview) {
      if (action === "accept") {
        return jsonResponse(await previewOffer(supabase, tokenHash));
      }
      return jsonResponse({
        ok: true,
        code: "preview",
        title: "Thanks for letting us know",
        message: "Tap Confirm to decline this visit.",
        button: "Confirm"
      });
    }
    if (action === "accept") {
      const { data: data2, error: error2 } = await supabase.rpc("accept_helper_offer", {
        p_token_hash: tokenHash
      });
      if (error2) {
        console.error("accept_helper_offer", error2);
        return jsonResponse(
          {
            ok: false,
            title: ON_SCREEN.link_inactive.title,
            message: "Could not process acceptance."
          },
          500
        );
      }
      const result2 = data2;
      let helperFirstName = "there";
      if (result2?.ok && result2.request_id && result2.helper_id) {
        const [{ data: request }, { data: helper }] = await Promise.all([
          supabase.from("consultation_requests").select(
            "id, ref_number, parent_name, parent_age, address_line1, street, area, landmark, city, pincode, appointment_date, appointment_time, doctor_hospital, booking_person_name, relationship, email, phone_country_code, phone, previous_helper_ids"
          ).eq("id", result2.request_id).maybeSingle(),
          supabase.from("helpers").select("id, full_name, email, phone, photo_path, photo_status").eq("id", result2.helper_id).maybeSingle()
        ]);
        if (request && helper) {
          helperFirstName = firstName(helper.full_name);
          await sendAcceptanceEmails(
            supabase,
            request,
            helper,
            Boolean(result2.is_replacement)
          );
          await triggerReminders(result2.request_id);
        }
      }
      const screen = mapAcceptScreen(result2?.code, helperFirstName);
      return jsonResponse({
        ok: Boolean(result2?.ok),
        code: result2?.code,
        title: screen.title,
        message: screen.message
      });
    }
    const { data, error } = await supabase.rpc("decline_helper_offer", {
      p_token_hash: tokenHash
    });
    if (error) {
      console.error("decline_helper_offer", error);
      return jsonResponse(
        {
          ok: false,
          title: ON_SCREEN.link_inactive.title,
          message: "Could not process decline."
        },
        500
      );
    }
    const result = data;
    if (result?.ok && result.request_id && result.request_status === "offered") {
      await triggerNextOffer(result.request_id, result.wave_number);
    }
    if (result?.ok && result.request_id && result.source === "senior" && result.request_status === "needs_senior") {
      await notifySeniorOfDecline(
        supabase,
        result.request_id,
        result.helper_name || "Helper"
      );
    }
    if (!result?.ok) {
      return jsonResponse({
        ok: false,
        code: result?.code,
        title: ON_SCREEN.link_inactive.title,
        message: ON_SCREEN.link_inactive.message
      });
    }
    return jsonResponse({
      ok: true,
      code: result?.code,
      title: ON_SCREEN.declined.title,
      message: ON_SCREEN.declined.message
    });
  } catch (error) {
    console.error(error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return jsonResponse({ ok: false, message }, 500);
  }
});
