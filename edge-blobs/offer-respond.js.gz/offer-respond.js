const se=globalThis.__sb.createClient,H="+91 73399 11220",le="https://nandhini-17223.github.io/elderly-care/helper/",pe="https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg",Y="#1d6fd8",me="#4a9cf7",K="#1f2937",q="#6b7280",j=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],ce=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function a(e){return e.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;")}function o(e,n="\u2013"){if(e==null)return n;const t=String(e).trim();return!t||t.toLowerCase()==="null"||t.toLowerCase()==="undefined"?n:t}function O(e){return o(e,"None given")}function E(e){if(!e)return null;const n=/^(\d{4})-(\d{2})-(\d{2})$/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]),i=Number(n[3]);return!r||r<1||r>12||!i||i<1||i>31?null:{year:t,month:r,day:i}}function z(e){if(!e)return null;const n=/^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]);return!Number.isInteger(t)||!Number.isInteger(r)||t<0||t>23||r<0||r>59?null:{hour24:t,minute:r}}function de(e,n){const t=E(e),r=z(n)??{hour24:0,minute:0};return t?Date.parse(`${String(t.year).padStart(4,"0")}-${String(t.month).padStart(2,"0")}-${String(t.day).padStart(2,"0")}T${String(r.hour24).padStart(2,"0")}:${String(r.minute).padStart(2,"0")}:00+05:30`):NaN}function L(e){const n=E(e);return n?`${n.day} ${j[n.month-1]} ${n.year}`:null}function T(e){const n=E(e);return n?`${n.day} ${j[n.month-1]}`:o(e)}function x(e){const n=E(e);if(!n)return o(e);const t=new Date(Date.UTC(n.year,n.month-1,n.day)).getUTCDay();return`${ce[t]}, ${n.day} ${j[n.month-1]} ${n.year}`}function N(e){const n=z(e);if(!n)return null;const t=n.hour24%12||12,r=n.hour24<12?"AM":"PM";return`${t}:${String(n.minute).padStart(2,"0")} ${r}`}function We(e,n){const t=L(e),r=N(n);return!t||!r?null:`${t}, ${r}`}function J(e){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(e))}function w(e,n,t=Date.now()){const r=de(e,n);if(!Number.isFinite(r))return"\u2013";const i=J(t),s=J(r),m=E(i),l=E(s),d=Math.round((Date.UTC(l.year,l.month-1,l.day)-Date.UTC(m.year,m.month-1,m.day))/864e5);if(d===0){const g=r-t;if(g<=0)return"today";const u=Math.round(g/6e4);if(u<60)return`today \xB7 in ${u} minute${u===1?"":"s"}`;const $=Math.round(u/60);return`today \xB7 in ${$} hour${$===1?"":"s"}`}return d===1?"tomorrow":d>1?`in ${d} days`:d===-1?"yesterday":`${Math.abs(d)} days ago`}function ue(e){if(!e)return"\u2013";const n=Date.parse(e);if(!Number.isFinite(n))return o(e);const t=new Date(n),r=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Kolkata",weekday:"short",day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit",hour12:!0}).formatToParts(t),i=C=>r.find(y=>y.type===C)?.value??"",s=i("day"),m=i("month"),l=i("year"),d=i("weekday"),g=i("hour"),u=i("minute"),$=i("dayPeriod").toUpperCase();return`${d}, ${s} ${m} ${l} \xB7 ${g}:${u} ${$}`}function f(e,n,t="primary"){const r=t==="primary"?Y:"#e5e7eb",i=t==="primary"?"#ffffff":"#111827";return`<a href="${a(e)}" style="background:${r};color:${i};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${a(n)}</a>`}function Q(){return`This is an automated message from ABI Parent Care. For help, call ${H}.`}function ge(e){const n=o(e.ref,""),t=n?`<td align="right" style="font-size:13px;color:${q};white-space:nowrap;">Ref <strong style="color:${K};">${a(n)}</strong></td>`:"<td></td>";return`<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${e.preheader?`<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${a(e.preheader)}</div>`:""}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${Y},${me});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${pe}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${n?`<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${a(n)}</strong></td>`:""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${K};">
          ${e.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${q};">
          ${a(Q())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`}function _e(e){return["ABI Parent Care",e.ref?`Ref ${o(e.ref)}`:null,"",e.bodyText.trim(),"",Q()].filter(t=>t!==null).join(`
`)}async function W(e){const n=Deno.env.get("RESEND_API_KEY");if(!n)throw new Error("Missing RESEND_API_KEY secret");const t=Deno.env.get("EMAIL_TEST_MODE")==="true",r=Deno.env.get("TEST_EMAIL_TO")?.trim()||"",i=(e.toName?.trim()||e.to).trim(),s=t&&r?r:e.to,m=t&&r?`[To: ${i}] ${e.subject}`:e.subject,l={from:"ABI Parent Care <onboarding@resend.dev>",to:[s],subject:m,html:e.html};e.text&&e.text.trim()&&(l.text=e.text);const d=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify(l)}),g=await d.json();return d.ok?{ok:!0,status:d.status,id:typeof g?.id=="string"?g.id:void 0,to:s,subject:m,testMode:t}:(console.error("Resend error:",g),{ok:!1,status:d.status,to:s,subject:m,testMode:t,error:g})}function R(e){const n=String(e??"").trim();return n?n.split(/\s+/)[0]??n:"there"}function S(e){return e==="female"?"Female helper":e==="male"?"Male helper":e==="no_preference"||e==="none"||!e?"No preference":o(e,"No preference")}function B(e){switch(e){case"no_acceptance":return"No helper accepted within 2 hours";case"no_suitable_helpers":return"No suitable helper nearby";case"all_declined":return"All offered helpers declined";case"short_notice":return"Booked at short notice";case"helper_dropped":return"Helper dropped out";case"helper_not_confirmed":return"Helper didn't confirm";case"helper_unavailable":return"Helper no longer available";default:return e?e.replaceAll("_"," "):"Needs senior attention"}}function b(e){return N(e)??o(e)}function k(e){return`<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${a(e)}</p>`}function c(e,n){return`<div style="margin:0 0 6px;"><strong>${a(e)}:</strong> ${a(n)}</div>`}function p(e,n){return`${e}: ${n}`}function X(e){return e?`<p style="margin:16px 0;"><img src="${a(e)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`:""}function P(e){return e.map(n=>String(n??"").trim()).filter(Boolean).join(", ")}function h(e,n,t,r,i){return{id:e,subject:n,html:ge({bodyHtml:r,ref:t,preheader:n}),text:_e({bodyText:i,ref:t})}}function Be(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=b(e.appointment_time),i=P([e.area,e.city,e.pincode])||"\u2013",s=S(e.helper_preference),m=`We've received your request \u2013 ${e.parent_name}, ${n} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Thank you for choosing ABI Parent Care. We've received your request for ${a(e.parent_name)}'s doctor appointment.</p>
    ${k("Appointment")}
    ${c("Date & time",`${t} \xB7 ${r}`)}
    ${c("Doctor/Hospital",o(e.doctor_hospital))}
    ${c("Pickup from",i)}
    ${c("Helper preference",s)}
    ${k("What happens next")}
    <p style="margin:0 0 12px;">We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.</p>
    <p style="margin:0 0 12px;">Need to change anything? Call us on ${a(H)} and quote Ref ${a(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,d=[`Dear ${e.booking_person_name},`,"",`Thank you for choosing ABI Parent Care. We've received your request for ${e.parent_name}'s doctor appointment.`,"","APPOINTMENT",p("Date & time",`${t} \xB7 ${r}`),p("Doctor/Hospital",o(e.doctor_hospital)),p("Pickup from",i),p("Helper preference",s),"","WHAT HAPPENS NEXT","We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.","",`Need to change anything? Call us on ${H} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G1",m,e.ref,l,d)}function Ve(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=b(e.appointment_time),i=`Update on ${e.parent_name}'s appointment \u2013 ${n} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${a(e.parent_name)}'s appointment on ${a(t)} at ${a(r)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${a(H)} and quote Ref ${a(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,m=[`Dear ${e.booking_person_name},`,"",`A quick update: our care team is personally arranging a suitable helper for ${e.parent_name}'s appointment on ${t} at ${r}.`,"","You don't need to do anything. We'll email you the helper's details shortly.","",`If you'd like to speak to us, call ${H} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G2",i,e.ref,s,m)}function he(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=b(e.appointment_time),i=w(e.appointment_date,e.appointment_time),s=P([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",m=`Helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name}, ${n} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news \u2013 ${a(e.helper_full_name)} will accompany ${a(e.parent_name)} to the appointment.</p>
    ${X(e.helper_photo_url)}
    ${k("Your helper")}
    ${c("Name",e.helper_full_name)}
    ${c("Phone",o(e.helper_phone))}
    ${c("Verified","ID and background checked by ABI Parent Care")}
    ${k("Appointment")}
    ${c("Date & time",`${t} \xB7 ${r} (${i})`)}
    ${c("Doctor/Hospital",o(e.doctor_hospital))}
    ${c("Pickup from",s)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${a(e.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,d=[`Dear ${e.booking_person_name},`,"",`Good news \u2013 ${e.helper_full_name} will accompany ${e.parent_name} to the appointment.`,"","YOUR HELPER",p("Name",e.helper_full_name),p("Phone",o(e.helper_phone)),p("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT",p("Date & time",`${t} \xB7 ${r} (${i})`),p("Doctor/Hospital",o(e.doctor_hospital)),p("Pickup from",s),"",`For safety, please share this with ${e.parent_name} so they know who to expect.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G3",m,e.ref,l,d)}function fe(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=b(e.appointment_time),i=`Change of helper for ${e.parent_name} \u2013 ${n} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${a(e.old_helper_first_name)} is unable to attend ${a(e.parent_name)}'s appointment on ${a(t)} at ${a(r)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${a(H)} and quote Ref ${a(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,m=[`Dear ${e.booking_person_name},`,"",`We're sorry \u2013 ${e.old_helper_first_name} is unable to attend ${e.parent_name}'s appointment on ${t} at ${r}.`,"","Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.","",`The appointment itself is unchanged. If you have concerns, call ${H} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G4",i,e.ref,s,m)}function $e(e){const n=x(e.appointment_date),t=b(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=`New helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} will now accompany ${a(e.parent_name)} to the appointment, in place of ${a(e.old_helper_first_name)}.</p>
    ${X(e.helper_photo_url)}
    ${k("Your new helper")}
    ${c("Name",e.helper_full_name)}
    ${c("Phone",o(e.helper_phone))}
    ${c("Verified","ID and background checked by ABI Parent Care")}
    ${k("Appointment (unchanged)")}
    ${c("Date & time",`${n} \xB7 ${t} (${r})`)}
    ${c("Doctor/Hospital",o(e.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,m=[`Dear ${e.booking_person_name},`,"",`${e.helper_full_name} will now accompany ${e.parent_name} to the appointment, in place of ${e.old_helper_first_name}.`,"","YOUR NEW HELPER",p("Name",e.helper_full_name),p("Phone",o(e.helper_phone)),p("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT (unchanged)",p("Date & time",`${n} \xB7 ${t} (${r})`),p("Doctor/Hospital",o(e.doctor_hospital)),"","Thank you for your patience.","","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G5",i,e.ref,s,m)}function Ue(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=b(e.appointment_time),i=w(e.appointment_date,e.appointment_time),s=e.distance_km==null||Number.isNaN(Number(e.distance_km))?"\u2013":String(Math.round(Number(e.distance_km)*10)/10),m=o(e.area),l=`New visit near you \u2013 ${n}, ${r} \xB7 ${m} (${s} km)`,d=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${c("When",`${t} \xB7 ${r} (${i})`)}
    ${c("Pickup area",`${m}, ${o(e.pincode)} \xB7 about ${s} km from you`)}
    ${c("Hospital",o(e.doctor_hospital))}
    ${c("Patient",`Age ${e.parent_age}`)}
    <p style="margin:22px 0;">
      ${f(e.accept_url,"Accept","primary")}
      ${f(e.decline_url,"Decline","secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,g=[`Hi ${e.helper_first_name},`,"","A new hospital visit is available near you. The first helper to accept gets it.","",p("When",`${t} \xB7 ${r} (${i})`),p("Pickup area",`${m}, ${o(e.pincode)} \xB7 about ${s} km from you`),p("Hospital",o(e.doctor_hospital)),p("Patient",`Age ${e.parent_age}`),"",`Accept: ${e.accept_url}`,`Decline: ${e.decline_url}`,"","The patient's name, full address and family contact are shared after you accept.","",`Ref ${e.ref}`].join(`
`);return h("H1",l,e.ref,d,g)}function ye(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=b(e.appointment_time),i=w(e.appointment_date,e.appointment_time),s=P([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",m=`Confirmed: ${e.parent_name}, ${n} ${r} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${k("Patient")}
    ${c("Name",`${e.parent_name}, ${e.parent_age}`)}
    ${c("Pickup",s)}
    ${c("Landmark",o(e.landmark))}
    <p style="margin:10px 0 16px;">${f(e.maps_url,"Open in Google Maps","secondary")}</p>
    ${k("Appointment")}
    ${c("When",`${t} \xB7 ${r} (${i})`)}
    ${c("Hospital",o(e.doctor_hospital))}
    ${k("Family contact")}
    <p style="margin:0 0 12px;">${a(e.booking_person_name)} (${a(o(e.relationship))}) \xB7 ${a(o(e.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${f(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,d=[`Hi ${e.helper_first_name},`,"","This visit is yours. Thank you!","","PATIENT",p("Name",`${e.parent_name}, ${e.parent_age}`),p("Pickup",s),p("Landmark",o(e.landmark)),`Open in Google Maps: ${e.maps_url}`,"","APPOINTMENT",p("When",`${t} \xB7 ${r} (${i})`),p("Hospital",o(e.doctor_hospital)),"","FAMILY CONTACT",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`,"","We'll remind you 12 hours and 6 hours before.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return h("H2",m,e.ref,l,d)}function be(e){const n=x(e.appointment_date),t=b(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=`Reminder: visit ${r} ${t} \u2013 ${e.parent_name}, ${o(e.area)}`,s=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${a(e.parent_name)} ${a(r)}.</p>
    ${c("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${a(o(e.full_address))} \xB7 <a href="${a(e.maps_url)}">Open in Google Maps</a></div>
    ${c("Hospital",o(e.doctor_hospital))}
    ${c("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${f(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,m=[`Hi ${e.helper_first_name},`,"",`A reminder that you're accompanying ${e.parent_name} ${r}.`,"",p("When",`${n} \xB7 ${t}`),p("Pickup",`${o(e.full_address)} \xB7 ${e.maps_url}`),p("Hospital",o(e.doctor_hospital)),p("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"","Plan to reach the pickup address 15 minutes early.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return h("H3",i,e.ref,s,m)}function ke(e){const n=x(e.appointment_date),t=b(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=`Please confirm: ${e.parent_name} at ${t} \u2013 ${r}`,s=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${a(e.parent_name)} is ${a(r)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${f(e.confirm_url,"I'll be there","primary")}
      ${f(e.cant_make_it_url,"Can't make it","secondary")}
    </p>
    ${c("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${a(o(e.full_address))} \xB7 <a href="${a(e.maps_url)}">Open in Google Maps</a></div>
    ${c("Hospital",o(e.doctor_hospital))}
    ${c("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,m=[`Hi ${e.helper_first_name},`,"",`Your visit with ${e.parent_name} is ${r}. Please confirm you'll be there.`,"",`I'll be there: ${e.confirm_url}`,`Can't make it: ${e.cant_make_it_url}`,"",p("When",`${n} \xB7 ${t}`),p("Pickup",`${o(e.full_address)} \xB7 ${e.maps_url}`),p("Hospital",o(e.doctor_hospital)),p("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"","If we don't hear from you, our care team will call you.","",`Ref ${e.ref}`].join(`
`);return h("H4",i,e.ref,s,m)}function Ge(e){const n=e.helper_app_link||le,t="Welcome to ABI Parent Care \u2013 your helper app login",r=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${c("App link",n)}
    ${c("Login email",e.helper_email)}
    ${c("Password","the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${f(n,"Open helper app","primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${a(H)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `,i=[`Hi ${e.helper_first_name},`,"","Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.","",p("App link",n),p("Login email",e.helper_email),p("Password","the temporary password given to you by your manager"),"","You'll be asked to set your own password the first time you log in.","",'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',"",`Questions? Call ${H}.`,"","The ABI Parent Care team"].join(`
`);return h("H5",t,null,r,i)}function Fe(e){const n=x(e.appointment_date),t=b(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=`URGENT \u2013 Helper needed in ${e.time_remaining} \xB7 ${e.parent_name} (${e.parent_age}) \xB7 ${t} \xB7 ${o(e.area)} \xB7 ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${a(r)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${k("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${k("Visit details")}
    ${c("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${c("When",`${n} \xB7 ${t} (${r})`)}
    ${c("Pickup",P([e.area,e.city,e.pincode])||"\u2013")}
    ${c("Hospital",o(e.doctor_hospital))}
    ${c("Preference",S(e.helper_preference))}
    ${c("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${f(e.assign_url,"Assign a helper","primary")}</p>
  `,m=[`Hi ${e.manager_first_name},`,"",`A booking has come in for ${r}. There isn't time to send offers automatically, so please assign a helper now.`,"","WHAT TO DO NOW","Open the request, pick an available helper and send them an offer.","","VISIT DETAILS",p("Patient",`${e.parent_name}, ${e.parent_age}`),p("When",`${n} \xB7 ${t} (${r})`),p("Pickup",P([e.area,e.city,e.pincode])||"\u2013"),p("Hospital",o(e.doctor_hospital)),p("Preference",S(e.helper_preference)),p("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"",`Assign a helper: ${e.assign_url}`].join(`
`);return h("M1",i,e.ref,s,m)}function Ye(e){const t=`${e.items.length} request(s) need a helper \u2013 ${e.digest_time}`,r=e.items.map((l,d)=>{const g=T(l.appointment_date),u=b(l.appointment_time),$=w(l.appointment_date,l.appointment_time);return`
      <div style="margin:0 0 16px;padding:12px 0;border-bottom:1px solid #e5e7eb;">
        <p style="margin:0 0 6px;"><strong>${d+1}. ${a(l.ref)}</strong> \xB7 ${a(l.parent_name)} (${l.parent_age}) \xB7 ${a(g)} ${a(u)} (${a($)})</p>
        <p style="margin:0 0 6px;">${a(o(l.area))} ${a(o(l.pincode))} \xB7 Preference: ${a(S(l.helper_preference))}</p>
        <p style="margin:0 0 10px;">Why: ${a(B(l.reason))}</p>
        <p style="margin:0;">${f(l.assign_url,"Assign","primary")}</p>
      </div>
    `}).join(""),i=e.items.map((l,d)=>{const g=T(l.appointment_date),u=b(l.appointment_time),$=w(l.appointment_date,l.appointment_time);return[`${d+1}. ${l.ref} \xB7 ${l.parent_name} (${l.parent_age}) \xB7 ${g} ${u} (${$})`,`   ${o(l.area)} ${o(l.pincode)} \xB7 Preference: ${S(l.helper_preference)}`,`   Why: ${B(l.reason)}`,`   Assign: ${l.assign_url}`].join(`
`)}).join(`

`),s=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">These requests still need a helper. The soonest appointment is first.</p>
    ${r}
    <p style="margin:22px 0;">${f(e.open_all_url,"Open all in the portal","primary")}</p>
  `,m=[`Hi ${e.manager_first_name},`,"","These requests still need a helper. The soonest appointment is first.","",i,"",`Open all in the portal: ${e.open_all_url}`].join(`
`);return h("M2",t,null,s,m)}function xe(e){const n=T(e.appointment_date),t=x(e.appointment_date),r=b(e.appointment_time),i=w(e.appointment_date,e.appointment_time),s=O(e.decline_reason),m=`${e.helper_full_name} declined \u2013 please assign another \xB7 ${e.parent_name}, ${n} ${r} \xB7 ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} declined the visit you offered.</p>
    ${c("Reason given",s)}
    <p style="margin:12px 0;">Appointment: ${a(t)} \xB7 ${a(r)} (${a(i)}) \xB7 ${a(o(e.area))}</p>
    <p style="margin:22px 0;">${f(e.assign_url,"Choose another helper","primary")}</p>
  `,d=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} declined the visit you offered.`,p("Reason given",s),"",`Appointment: ${t} \xB7 ${r} (${i}) \xB7 ${o(e.area)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return h("M3",m,e.ref,l,d)}function Ke(e){const n=x(e.appointment_date),t=b(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=`No response from ${e.helper_full_name} \u2013 please assign another \xB7 ${e.parent_name} \xB7 ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} didn't respond within ${a(e.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${a(n)} \xB7 ${a(t)} (${a(r)}) \xB7 ${a(o(e.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${a(o(e.helper_phone))}</p>
    <p style="margin:22px 0;">${f(e.assign_url,"Choose another helper","primary")}</p>
  `,m=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} didn't respond within ${e.expiry_window}, so the offer has been withdrawn.`,"",`Appointment: ${n} \xB7 ${t} (${r}) \xB7 ${o(e.area)}`,`Helper phone (if you'd like to call): ${o(e.helper_phone)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return h("M4",i,e.ref,s,m)}function qe(e){const n=x(e.appointment_date),t=b(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=O(e.dropout_reason),s=`URGENT \u2013 ${e.helper_full_name} can't attend \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,m=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} has said they can't attend this visit.</p>
    ${c("Reason given",i)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${k("Visit details")}
    ${c("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${c("When",`${n} \xB7 ${t} (${r})`)}
    ${c("Pickup",P([e.area,e.city,e.pincode])||"\u2013")}
    ${c("Hospital",o(e.doctor_hospital))}
    ${c("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${f(e.assign_url,"Assign a replacement","primary")}</p>
  `,l=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has said they can't attend this visit.`,p("Reason given",i),"","The family has been told we're arranging a replacement. Please assign a new helper now.","","VISIT DETAILS",p("Patient",`${e.parent_name}, ${e.parent_age}`),p("When",`${n} \xB7 ${t} (${r})`),p("Pickup",P([e.area,e.city,e.pincode])||"\u2013"),p("Hospital",o(e.doctor_hospital)),p("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"",`Assign a replacement: ${e.assign_url}`].join(`
`);return h("M5",s,e.ref,m,l)}function we(e){const n=x(e.appointment_date),t=b(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=ue(e.assigned_at),s=e.urgent?`URGENT \u2013 visit in 1 hour, ${e.helper_full_name} still not confirmed \xB7 ${e.parent_name} \xB7 ${e.ref}`:`Action needed \u2013 ${e.helper_full_name} hasn't confirmed \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,m=e.urgent?`The visit starts in about 1 hour and ${a(e.helper_full_name)} still hasn't confirmed. Please resolve this now.`:`${a(e.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,l=e.urgent?`The visit starts in about 1 hour and ${e.helper_full_name} still hasn't confirmed. Please resolve this now.`:`${e.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,d=e.urgent?`<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${a(e.helper_first_name)}: ${a(o(e.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".</li>
      </ol>`:`${k("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${a(e.helper_first_name)}: ${a(o(e.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone \u2013 nothing else happens, or</li>
            <li>Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`,g=e.urgent?[`1. Call ${e.helper_first_name}: ${o(e.helper_phone)}`,'2. Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".'].join(`
`):["WHAT TO DO NOW",`1. Call ${e.helper_first_name}: ${o(e.helper_phone)}`,"2. Then in the portal, choose:","   \u2022 Helper confirmed by phone \u2013 nothing else happens, or","   \u2022 Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper"].join(`
`),u=`
    ${k("Visit details")}
    ${c("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${c("When",`${n} \xB7 ${t} (${r})`)}
    ${c("Pickup",P([e.area,e.city,e.pincode])||"\u2013")}
    ${c("Hospital",o(e.doctor_hospital))}
    ${k("Helper status")}
    ${c("Assigned",i)}
    ${c("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`)}
    ${c("Confirmed","Not yet")}
  `,$=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${m}</p>
    ${d}
    ${u}
    <p style="margin:22px 0;">${f(e.open_url,"Open request","primary")}</p>
  `,C=[`Hi ${e.manager_first_name},`,"",l,"",g,"","VISIT DETAILS",p("Patient",`${e.parent_name}, ${e.parent_age}`),p("When",`${n} \xB7 ${t} (${r})`),p("Pickup",P([e.area,e.city,e.pincode])||"\u2013"),p("Hospital",o(e.doctor_hospital)),"","HELPER STATUS",p("Assigned",i),p("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`),p("Confirmed","Not yet"),"",`Open request: ${e.open_url}`].join(`
`);return h(e.urgent?"M7":"M6",s,e.ref,$,C)}function ze(e){return we({...e,urgent:!0})}function Je(e){const n=`Driving licence ${e.expiry_phrase} \u2013 ${e.helper_full_name}`,t=e.expired?`<p style="margin:0 0 12px;">If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).</p>`:'<p style="margin:0 0 12px;">If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.</p>',r=e.expired?`If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).`:"If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.",i=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)}'s driving licence ${a(e.expiry_phrase)} (${a(e.dl_expiry)}).</p>
    ${t}
    <p style="margin:22px 0;">${f(e.open_url,"Open helper profile","primary")}</p>
  `,s=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name}'s driving licence ${e.expiry_phrase} (${e.dl_expiry}).`,"",r,"",`Open helper profile: ${e.open_url}`].join(`
`);return h("M8",n,null,i,s)}function Qe(e){const n=`Profile change request \u2013 ${e.helper_full_name}`,t=O(e.request_note),r=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} has asked to update their profile:</p>
    <p style="margin:0 0 12px;padding:12px 14px;background:#f3f6fb;border-radius:8px;font-style:italic;">"${a(t)}"</p>
    <p style="margin:0 0 12px;">Please review and update their details in the portal if appropriate.</p>
    <p style="margin:22px 0;">${f(e.open_url,"Open helper profile","primary")}</p>
  `,i=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has asked to update their profile:`,"",`"${t}"`,"","Please review and update their details in the portal if appropriate.","",`Open helper profile: ${e.open_url}`].join(`
`);return h("M9",n,null,r,i)}const _={accept_confirm:{title:"Accept this visit?",message:"{{appointment_date_short}} \xB7 {{appointment_time}} \xB7 {{area}}. Tap Confirm to take this visit.",button:"Confirm"},accepted:{title:"This visit is yours!",message:"We've emailed you the full details. Thank you, {{helper_first_name}}."},already_taken:{title:"Already taken",message:"Another helper accepted this visit first. Thank you for responding quickly."},helper_engaged:{title:"You're already booked",message:"You have another visit around this time, so we can't assign this one to you."},declined:{title:"Thanks for letting us know",message:"We've offered this visit to another helper."},confirmed:{title:"See you there!",message:"Thanks for confirming. The family is counting on you."},cant_make_it_confirm:{title:"Can't make this visit?",message:"Tell us why (optional), then tap Confirm. We'll arrange a replacement.",button:"Confirm"},cant_make_it_done:{title:"Thanks for telling us",message:"Our care team will arrange a replacement."},link_inactive:{title:"This link is no longer active",message:"The visit may have been assigned, cancelled or already passed. Please contact your manager if you need help."}};function Z(e,n){return e.replace(/\{\{(\w+)\}\}/g,(t,r)=>o(n[r],""))}async function Te(e,n){const t=Deno.env.get(n)?.trim()||"";if(t)return t;const{data:r,error:i}=await e.rpc("get_app_secret",{p_name:n});return i?(console.error(`get_app_secret(${n}) failed`,i),null):(typeof r=="string"?r.trim():"")||null}function Xe(e,n){const t=new TextEncoder,r=t.encode(e),i=t.encode(n),s=Math.max(r.length,i.length);let m=r.length===i.length?0:1;for(let l=0;l<s;l++)m|=(r[l]??0)^(i[l]??0);return m===0}const V="https://nandhini-17223.github.io/elderly-care/admin",Ae="https://nandhini-17223.github.io/elderly-care/respond.html",Ze="https://nandhini-17223.github.io/elderly-care/admin/helper.html",He="Manager";function Pe(e){const n=`needs-action.html?request=${encodeURIComponent(e)}`;return`${V}/login.html?next=${encodeURIComponent(n)}`}function ve(){return`${V}/login.html?next=${encodeURIComponent("needs-action.html")}`}function en(e){const n=`helper.html?id=${encodeURIComponent(e)}`;return`${V}/login.html?next=${encodeURIComponent(n)}`}function nn(e,n="Assign helper"){return`<a href="${e}" style="background:#1d6fd8;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;">${a(n)}</a>`}function tn(e){const n=L(e.appointmentDate)??e.appointmentDate,t=N(e.appointmentTime)??e.appointmentTime,r=[e.area,e.pincode].filter(Boolean).join(" \xB7 ")||"Area on file";return`
    <p>
      ${e.refNumber?`<strong>Ref:</strong> ${a(e.refNumber)}<br />`:""}
      <strong>Patient:</strong> ${a(e.parentName)} (age ${a(String(e.parentAge))})<br />
      <strong>Date:</strong> ${a(n)}<br />
      <strong>Time:</strong> ${a(t)}<br />
      <strong>Area:</strong> ${a(r)}<br />
      ${e.doctorHospital?`<strong>Doctor / Hospital:</strong> ${a(e.doctorHospital)}<br />`:""}
      ${e.helperPreference?`<strong>Helper preference:</strong> ${a(S(e.helperPreference))}<br />`:""}
      ${e.reason?`<strong>Reason:</strong> ${a(B(e.reason))}<br />`:""}
      ${e.address?`<strong>Address:</strong> ${a(e.address)}<br />`:""}
    </p>
  `}function rn(e){return e==null||Number.isNaN(Number(e))?"Nearby":`~${Math.round(Number(e)*10)/10} km`}function an(e){return e?"sent":"not sent"}function v(e){return[e.address_line1,e.street,e.area,e.city,e.pincode].map(n=>n?String(n).trim():"").filter(Boolean).join(", ")}function ee(e){return`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e)}`}function ne(e){return`${e.phone_country_code} ${e.phone}`.trim()}function on(e){return{dateLabel:L(e.appointment_date)??e.appointment_date,timeLabel:N(e.appointment_time)??e.appointment_time}}function U(e,n){return`${Ae}?token=${encodeURIComponent(e)}&action=${encodeURIComponent(n)}`}function te(e){return Array.from(e).map(n=>n.toString(16).padStart(2,"0")).join("")}async function Ce(){const e=crypto.getRandomValues(new Uint8Array(32)),n=te(e),t=await G(n);return{token:n,hash:t}}function re(e,n,t){const r=v(e);return ye({ref:String(e.ref_number??"\u2013"),helper_first_name:R(n),parent_name:e.parent_name,parent_age:e.parent_age,address_line1:e.address_line1,street:e.street,area:e.area,city:e.city,pincode:e.pincode,landmark:e.landmark,maps_url:ee(r),appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,guardian_phone:ne(e),cant_make_it_url:U(t,"cant_make_it")})}function sn(e,n,t){return re(e,n,t).html}function Ee(e,n,t,r){const i=v(e),s={ref:String(e.ref_number??"\u2013"),helper_first_name:R(n),parent_name:e.parent_name,area:e.area,appointment_date:e.appointment_date,appointment_time:e.appointment_time,full_address:i,maps_url:ee(i),doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,guardian_phone:ne(e),cant_make_it_url:U(t,"cant_make_it")};return r==="6h"?ke({...s,confirm_url:U(t,"confirm_attendance")}):be(s)}function ln(e,n,t,r){return Ee(e,n,t,r).html}function ae(e,n,t){return $e({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,helper_full_name:n.full_name,helper_phone:n.phone,helper_photo_url:n.photo_url,old_helper_first_name:t||"the previous helper",appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital})}function pn(e,n,t="the previous helper"){return ae(e,n,t).html}function ie(e,n){return he({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,helper_full_name:n.full_name,helper_phone:n.phone,helper_photo_url:n.photo_url,appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,address_line1:e.address_line1,street:e.street,area:e.area,city:e.city,pincode:e.pincode})}function mn(e,n){return ie(e,n).html}function Re(e,n){return fe({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,old_helper_first_name:R(n),appointment_date:e.appointment_date,appointment_time:e.appointment_time})}function cn(e,n){return Re(e,n).html}function dn(e){if(e<=0)return"less than 1 minute";const n=Math.round(e/6e4);if(n<60)return`${n} minute${n===1?"":"s"}`;const t=Math.floor(n/60),r=n%60;return r===0?`${t} hour${t===1?"":"s"}`:`${t}h ${r}m`}async function Se(e,n,t){if(n.photo_status!=="approved"||!n.photo_path)return null;const r=new Date(`${t}T23:59:59+05:30`);if(Number.isNaN(r.getTime()))return null;r.setDate(r.getDate()+1);const i=Math.max(60,Math.floor((r.getTime()-Date.now())/1e3)),{data:s,error:m}=await e.storage.from("helper-photos").createSignedUrl(n.photo_path,i);return m?(console.error("helper photo signed url",m),null):s?.signedUrl??null}const oe={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};function A(e,n=200){return new Response(JSON.stringify(e),{status:n,headers:{...oe,"Content-Type":"application/json",Connection:"keep-alive"}})}async function G(e){const n=new TextEncoder().encode(e),t=await crypto.subtle.digest("SHA-256",n);return Array.from(new Uint8Array(t)).map(r=>r.toString(16).padStart(2,"0")).join("")}async function Ne(e,n){const t=n??[];if(!t.length)return"the previous helper";const r=t[t.length-1],{data:i}=await e.from("helpers").select("full_name").eq("id",r).maybeSingle();return R(i?.full_name)||"the previous helper"}async function Ie(e,n,t,r){const{token:i,hash:s}=await Ce(),{data:m,error:l}=await e.rpc("create_assignment_token",{p_request_id:n.id,p_helper_id:t.id,p_token_hash:s});l&&console.error("create_assignment_token",l);const d=!!m?.ok,g=await Se(e,t,n.appointment_date),u={...t,photo_url:g},$=re(n,t.full_name,i),C=r?await Ne(e,n.previous_helper_ids):"",y=r?ae(n,u,C):ie(n,u),I=await W({to:t.email,toName:t.full_name,subject:$.subject,html:$.html,text:$.text}),D=await W({to:n.email,toName:n.booking_person_name,subject:y.subject,html:y.html,text:y.text});return{helper:I.ok,guardian:D.ok,token_ok:d}}async function De(e,n){const t=Deno.env.get("SUPABASE_URL"),r=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");if(!(!t||!r))try{await fetch(`${t}/functions/v1/offer-dispatcher`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${r}`,apikey:r},body:JSON.stringify({request_id:e,reason:"decline_backfill",offer_next:!0,force:!0,wave_number:n})})}catch(i){console.error("Failed to trigger next offer after decline",i)}}async function Me(e){const n=Deno.env.get("SUPABASE_URL"),t=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");if(!(!n||!t))try{await fetch(`${n}/functions/v1/helper-reminders`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`,apikey:t},body:JSON.stringify({request_id:e,reason:"post_accept"})})}catch(r){console.error("Failed to trigger helper-reminders after accept",r)}}async function je(e,n,t){const r=await Te(e,"SENIOR_EMAIL");if(!r){console.error("Missing SENIOR_EMAIL for decline alert");return}const{data:i}=await e.from("consultation_requests").select("id, ref_number, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason").eq("id",n).maybeSingle();if(!i)return;const s=xe({ref:String(i.ref_number??"\u2013"),manager_first_name:He,helper_full_name:t,parent_name:i.parent_name,appointment_date:i.appointment_date,appointment_time:i.appointment_time,area:i.area,decline_reason:null,assign_url:Pe(n)});await W({to:r,toName:"Senior coordinator",subject:s.subject,html:s.html,text:s.text})}async function Oe(e,n){const{data:t}=await e.from("helper_offers").select("id, status, helper_id, request_id, helpers(full_name), consultation_requests(ref_number, appointment_date, appointment_time, area, pincode, parent_name, status)").eq("token_hash",n).maybeSingle();if(!t)return{ok:!1,code:"invalid_token",title:_.link_inactive.title,message:_.link_inactive.message};const r=t.consultation_requests;if(!r||t.status!=="sent"||r.status==="assigned")return{ok:!1,code:"token_invalid",title:_.link_inactive.title,message:_.link_inactive.message};const i={appointment_date_short:T(r.appointment_date),appointment_time:N(r.appointment_time)??String(r.appointment_time??""),area:String(r.area??r.pincode??"\u2013"),helper_first_name:R(t.helpers?.full_name),ref:String(r.ref_number??"\u2013")};return{ok:!0,code:"preview",ref_number:r.ref_number,title:_.accept_confirm.title,message:Z(_.accept_confirm.message,i),button:_.accept_confirm.button,helper_first_name:i.helper_first_name}}function Le(e,n){return e==="accepted"?{title:_.accepted.title,message:Z(_.accepted.message,{helper_first_name:n})}:e==="already_taken"?{title:_.already_taken.title,message:_.already_taken.message}:e==="helper_engaged"?{title:_.helper_engaged.title,message:_.helper_engaged.message}:{title:_.link_inactive.title,message:_.link_inactive.message}}Deno.serve(async e=>{if(e.method==="OPTIONS")return new Response(null,{status:204,headers:oe});if(e.method!=="POST")return A({error:"Method not allowed"},405);try{const n=Deno.env.get("SUPABASE_URL"),t=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");if(!n||!t)throw new Error("Missing Supabase environment configuration");const r=await e.json(),i=String(r.token??"").trim(),s=String(r.action??"").trim().toLowerCase();if(!i||s!=="accept"&&s!=="decline")return A({ok:!1,message:"Missing token or action."},400);const m=await G(i),l=se(n,t);if(r.preview)return A(s==="accept"?await Oe(l,m):{ok:!0,code:"preview",title:"Thanks for letting us know",message:"Tap Confirm to decline this visit.",button:"Confirm"});if(s==="accept"){const{data:$,error:C}=await l.rpc("accept_helper_offer",{p_token_hash:m});if(C)return console.error("accept_helper_offer",C),A({ok:!1,title:_.link_inactive.title,message:"Could not process acceptance."},500);const y=$;let I="there";if(y?.ok&&y.request_id&&y.helper_id){const[{data:F},{data:M}]=await Promise.all([l.from("consultation_requests").select("id, ref_number, parent_name, parent_age, address_line1, street, area, landmark, city, pincode, appointment_date, appointment_time, doctor_hospital, booking_person_name, relationship, email, phone_country_code, phone, previous_helper_ids").eq("id",y.request_id).maybeSingle(),l.from("helpers").select("id, full_name, email, phone, photo_path, photo_status").eq("id",y.helper_id).maybeSingle()]);F&&M&&(I=R(M.full_name),await Ie(l,F,M,!!y.is_replacement),await Me(y.request_id))}const D=Le(y?.code,I);return A({ok:!!y?.ok,code:y?.code,title:D.title,message:D.message})}const{data:d,error:g}=await l.rpc("decline_helper_offer",{p_token_hash:m});if(g)return console.error("decline_helper_offer",g),A({ok:!1,title:_.link_inactive.title,message:"Could not process decline."},500);const u=d;return u?.ok&&u.request_id&&u.request_status==="offered"&&await De(u.request_id,u.wave_number),u?.ok&&u.request_id&&u.source==="senior"&&u.request_status==="needs_senior"&&await je(l,u.request_id,u.helper_name||"Helper"),u?.ok?A({ok:!0,code:u?.code,title:_.declined.title,message:_.declined.message}):A({ok:!1,code:u?.code,title:_.link_inactive.title,message:_.link_inactive.message})}catch(n){console.error(n);const t=n instanceof Error?n.message:"Unknown error";return A({ok:!1,message:t},500)}});
