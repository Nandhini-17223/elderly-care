const Z=globalThis.__sb.createClient,k="+91 73399 11220",v="https://nandhini-17223.github.io/elderly-care/helper/",ee="https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg",V="#1d6fd8",ne="#4a9cf7",B="#1f2937",G="#6b7280",I=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],te=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function a(e){return e.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;")}function i(e,n="\u2013"){if(e==null)return n;const t=String(e).trim();return!t||t.toLowerCase()==="null"||t.toLowerCase()==="undefined"?n:t}function M(e){return i(e,"None given")}function A(e){if(!e)return null;const n=/^(\d{4})-(\d{2})-(\d{2})$/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]),o=Number(n[3]);return!r||r<1||r>12||!o||o<1||o>31?null:{year:t,month:r,day:o}}function U(e){if(!e)return null;const n=/^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]);return!Number.isInteger(t)||!Number.isInteger(r)||t<0||t>23||r<0||r>59?null:{hour24:t,minute:r}}function F(e,n){const t=A(e),r=U(n)??{hour24:0,minute:0};return t?Date.parse(`${String(t.year).padStart(4,"0")}-${String(t.month).padStart(2,"0")}-${String(t.day).padStart(2,"0")}T${String(r.hour24).padStart(2,"0")}:${String(r.minute).padStart(2,"0")}:00+05:30`):NaN}function D(e){const n=A(e);return n?`${n.day} ${I[n.month-1]} ${n.year}`:null}function H(e){const n=A(e);return n?`${n.day} ${I[n.month-1]}`:i(e)}function b(e){const n=A(e);if(!n)return i(e);const t=new Date(Date.UTC(n.year,n.month-1,n.day)).getUTCDay();return`${te[t]}, ${n.day} ${I[n.month-1]} ${n.year}`}function N(e){const n=U(e);if(!n)return null;const t=n.hour24%12||12,r=n.hour24<12?"AM":"PM";return`${t}:${String(n.minute).padStart(2,"0")} ${r}`}function we(e,n){const t=D(e),r=N(n);return!t||!r?null:`${t}, ${r}`}function Y(e){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(e))}function x(e,n,t=Date.now()){const r=F(e,n);if(!Number.isFinite(r))return"\u2013";const o=Y(t),p=Y(r),c=A(o),l=A(p),s=Math.round((Date.UTC(l.year,l.month-1,l.day)-Date.UTC(c.year,c.month-1,c.day))/864e5);if(s===0){const u=r-t;if(u<=0)return"today";const g=Math.round(u/6e4);if(g<60)return`today \xB7 in ${g} minute${g===1?"":"s"}`;const _=Math.round(g/60);return`today \xB7 in ${_} hour${_===1?"":"s"}`}return s===1?"tomorrow":s>1?`in ${s} days`:s===-1?"yesterday":`${Math.abs(s)} days ago`}function re(e){if(!e)return"\u2013";const n=Date.parse(e);if(!Number.isFinite(n))return i(e);const t=new Date(n),r=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Kolkata",weekday:"short",day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit",hour12:!0}).formatToParts(t),o=C=>r.find(R=>R.type===C)?.value??"",p=o("day"),c=o("month"),l=o("year"),s=o("weekday"),u=o("hour"),g=o("minute"),_=o("dayPeriod").toUpperCase();return`${s}, ${p} ${c} ${l} \xB7 ${u}:${g} ${_}`}function f(e,n,t="primary"){const r=t==="primary"?V:"#e5e7eb",o=t==="primary"?"#ffffff":"#111827";return`<a href="${a(e)}" style="background:${r};color:${o};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${a(n)}</a>`}function K(){return`This is an automated message from ABI Parent Care. For help, call ${k}.`}function ae(e){const n=i(e.ref,""),t=n?`<td align="right" style="font-size:13px;color:${G};white-space:nowrap;">Ref <strong style="color:${B};">${a(n)}</strong></td>`:"<td></td>";return`<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${e.preheader?`<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${a(e.preheader)}</div>`:""}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${V},${ne});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${ee}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${n?`<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${a(n)}</strong></td>`:""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${B};">
          ${e.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${G};">
          ${a(K())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`}function ie(e){return["ABI Parent Care",e.ref?`Ref ${i(e.ref)}`:null,"",e.bodyText.trim(),"",K()].filter(t=>t!==null).join(`
`)}async function z(e){const n=Deno.env.get("RESEND_API_KEY");if(!n)throw new Error("Missing RESEND_API_KEY secret");const t=Deno.env.get("EMAIL_TEST_MODE")==="true",r=Deno.env.get("TEST_EMAIL_TO")?.trim()||"",o=(e.toName?.trim()||e.to).trim(),p=t&&r?r:e.to,c=t&&r?`[To: ${o}] ${e.subject}`:e.subject,l={from:"ABI Parent Care <onboarding@resend.dev>",to:[p],subject:c,html:e.html};e.text&&e.text.trim()&&(l.text=e.text);const s=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify(l)}),u=await s.json();return s.ok?{ok:!0,status:s.status,id:typeof u?.id=="string"?u.id:void 0,to:p,subject:c,testMode:t}:(console.error("Resend error:",u),{ok:!1,status:s.status,to:p,subject:c,testMode:t,error:u})}function j(e){const n=String(e??"").trim();return n?n.split(/\s+/)[0]??n:"there"}function w(e){return e==="female"?"Female helper":e==="male"?"Male helper":e==="no_preference"||e==="none"||!e?"No preference":i(e,"No preference")}function O(e){switch(e){case"no_acceptance":return"No helper accepted within 2 hours";case"no_suitable_helpers":return"No suitable helper nearby";case"all_declined":return"All offered helpers declined";case"short_notice":return"Booked at short notice";case"helper_dropped":return"Helper dropped out";case"helper_not_confirmed":return"Helper didn't confirm";case"helper_unavailable":return"Helper no longer available";default:return e?e.replaceAll("_"," "):"Needs senior attention"}}function $(e){return N(e)??i(e)}function y(e){return`<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${a(e)}</p>`}function d(e,n){return`<div style="margin:0 0 6px;"><strong>${a(e)}:</strong> ${a(n)}</div>`}function m(e,n){return`${e}: ${n}`}function J(e){return e?`<p style="margin:16px 0;"><img src="${a(e)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`:""}function T(e){return e.map(n=>String(n??"").trim()).filter(Boolean).join(", ")}function h(e,n,t,r,o){return{id:e,subject:n,html:ae({bodyHtml:r,ref:t,preheader:n}),text:ie({bodyText:o,ref:t})}}function Pe(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=$(e.appointment_time),o=T([e.area,e.city,e.pincode])||"\u2013",p=w(e.helper_preference),c=`We've received your request \u2013 ${e.parent_name}, ${n} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Thank you for choosing ABI Parent Care. We've received your request for ${a(e.parent_name)}'s doctor appointment.</p>
    ${y("Appointment")}
    ${d("Date & time",`${t} \xB7 ${r}`)}
    ${d("Doctor/Hospital",i(e.doctor_hospital))}
    ${d("Pickup from",o)}
    ${d("Helper preference",p)}
    ${y("What happens next")}
    <p style="margin:0 0 12px;">We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.</p>
    <p style="margin:0 0 12px;">Need to change anything? Call us on ${a(k)} and quote Ref ${a(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,s=[`Dear ${e.booking_person_name},`,"",`Thank you for choosing ABI Parent Care. We've received your request for ${e.parent_name}'s doctor appointment.`,"","APPOINTMENT",m("Date & time",`${t} \xB7 ${r}`),m("Doctor/Hospital",i(e.doctor_hospital)),m("Pickup from",o),m("Helper preference",p),"","WHAT HAPPENS NEXT","We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.","",`Need to change anything? Call us on ${k} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G1",c,e.ref,l,s)}function oe(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=$(e.appointment_time),o=`Update on ${e.parent_name}'s appointment \u2013 ${n} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${a(e.parent_name)}'s appointment on ${a(t)} at ${a(r)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${a(k)} and quote Ref ${a(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`A quick update: our care team is personally arranging a suitable helper for ${e.parent_name}'s appointment on ${t} at ${r}.`,"","You don't need to do anything. We'll email you the helper's details shortly.","",`If you'd like to speak to us, call ${k} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G2",o,e.ref,p,c)}function se(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=$(e.appointment_time),o=x(e.appointment_date,e.appointment_time),p=T([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",c=`Helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name}, ${n} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news \u2013 ${a(e.helper_full_name)} will accompany ${a(e.parent_name)} to the appointment.</p>
    ${J(e.helper_photo_url)}
    ${y("Your helper")}
    ${d("Name",e.helper_full_name)}
    ${d("Phone",i(e.helper_phone))}
    ${d("Verified","ID and background checked by ABI Parent Care")}
    ${y("Appointment")}
    ${d("Date & time",`${t} \xB7 ${r} (${o})`)}
    ${d("Doctor/Hospital",i(e.doctor_hospital))}
    ${d("Pickup from",p)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${a(e.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,s=[`Dear ${e.booking_person_name},`,"",`Good news \u2013 ${e.helper_full_name} will accompany ${e.parent_name} to the appointment.`,"","YOUR HELPER",m("Name",e.helper_full_name),m("Phone",i(e.helper_phone)),m("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT",m("Date & time",`${t} \xB7 ${r} (${o})`),m("Doctor/Hospital",i(e.doctor_hospital)),m("Pickup from",p),"",`For safety, please share this with ${e.parent_name} so they know who to expect.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G3",c,e.ref,l,s)}function pe(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=$(e.appointment_time),o=`Change of helper for ${e.parent_name} \u2013 ${n} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${a(e.old_helper_first_name)} is unable to attend ${a(e.parent_name)}'s appointment on ${a(t)} at ${a(r)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${a(k)} and quote Ref ${a(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`We're sorry \u2013 ${e.old_helper_first_name} is unable to attend ${e.parent_name}'s appointment on ${t} at ${r}.`,"","Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.","",`The appointment itself is unchanged. If you have concerns, call ${k} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G4",o,e.ref,p,c)}function le(e){const n=b(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),o=`New helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} will now accompany ${a(e.parent_name)} to the appointment, in place of ${a(e.old_helper_first_name)}.</p>
    ${J(e.helper_photo_url)}
    ${y("Your new helper")}
    ${d("Name",e.helper_full_name)}
    ${d("Phone",i(e.helper_phone))}
    ${d("Verified","ID and background checked by ABI Parent Care")}
    ${y("Appointment (unchanged)")}
    ${d("Date & time",`${n} \xB7 ${t} (${r})`)}
    ${d("Doctor/Hospital",i(e.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`${e.helper_full_name} will now accompany ${e.parent_name} to the appointment, in place of ${e.old_helper_first_name}.`,"","YOUR NEW HELPER",m("Name",e.helper_full_name),m("Phone",i(e.helper_phone)),m("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT (unchanged)",m("Date & time",`${n} \xB7 ${t} (${r})`),m("Doctor/Hospital",i(e.doctor_hospital)),"","Thank you for your patience.","","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G5",o,e.ref,p,c)}function Ce(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=$(e.appointment_time),o=x(e.appointment_date,e.appointment_time),p=e.distance_km==null||Number.isNaN(Number(e.distance_km))?"\u2013":String(Math.round(Number(e.distance_km)*10)/10),c=i(e.area),l=`New visit near you \u2013 ${n}, ${r} \xB7 ${c} (${p} km)`,s=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${d("When",`${t} \xB7 ${r} (${o})`)}
    ${d("Pickup area",`${c}, ${i(e.pincode)} \xB7 about ${p} km from you`)}
    ${d("Hospital",i(e.doctor_hospital))}
    ${d("Patient",`Age ${e.parent_age}`)}
    <p style="margin:22px 0;">
      ${f(e.accept_url,"Accept","primary")}
      ${f(e.decline_url,"Decline","secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,u=[`Hi ${e.helper_first_name},`,"","A new hospital visit is available near you. The first helper to accept gets it.","",m("When",`${t} \xB7 ${r} (${o})`),m("Pickup area",`${c}, ${i(e.pincode)} \xB7 about ${p} km from you`),m("Hospital",i(e.doctor_hospital)),m("Patient",`Age ${e.parent_age}`),"",`Accept: ${e.accept_url}`,`Decline: ${e.decline_url}`,"","The patient's name, full address and family contact are shared after you accept.","",`Ref ${e.ref}`].join(`
`);return h("H1",l,e.ref,s,u)}function me(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=$(e.appointment_time),o=x(e.appointment_date,e.appointment_time),p=T([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",c=`Confirmed: ${e.parent_name}, ${n} ${r} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${y("Patient")}
    ${d("Name",`${e.parent_name}, ${e.parent_age}`)}
    ${d("Pickup",p)}
    ${d("Landmark",i(e.landmark))}
    <p style="margin:10px 0 16px;">${f(e.maps_url,"Open in Google Maps","secondary")}</p>
    ${y("Appointment")}
    ${d("When",`${t} \xB7 ${r} (${o})`)}
    ${d("Hospital",i(e.doctor_hospital))}
    ${y("Family contact")}
    <p style="margin:0 0 12px;">${a(e.booking_person_name)} (${a(i(e.relationship))}) \xB7 ${a(i(e.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${f(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,s=[`Hi ${e.helper_first_name},`,"","This visit is yours. Thank you!","","PATIENT",m("Name",`${e.parent_name}, ${e.parent_age}`),m("Pickup",p),m("Landmark",i(e.landmark)),`Open in Google Maps: ${e.maps_url}`,"","APPOINTMENT",m("When",`${t} \xB7 ${r} (${o})`),m("Hospital",i(e.doctor_hospital)),"","FAMILY CONTACT",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`,"","We'll remind you 12 hours and 6 hours before.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return h("H2",c,e.ref,l,s)}function de(e){const n=b(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),o=`Reminder: visit ${r} ${t} \u2013 ${e.parent_name}, ${i(e.area)}`,p=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${a(e.parent_name)} ${a(r)}.</p>
    ${d("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${a(i(e.full_address))} \xB7 <a href="${a(e.maps_url)}">Open in Google Maps</a></div>
    ${d("Hospital",i(e.doctor_hospital))}
    ${d("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${f(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,c=[`Hi ${e.helper_first_name},`,"",`A reminder that you're accompanying ${e.parent_name} ${r}.`,"",m("When",`${n} \xB7 ${t}`),m("Pickup",`${i(e.full_address)} \xB7 ${e.maps_url}`),m("Hospital",i(e.doctor_hospital)),m("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`),"","Plan to reach the pickup address 15 minutes early.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return h("H3",o,e.ref,p,c)}function ce(e){const n=b(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),o=`Please confirm: ${e.parent_name} at ${t} \u2013 ${r}`,p=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${a(e.parent_name)} is ${a(r)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${f(e.confirm_url,"I'll be there","primary")}
      ${f(e.cant_make_it_url,"Can't make it","secondary")}
    </p>
    ${d("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${a(i(e.full_address))} \xB7 <a href="${a(e.maps_url)}">Open in Google Maps</a></div>
    ${d("Hospital",i(e.doctor_hospital))}
    ${d("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,c=[`Hi ${e.helper_first_name},`,"",`Your visit with ${e.parent_name} is ${r}. Please confirm you'll be there.`,"",`I'll be there: ${e.confirm_url}`,`Can't make it: ${e.cant_make_it_url}`,"",m("When",`${n} \xB7 ${t}`),m("Pickup",`${i(e.full_address)} \xB7 ${e.maps_url}`),m("Hospital",i(e.doctor_hospital)),m("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`),"","If we don't hear from you, our care team will call you.","",`Ref ${e.ref}`].join(`
`);return h("H4",o,e.ref,p,c)}function Re(e){const n=e.helper_app_link||v,t="Welcome to ABI Parent Care \u2013 your helper app login",r=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${d("App link",n)}
    ${d("Login email",e.helper_email)}
    ${d("Password","the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${f(n,"Open helper app","primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${a(k)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `,o=[`Hi ${e.helper_first_name},`,"","Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.","",m("App link",n),m("Login email",e.helper_email),m("Password","the temporary password given to you by your manager"),"","You'll be asked to set your own password the first time you log in.","",'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',"",`Questions? Call ${k}.`,"","The ABI Parent Care team"].join(`
`);return h("H5",t,null,r,o)}function ue(e){const n=b(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),o=`URGENT \u2013 Helper needed in ${e.time_remaining} \xB7 ${e.parent_name} (${e.parent_age}) \xB7 ${t} \xB7 ${i(e.area)} \xB7 ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${a(r)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${y("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${y("Visit details")}
    ${d("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${d("When",`${n} \xB7 ${t} (${r})`)}
    ${d("Pickup",T([e.area,e.city,e.pincode])||"\u2013")}
    ${d("Hospital",i(e.doctor_hospital))}
    ${d("Preference",w(e.helper_preference))}
    ${d("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${f(e.assign_url,"Assign a helper","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"",`A booking has come in for ${r}. There isn't time to send offers automatically, so please assign a helper now.`,"","WHAT TO DO NOW","Open the request, pick an available helper and send them an offer.","","VISIT DETAILS",m("Patient",`${e.parent_name}, ${e.parent_age}`),m("When",`${n} \xB7 ${t} (${r})`),m("Pickup",T([e.area,e.city,e.pincode])||"\u2013"),m("Hospital",i(e.doctor_hospital)),m("Preference",w(e.helper_preference)),m("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`),"",`Assign a helper: ${e.assign_url}`].join(`
`);return h("M1",o,e.ref,p,c)}function Ee(e){const t=`${e.items.length} request(s) need a helper \u2013 ${e.digest_time}`,r=e.items.map((l,s)=>{const u=H(l.appointment_date),g=$(l.appointment_time),_=x(l.appointment_date,l.appointment_time);return`
      <div style="margin:0 0 16px;padding:12px 0;border-bottom:1px solid #e5e7eb;">
        <p style="margin:0 0 6px;"><strong>${s+1}. ${a(l.ref)}</strong> \xB7 ${a(l.parent_name)} (${l.parent_age}) \xB7 ${a(u)} ${a(g)} (${a(_)})</p>
        <p style="margin:0 0 6px;">${a(i(l.area))} ${a(i(l.pincode))} \xB7 Preference: ${a(w(l.helper_preference))}</p>
        <p style="margin:0 0 10px;">Why: ${a(O(l.reason))}</p>
        <p style="margin:0;">${f(l.assign_url,"Assign","primary")}</p>
      </div>
    `}).join(""),o=e.items.map((l,s)=>{const u=H(l.appointment_date),g=$(l.appointment_time),_=x(l.appointment_date,l.appointment_time);return[`${s+1}. ${l.ref} \xB7 ${l.parent_name} (${l.parent_age}) \xB7 ${u} ${g} (${_})`,`   ${i(l.area)} ${i(l.pincode)} \xB7 Preference: ${w(l.helper_preference)}`,`   Why: ${O(l.reason)}`,`   Assign: ${l.assign_url}`].join(`
`)}).join(`

`),p=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">These requests still need a helper. The soonest appointment is first.</p>
    ${r}
    <p style="margin:22px 0;">${f(e.open_all_url,"Open all in the portal","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"","These requests still need a helper. The soonest appointment is first.","",o,"",`Open all in the portal: ${e.open_all_url}`].join(`
`);return h("M2",t,null,p,c)}function Ne(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=$(e.appointment_time),o=x(e.appointment_date,e.appointment_time),p=M(e.decline_reason),c=`${e.helper_full_name} declined \u2013 please assign another \xB7 ${e.parent_name}, ${n} ${r} \xB7 ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} declined the visit you offered.</p>
    ${d("Reason given",p)}
    <p style="margin:12px 0;">Appointment: ${a(t)} \xB7 ${a(r)} (${a(o)}) \xB7 ${a(i(e.area))}</p>
    <p style="margin:22px 0;">${f(e.assign_url,"Choose another helper","primary")}</p>
  `,s=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} declined the visit you offered.`,m("Reason given",p),"",`Appointment: ${t} \xB7 ${r} (${o}) \xB7 ${i(e.area)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return h("M3",c,e.ref,l,s)}function Se(e){const n=b(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),o=`No response from ${e.helper_full_name} \u2013 please assign another \xB7 ${e.parent_name} \xB7 ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} didn't respond within ${a(e.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${a(n)} \xB7 ${a(t)} (${a(r)}) \xB7 ${a(i(e.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${a(i(e.helper_phone))}</p>
    <p style="margin:22px 0;">${f(e.assign_url,"Choose another helper","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} didn't respond within ${e.expiry_window}, so the offer has been withdrawn.`,"",`Appointment: ${n} \xB7 ${t} (${r}) \xB7 ${i(e.area)}`,`Helper phone (if you'd like to call): ${i(e.helper_phone)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return h("M4",o,e.ref,p,c)}function Ie(e){const n=b(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),o=M(e.dropout_reason),p=`URGENT \u2013 ${e.helper_full_name} can't attend \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,c=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} has said they can't attend this visit.</p>
    ${d("Reason given",o)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${y("Visit details")}
    ${d("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${d("When",`${n} \xB7 ${t} (${r})`)}
    ${d("Pickup",T([e.area,e.city,e.pincode])||"\u2013")}
    ${d("Hospital",i(e.doctor_hospital))}
    ${d("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${f(e.assign_url,"Assign a replacement","primary")}</p>
  `,l=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has said they can't attend this visit.`,m("Reason given",o),"","The family has been told we're arranging a replacement. Please assign a new helper now.","","VISIT DETAILS",m("Patient",`${e.parent_name}, ${e.parent_age}`),m("When",`${n} \xB7 ${t} (${r})`),m("Pickup",T([e.area,e.city,e.pincode])||"\u2013"),m("Hospital",i(e.doctor_hospital)),m("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`),"",`Assign a replacement: ${e.assign_url}`].join(`
`);return h("M5",p,e.ref,c,l)}function ge(e){const n=b(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),o=re(e.assigned_at),p=e.urgent?`URGENT \u2013 visit in 1 hour, ${e.helper_full_name} still not confirmed \xB7 ${e.parent_name} \xB7 ${e.ref}`:`Action needed \u2013 ${e.helper_full_name} hasn't confirmed \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,c=e.urgent?`The visit starts in about 1 hour and ${a(e.helper_full_name)} still hasn't confirmed. Please resolve this now.`:`${a(e.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,l=e.urgent?`The visit starts in about 1 hour and ${e.helper_full_name} still hasn't confirmed. Please resolve this now.`:`${e.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,s=e.urgent?`<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${a(e.helper_first_name)}: ${a(i(e.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".</li>
      </ol>`:`${y("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${a(e.helper_first_name)}: ${a(i(e.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone \u2013 nothing else happens, or</li>
            <li>Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`,u=e.urgent?[`1. Call ${e.helper_first_name}: ${i(e.helper_phone)}`,'2. Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".'].join(`
`):["WHAT TO DO NOW",`1. Call ${e.helper_first_name}: ${i(e.helper_phone)}`,"2. Then in the portal, choose:","   \u2022 Helper confirmed by phone \u2013 nothing else happens, or","   \u2022 Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper"].join(`
`),g=`
    ${y("Visit details")}
    ${d("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${d("When",`${n} \xB7 ${t} (${r})`)}
    ${d("Pickup",T([e.area,e.city,e.pincode])||"\u2013")}
    ${d("Hospital",i(e.doctor_hospital))}
    ${y("Helper status")}
    ${d("Assigned",o)}
    ${d("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`)}
    ${d("Confirmed","Not yet")}
  `,_=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${c}</p>
    ${s}
    ${g}
    <p style="margin:22px 0;">${f(e.open_url,"Open request","primary")}</p>
  `,C=[`Hi ${e.manager_first_name},`,"",l,"",u,"","VISIT DETAILS",m("Patient",`${e.parent_name}, ${e.parent_age}`),m("When",`${n} \xB7 ${t} (${r})`),m("Pickup",T([e.area,e.city,e.pincode])||"\u2013"),m("Hospital",i(e.doctor_hospital)),"","HELPER STATUS",m("Assigned",o),m("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`),m("Confirmed","Not yet"),"",`Open request: ${e.open_url}`].join(`
`);return h(e.urgent?"M7":"M6",p,e.ref,_,C)}function Me(e){return ge({...e,urgent:!0})}function De(e){const n=`Driving licence ${e.expiry_phrase} \u2013 ${e.helper_full_name}`,t=e.expired?`<p style="margin:0 0 12px;">If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).</p>`:'<p style="margin:0 0 12px;">If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.</p>',r=e.expired?`If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).`:"If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.",o=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)}'s driving licence ${a(e.expiry_phrase)} (${a(e.dl_expiry)}).</p>
    ${t}
    <p style="margin:22px 0;">${f(e.open_url,"Open helper profile","primary")}</p>
  `,p=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name}'s driving licence ${e.expiry_phrase} (${e.dl_expiry}).`,"",r,"",`Open helper profile: ${e.open_url}`].join(`
`);return h("M8",n,null,o,p)}function je(e){const n=`Profile change request \u2013 ${e.helper_full_name}`,t=M(e.request_note),r=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} has asked to update their profile:</p>
    <p style="margin:0 0 12px;padding:12px 14px;background:#f3f6fb;border-radius:8px;font-style:italic;">"${a(t)}"</p>
    <p style="margin:0 0 12px;">Please review and update their details in the portal if appropriate.</p>
    <p style="margin:22px 0;">${f(e.open_url,"Open helper profile","primary")}</p>
  `,o=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has asked to update their profile:`,"",`"${t}"`,"","Please review and update their details in the portal if appropriate.","",`Open helper profile: ${e.open_url}`].join(`
`);return h("M9",n,null,r,o)}const Oe={accept_confirm:{title:"Accept this visit?",message:"{{appointment_date_short}} \xB7 {{appointment_time}} \xB7 {{area}}. Tap Confirm to take this visit.",button:"Confirm"},accepted:{title:"This visit is yours!",message:"We've emailed you the full details. Thank you, {{helper_first_name}}."},already_taken:{title:"Already taken",message:"Another helper accepted this visit first. Thank you for responding quickly."},helper_engaged:{title:"You're already booked",message:"You have another visit around this time, so we can't assign this one to you."},declined:{title:"Thanks for letting us know",message:"We've offered this visit to another helper."},confirmed:{title:"See you there!",message:"Thanks for confirming. The family is counting on you."},cant_make_it_confirm:{title:"Can't make this visit?",message:"Tell us why (optional), then tap Confirm. We'll arrange a replacement.",button:"Confirm"},cant_make_it_done:{title:"Thanks for telling us",message:"Our care team will arrange a replacement."},link_inactive:{title:"This link is no longer active",message:"The visit may have been assigned, cancelled or already passed. Please contact your manager if you need help."}};function We(e,n){return e.replace(/\{\{(\w+)\}\}/g,(t,r)=>i(n[r],""))}async function _e(e,n){const t=Deno.env.get(n)?.trim()||"";if(t)return t;const{data:r,error:o}=await e.rpc("get_app_secret",{p_name:n});return o?(console.error(`get_app_secret(${n}) failed`,o),null):(typeof r=="string"?r.trim():"")||null}function Le(e,n){const t=new TextEncoder,r=t.encode(e),o=t.encode(n),p=Math.max(r.length,o.length);let c=r.length===o.length?0:1;for(let l=0;l<p;l++)c|=(r[l]??0)^(o[l]??0);return c===0}const W="https://nandhini-17223.github.io/elderly-care/admin",he="https://nandhini-17223.github.io/elderly-care/respond.html",Ve="https://nandhini-17223.github.io/elderly-care/admin/helper.html",fe="Manager";function $e(e){const n=`needs-action.html?request=${encodeURIComponent(e)}`;return`${W}/login.html?next=${encodeURIComponent(n)}`}function Be(){return`${W}/login.html?next=${encodeURIComponent("needs-action.html")}`}function Ge(e){const n=`helper.html?id=${encodeURIComponent(e)}`;return`${W}/login.html?next=${encodeURIComponent(n)}`}function Ue(e,n="Assign helper"){return`<a href="${e}" style="background:#1d6fd8;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;">${a(n)}</a>`}function Fe(e){const n=D(e.appointmentDate)??e.appointmentDate,t=N(e.appointmentTime)??e.appointmentTime,r=[e.area,e.pincode].filter(Boolean).join(" \xB7 ")||"Area on file";return`
    <p>
      ${e.refNumber?`<strong>Ref:</strong> ${a(e.refNumber)}<br />`:""}
      <strong>Patient:</strong> ${a(e.parentName)} (age ${a(String(e.parentAge))})<br />
      <strong>Date:</strong> ${a(n)}<br />
      <strong>Time:</strong> ${a(t)}<br />
      <strong>Area:</strong> ${a(r)}<br />
      ${e.doctorHospital?`<strong>Doctor / Hospital:</strong> ${a(e.doctorHospital)}<br />`:""}
      ${e.helperPreference?`<strong>Helper preference:</strong> ${a(w(e.helperPreference))}<br />`:""}
      ${e.reason?`<strong>Reason:</strong> ${a(O(e.reason))}<br />`:""}
      ${e.address?`<strong>Address:</strong> ${a(e.address)}<br />`:""}
    </p>
  `}function Ye(e){return e==null||Number.isNaN(Number(e))?"Nearby":`~${Math.round(Number(e)*10)/10} km`}function Ke(e){return e?"sent":"not sent"}function q(e){return[e.address_line1,e.street,e.area,e.city,e.pincode].map(n=>n?String(n).trim():"").filter(Boolean).join(", ")}function Q(e){return`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e)}`}function ze(e){return{dateLabel:D(e.appointment_date)??e.appointment_date,timeLabel:N(e.appointment_time)??e.appointment_time}}function L(e,n){return`${he}?token=${encodeURIComponent(e)}&action=${encodeURIComponent(n)}`}function X(e){return Array.from(e).map(n=>n.toString(16).padStart(2,"0")).join("")}async function ye(e){const n=new TextEncoder().encode(e),t=await crypto.subtle.digest("SHA-256",n);return X(new Uint8Array(t))}async function Je(){const e=crypto.getRandomValues(new Uint8Array(32)),n=X(e),t=await ye(n);return{token:n,hash:t}}function be(e,n,t){const r=q(e);return me({ref:String(e.ref_number??"\u2013"),helper_first_name:j(n),parent_name:e.parent_name,parent_age:e.parent_age,address_line1:e.address_line1,street:e.street,area:e.area,city:e.city,pincode:e.pincode,landmark:e.landmark,maps_url:Q(r),appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,guardian_phone:S(e),cant_make_it_url:L(t,"cant_make_it")})}function qe(e,n,t){return be(e,n,t).html}function xe(e,n,t,r){const o=q(e),p={ref:String(e.ref_number??"\u2013"),helper_first_name:j(n),parent_name:e.parent_name,area:e.area,appointment_date:e.appointment_date,appointment_time:e.appointment_time,full_address:o,maps_url:Q(o),doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,guardian_phone:S(e),cant_make_it_url:L(t,"cant_make_it")};return r==="6h"?ce({...p,confirm_url:L(t,"confirm_attendance")}):de(p)}function Qe(e,n,t,r){return xe(e,n,t,r).html}function ke(e,n,t){return le({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,helper_full_name:n.full_name,helper_phone:n.phone,helper_photo_url:n.photo_url,old_helper_first_name:t||"the previous helper",appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital})}function Xe(e,n,t="the previous helper"){return ke(e,n,t).html}function He(e,n){return se({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,helper_full_name:n.full_name,helper_phone:n.phone,helper_photo_url:n.photo_url,appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,address_line1:e.address_line1,street:e.street,area:e.area,city:e.city,pincode:e.pincode})}function Ze(e,n){return He(e,n).html}function Te(e,n){return pe({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,old_helper_first_name:j(n),appointment_date:e.appointment_date,appointment_time:e.appointment_time})}function ve(e,n){return Te(e,n).html}function Ae(e){if(e<=0)return"less than 1 minute";const n=Math.round(e/6e4);if(n<60)return`${n} minute${n===1?"":"s"}`;const t=Math.floor(n/60),r=n%60;return r===0?`${t} hour${t===1?"":"s"}`:`${t}h ${r}m`}function P(e,n=200){return new Response(JSON.stringify(e),{status:n,headers:{"Content-Type":"application/json",Connection:"keep-alive"}})}function S(e){return`${e.phone_country_code??""} ${e.phone??""}`.trim()}Deno.serve(async e=>{if(e.method==="OPTIONS")return new Response(null,{status:204});if(e.method!=="POST")return P({error:"Method not allowed"},405);try{const n=Deno.env.get("SUPABASE_URL"),t=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");if(!n||!t)throw new Error("Missing Supabase environment configuration");const r=await e.json().catch(()=>({})),o=String(r.request_id??"").trim();if(!o)return P({error:"request_id required"},400);const p=Z(n,t),{data:c,error:l}=await p.from("consultation_requests").select("id, ref_number, status, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason, booking_person_name, relationship, phone_country_code, phone, email, senior_notified_at, guardian_arranging_sent_at, address_line1, street, landmark, city").eq("id",o).maybeSingle();if(l)throw l;if(!c)return P({error:"Request not found"},404);const s=c;if(s.status!=="needs_senior")return P({ok:!0,skipped:!0,reason:"not_needs_senior",status:s.status});const u={request_id:s.id,guardian:null,senior_urgent:null};if(s.guardian_arranging_sent_at)u.guardian={skipped:!0,reason:"already_sent"};else{const g=oe({ref:String(s.ref_number??"\u2013"),booking_person_name:s.booking_person_name,parent_name:s.parent_name,appointment_date:s.appointment_date,appointment_time:s.appointment_time}),_=await z({to:s.email,toName:s.booking_person_name,subject:g.subject,html:g.html,text:g.text});_.ok&&await p.from("consultation_requests").update({guardian_arranging_sent_at:new Date().toISOString()}).eq("id",s.id).is("guardian_arranging_sent_at",null),u.guardian={ok:_.ok,id:_.id,subject:_.subject}}if(s.needs_senior_reason==="short_notice"&&!s.senior_notified_at){const g=await _e(p,"SENIOR_EMAIL");if(!g)u.senior_urgent={ok:!1,error:"SENIOR_EMAIL missing"};else{const _=F(s.appointment_date,s.appointment_time),C=Number.isFinite(_)?Ae(_-Date.now()):"soon",R=ue({ref:String(s.ref_number??"\u2013"),manager_first_name:fe,parent_name:s.parent_name,parent_age:s.parent_age,appointment_date:s.appointment_date,appointment_time:s.appointment_time,area:s.area,city:s.city,pincode:s.pincode,doctor_hospital:s.doctor_hospital,helper_preference:s.helper_preference,booking_person_name:s.booking_person_name,relationship:String(s.relationship??""),guardian_phone:S(s),time_remaining:C,assign_url:$e(s.id)}),E=await z({to:g,toName:"Senior coordinator",subject:R.subject,html:R.html,text:R.text});E.ok&&await p.from("consultation_requests").update({senior_notified_at:new Date().toISOString()}).eq("id",s.id).is("senior_notified_at",null),u.senior_urgent={ok:E.ok,id:E.id,subject:E.subject}}}else u.senior_urgent={skipped:!0,reason:s.needs_senior_reason==="short_notice"?"already_notified":"not_short_notice"};return P({ok:!0,...u})}catch(n){console.error(n);const t=n instanceof Error?n.message:"Unknown error";return P({error:t},500)}});
