// ../../../tmp/fn-src/supabase/functions/senior-notify/index.ts
import { createClient } from "jsr:@supabase/supabase-js@2";

// ../../../tmp/fn-src/supabase/functions/_shared/email.ts
var SUPPORT_PHONE = "+91 73399 11220";
var LOGO_URL = "https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg";
var BRAND_PRIMARY = "#1d6fd8";
var BRAND_ACCENT = "#4a9cf7";
var BRAND_TEXT = "#1f2937";
var BRAND_MUTED = "#6b7280";
var MONTHS_SHORT = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
];
var WEEKDAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
function escapeHtml(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}
function displayValue(value, fallback = "\u2013") {
  if (value === null || value === void 0) return fallback;
  const text = String(value).trim();
  if (!text || text.toLowerCase() === "null" || text.toLowerCase() === "undefined") {
    return fallback;
  }
  return text;
}
function parseDateParts(appointmentDate) {
  if (!appointmentDate) return null;
  const dateMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(appointmentDate.trim());
  if (!dateMatch) return null;
  const year = Number(dateMatch[1]);
  const month = Number(dateMatch[2]);
  const day = Number(dateMatch[3]);
  if (!month || month < 1 || month > 12 || !day || day < 1 || day > 31) {
    return null;
  }
  return { year, month, day };
}
function parseTimeParts(appointmentTime) {
  if (!appointmentTime) return null;
  const timeMatch = /^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(
    appointmentTime.trim()
  );
  if (!timeMatch) return null;
  const hour24 = Number(timeMatch[1]);
  const minute = Number(timeMatch[2]);
  if (!Number.isInteger(hour24) || !Number.isInteger(minute) || hour24 < 0 || hour24 > 23 || minute < 0 || minute > 59) {
    return null;
  }
  return { hour24, minute };
}
function appointmentMsIst(appointmentDate, appointmentTime) {
  const d = parseDateParts(appointmentDate);
  const t = parseTimeParts(appointmentTime) ?? { hour24: 0, minute: 0 };
  if (!d) return NaN;
  return Date.parse(
    `${String(d.year).padStart(4, "0")}-${String(d.month).padStart(2, "0")}-${String(d.day).padStart(2, "0")}T${String(t.hour24).padStart(2, "0")}:${String(t.minute).padStart(2, "0")}:00+05:30`
  );
}
function formatAppointmentDateShort(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  return `${d.day} ${MONTHS_SHORT[d.month - 1]}`;
}
function formatAppointmentDateLong(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  const weekday = new Date(Date.UTC(d.year, d.month - 1, d.day)).getUTCDay();
  return `${WEEKDAYS_SHORT[weekday]}, ${d.day} ${MONTHS_SHORT[d.month - 1]} ${d.year}`;
}
function formatAppointmentTime(appointmentTime) {
  const t = parseTimeParts(appointmentTime);
  if (!t) return null;
  const hour12 = t.hour24 % 12 || 12;
  const ampm = t.hour24 < 12 ? "AM" : "PM";
  return `${hour12}:${String(t.minute).padStart(2, "0")} ${ampm}`;
}
function istYmd(ms) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date(ms));
}
function formatRelativeTime(appointmentDate, appointmentTime, nowMs = Date.now()) {
  const appt = appointmentMsIst(appointmentDate, appointmentTime);
  if (!Number.isFinite(appt)) return "\u2013";
  const today = istYmd(nowMs);
  const apptDay = istYmd(appt);
  const todayParts = parseDateParts(today);
  const apptParts = parseDateParts(apptDay);
  const dayDiff = Math.round(
    (Date.UTC(apptParts.year, apptParts.month - 1, apptParts.day) - Date.UTC(todayParts.year, todayParts.month - 1, todayParts.day)) / 864e5
  );
  if (dayDiff === 0) {
    const deltaMs = appt - nowMs;
    if (deltaMs <= 0) return "today";
    const totalMinutes = Math.round(deltaMs / 6e4);
    if (totalMinutes < 60) {
      return `today \xB7 in ${totalMinutes} minute${totalMinutes === 1 ? "" : "s"}`;
    }
    const hours = Math.round(totalMinutes / 60);
    return `today \xB7 in ${hours} hour${hours === 1 ? "" : "s"}`;
  }
  if (dayDiff === 1) return "tomorrow";
  if (dayDiff > 1) return `in ${dayDiff} days`;
  if (dayDiff === -1) return "yesterday";
  return `${Math.abs(dayDiff)} days ago`;
}
function emailButtonHtml(href, label, variant = "primary") {
  const bg = variant === "primary" ? BRAND_PRIMARY : "#e5e7eb";
  const color = variant === "primary" ? "#ffffff" : "#111827";
  return `<a href="${escapeHtml(href)}" style="background:${bg};color:${color};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${escapeHtml(label)}</a>`;
}
function emailFooterText() {
  return `This is an automated message from ABI Parent Care. For help, call ${SUPPORT_PHONE}.`;
}
function wrapEmailHtml(args) {
  const ref = displayValue(args.ref, "");
  const refHtml = ref ? `<td align="right" style="font-size:13px;color:${BRAND_MUTED};white-space:nowrap;">Ref <strong style="color:${BRAND_TEXT};">${escapeHtml(ref)}</strong></td>` : `<td></td>`;
  const preheader = args.preheader ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${escapeHtml(args.preheader)}</div>` : "";
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${preheader}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${BRAND_PRIMARY},${BRAND_ACCENT});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${LOGO_URL}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${ref ? `<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${escapeHtml(ref)}</strong></td>` : ""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${BRAND_TEXT};">
          ${args.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${BRAND_MUTED};">
          ${escapeHtml(emailFooterText())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`;
}
function wrapEmailText(args) {
  const lines = [
    "ABI Parent Care",
    args.ref ? `Ref ${displayValue(args.ref)}` : null,
    "",
    args.bodyText.trim(),
    "",
    emailFooterText()
  ].filter((line2) => line2 !== null);
  return lines.join("\n");
}
async function sendEmail(args) {
  const resendApiKey = Deno.env.get("RESEND_API_KEY");
  if (!resendApiKey) {
    throw new Error("Missing RESEND_API_KEY secret");
  }
  const testMode = Deno.env.get("EMAIL_TEST_MODE") === "true";
  const testTo = Deno.env.get("TEST_EMAIL_TO")?.trim() || "";
  const realRecipientLabel = (args.toName?.trim() || args.to).trim();
  const finalTo = testMode && testTo ? testTo : args.to;
  const finalSubject = testMode && testTo ? `[To: ${realRecipientLabel}] ${args.subject}` : args.subject;
  const payload = {
    from: "ABI Parent Care <onboarding@resend.dev>",
    to: [finalTo],
    subject: finalSubject,
    html: args.html
  };
  if (args.text && args.text.trim()) {
    payload.text = args.text;
  }
  const emailResponse = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${resendApiKey}`
    },
    body: JSON.stringify(payload)
  });
  const emailResult = await emailResponse.json();
  if (!emailResponse.ok) {
    console.error("Resend error:", emailResult);
    return {
      ok: false,
      status: emailResponse.status,
      to: finalTo,
      subject: finalSubject,
      testMode,
      error: emailResult
    };
  }
  return {
    ok: true,
    status: emailResponse.status,
    id: typeof emailResult?.id === "string" ? emailResult.id : void 0,
    to: finalTo,
    subject: finalSubject,
    testMode
  };
}

// ../../../tmp/fn-src/supabase/functions/_shared/templates.ts
function preferenceLabel(value) {
  if (value === "female") return "Female helper";
  if (value === "male") return "Male helper";
  if (value === "no_preference" || value === "none" || !value) {
    return "No preference";
  }
  return displayValue(value, "No preference");
}
function timeLabel(appointmentTime) {
  return formatAppointmentTime(appointmentTime) ?? displayValue(appointmentTime);
}
function sectionHeading(label) {
  return `<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${escapeHtml(label)}</p>`;
}
function line(label, value) {
  return `<div style="margin:0 0 6px;"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</div>`;
}
function textLine(label, value) {
  return `${label}: ${value}`;
}
function joinAddress(parts) {
  return parts.map((p) => String(p ?? "").trim()).filter(Boolean).join(", ");
}
function build(id, subject, ref, bodyHtml, bodyText) {
  return {
    id,
    subject,
    html: wrapEmailHtml({ bodyHtml, ref, preheader: subject }),
    text: wrapEmailText({ bodyText, ref })
  };
}
function templateG2(v) {
  const dateShort = formatAppointmentDateShort(v.appointment_date);
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const subject = `Update on ${v.parent_name}'s appointment \u2013 ${dateShort} \xB7 Ref ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Dear ${escapeHtml(v.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${escapeHtml(v.parent_name)}'s appointment on ${escapeHtml(dateLong)} at ${escapeHtml(time)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${escapeHtml(SUPPORT_PHONE)} and quote Ref ${escapeHtml(v.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `;
  const bodyText = [
    `Dear ${v.booking_person_name},`,
    "",
    `A quick update: our care team is personally arranging a suitable helper for ${v.parent_name}'s appointment on ${dateLong} at ${time}.`,
    "",
    "You don't need to do anything. We'll email you the helper's details shortly.",
    "",
    `If you'd like to speak to us, call ${SUPPORT_PHONE} and quote Ref ${v.ref}.`,
    "",
    "Warm regards,",
    "The ABI Parent Care team"
  ].join("\n");
  return build("G2", subject, v.ref, bodyHtml, bodyText);
}
function templateM1(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject = `URGENT \u2013 Helper needed in ${v.time_remaining} \xB7 ${v.parent_name} (${v.parent_age}) \xB7 ${time} \xB7 ${displayValue(v.area)} \xB7 ${v.ref}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${escapeHtml(relative)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${sectionHeading("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${sectionHeading("Visit details")}
    ${line("Patient", `${v.parent_name}, ${v.parent_age}`)}
    ${line("When", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013")}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Preference", preferenceLabel(v.helper_preference))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`)}
    <p style="margin:22px 0;">${emailButtonHtml(v.assign_url, "Assign a helper", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    `A booking has come in for ${relative}. There isn't time to send offers automatically, so please assign a helper now.`,
    "",
    "WHAT TO DO NOW",
    "Open the request, pick an available helper and send them an offer.",
    "",
    "VISIT DETAILS",
    textLine("Patient", `${v.parent_name}, ${v.parent_age}`),
    textLine("When", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013"),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine("Preference", preferenceLabel(v.helper_preference)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`
    ),
    "",
    `Assign a helper: ${v.assign_url}`
  ].join("\n");
  return build("M1", subject, v.ref, bodyHtml, bodyText);
}

// ../../../tmp/fn-src/supabase/functions/_shared/senior.ts
var ADMIN_PAGE_BASE = "https://nandhini-17223.github.io/elderly-care/admin";
var MANAGER_FIRST_NAME = "Manager";
function seniorAssignUrl(requestId) {
  const next = `needs-action.html?request=${encodeURIComponent(requestId)}`;
  return `${ADMIN_PAGE_BASE}/login.html?next=${encodeURIComponent(next)}`;
}

// ../../../tmp/fn-src/supabase/functions/_shared/assignment.ts
function formatRemaining(ms) {
  if (ms <= 0) return "less than 1 minute";
  const totalMinutes = Math.round(ms / 6e4);
  if (totalMinutes < 60) {
    return `${totalMinutes} minute${totalMinutes === 1 ? "" : "s"}`;
  }
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (minutes === 0) return `${hours} hour${hours === 1 ? "" : "s"}`;
  return `${hours}h ${minutes}m`;
}

// ../../../tmp/fn-src/supabase/functions/_shared/secrets.ts
async function resolveSecret(supabase, name) {
  const fromEnv = Deno.env.get(name)?.trim() || "";
  if (fromEnv) return fromEnv;
  const { data, error } = await supabase.rpc("get_app_secret", {
    p_name: name
  });
  if (error) {
    console.error(`get_app_secret(${name}) failed`, error);
    return null;
  }
  const value = typeof data === "string" ? data.trim() : "";
  return value || null;
}

// ../../../tmp/fn-src/supabase/functions/senior-notify/index.ts
function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json",
      Connection: "keep-alive"
    }
  });
}
function familyPhone(request) {
  return `${request.phone_country_code ?? ""} ${request.phone ?? ""}`.trim();
}
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }
  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceRoleKey) {
      throw new Error("Missing Supabase environment configuration");
    }
    const payload = await req.json().catch(() => ({}));
    const requestId = String(payload.request_id ?? "").trim();
    if (!requestId) {
      return jsonResponse({ error: "request_id required" }, 400);
    }
    const supabase = createClient(supabaseUrl, serviceRoleKey);
    const { data, error } = await supabase.from("consultation_requests").select(
      "id, ref_number, status, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason, booking_person_name, relationship, phone_country_code, phone, email, senior_notified_at, guardian_arranging_sent_at, address_line1, street, landmark, city"
    ).eq("id", requestId).maybeSingle();
    if (error) throw error;
    if (!data) return jsonResponse({ error: "Request not found" }, 404);
    const request = data;
    if (request.status !== "needs_senior") {
      return jsonResponse({
        ok: true,
        skipped: true,
        reason: "not_needs_senior",
        status: request.status
      });
    }
    const results = {
      request_id: request.id,
      guardian: null,
      senior_urgent: null
    };
    if (!request.guardian_arranging_sent_at) {
      const guardianEmail = templateG2({
        ref: String(request.ref_number ?? "\u2013"),
        booking_person_name: request.booking_person_name,
        parent_name: request.parent_name,
        appointment_date: request.appointment_date,
        appointment_time: request.appointment_time
      });
      const guardianResult = await sendEmail({
        to: request.email,
        toName: request.booking_person_name,
        subject: guardianEmail.subject,
        html: guardianEmail.html,
        text: guardianEmail.text
      });
      if (guardianResult.ok) {
        await supabase.from("consultation_requests").update({ guardian_arranging_sent_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", request.id).is("guardian_arranging_sent_at", null);
      }
      results.guardian = {
        ok: guardianResult.ok,
        id: guardianResult.id,
        subject: guardianResult.subject
      };
    } else {
      results.guardian = { skipped: true, reason: "already_sent" };
    }
    if (request.needs_senior_reason === "short_notice" && !request.senior_notified_at) {
      const seniorEmail = await resolveSecret(supabase, "SENIOR_EMAIL");
      if (!seniorEmail) {
        results.senior_urgent = { ok: false, error: "SENIOR_EMAIL missing" };
      } else {
        const apptMs = appointmentMsIst(
          request.appointment_date,
          request.appointment_time
        );
        const remaining = Number.isFinite(apptMs) ? formatRemaining(apptMs - Date.now()) : "soon";
        const seniorEmailContent = templateM1({
          ref: String(request.ref_number ?? "\u2013"),
          manager_first_name: MANAGER_FIRST_NAME,
          parent_name: request.parent_name,
          parent_age: request.parent_age,
          appointment_date: request.appointment_date,
          appointment_time: request.appointment_time,
          area: request.area,
          city: request.city,
          pincode: request.pincode,
          doctor_hospital: request.doctor_hospital,
          helper_preference: request.helper_preference,
          booking_person_name: request.booking_person_name,
          relationship: String(request.relationship ?? ""),
          guardian_phone: familyPhone(request),
          time_remaining: remaining,
          assign_url: seniorAssignUrl(request.id)
        });
        const seniorResult = await sendEmail({
          to: seniorEmail,
          toName: "Senior coordinator",
          subject: seniorEmailContent.subject,
          html: seniorEmailContent.html,
          text: seniorEmailContent.text
        });
        if (seniorResult.ok) {
          await supabase.from("consultation_requests").update({ senior_notified_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", request.id).is("senior_notified_at", null);
        }
        results.senior_urgent = {
          ok: seniorResult.ok,
          id: seniorResult.id,
          subject: seniorResult.subject
        };
      }
    } else {
      results.senior_urgent = {
        skipped: true,
        reason: request.needs_senior_reason === "short_notice" ? "already_notified" : "not_short_notice"
      };
    }
    return jsonResponse({ ok: true, ...results });
  } catch (error) {
    console.error(error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return jsonResponse({ error: message }, 500);
  }
});
