const ie=globalThis.__sb.createClient,w="+91 73399 11220",oe="https://nandhini-17223.github.io/elderly-care/helper/",se="https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg",F="#1d6fd8",pe="#4a9cf7",Y="#1f2937",K="#6b7280",M=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],le=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function i(e){return e.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;")}function o(e,n="\u2013"){if(e==null)return n;const t=String(e).trim();return!t||t.toLowerCase()==="null"||t.toLowerCase()==="undefined"?n:t}function j(e){return o(e,"None given")}function P(e){if(!e)return null;const n=/^(\d{4})-(\d{2})-(\d{2})$/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]),a=Number(n[3]);return!r||r<1||r>12||!a||a<1||a>31?null:{year:t,month:r,day:a}}function z(e){if(!e)return null;const n=/^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]);return!Number.isInteger(t)||!Number.isInteger(r)||t<0||t>23||r<0||r>59?null:{hour24:t,minute:r}}function me(e,n){const t=P(e),r=z(n)??{hour24:0,minute:0};return t?Date.parse(`${String(t.year).padStart(4,"0")}-${String(t.month).padStart(2,"0")}-${String(t.day).padStart(2,"0")}T${String(r.hour24).padStart(2,"0")}:${String(r.minute).padStart(2,"0")}:00+05:30`):NaN}function O(e){const n=P(e);return n?`${n.day} ${M[n.month-1]} ${n.year}`:null}function H(e){const n=P(e);return n?`${n.day} ${M[n.month-1]}`:o(e)}function b(e){const n=P(e);if(!n)return o(e);const t=new Date(Date.UTC(n.year,n.month-1,n.day)).getUTCDay();return`${le[t]}, ${n.day} ${M[n.month-1]} ${n.year}`}function I(e){const n=z(e);if(!n)return null;const t=n.hour24%12||12,r=n.hour24<12?"AM":"PM";return`${t}:${String(n.minute).padStart(2,"0")} ${r}`}function Me(e,n){const t=O(e),r=I(n);return!t||!r?null:`${t}, ${r}`}function J(e){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(e))}function x(e,n,t=Date.now()){const r=me(e,n);if(!Number.isFinite(r))return"\u2013";const a=J(t),s=J(r),p=P(a),l=P(s),c=Math.round((Date.UTC(l.year,l.month-1,l.day)-Date.UTC(p.year,p.month-1,p.day))/864e5);if(c===0){const _=r-t;if(_<=0)return"today";const g=Math.round(_/6e4);if(g<60)return`today \xB7 in ${g} minute${g===1?"":"s"}`;const k=Math.round(g/60);return`today \xB7 in ${k} hour${k===1?"":"s"}`}return c===1?"tomorrow":c>1?`in ${c} days`:c===-1?"yesterday":`${Math.abs(c)} days ago`}function de(e){if(!e)return"\u2013";const n=Date.parse(e);if(!Number.isFinite(n))return o(e);const t=new Date(n),r=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Kolkata",weekday:"short",day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit",hour12:!0}).formatToParts(t),a=E=>r.find(R=>R.type===E)?.value??"",s=a("day"),p=a("month"),l=a("year"),c=a("weekday"),_=a("hour"),g=a("minute"),k=a("dayPeriod").toUpperCase();return`${c}, ${s} ${p} ${l} \xB7 ${_}:${g} ${k}`}function h(e,n,t="primary"){const r=t==="primary"?F:"#e5e7eb",a=t==="primary"?"#ffffff":"#111827";return`<a href="${i(e)}" style="background:${r};color:${a};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${i(n)}</a>`}function Z(){return`This is an automated message from ABI Parent Care. For help, call ${w}.`}function ce(e){const n=o(e.ref,""),t=n?`<td align="right" style="font-size:13px;color:${K};white-space:nowrap;">Ref <strong style="color:${Y};">${i(n)}</strong></td>`:"<td></td>";return`<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${e.preheader?`<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${i(e.preheader)}</div>`:""}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${F},${pe});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${se}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${n?`<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${i(n)}</strong></td>`:""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${Y};">
          ${e.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${K};">
          ${i(Z())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`}function _e(e){return["ABI Parent Care",e.ref?`Ref ${o(e.ref)}`:null,"",e.bodyText.trim(),"",Z()].filter(t=>t!==null).join(`
`)}async function W(e){const n=Deno.env.get("RESEND_API_KEY");if(!n)throw new Error("Missing RESEND_API_KEY secret");const t=Deno.env.get("EMAIL_TEST_MODE")==="true",r=Deno.env.get("TEST_EMAIL_TO")?.trim()||"",a=(e.toName?.trim()||e.to).trim(),s=t&&r?r:e.to,p=t&&r?`[To: ${a}] ${e.subject}`:e.subject,l={from:"ABI Parent Care <onboarding@resend.dev>",to:[s],subject:p,html:e.html};e.text&&e.text.trim()&&(l.text=e.text);const c=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify(l)}),_=await c.json();return c.ok?{ok:!0,status:c.status,id:typeof _?.id=="string"?_.id:void 0,to:s,subject:p,testMode:t}:(console.error("Resend error:",_),{ok:!1,status:c.status,to:s,subject:p,testMode:t,error:_})}function L(e){const n=String(e??"").trim();return n?n.split(/\s+/)[0]??n:"there"}function C(e){return e==="female"?"Female helper":e==="male"?"Male helper":e==="no_preference"||e==="none"||!e?"No preference":o(e,"No preference")}function V(e){switch(e){case"no_acceptance":return"No helper accepted within 2 hours";case"no_suitable_helpers":return"No suitable helper nearby";case"all_declined":return"All offered helpers declined";case"short_notice":return"Booked at short notice";case"helper_dropped":return"Helper dropped out";case"helper_not_confirmed":return"Helper didn't confirm";case"helper_unavailable":return"Helper no longer available";default:return e?e.replaceAll("_"," "):"Needs senior attention"}}function f(e){return I(e)??o(e)}function $(e){return`<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${i(e)}</p>`}function d(e,n){return`<div style="margin:0 0 6px;"><strong>${i(e)}:</strong> ${i(n)}</div>`}function m(e,n){return`${e}: ${n}`}function Q(e){return e?`<p style="margin:16px 0;"><img src="${i(e)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`:""}function A(e){return e.map(n=>String(n??"").trim()).filter(Boolean).join(", ")}function u(e,n,t,r,a){return{id:e,subject:n,html:ce({bodyHtml:r,ref:t,preheader:n}),text:_e({bodyText:a,ref:t})}}function je(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=f(e.appointment_time),a=A([e.area,e.city,e.pincode])||"\u2013",s=C(e.helper_preference),p=`We've received your request \u2013 ${e.parent_name}, ${n} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Thank you for choosing ABI Parent Care. We've received your request for ${i(e.parent_name)}'s doctor appointment.</p>
    ${$("Appointment")}
    ${d("Date & time",`${t} \xB7 ${r}`)}
    ${d("Doctor/Hospital",o(e.doctor_hospital))}
    ${d("Pickup from",a)}
    ${d("Helper preference",s)}
    ${$("What happens next")}
    <p style="margin:0 0 12px;">We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.</p>
    <p style="margin:0 0 12px;">Need to change anything? Call us on ${i(w)} and quote Ref ${i(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`Thank you for choosing ABI Parent Care. We've received your request for ${e.parent_name}'s doctor appointment.`,"","APPOINTMENT",m("Date & time",`${t} \xB7 ${r}`),m("Doctor/Hospital",o(e.doctor_hospital)),m("Pickup from",a),m("Helper preference",s),"","WHAT HAPPENS NEXT","We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.","",`Need to change anything? Call us on ${w} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return u("G1",p,e.ref,l,c)}function Oe(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=f(e.appointment_time),a=`Update on ${e.parent_name}'s appointment \u2013 ${n} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${i(e.parent_name)}'s appointment on ${i(t)} at ${i(r)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${i(w)} and quote Ref ${i(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,p=[`Dear ${e.booking_person_name},`,"",`A quick update: our care team is personally arranging a suitable helper for ${e.parent_name}'s appointment on ${t} at ${r}.`,"","You don't need to do anything. We'll email you the helper's details shortly.","",`If you'd like to speak to us, call ${w} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return u("G2",a,e.ref,s,p)}function ue(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=f(e.appointment_time),a=x(e.appointment_date,e.appointment_time),s=A([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",p=`Helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name}, ${n} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news \u2013 ${i(e.helper_full_name)} will accompany ${i(e.parent_name)} to the appointment.</p>
    ${Q(e.helper_photo_url)}
    ${$("Your helper")}
    ${d("Name",e.helper_full_name)}
    ${d("Phone",o(e.helper_phone))}
    ${d("Verified","ID and background checked by ABI Parent Care")}
    ${$("Appointment")}
    ${d("Date & time",`${t} \xB7 ${r} (${a})`)}
    ${d("Doctor/Hospital",o(e.doctor_hospital))}
    ${d("Pickup from",s)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${i(e.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`Good news \u2013 ${e.helper_full_name} will accompany ${e.parent_name} to the appointment.`,"","YOUR HELPER",m("Name",e.helper_full_name),m("Phone",o(e.helper_phone)),m("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT",m("Date & time",`${t} \xB7 ${r} (${a})`),m("Doctor/Hospital",o(e.doctor_hospital)),m("Pickup from",s),"",`For safety, please share this with ${e.parent_name} so they know who to expect.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return u("G3",p,e.ref,l,c)}function ge(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=f(e.appointment_time),a=`Change of helper for ${e.parent_name} \u2013 ${n} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${i(e.old_helper_first_name)} is unable to attend ${i(e.parent_name)}'s appointment on ${i(t)} at ${i(r)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${i(w)} and quote Ref ${i(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,p=[`Dear ${e.booking_person_name},`,"",`We're sorry \u2013 ${e.old_helper_first_name} is unable to attend ${e.parent_name}'s appointment on ${t} at ${r}.`,"","Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.","",`The appointment itself is unchanged. If you have concerns, call ${w} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return u("G4",a,e.ref,s,p)}function he(e){const n=b(e.appointment_date),t=f(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=`New helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} will now accompany ${i(e.parent_name)} to the appointment, in place of ${i(e.old_helper_first_name)}.</p>
    ${Q(e.helper_photo_url)}
    ${$("Your new helper")}
    ${d("Name",e.helper_full_name)}
    ${d("Phone",o(e.helper_phone))}
    ${d("Verified","ID and background checked by ABI Parent Care")}
    ${$("Appointment (unchanged)")}
    ${d("Date & time",`${n} \xB7 ${t} (${r})`)}
    ${d("Doctor/Hospital",o(e.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,p=[`Dear ${e.booking_person_name},`,"",`${e.helper_full_name} will now accompany ${e.parent_name} to the appointment, in place of ${e.old_helper_first_name}.`,"","YOUR NEW HELPER",m("Name",e.helper_full_name),m("Phone",o(e.helper_phone)),m("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT (unchanged)",m("Date & time",`${n} \xB7 ${t} (${r})`),m("Doctor/Hospital",o(e.doctor_hospital)),"","Thank you for your patience.","","Warm regards,","The ABI Parent Care team"].join(`
`);return u("G5",a,e.ref,s,p)}function We(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=f(e.appointment_time),a=x(e.appointment_date,e.appointment_time),s=e.distance_km==null||Number.isNaN(Number(e.distance_km))?"\u2013":String(Math.round(Number(e.distance_km)*10)/10),p=o(e.area),l=`New visit near you \u2013 ${n}, ${r} \xB7 ${p} (${s} km)`,c=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${d("When",`${t} \xB7 ${r} (${a})`)}
    ${d("Pickup area",`${p}, ${o(e.pincode)} \xB7 about ${s} km from you`)}
    ${d("Hospital",o(e.doctor_hospital))}
    ${d("Patient",`Age ${e.parent_age}`)}
    <p style="margin:22px 0;">
      ${h(e.accept_url,"Accept","primary")}
      ${h(e.decline_url,"Decline","secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,_=[`Hi ${e.helper_first_name},`,"","A new hospital visit is available near you. The first helper to accept gets it.","",m("When",`${t} \xB7 ${r} (${a})`),m("Pickup area",`${p}, ${o(e.pincode)} \xB7 about ${s} km from you`),m("Hospital",o(e.doctor_hospital)),m("Patient",`Age ${e.parent_age}`),"",`Accept: ${e.accept_url}`,`Decline: ${e.decline_url}`,"","The patient's name, full address and family contact are shared after you accept.","",`Ref ${e.ref}`].join(`
`);return u("H1",l,e.ref,c,_)}function fe(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=f(e.appointment_time),a=x(e.appointment_date,e.appointment_time),s=A([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",p=`Confirmed: ${e.parent_name}, ${n} ${r} \xB7 Ref ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${$("Patient")}
    ${d("Name",`${e.parent_name}, ${e.parent_age}`)}
    ${d("Pickup",s)}
    ${d("Landmark",o(e.landmark))}
    <p style="margin:10px 0 16px;">${h(e.maps_url,"Open in Google Maps","secondary")}</p>
    ${$("Appointment")}
    ${d("When",`${t} \xB7 ${r} (${a})`)}
    ${d("Hospital",o(e.doctor_hospital))}
    ${$("Family contact")}
    <p style="margin:0 0 12px;">${i(e.booking_person_name)} (${i(o(e.relationship))}) \xB7 ${i(o(e.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${h(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,c=[`Hi ${e.helper_first_name},`,"","This visit is yours. Thank you!","","PATIENT",m("Name",`${e.parent_name}, ${e.parent_age}`),m("Pickup",s),m("Landmark",o(e.landmark)),`Open in Google Maps: ${e.maps_url}`,"","APPOINTMENT",m("When",`${t} \xB7 ${r} (${a})`),m("Hospital",o(e.doctor_hospital)),"","FAMILY CONTACT",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`,"","We'll remind you 12 hours and 6 hours before.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return u("H2",p,e.ref,l,c)}function $e(e){const n=b(e.appointment_date),t=f(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=`Reminder: visit ${r} ${t} \u2013 ${e.parent_name}, ${o(e.area)}`,s=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${i(e.parent_name)} ${i(r)}.</p>
    ${d("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${i(o(e.full_address))} \xB7 <a href="${i(e.maps_url)}">Open in Google Maps</a></div>
    ${d("Hospital",o(e.doctor_hospital))}
    ${d("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${h(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,p=[`Hi ${e.helper_first_name},`,"",`A reminder that you're accompanying ${e.parent_name} ${r}.`,"",m("When",`${n} \xB7 ${t}`),m("Pickup",`${o(e.full_address)} \xB7 ${e.maps_url}`),m("Hospital",o(e.doctor_hospital)),m("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"","Plan to reach the pickup address 15 minutes early.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return u("H3",a,e.ref,s,p)}function ye(e){const n=b(e.appointment_date),t=f(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=`Please confirm: ${e.parent_name} at ${t} \u2013 ${r}`,s=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${i(e.parent_name)} is ${i(r)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${h(e.confirm_url,"I'll be there","primary")}
      ${h(e.cant_make_it_url,"Can't make it","secondary")}
    </p>
    ${d("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${i(o(e.full_address))} \xB7 <a href="${i(e.maps_url)}">Open in Google Maps</a></div>
    ${d("Hospital",o(e.doctor_hospital))}
    ${d("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,p=[`Hi ${e.helper_first_name},`,"",`Your visit with ${e.parent_name} is ${r}. Please confirm you'll be there.`,"",`I'll be there: ${e.confirm_url}`,`Can't make it: ${e.cant_make_it_url}`,"",m("When",`${n} \xB7 ${t}`),m("Pickup",`${o(e.full_address)} \xB7 ${e.maps_url}`),m("Hospital",o(e.doctor_hospital)),m("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"","If we don't hear from you, our care team will call you.","",`Ref ${e.ref}`].join(`
`);return u("H4",a,e.ref,s,p)}function Le(e){const n=e.helper_app_link||oe,t="Welcome to ABI Parent Care \u2013 your helper app login",r=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${d("App link",n)}
    ${d("Login email",e.helper_email)}
    ${d("Password","the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${h(n,"Open helper app","primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${i(w)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `,a=[`Hi ${e.helper_first_name},`,"","Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.","",m("App link",n),m("Login email",e.helper_email),m("Password","the temporary password given to you by your manager"),"","You'll be asked to set your own password the first time you log in.","",'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',"",`Questions? Call ${w}.`,"","The ABI Parent Care team"].join(`
`);return u("H5",t,null,r,a)}function Ve(e){const n=b(e.appointment_date),t=f(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=`URGENT \u2013 Helper needed in ${e.time_remaining} \xB7 ${e.parent_name} (${e.parent_age}) \xB7 ${t} \xB7 ${o(e.area)} \xB7 ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${i(r)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${$("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${$("Visit details")}
    ${d("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${d("When",`${n} \xB7 ${t} (${r})`)}
    ${d("Pickup",A([e.area,e.city,e.pincode])||"\u2013")}
    ${d("Hospital",o(e.doctor_hospital))}
    ${d("Preference",C(e.helper_preference))}
    ${d("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${h(e.assign_url,"Assign a helper","primary")}</p>
  `,p=[`Hi ${e.manager_first_name},`,"",`A booking has come in for ${r}. There isn't time to send offers automatically, so please assign a helper now.`,"","WHAT TO DO NOW","Open the request, pick an available helper and send them an offer.","","VISIT DETAILS",m("Patient",`${e.parent_name}, ${e.parent_age}`),m("When",`${n} \xB7 ${t} (${r})`),m("Pickup",A([e.area,e.city,e.pincode])||"\u2013"),m("Hospital",o(e.doctor_hospital)),m("Preference",C(e.helper_preference)),m("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"",`Assign a helper: ${e.assign_url}`].join(`
`);return u("M1",a,e.ref,s,p)}function Be(e){const t=`${e.items.length} request(s) need a helper \u2013 ${e.digest_time}`,r=e.items.map((l,c)=>{const _=H(l.appointment_date),g=f(l.appointment_time),k=x(l.appointment_date,l.appointment_time);return`
      <div style="margin:0 0 16px;padding:12px 0;border-bottom:1px solid #e5e7eb;">
        <p style="margin:0 0 6px;"><strong>${c+1}. ${i(l.ref)}</strong> \xB7 ${i(l.parent_name)} (${l.parent_age}) \xB7 ${i(_)} ${i(g)} (${i(k)})</p>
        <p style="margin:0 0 6px;">${i(o(l.area))} ${i(o(l.pincode))} \xB7 Preference: ${i(C(l.helper_preference))}</p>
        <p style="margin:0 0 10px;">Why: ${i(V(l.reason))}</p>
        <p style="margin:0;">${h(l.assign_url,"Assign","primary")}</p>
      </div>
    `}).join(""),a=e.items.map((l,c)=>{const _=H(l.appointment_date),g=f(l.appointment_time),k=x(l.appointment_date,l.appointment_time);return[`${c+1}. ${l.ref} \xB7 ${l.parent_name} (${l.parent_age}) \xB7 ${_} ${g} (${k})`,`   ${o(l.area)} ${o(l.pincode)} \xB7 Preference: ${C(l.helper_preference)}`,`   Why: ${V(l.reason)}`,`   Assign: ${l.assign_url}`].join(`
`)}).join(`

`),s=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">These requests still need a helper. The soonest appointment is first.</p>
    ${r}
    <p style="margin:22px 0;">${h(e.open_all_url,"Open all in the portal","primary")}</p>
  `,p=[`Hi ${e.manager_first_name},`,"","These requests still need a helper. The soonest appointment is first.","",a,"",`Open all in the portal: ${e.open_all_url}`].join(`
`);return u("M2",t,null,s,p)}function Ue(e){const n=H(e.appointment_date),t=b(e.appointment_date),r=f(e.appointment_time),a=x(e.appointment_date,e.appointment_time),s=j(e.decline_reason),p=`${e.helper_full_name} declined \u2013 please assign another \xB7 ${e.parent_name}, ${n} ${r} \xB7 ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} declined the visit you offered.</p>
    ${d("Reason given",s)}
    <p style="margin:12px 0;">Appointment: ${i(t)} \xB7 ${i(r)} (${i(a)}) \xB7 ${i(o(e.area))}</p>
    <p style="margin:22px 0;">${h(e.assign_url,"Choose another helper","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} declined the visit you offered.`,m("Reason given",s),"",`Appointment: ${t} \xB7 ${r} (${a}) \xB7 ${o(e.area)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return u("M3",p,e.ref,l,c)}function Ge(e){const n=b(e.appointment_date),t=f(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=`No response from ${e.helper_full_name} \u2013 please assign another \xB7 ${e.parent_name} \xB7 ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} didn't respond within ${i(e.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${i(n)} \xB7 ${i(t)} (${i(r)}) \xB7 ${i(o(e.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${i(o(e.helper_phone))}</p>
    <p style="margin:22px 0;">${h(e.assign_url,"Choose another helper","primary")}</p>
  `,p=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} didn't respond within ${e.expiry_window}, so the offer has been withdrawn.`,"",`Appointment: ${n} \xB7 ${t} (${r}) \xB7 ${o(e.area)}`,`Helper phone (if you'd like to call): ${o(e.helper_phone)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return u("M4",a,e.ref,s,p)}function be(e){const n=b(e.appointment_date),t=f(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=j(e.dropout_reason),s=`URGENT \u2013 ${e.helper_full_name} can't attend \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} has said they can't attend this visit.</p>
    ${d("Reason given",a)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${$("Visit details")}
    ${d("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${d("When",`${n} \xB7 ${t} (${r})`)}
    ${d("Pickup",A([e.area,e.city,e.pincode])||"\u2013")}
    ${d("Hospital",o(e.doctor_hospital))}
    ${d("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${h(e.assign_url,"Assign a replacement","primary")}</p>
  `,l=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has said they can't attend this visit.`,m("Reason given",a),"","The family has been told we're arranging a replacement. Please assign a new helper now.","","VISIT DETAILS",m("Patient",`${e.parent_name}, ${e.parent_age}`),m("When",`${n} \xB7 ${t} (${r})`),m("Pickup",A([e.area,e.city,e.pincode])||"\u2013"),m("Hospital",o(e.doctor_hospital)),m("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"",`Assign a replacement: ${e.assign_url}`].join(`
`);return u("M5",s,e.ref,p,l)}function xe(e){const n=b(e.appointment_date),t=f(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=de(e.assigned_at),s=e.urgent?`URGENT \u2013 visit in 1 hour, ${e.helper_full_name} still not confirmed \xB7 ${e.parent_name} \xB7 ${e.ref}`:`Action needed \u2013 ${e.helper_full_name} hasn't confirmed \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,p=e.urgent?`The visit starts in about 1 hour and ${i(e.helper_full_name)} still hasn't confirmed. Please resolve this now.`:`${i(e.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,l=e.urgent?`The visit starts in about 1 hour and ${e.helper_full_name} still hasn't confirmed. Please resolve this now.`:`${e.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,c=e.urgent?`<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${i(e.helper_first_name)}: ${i(o(e.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".</li>
      </ol>`:`${$("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${i(e.helper_first_name)}: ${i(o(e.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone \u2013 nothing else happens, or</li>
            <li>Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`,_=e.urgent?[`1. Call ${e.helper_first_name}: ${o(e.helper_phone)}`,'2. Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".'].join(`
`):["WHAT TO DO NOW",`1. Call ${e.helper_first_name}: ${o(e.helper_phone)}`,"2. Then in the portal, choose:","   \u2022 Helper confirmed by phone \u2013 nothing else happens, or","   \u2022 Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper"].join(`
`),g=`
    ${$("Visit details")}
    ${d("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${d("When",`${n} \xB7 ${t} (${r})`)}
    ${d("Pickup",A([e.area,e.city,e.pincode])||"\u2013")}
    ${d("Hospital",o(e.doctor_hospital))}
    ${$("Helper status")}
    ${d("Assigned",a)}
    ${d("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`)}
    ${d("Confirmed","Not yet")}
  `,k=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${p}</p>
    ${c}
    ${g}
    <p style="margin:22px 0;">${h(e.open_url,"Open request","primary")}</p>
  `,E=[`Hi ${e.manager_first_name},`,"",l,"",_,"","VISIT DETAILS",m("Patient",`${e.parent_name}, ${e.parent_age}`),m("When",`${n} \xB7 ${t} (${r})`),m("Pickup",A([e.area,e.city,e.pincode])||"\u2013"),m("Hospital",o(e.doctor_hospital)),"","HELPER STATUS",m("Assigned",a),m("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`),m("Confirmed","Not yet"),"",`Open request: ${e.open_url}`].join(`
`);return u(e.urgent?"M7":"M6",s,e.ref,k,E)}function Fe(e){return xe({...e,urgent:!0})}function ke(e){const n=`Driving licence ${e.expiry_phrase} \u2013 ${e.helper_full_name}`,t=e.expired?`<p style="margin:0 0 12px;">If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).</p>`:'<p style="margin:0 0 12px;">If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.</p>',r=e.expired?`If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).`:"If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.",a=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)}'s driving licence ${i(e.expiry_phrase)} (${i(e.dl_expiry)}).</p>
    ${t}
    <p style="margin:22px 0;">${h(e.open_url,"Open helper profile","primary")}</p>
  `,s=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name}'s driving licence ${e.expiry_phrase} (${e.dl_expiry}).`,"",r,"",`Open helper profile: ${e.open_url}`].join(`
`);return u("M8",n,null,a,s)}function Ye(e){const n=`Profile change request \u2013 ${e.helper_full_name}`,t=j(e.request_note),r=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} has asked to update their profile:</p>
    <p style="margin:0 0 12px;padding:12px 14px;background:#f3f6fb;border-radius:8px;font-style:italic;">"${i(t)}"</p>
    <p style="margin:0 0 12px;">Please review and update their details in the portal if appropriate.</p>
    <p style="margin:22px 0;">${h(e.open_url,"Open helper profile","primary")}</p>
  `,a=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has asked to update their profile:`,"",`"${t}"`,"","Please review and update their details in the portal if appropriate.","",`Open helper profile: ${e.open_url}`].join(`
`);return u("M9",n,null,r,a)}const Ke={accept_confirm:{title:"Accept this visit?",message:"{{appointment_date_short}} \xB7 {{appointment_time}} \xB7 {{area}}. Tap Confirm to take this visit.",button:"Confirm"},accepted:{title:"This visit is yours!",message:"We've emailed you the full details. Thank you, {{helper_first_name}}."},already_taken:{title:"Already taken",message:"Another helper accepted this visit first. Thank you for responding quickly."},helper_engaged:{title:"You're already booked",message:"You have another visit around this time, so we can't assign this one to you."},declined:{title:"Thanks for letting us know",message:"We've offered this visit to another helper."},confirmed:{title:"See you there!",message:"Thanks for confirming. The family is counting on you."},cant_make_it_confirm:{title:"Can't make this visit?",message:"Tell us why (optional), then tap Confirm. We'll arrange a replacement.",button:"Confirm"},cant_make_it_done:{title:"Thanks for telling us",message:"Our care team will arrange a replacement."},link_inactive:{title:"This link is no longer active",message:"The visit may have been assigned, cancelled or already passed. Please contact your manager if you need help."}};function ze(e,n){return e.replace(/\{\{(\w+)\}\}/g,(t,r)=>o(n[r],""))}async function X(e,n){const t=Deno.env.get(n)?.trim()||"";if(t)return t;const{data:r,error:a}=await e.rpc("get_app_secret",{p_name:n});return a?(console.error(`get_app_secret(${n}) failed`,a),null):(typeof r=="string"?r.trim():"")||null}function Je(e,n){const t=new TextEncoder,r=t.encode(e),a=t.encode(n),s=Math.max(r.length,a.length);let p=r.length===a.length?0:1;for(let l=0;l<s;l++)p|=(r[l]??0)^(a[l]??0);return p===0}const B="https://nandhini-17223.github.io/elderly-care/admin",we="https://nandhini-17223.github.io/elderly-care/respond.html",Ze="https://nandhini-17223.github.io/elderly-care/admin/helper.html",q="Manager";function He(e){const n=`needs-action.html?request=${encodeURIComponent(e)}`;return`${B}/login.html?next=${encodeURIComponent(n)}`}function Qe(){return`${B}/login.html?next=${encodeURIComponent("needs-action.html")}`}function Ae(e){const n=`helper.html?id=${encodeURIComponent(e)}`;return`${B}/login.html?next=${encodeURIComponent(n)}`}function Xe(e,n="Assign helper"){return`<a href="${e}" style="background:#1d6fd8;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;">${i(n)}</a>`}function qe(e){const n=O(e.appointmentDate)??e.appointmentDate,t=I(e.appointmentTime)??e.appointmentTime,r=[e.area,e.pincode].filter(Boolean).join(" \xB7 ")||"Area on file";return`
    <p>
      ${e.refNumber?`<strong>Ref:</strong> ${i(e.refNumber)}<br />`:""}
      <strong>Patient:</strong> ${i(e.parentName)} (age ${i(String(e.parentAge))})<br />
      <strong>Date:</strong> ${i(n)}<br />
      <strong>Time:</strong> ${i(t)}<br />
      <strong>Area:</strong> ${i(r)}<br />
      ${e.doctorHospital?`<strong>Doctor / Hospital:</strong> ${i(e.doctorHospital)}<br />`:""}
      ${e.helperPreference?`<strong>Helper preference:</strong> ${i(C(e.helperPreference))}<br />`:""}
      ${e.reason?`<strong>Reason:</strong> ${i(V(e.reason))}<br />`:""}
      ${e.address?`<strong>Address:</strong> ${i(e.address)}<br />`:""}
    </p>
  `}function ve(e){return e==null||Number.isNaN(Number(e))?"Nearby":`~${Math.round(Number(e)*10)/10} km`}function en(e){return e?"sent":"not sent"}function v(e){return[e.address_line1,e.street,e.area,e.city,e.pincode].map(n=>n?String(n).trim():"").filter(Boolean).join(", ")}function ee(e){return`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e)}`}function ne(e){return`${e.phone_country_code} ${e.phone}`.trim()}function nn(e){return{dateLabel:O(e.appointment_date)??e.appointment_date,timeLabel:I(e.appointment_time)??e.appointment_time}}function U(e,n){return`${we}?token=${encodeURIComponent(e)}&action=${encodeURIComponent(n)}`}function te(e){return Array.from(e).map(n=>n.toString(16).padStart(2,"0")).join("")}async function Te(e){const n=new TextEncoder().encode(e),t=await crypto.subtle.digest("SHA-256",n);return te(new Uint8Array(t))}async function tn(){const e=crypto.getRandomValues(new Uint8Array(32)),n=te(e),t=await Te(n);return{token:n,hash:t}}function Pe(e,n,t){const r=v(e);return fe({ref:String(e.ref_number??"\u2013"),helper_first_name:L(n),parent_name:e.parent_name,parent_age:e.parent_age,address_line1:e.address_line1,street:e.street,area:e.area,city:e.city,pincode:e.pincode,landmark:e.landmark,maps_url:ee(r),appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,guardian_phone:ne(e),cant_make_it_url:U(t,"cant_make_it")})}function rn(e,n,t){return Pe(e,n,t).html}function Ce(e,n,t,r){const a=v(e),s={ref:String(e.ref_number??"\u2013"),helper_first_name:L(n),parent_name:e.parent_name,area:e.area,appointment_date:e.appointment_date,appointment_time:e.appointment_time,full_address:a,maps_url:ee(a),doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,guardian_phone:ne(e),cant_make_it_url:U(t,"cant_make_it")};return r==="6h"?ye({...s,confirm_url:U(t,"confirm_attendance")}):$e(s)}function an(e,n,t,r){return Ce(e,n,t,r).html}function Ee(e,n,t){return he({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,helper_full_name:n.full_name,helper_phone:n.phone,helper_photo_url:n.photo_url,old_helper_first_name:t||"the previous helper",appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital})}function on(e,n,t="the previous helper"){return Ee(e,n,t).html}function Re(e,n){return ue({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,helper_full_name:n.full_name,helper_phone:n.phone,helper_photo_url:n.photo_url,appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,address_line1:e.address_line1,street:e.street,area:e.area,city:e.city,pincode:e.pincode})}function sn(e,n){return Re(e,n).html}function re(e,n){return ge({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,old_helper_first_name:L(n),appointment_date:e.appointment_date,appointment_time:e.appointment_time})}function pn(e,n){return re(e,n).html}function ln(e){if(e<=0)return"less than 1 minute";const n=Math.round(e/6e4);if(n<60)return`${n} minute${n===1?"":"s"}`;const t=Math.floor(n/60),r=n%60;return r===0?`${t} hour${t===1?"":"s"}`:`${t}h ${r}m`}function N(e,n=200){return new Response(JSON.stringify(e),{status:n,headers:{"Content-Type":"application/json",Connection:"keep-alive"}})}function Se(){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date)}function ae(e,n){const t=new Date(`${e}T12:00:00+05:30`);return t.setDate(t.getDate()+n),new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(t)}async function Ie(e,n,t,r){const[{data:a},s]=await Promise.all([e.from("consultation_requests").select("id, ref_number, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason, booking_person_name, relationship, phone_country_code, phone, email, address_line1, street, landmark, city").eq("id",n).maybeSingle(),X(e,"SENIOR_EMAIL")]);if(a){if(s){const p=be({ref:String(a.ref_number??"\u2013"),manager_first_name:q,helper_full_name:t.full_name,parent_name:a.parent_name,parent_age:a.parent_age,appointment_date:a.appointment_date,appointment_time:a.appointment_time,area:a.area,city:a.city,pincode:a.pincode,doctor_hospital:a.doctor_hospital,booking_person_name:a.booking_person_name,relationship:String(a.relationship??""),guardian_phone:`${a.phone_country_code??""} ${a.phone??""}`.trim(),dropout_reason:r,assign_url:He(n)});await W({to:s,toName:"Senior coordinator",subject:p.subject,html:p.html,text:p.text})}if(a.email){const p=re({parent_name:a.parent_name,parent_age:a.parent_age,address_line1:a.address_line1,street:a.street,area:a.area,landmark:a.landmark,city:a.city,pincode:a.pincode,appointment_date:a.appointment_date,appointment_time:a.appointment_time,doctor_hospital:a.doctor_hospital,booking_person_name:a.booking_person_name,relationship:String(a.relationship??""),phone_country_code:String(a.phone_country_code??""),phone:String(a.phone??""),email:a.email,ref_number:a.ref_number},t.full_name);await W({to:a.email,toName:a.booking_person_name,subject:p.subject,html:p.html,text:p.text})}}}async function Ne(e,n){const{data:t,error:r}=await e.rpc("list_helper_upcoming_assigned_jobs",{p_helper_id:n.id});if(r)throw r;const a=[];for(const s of t??[]){const{data:p,error:l}=await e.rpc("release_assigned_helper",{p_request_id:s.request_id,p_reason:"helper_unavailable",p_expected_helper_id:n.id});if(l){console.error("release_assigned_helper",l);continue}p?.ok&&(a.push(s.request_id),await Ie(e,s.request_id,n,"Driving licence expired"))}return await e.rpc("withdraw_helper_open_offers",{p_helper_id:n.id}),a}async function G(e,n,t){const r=await X(e,"SENIOR_EMAIL");if(!r)return console.error("Missing SENIOR_EMAIL for DL warning"),!1;const a=n.dl_expiry??"unknown";let s,p=!1;t==="expired"?(s="has expired",p=!0):t==="7"?s="expires in 7 days":s="expires in 30 days";let l=0;if(p){const{data:g}=await e.rpc("list_helper_upcoming_assigned_jobs",{p_helper_id:n.id});l=Array.isArray(g)?g.length:0}const c=ke({manager_first_name:q,helper_full_name:n.full_name,expiry_phrase:s,dl_expiry:String(a),upcoming_count:l,open_url:Ae(n.id),expired:p});return(await W({to:r,toName:"Manager",subject:c.subject,html:c.html,text:c.text})).ok}Deno.serve(async e=>{if(e.method==="OPTIONS")return new Response(null,{status:204});if(e.method!=="POST")return N({ok:!1,error:"Method not allowed"},405);try{const n=Deno.env.get("SUPABASE_URL"),t=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"),r=Deno.env.get("SUPABASE_ANON_KEY");if(!n||!t)throw new Error("Missing Supabase environment configuration");const s=(e.headers.get("Authorization")||"").replace(/^Bearer\s+/i,"").trim(),p=await e.json().catch(()=>({}));if(!(s===t||p.reason==="cron"||r&&s===r))return N({ok:!1,error:"Unauthorized"},401);const c=ie(n,t,{auth:{persistSession:!1,autoRefreshToken:!1}}),_=Se(),g=ae(_,7),k=ae(_,30),{data:E,error:R}=await c.from("helpers").select("id, full_name, email, phone, dl_expiry, verification_status, dl_warn_30_sent_at, dl_warn_7_sent_at, dl_expired_notified_at").eq("can_drive",!0).not("dl_expiry","is",null);if(R)throw R;const T={warned_30:0,warned_7:0,expired:0,released_jobs:0};for(const y of E??[]){const S=y.dl_expiry;if(S&&(S===k&&!y.dl_warn_30_sent_at&&await G(c,y,"30")&&(await c.from("helpers").update({dl_warn_30_sent_at:new Date().toISOString()}).eq("id",y.id),T.warned_30+=1),S===g&&!y.dl_warn_7_sent_at&&await G(c,y,"7")&&(await c.from("helpers").update({dl_warn_7_sent_at:new Date().toISOString()}).eq("id",y.id),T.warned_7+=1),S<=_)){y.verification_status==="verified"&&await c.from("helpers").update({verification_status:"expired"}).eq("id",y.id);const D=await Ne(c,y);T.released_jobs+=D.length,y.dl_expired_notified_at?y.verification_status==="verified"&&(T.expired+=1):await G(c,y,"expired")&&(await c.from("helpers").update({dl_expired_notified_at:new Date().toISOString()}).eq("id",y.id),T.expired+=1)}}return N({ok:!0,reason:p.reason??"manual",today_ist:_,...T})}catch(n){console.error(n);const t=n instanceof Error?n.message:"Unknown error";return N({ok:!1,error:t},500)}});
