// ../../../tmp/fn-src/supabase/functions/helper-reminders/index.ts
import { createClient } from "jsr:@supabase/supabase-js@2";

// ../../../tmp/fn-src/supabase/functions/_shared/email.ts
var SUPPORT_PHONE = "+91 73399 11220";
var LOGO_URL = "https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg";
var BRAND_PRIMARY = "#1d6fd8";
var BRAND_ACCENT = "#4a9cf7";
var BRAND_TEXT = "#1f2937";
var BRAND_MUTED = "#6b7280";
var MONTHS_SHORT = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
];
var WEEKDAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
function escapeHtml(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}
function displayValue(value, fallback = "\u2013") {
  if (value === null || value === void 0) return fallback;
  const text = String(value).trim();
  if (!text || text.toLowerCase() === "null" || text.toLowerCase() === "undefined") {
    return fallback;
  }
  return text;
}
function parseDateParts(appointmentDate) {
  if (!appointmentDate) return null;
  const dateMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(appointmentDate.trim());
  if (!dateMatch) return null;
  const year = Number(dateMatch[1]);
  const month = Number(dateMatch[2]);
  const day = Number(dateMatch[3]);
  if (!month || month < 1 || month > 12 || !day || day < 1 || day > 31) {
    return null;
  }
  return { year, month, day };
}
function parseTimeParts(appointmentTime) {
  if (!appointmentTime) return null;
  const timeMatch = /^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(
    appointmentTime.trim()
  );
  if (!timeMatch) return null;
  const hour24 = Number(timeMatch[1]);
  const minute = Number(timeMatch[2]);
  if (!Number.isInteger(hour24) || !Number.isInteger(minute) || hour24 < 0 || hour24 > 23 || minute < 0 || minute > 59) {
    return null;
  }
  return { hour24, minute };
}
function appointmentMsIst(appointmentDate, appointmentTime) {
  const d = parseDateParts(appointmentDate);
  const t = parseTimeParts(appointmentTime) ?? { hour24: 0, minute: 0 };
  if (!d) return NaN;
  return Date.parse(
    `${String(d.year).padStart(4, "0")}-${String(d.month).padStart(2, "0")}-${String(d.day).padStart(2, "0")}T${String(t.hour24).padStart(2, "0")}:${String(t.minute).padStart(2, "0")}:00+05:30`
  );
}
function formatAppointmentDateLong(appointmentDate) {
  const d = parseDateParts(appointmentDate);
  if (!d) return displayValue(appointmentDate);
  const weekday = new Date(Date.UTC(d.year, d.month - 1, d.day)).getUTCDay();
  return `${WEEKDAYS_SHORT[weekday]}, ${d.day} ${MONTHS_SHORT[d.month - 1]} ${d.year}`;
}
function formatAppointmentTime(appointmentTime) {
  const t = parseTimeParts(appointmentTime);
  if (!t) return null;
  const hour12 = t.hour24 % 12 || 12;
  const ampm = t.hour24 < 12 ? "AM" : "PM";
  return `${hour12}:${String(t.minute).padStart(2, "0")} ${ampm}`;
}
function istYmd(ms) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date(ms));
}
function formatRelativeTime(appointmentDate, appointmentTime, nowMs = Date.now()) {
  const appt = appointmentMsIst(appointmentDate, appointmentTime);
  if (!Number.isFinite(appt)) return "\u2013";
  const today = istYmd(nowMs);
  const apptDay = istYmd(appt);
  const todayParts = parseDateParts(today);
  const apptParts = parseDateParts(apptDay);
  const dayDiff = Math.round(
    (Date.UTC(apptParts.year, apptParts.month - 1, apptParts.day) - Date.UTC(todayParts.year, todayParts.month - 1, todayParts.day)) / 864e5
  );
  if (dayDiff === 0) {
    const deltaMs = appt - nowMs;
    if (deltaMs <= 0) return "today";
    const totalMinutes = Math.round(deltaMs / 6e4);
    if (totalMinutes < 60) {
      return `today \xB7 in ${totalMinutes} minute${totalMinutes === 1 ? "" : "s"}`;
    }
    const hours = Math.round(totalMinutes / 60);
    return `today \xB7 in ${hours} hour${hours === 1 ? "" : "s"}`;
  }
  if (dayDiff === 1) return "tomorrow";
  if (dayDiff > 1) return `in ${dayDiff} days`;
  if (dayDiff === -1) return "yesterday";
  return `${Math.abs(dayDiff)} days ago`;
}
function formatIstDateTime(iso) {
  if (!iso) return "\u2013";
  const ms = Date.parse(iso);
  if (!Number.isFinite(ms)) return displayValue(iso);
  const d = new Date(ms);
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata",
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true
  }).formatToParts(d);
  const get = (type) => parts.find((p) => p.type === type)?.value ?? "";
  const day = get("day");
  const month = get("month");
  const year = get("year");
  const weekday = get("weekday");
  const hour = get("hour");
  const minute = get("minute");
  const dayPeriod = get("dayPeriod").toUpperCase();
  return `${weekday}, ${day} ${month} ${year} \xB7 ${hour}:${minute} ${dayPeriod}`;
}
function emailButtonHtml(href, label, variant = "primary") {
  const bg = variant === "primary" ? BRAND_PRIMARY : "#e5e7eb";
  const color = variant === "primary" ? "#ffffff" : "#111827";
  return `<a href="${escapeHtml(href)}" style="background:${bg};color:${color};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${escapeHtml(label)}</a>`;
}
function emailFooterText() {
  return `This is an automated message from ABI Parent Care. For help, call ${SUPPORT_PHONE}.`;
}
function wrapEmailHtml(args) {
  const ref = displayValue(args.ref, "");
  const refHtml = ref ? `<td align="right" style="font-size:13px;color:${BRAND_MUTED};white-space:nowrap;">Ref <strong style="color:${BRAND_TEXT};">${escapeHtml(ref)}</strong></td>` : `<td></td>`;
  const preheader = args.preheader ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${escapeHtml(args.preheader)}</div>` : "";
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${preheader}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${BRAND_PRIMARY},${BRAND_ACCENT});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${LOGO_URL}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${ref ? `<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${escapeHtml(ref)}</strong></td>` : ""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${BRAND_TEXT};">
          ${args.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${BRAND_MUTED};">
          ${escapeHtml(emailFooterText())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`;
}
function wrapEmailText(args) {
  const lines = [
    "ABI Parent Care",
    args.ref ? `Ref ${displayValue(args.ref)}` : null,
    "",
    args.bodyText.trim(),
    "",
    emailFooterText()
  ].filter((line2) => line2 !== null);
  return lines.join("\n");
}
async function sendEmail(args) {
  const resendApiKey = Deno.env.get("RESEND_API_KEY");
  if (!resendApiKey) {
    throw new Error("Missing RESEND_API_KEY secret");
  }
  const testMode = Deno.env.get("EMAIL_TEST_MODE") === "true";
  const testTo = Deno.env.get("TEST_EMAIL_TO")?.trim() || "";
  const realRecipientLabel = (args.toName?.trim() || args.to).trim();
  const finalTo = testMode && testTo ? testTo : args.to;
  const finalSubject = testMode && testTo ? `[To: ${realRecipientLabel}] ${args.subject}` : args.subject;
  const payload = {
    from: "ABI Parent Care <onboarding@resend.dev>",
    to: [finalTo],
    subject: finalSubject,
    html: args.html
  };
  if (args.text && args.text.trim()) {
    payload.text = args.text;
  }
  const emailResponse = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${resendApiKey}`
    },
    body: JSON.stringify(payload)
  });
  const emailResult = await emailResponse.json();
  if (!emailResponse.ok) {
    console.error("Resend error:", emailResult);
    return {
      ok: false,
      status: emailResponse.status,
      to: finalTo,
      subject: finalSubject,
      testMode,
      error: emailResult
    };
  }
  return {
    ok: true,
    status: emailResponse.status,
    id: typeof emailResult?.id === "string" ? emailResult.id : void 0,
    to: finalTo,
    subject: finalSubject,
    testMode
  };
}

// ../../../tmp/fn-src/supabase/functions/_shared/templates.ts
function firstName(fullName) {
  const trimmed = String(fullName ?? "").trim();
  if (!trimmed) return "there";
  return trimmed.split(/\s+/)[0] ?? trimmed;
}
function timeLabel(appointmentTime) {
  return formatAppointmentTime(appointmentTime) ?? displayValue(appointmentTime);
}
function sectionHeading(label) {
  return `<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${escapeHtml(label)}</p>`;
}
function line(label, value) {
  return `<div style="margin:0 0 6px;"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</div>`;
}
function textLine(label, value) {
  return `${label}: ${value}`;
}
function joinAddress(parts) {
  return parts.map((p) => String(p ?? "").trim()).filter(Boolean).join(", ");
}
function build(id, subject, ref, bodyHtml, bodyText) {
  return {
    id,
    subject,
    html: wrapEmailHtml({ bodyHtml, ref, preheader: subject }),
    text: wrapEmailText({ bodyText, ref })
  };
}
function templateH3(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject = `Reminder: visit ${relative} ${time} \u2013 ${v.parent_name}, ${displayValue(v.area)}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${escapeHtml(v.parent_name)} ${escapeHtml(relative)}.</p>
    ${line("When", `${dateLong} \xB7 ${time}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${escapeHtml(displayValue(v.full_address))} \xB7 <a href="${escapeHtml(v.maps_url)}">Open in Google Maps</a></div>
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${emailButtonHtml(v.cant_make_it_url, "Can't make it", "secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    `A reminder that you're accompanying ${v.parent_name} ${relative}.`,
    "",
    textLine("When", `${dateLong} \xB7 ${time}`),
    textLine("Pickup", `${displayValue(v.full_address)} \xB7 ${v.maps_url}`),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`
    ),
    "",
    "Plan to reach the pickup address 15 minutes early.",
    "",
    `Can't make it? ${v.cant_make_it_url}`,
    "",
    `Ref ${v.ref}`
  ].join("\n");
  return build("H3", subject, v.ref, bodyHtml, bodyText);
}
function templateH4(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const subject = `Please confirm: ${v.parent_name} at ${time} \u2013 ${relative}`;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${escapeHtml(v.parent_name)} is ${escapeHtml(relative)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${emailButtonHtml(v.confirm_url, "I'll be there", "primary")}
      ${emailButtonHtml(v.cant_make_it_url, "Can't make it", "secondary")}
    </p>
    ${line("When", `${dateLong} \xB7 ${time}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${escapeHtml(displayValue(v.full_address))} \xB7 <a href="${escapeHtml(v.maps_url)}">Open in Google Maps</a></div>
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${line("Family", `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${escapeHtml(v.ref)}</p>
  `;
  const bodyText = [
    `Hi ${v.helper_first_name},`,
    "",
    `Your visit with ${v.parent_name} is ${relative}. Please confirm you'll be there.`,
    "",
    `I'll be there: ${v.confirm_url}`,
    `Can't make it: ${v.cant_make_it_url}`,
    "",
    textLine("When", `${dateLong} \xB7 ${time}`),
    textLine("Pickup", `${displayValue(v.full_address)} \xB7 ${v.maps_url}`),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    textLine(
      "Family",
      `${v.booking_person_name} (${displayValue(v.relationship)}) \xB7 ${displayValue(v.guardian_phone)}`
    ),
    "",
    "If we don't hear from you, our care team will call you.",
    "",
    `Ref ${v.ref}`
  ].join("\n");
  return build("H4", subject, v.ref, bodyHtml, bodyText);
}
function templateM6(v) {
  const dateLong = formatAppointmentDateLong(v.appointment_date);
  const time = timeLabel(v.appointment_time);
  const relative = formatRelativeTime(v.appointment_date, v.appointment_time);
  const assigned = formatIstDateTime(v.assigned_at);
  const subject = v.urgent ? `URGENT \u2013 visit in 1 hour, ${v.helper_full_name} still not confirmed \xB7 ${v.parent_name} \xB7 ${v.ref}` : `Action needed \u2013 ${v.helper_full_name} hasn't confirmed \xB7 ${v.parent_name} \xB7 ${time} (${relative}) \xB7 ${v.ref}`;
  const lead = v.urgent ? `The visit starts in about 1 hour and ${escapeHtml(v.helper_full_name)} still hasn't confirmed. Please resolve this now.` : `${escapeHtml(v.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`;
  const leadText = v.urgent ? `The visit starts in about 1 hour and ${v.helper_full_name} still hasn't confirmed. Please resolve this now.` : `${v.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`;
  const stepsHtml = v.urgent ? `<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${escapeHtml(v.helper_first_name)}: ${escapeHtml(displayValue(v.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".</li>
      </ol>` : `${sectionHeading("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${escapeHtml(v.helper_first_name)}: ${escapeHtml(displayValue(v.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone \u2013 nothing else happens, or</li>
            <li>Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`;
  const stepsText = v.urgent ? [
    `1. Call ${v.helper_first_name}: ${displayValue(v.helper_phone)}`,
    `2. Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".`
  ].join("\n") : [
    "WHAT TO DO NOW",
    `1. Call ${v.helper_first_name}: ${displayValue(v.helper_phone)}`,
    "2. Then in the portal, choose:",
    "   \u2022 Helper confirmed by phone \u2013 nothing else happens, or",
    "   \u2022 Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper"
  ].join("\n");
  const detailsHtml = `
    ${sectionHeading("Visit details")}
    ${line("Patient", `${v.parent_name}, ${v.parent_age}`)}
    ${line("When", `${dateLong} \xB7 ${time} (${relative})`)}
    ${line("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013")}
    ${line("Hospital", displayValue(v.doctor_hospital))}
    ${sectionHeading("Helper status")}
    ${line("Assigned", assigned)}
    ${line("Reminders", `12-hour ${v.r12_status} \xB7 6-hour ${v.r6_status}`)}
    ${line("Confirmed", "Not yet")}
  `;
  const bodyHtml = `
    <p style="margin:0 0 12px;">Hi ${escapeHtml(v.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${lead}</p>
    ${stepsHtml}
    ${detailsHtml}
    <p style="margin:22px 0;">${emailButtonHtml(v.open_url, "Open request", "primary")}</p>
  `;
  const bodyText = [
    `Hi ${v.manager_first_name},`,
    "",
    leadText,
    "",
    stepsText,
    "",
    "VISIT DETAILS",
    textLine("Patient", `${v.parent_name}, ${v.parent_age}`),
    textLine("When", `${dateLong} \xB7 ${time} (${relative})`),
    textLine("Pickup", joinAddress([v.area, v.city, v.pincode]) || "\u2013"),
    textLine("Hospital", displayValue(v.doctor_hospital)),
    "",
    "HELPER STATUS",
    textLine("Assigned", assigned),
    textLine("Reminders", `12-hour ${v.r12_status} \xB7 6-hour ${v.r6_status}`),
    textLine("Confirmed", "Not yet"),
    "",
    `Open request: ${v.open_url}`
  ].join("\n");
  return build(v.urgent ? "M7" : "M6", subject, v.ref, bodyHtml, bodyText);
}
function templateM7(v) {
  return templateM6({ ...v, urgent: true });
}

// ../../../tmp/fn-src/supabase/functions/_shared/senior.ts
var ADMIN_PAGE_BASE = "https://nandhini-17223.github.io/elderly-care/admin";
var RESPOND_BASE = "https://nandhini-17223.github.io/elderly-care/respond.html";
var MANAGER_FIRST_NAME = "Manager";
function seniorAssignUrl(requestId) {
  const next = `needs-action.html?request=${encodeURIComponent(requestId)}`;
  return `${ADMIN_PAGE_BASE}/login.html?next=${encodeURIComponent(next)}`;
}
function reminderStatusLabel(sentAt) {
  return sentAt ? "sent" : "not sent";
}

// ../../../tmp/fn-src/supabase/functions/_shared/assignment.ts
function fullPickupAddress(request) {
  return [
    request.address_line1,
    request.street,
    request.area,
    request.city,
    request.pincode
  ].map((part) => part ? String(part).trim() : "").filter(Boolean).join(", ");
}
function mapsSearchUrl(address) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
}
function familyPhone(request) {
  return `${request.phone_country_code} ${request.phone}`.trim();
}
function actionUrl(token, action) {
  return `${RESPOND_BASE}?token=${encodeURIComponent(token)}&action=${encodeURIComponent(action)}`;
}
function bytesToHex(bytes) {
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function sha256Hex(value) {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return bytesToHex(new Uint8Array(digest));
}
async function createRawToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  const token = bytesToHex(bytes);
  const hash = await sha256Hex(token);
  return { token, hash };
}
function reminderEmail(request, helperName, token, kind) {
  const address = fullPickupAddress(request);
  const base = {
    ref: String(request.ref_number ?? "\u2013"),
    helper_first_name: firstName(helperName),
    parent_name: request.parent_name,
    area: request.area,
    appointment_date: request.appointment_date,
    appointment_time: request.appointment_time,
    full_address: address,
    maps_url: mapsSearchUrl(address),
    doctor_hospital: request.doctor_hospital,
    booking_person_name: request.booking_person_name,
    relationship: request.relationship,
    guardian_phone: familyPhone(request),
    cant_make_it_url: actionUrl(token, "cant_make_it")
  };
  if (kind === "6h") {
    return templateH4({
      ...base,
      confirm_url: actionUrl(token, "confirm_attendance")
    });
  }
  return templateH3(base);
}

// ../../../tmp/fn-src/supabase/functions/_shared/secrets.ts
async function resolveSecret(supabase, name) {
  const fromEnv = Deno.env.get(name)?.trim() || "";
  if (fromEnv) return fromEnv;
  const { data, error } = await supabase.rpc("get_app_secret", {
    p_name: name
  });
  if (error) {
    console.error(`get_app_secret(${name}) failed`, error);
    return null;
  }
  const value = typeof data === "string" ? data.trim() : "";
  return value || null;
}

// ../../../tmp/fn-src/supabase/functions/helper-reminders/index.ts
function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json",
      Connection: "keep-alive"
    }
  });
}
function asContact(row) {
  return {
    ref_number: row.ref_number,
    parent_name: row.parent_name,
    parent_age: row.parent_age,
    address_line1: row.address_line1,
    street: row.street,
    area: row.area,
    landmark: row.landmark,
    city: row.city,
    pincode: row.pincode,
    appointment_date: row.appointment_date,
    appointment_time: row.appointment_time,
    doctor_hospital: row.doctor_hospital,
    booking_person_name: row.booking_person_name,
    relationship: row.relationship,
    phone_country_code: row.phone_country_code,
    phone: row.phone
  };
}
function appointmentMs(row) {
  return Date.parse(
    `${row.appointment_date}T${String(row.appointment_time).slice(0, 8)}+05:30`
  );
}
async function ensureAssignmentToken(supabase, requestId, helperId) {
  const { token, hash } = await createRawToken();
  const { data, error } = await supabase.rpc("create_assignment_token", {
    p_request_id: requestId,
    p_helper_id: helperId,
    p_token_hash: hash
  });
  if (error) {
    console.error("create_assignment_token", error);
    return null;
  }
  const result = data;
  if (!result?.ok) return null;
  return token;
}
async function markSent(supabase, requestId, column) {
  const { data, error } = await supabase.from("consultation_requests").update({ [column]: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", requestId).eq("status", "assigned").is(column, null).select("id").maybeSingle();
  if (error) {
    console.error(`markSent ${column}`, error);
    return false;
  }
  return Boolean(data?.id);
}
async function processReminders(supabase, rows, helpersById) {
  const results = [];
  for (const row of rows) {
    if (row.status !== "assigned") continue;
    const helper = helpersById.get(row.assigned_helper_id);
    if (!helper) continue;
    const appt = appointmentMs(row);
    const assignedAt = Date.parse(row.assigned_at);
    if (!Number.isFinite(appt) || !Number.isFinite(assignedAt)) continue;
    const hoursLead = (appt - assignedAt) / 36e5;
    const skip12 = hoursLead < 12;
    const skipBoth = hoursLead < 6;
    const { data: rem12 } = await supabase.rpc("effective_reminder_at", {
      p_appointment: new Date(appt).toISOString(),
      p_hours_before: 12,
      p_assigned_at: row.assigned_at
    });
    const { data: rem6 } = await supabase.rpc("effective_reminder_at", {
      p_appointment: new Date(appt).toISOString(),
      p_hours_before: 6,
      p_assigned_at: row.assigned_at
    });
    const now = Date.now();
    const due12 = typeof rem12 === "string" ? Date.parse(rem12) : NaN;
    const due6 = typeof rem6 === "string" ? Date.parse(rem6) : NaN;
    const entry = {
      request_id: row.id,
      helper_id: helper.id,
      hours_lead: Math.round(hoursLead * 100) / 100,
      skip12,
      skipBoth,
      due12: rem12,
      due6: rem6
    };
    if (!skipBoth && !skip12 && !row.reminder_12h_sent_at && Number.isFinite(due12) && now >= due12) {
      const claimed = await markSent(supabase, row.id, "reminder_12h_sent_at");
      if (claimed) {
        const token = await ensureAssignmentToken(
          supabase,
          row.id,
          helper.id
        );
        if (token) {
          const email = reminderEmail(
            asContact(row),
            helper.full_name,
            token,
            "12h"
          );
          const sent = await sendEmail({
            to: helper.email,
            toName: helper.full_name,
            subject: email.subject,
            html: email.html,
            text: email.text
          });
          entry.reminder_12h = { sent: sent.ok };
        } else {
          entry.reminder_12h = { sent: false, error: "token_failed" };
        }
      } else {
        entry.reminder_12h = { skipped: "already_sent" };
      }
    }
    if (!skipBoth && !row.reminder_6h_sent_at && Number.isFinite(due6) && now >= due6) {
      const claimed = await markSent(supabase, row.id, "reminder_6h_sent_at");
      if (claimed) {
        const token = await ensureAssignmentToken(
          supabase,
          row.id,
          helper.id
        );
        if (token) {
          const email = reminderEmail(
            asContact(row),
            helper.full_name,
            token,
            "6h"
          );
          const sent = await sendEmail({
            to: helper.email,
            toName: helper.full_name,
            subject: email.subject,
            html: email.html,
            text: email.text
          });
          entry.reminder_6h = { sent: sent.ok };
        } else {
          entry.reminder_6h = { sent: false, error: "token_failed" };
        }
      } else {
        entry.reminder_6h = { skipped: "already_sent" };
      }
    }
    results.push(entry);
  }
  return results;
}
async function processNoConfirmAlerts(supabase, rows, helpersById) {
  const seniorEmail = await resolveSecret(supabase, "SENIOR_EMAIL");
  const results = [];
  if (!seniorEmail) {
    return [{ error: "missing_senior_secrets" }];
  }
  for (const row of rows) {
    if (row.helper_confirmed_at) continue;
    const helper = helpersById.get(row.assigned_helper_id);
    if (!helper) continue;
    const appt = appointmentMs(row);
    if (!Number.isFinite(appt)) continue;
    const hoursLeft = (appt - Date.now()) / 36e5;
    const assignUrl = seniorAssignUrl(row.id);
    const m6base = {
      ref: String(row.ref_number ?? "\u2013"),
      manager_first_name: MANAGER_FIRST_NAME,
      helper_full_name: helper.full_name,
      helper_first_name: firstName(helper.full_name),
      helper_phone: helper.phone,
      parent_name: row.parent_name,
      parent_age: row.parent_age,
      appointment_date: row.appointment_date,
      appointment_time: row.appointment_time,
      area: row.area,
      city: row.city,
      pincode: row.pincode,
      doctor_hospital: row.doctor_hospital,
      assigned_at: row.assigned_at,
      r12_status: reminderStatusLabel(row.reminder_12h_sent_at),
      r6_status: reminderStatusLabel(row.reminder_6h_sent_at),
      open_url: assignUrl
    };
    const entry = {
      request_id: row.id,
      hours_left: Math.round(hoursLeft * 100) / 100
    };
    if (hoursLeft <= 3 && hoursLeft > 0 && !row.no_confirm_alert_sent_at) {
      const claimed = await markSent(
        supabase,
        row.id,
        "no_confirm_alert_sent_at"
      );
      if (claimed) {
        const email = templateM6(m6base);
        const sent = await sendEmail({
          to: seniorEmail,
          toName: "Senior coordinator",
          subject: email.subject,
          html: email.html,
          text: email.text
        });
        entry.alert_3h = { sent: sent.ok };
      }
    }
    if (hoursLeft <= 1 && hoursLeft > 0 && !row.no_confirm_second_alert_sent_at) {
      const { data: fresh } = await supabase.from("consultation_requests").select("helper_confirmed_at, status, assigned_helper_id").eq("id", row.id).maybeSingle();
      if (fresh?.status === "assigned" && !fresh.helper_confirmed_at && fresh.assigned_helper_id === row.assigned_helper_id) {
        const claimed = await markSent(
          supabase,
          row.id,
          "no_confirm_second_alert_sent_at"
        );
        if (claimed) {
          const email = templateM7(m6base);
          const sent = await sendEmail({
            to: seniorEmail,
            toName: "Senior coordinator",
            subject: email.subject,
            html: email.html,
            text: email.text
          });
          entry.alert_1h = { sent: sent.ok };
        }
      }
    }
    results.push(entry);
  }
  return results;
}
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }
  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceRoleKey) {
      throw new Error("Missing Supabase environment configuration");
    }
    const supabase = createClient(supabaseUrl, serviceRoleKey);
    const payload = await req.json().catch(() => ({}));
    let query = supabase.from("consultation_requests").select(
      "id, ref_number, status, parent_name, parent_age, address_line1, street, area, landmark, city, pincode, appointment_date, appointment_time, doctor_hospital, booking_person_name, relationship, phone_country_code, phone, assigned_helper_id, assigned_at, helper_confirmed_at, reminder_12h_sent_at, reminder_6h_sent_at, no_confirm_alert_sent_at, no_confirm_second_alert_sent_at"
    ).eq("status", "assigned").not("assigned_helper_id", "is", null);
    if (payload.request_id) {
      query = query.eq("id", payload.request_id);
    }
    const { data, error } = await query;
    if (error) throw error;
    const rows = data ?? [];
    const helperIds = [...new Set(rows.map((r) => r.assigned_helper_id))];
    const helpersById = /* @__PURE__ */ new Map();
    if (helperIds.length) {
      const { data: helpers, error: helpersError } = await supabase.from("helpers").select("id, full_name, email, phone").in("id", helperIds);
      if (helpersError) throw helpersError;
      for (const helper of helpers ?? []) {
        helpersById.set(helper.id, helper);
      }
    }
    const reminders = await processReminders(supabase, rows, helpersById);
    const alerts = await processNoConfirmAlerts(supabase, rows, helpersById);
    return jsonResponse({
      ok: true,
      reason: payload.reason ?? "manual",
      assigned_count: rows.length,
      reminders,
      alerts
    });
  } catch (error) {
    console.error(error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return jsonResponse({ ok: false, error: message }, 500);
  }
});
