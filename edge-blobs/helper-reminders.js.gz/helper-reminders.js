const me=globalThis.__sb.createClient,A="+91 73399 11220",de="https://nandhini-17223.github.io/elderly-care/helper/",ce="https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg",z="#1d6fd8",_e="#4a9cf7",J="#1f2937",q="#6b7280",L=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],ue=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function a(e){return e.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;")}function s(e,n="\u2013"){if(e==null)return n;const t=String(e).trim();return!t||t.toLowerCase()==="null"||t.toLowerCase()==="undefined"?n:t}function V(e){return s(e,"None given")}function N(e){if(!e)return null;const n=/^(\d{4})-(\d{2})-(\d{2})$/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]),i=Number(n[3]);return!r||r<1||r>12||!i||i<1||i>31?null:{year:t,month:r,day:i}}function Q(e){if(!e)return null;const n=/^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]);return!Number.isInteger(t)||!Number.isInteger(r)||t<0||t>23||r<0||r>59?null:{hour24:t,minute:r}}function ge(e,n){const t=N(e),r=Q(n)??{hour24:0,minute:0};return t?Date.parse(`${String(t.year).padStart(4,"0")}-${String(t.month).padStart(2,"0")}-${String(t.day).padStart(2,"0")}T${String(r.hour24).padStart(2,"0")}:${String(r.minute).padStart(2,"0")}:00+05:30`):NaN}function B(e){const n=N(e);return n?`${n.day} ${L[n.month-1]} ${n.year}`:null}function T(e){const n=N(e);return n?`${n.day} ${L[n.month-1]}`:s(e)}function k(e){const n=N(e);if(!n)return s(e);const t=new Date(Date.UTC(n.year,n.month-1,n.day)).getUTCDay();return`${ue[t]}, ${n.day} ${L[n.month-1]} ${n.year}`}function M(e){const n=Q(e);if(!n)return null;const t=n.hour24%12||12,r=n.hour24<12?"AM":"PM";return`${t}:${String(n.minute).padStart(2,"0")} ${r}`}function We(e,n){const t=B(e),r=M(n);return!t||!r?null:`${t}, ${r}`}function X(e){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(e))}function w(e,n,t=Date.now()){const r=ge(e,n);if(!Number.isFinite(r))return"\u2013";const i=X(t),o=X(r),l=N(i),p=N(o),c=Math.round((Date.UTC(p.year,p.month-1,p.day)-Date.UTC(l.year,l.month-1,l.day))/864e5);if(c===0){const _=r-t;if(_<=0)return"today";const u=Math.round(_/6e4);if(u<60)return`today \xB7 in ${u} minute${u===1?"":"s"}`;const g=Math.round(u/60);return`today \xB7 in ${g} hour${g===1?"":"s"}`}return c===1?"tomorrow":c>1?`in ${c} days`:c===-1?"yesterday":`${Math.abs(c)} days ago`}function he(e){if(!e)return"\u2013";const n=Date.parse(e);if(!Number.isFinite(n))return s(e);const t=new Date(n),r=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Kolkata",weekday:"short",day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit",hour12:!0}).formatToParts(t),i=b=>r.find(x=>x.type===b)?.value??"",o=i("day"),l=i("month"),p=i("year"),c=i("weekday"),_=i("hour"),u=i("minute"),g=i("dayPeriod").toUpperCase();return`${c}, ${o} ${l} ${p} \xB7 ${_}:${u} ${g}`}function f(e,n,t="primary"){const r=t==="primary"?z:"#e5e7eb",i=t==="primary"?"#ffffff":"#111827";return`<a href="${a(e)}" style="background:${r};color:${i};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${a(n)}</a>`}function Z(){return`This is an automated message from ABI Parent Care. For help, call ${A}.`}function fe(e){const n=s(e.ref,""),t=n?`<td align="right" style="font-size:13px;color:${q};white-space:nowrap;">Ref <strong style="color:${J};">${a(n)}</strong></td>`:"<td></td>";return`<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${e.preheader?`<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${a(e.preheader)}</div>`:""}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${z},${_e});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${ce}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${n?`<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${a(n)}</strong></td>`:""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${J};">
          ${e.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${q};">
          ${a(Z())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`}function $e(e){return["ABI Parent Care",e.ref?`Ref ${s(e.ref)}`:null,"",e.bodyText.trim(),"",Z()].filter(t=>t!==null).join(`
`)}async function D(e){const n=Deno.env.get("RESEND_API_KEY");if(!n)throw new Error("Missing RESEND_API_KEY secret");const t=Deno.env.get("EMAIL_TEST_MODE")==="true",r=Deno.env.get("TEST_EMAIL_TO")?.trim()||"",i=(e.toName?.trim()||e.to).trim(),o=t&&r?r:e.to,l=t&&r?`[To: ${i}] ${e.subject}`:e.subject,p={from:"ABI Parent Care <onboarding@resend.dev>",to:[o],subject:l,html:e.html};e.text&&e.text.trim()&&(p.text=e.text);const c=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify(p)}),_=await c.json();return c.ok?{ok:!0,status:c.status,id:typeof _?.id=="string"?_.id:void 0,to:o,subject:l,testMode:t}:(console.error("Resend error:",_),{ok:!1,status:c.status,to:o,subject:l,testMode:t,error:_})}function j(e){const n=String(e??"").trim();return n?n.split(/\s+/)[0]??n:"there"}function S(e){return e==="female"?"Female helper":e==="male"?"Male helper":e==="no_preference"||e==="none"||!e?"No preference":s(e,"No preference")}function G(e){switch(e){case"no_acceptance":return"No helper accepted within 2 hours";case"no_suitable_helpers":return"No suitable helper nearby";case"all_declined":return"All offered helpers declined";case"short_notice":return"Booked at short notice";case"helper_dropped":return"Helper dropped out";case"helper_not_confirmed":return"Helper didn't confirm";case"helper_unavailable":return"Helper no longer available";default:return e?e.replaceAll("_"," "):"Needs senior attention"}}function $(e){return M(e)??s(e)}function y(e){return`<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${a(e)}</p>`}function d(e,n){return`<div style="margin:0 0 6px;"><strong>${a(e)}:</strong> ${a(n)}</div>`}function m(e,n){return`${e}: ${n}`}function v(e){return e?`<p style="margin:16px 0;"><img src="${a(e)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`:""}function P(e){return e.map(n=>String(n??"").trim()).filter(Boolean).join(", ")}function h(e,n,t,r,i){return{id:e,subject:n,html:fe({bodyHtml:r,ref:t,preheader:n}),text:$e({bodyText:i,ref:t})}}function Le(e){const n=T(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),i=P([e.area,e.city,e.pincode])||"\u2013",o=S(e.helper_preference),l=`We've received your request \u2013 ${e.parent_name}, ${n} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Thank you for choosing ABI Parent Care. We've received your request for ${a(e.parent_name)}'s doctor appointment.</p>
    ${y("Appointment")}
    ${d("Date & time",`${t} \xB7 ${r}`)}
    ${d("Doctor/Hospital",s(e.doctor_hospital))}
    ${d("Pickup from",i)}
    ${d("Helper preference",o)}
    ${y("What happens next")}
    <p style="margin:0 0 12px;">We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.</p>
    <p style="margin:0 0 12px;">Need to change anything? Call us on ${a(A)} and quote Ref ${a(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`Thank you for choosing ABI Parent Care. We've received your request for ${e.parent_name}'s doctor appointment.`,"","APPOINTMENT",m("Date & time",`${t} \xB7 ${r}`),m("Doctor/Hospital",s(e.doctor_hospital)),m("Pickup from",i),m("Helper preference",o),"","WHAT HAPPENS NEXT","We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.","",`Need to change anything? Call us on ${A} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G1",l,e.ref,p,c)}function Ve(e){const n=T(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),i=`Update on ${e.parent_name}'s appointment \u2013 ${n} \xB7 Ref ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${a(e.parent_name)}'s appointment on ${a(t)} at ${a(r)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${a(A)} and quote Ref ${a(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,l=[`Dear ${e.booking_person_name},`,"",`A quick update: our care team is personally arranging a suitable helper for ${e.parent_name}'s appointment on ${t} at ${r}.`,"","You don't need to do anything. We'll email you the helper's details shortly.","",`If you'd like to speak to us, call ${A} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G2",i,e.ref,o,l)}function ye(e){const n=T(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),i=w(e.appointment_date,e.appointment_time),o=P([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",l=`Helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name}, ${n} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news \u2013 ${a(e.helper_full_name)} will accompany ${a(e.parent_name)} to the appointment.</p>
    ${v(e.helper_photo_url)}
    ${y("Your helper")}
    ${d("Name",e.helper_full_name)}
    ${d("Phone",s(e.helper_phone))}
    ${d("Verified","ID and background checked by ABI Parent Care")}
    ${y("Appointment")}
    ${d("Date & time",`${t} \xB7 ${r} (${i})`)}
    ${d("Doctor/Hospital",s(e.doctor_hospital))}
    ${d("Pickup from",o)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${a(e.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`Good news \u2013 ${e.helper_full_name} will accompany ${e.parent_name} to the appointment.`,"","YOUR HELPER",m("Name",e.helper_full_name),m("Phone",s(e.helper_phone)),m("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT",m("Date & time",`${t} \xB7 ${r} (${i})`),m("Doctor/Hospital",s(e.doctor_hospital)),m("Pickup from",o),"",`For safety, please share this with ${e.parent_name} so they know who to expect.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G3",l,e.ref,p,c)}function be(e){const n=T(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),i=`Change of helper for ${e.parent_name} \u2013 ${n} \xB7 Ref ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${a(e.old_helper_first_name)} is unable to attend ${a(e.parent_name)}'s appointment on ${a(t)} at ${a(r)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${a(A)} and quote Ref ${a(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,l=[`Dear ${e.booking_person_name},`,"",`We're sorry \u2013 ${e.old_helper_first_name} is unable to attend ${e.parent_name}'s appointment on ${t} at ${r}.`,"","Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.","",`The appointment itself is unchanged. If you have concerns, call ${A} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G4",i,e.ref,o,l)}function ke(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=`New helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name} \xB7 Ref ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Dear ${a(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} will now accompany ${a(e.parent_name)} to the appointment, in place of ${a(e.old_helper_first_name)}.</p>
    ${v(e.helper_photo_url)}
    ${y("Your new helper")}
    ${d("Name",e.helper_full_name)}
    ${d("Phone",s(e.helper_phone))}
    ${d("Verified","ID and background checked by ABI Parent Care")}
    ${y("Appointment (unchanged)")}
    ${d("Date & time",`${n} \xB7 ${t} (${r})`)}
    ${d("Doctor/Hospital",s(e.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,l=[`Dear ${e.booking_person_name},`,"",`${e.helper_full_name} will now accompany ${e.parent_name} to the appointment, in place of ${e.old_helper_first_name}.`,"","YOUR NEW HELPER",m("Name",e.helper_full_name),m("Phone",s(e.helper_phone)),m("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT (unchanged)",m("Date & time",`${n} \xB7 ${t} (${r})`),m("Doctor/Hospital",s(e.doctor_hospital)),"","Thank you for your patience.","","Warm regards,","The ABI Parent Care team"].join(`
`);return h("G5",i,e.ref,o,l)}function Be(e){const n=T(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),i=w(e.appointment_date,e.appointment_time),o=e.distance_km==null||Number.isNaN(Number(e.distance_km))?"\u2013":String(Math.round(Number(e.distance_km)*10)/10),l=s(e.area),p=`New visit near you \u2013 ${n}, ${r} \xB7 ${l} (${o} km)`,c=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${d("When",`${t} \xB7 ${r} (${i})`)}
    ${d("Pickup area",`${l}, ${s(e.pincode)} \xB7 about ${o} km from you`)}
    ${d("Hospital",s(e.doctor_hospital))}
    ${d("Patient",`Age ${e.parent_age}`)}
    <p style="margin:22px 0;">
      ${f(e.accept_url,"Accept","primary")}
      ${f(e.decline_url,"Decline","secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,_=[`Hi ${e.helper_first_name},`,"","A new hospital visit is available near you. The first helper to accept gets it.","",m("When",`${t} \xB7 ${r} (${i})`),m("Pickup area",`${l}, ${s(e.pincode)} \xB7 about ${o} km from you`),m("Hospital",s(e.doctor_hospital)),m("Patient",`Age ${e.parent_age}`),"",`Accept: ${e.accept_url}`,`Decline: ${e.decline_url}`,"","The patient's name, full address and family contact are shared after you accept.","",`Ref ${e.ref}`].join(`
`);return h("H1",p,e.ref,c,_)}function xe(e){const n=T(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),i=w(e.appointment_date,e.appointment_time),o=P([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",l=`Confirmed: ${e.parent_name}, ${n} ${r} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${y("Patient")}
    ${d("Name",`${e.parent_name}, ${e.parent_age}`)}
    ${d("Pickup",o)}
    ${d("Landmark",s(e.landmark))}
    <p style="margin:10px 0 16px;">${f(e.maps_url,"Open in Google Maps","secondary")}</p>
    ${y("Appointment")}
    ${d("When",`${t} \xB7 ${r} (${i})`)}
    ${d("Hospital",s(e.doctor_hospital))}
    ${y("Family contact")}
    <p style="margin:0 0 12px;">${a(e.booking_person_name)} (${a(s(e.relationship))}) \xB7 ${a(s(e.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${f(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,c=[`Hi ${e.helper_first_name},`,"","This visit is yours. Thank you!","","PATIENT",m("Name",`${e.parent_name}, ${e.parent_age}`),m("Pickup",o),m("Landmark",s(e.landmark)),`Open in Google Maps: ${e.maps_url}`,"","APPOINTMENT",m("When",`${t} \xB7 ${r} (${i})`),m("Hospital",s(e.doctor_hospital)),"","FAMILY CONTACT",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`,"","We'll remind you 12 hours and 6 hours before.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return h("H2",l,e.ref,p,c)}function we(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=`Reminder: visit ${r} ${t} \u2013 ${e.parent_name}, ${s(e.area)}`,o=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${a(e.parent_name)} ${a(r)}.</p>
    ${d("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${a(s(e.full_address))} \xB7 <a href="${a(e.maps_url)}">Open in Google Maps</a></div>
    ${d("Hospital",s(e.doctor_hospital))}
    ${d("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${f(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,l=[`Hi ${e.helper_first_name},`,"",`A reminder that you're accompanying ${e.parent_name} ${r}.`,"",m("When",`${n} \xB7 ${t}`),m("Pickup",`${s(e.full_address)} \xB7 ${e.maps_url}`),m("Hospital",s(e.doctor_hospital)),m("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`),"","Plan to reach the pickup address 15 minutes early.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return h("H3",i,e.ref,o,l)}function He(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=`Please confirm: ${e.parent_name} at ${t} \u2013 ${r}`,o=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${a(e.parent_name)} is ${a(r)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${f(e.confirm_url,"I'll be there","primary")}
      ${f(e.cant_make_it_url,"Can't make it","secondary")}
    </p>
    ${d("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${a(s(e.full_address))} \xB7 <a href="${a(e.maps_url)}">Open in Google Maps</a></div>
    ${d("Hospital",s(e.doctor_hospital))}
    ${d("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${a(e.ref)}</p>
  `,l=[`Hi ${e.helper_first_name},`,"",`Your visit with ${e.parent_name} is ${r}. Please confirm you'll be there.`,"",`I'll be there: ${e.confirm_url}`,`Can't make it: ${e.cant_make_it_url}`,"",m("When",`${n} \xB7 ${t}`),m("Pickup",`${s(e.full_address)} \xB7 ${e.maps_url}`),m("Hospital",s(e.doctor_hospital)),m("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`),"","If we don't hear from you, our care team will call you.","",`Ref ${e.ref}`].join(`
`);return h("H4",i,e.ref,o,l)}function Ge(e){const n=e.helper_app_link||de,t="Welcome to ABI Parent Care \u2013 your helper app login",r=`
    <p style="margin:0 0 12px;">Hi ${a(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${d("App link",n)}
    ${d("Login email",e.helper_email)}
    ${d("Password","the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${f(n,"Open helper app","primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${a(A)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `,i=[`Hi ${e.helper_first_name},`,"","Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.","",m("App link",n),m("Login email",e.helper_email),m("Password","the temporary password given to you by your manager"),"","You'll be asked to set your own password the first time you log in.","",'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',"",`Questions? Call ${A}.`,"","The ABI Parent Care team"].join(`
`);return h("H5",t,null,r,i)}function Ue(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=`URGENT \u2013 Helper needed in ${e.time_remaining} \xB7 ${e.parent_name} (${e.parent_age}) \xB7 ${t} \xB7 ${s(e.area)} \xB7 ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${a(r)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${y("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${y("Visit details")}
    ${d("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${d("When",`${n} \xB7 ${t} (${r})`)}
    ${d("Pickup",P([e.area,e.city,e.pincode])||"\u2013")}
    ${d("Hospital",s(e.doctor_hospital))}
    ${d("Preference",S(e.helper_preference))}
    ${d("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${f(e.assign_url,"Assign a helper","primary")}</p>
  `,l=[`Hi ${e.manager_first_name},`,"",`A booking has come in for ${r}. There isn't time to send offers automatically, so please assign a helper now.`,"","WHAT TO DO NOW","Open the request, pick an available helper and send them an offer.","","VISIT DETAILS",m("Patient",`${e.parent_name}, ${e.parent_age}`),m("When",`${n} \xB7 ${t} (${r})`),m("Pickup",P([e.area,e.city,e.pincode])||"\u2013"),m("Hospital",s(e.doctor_hospital)),m("Preference",S(e.helper_preference)),m("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`),"",`Assign a helper: ${e.assign_url}`].join(`
`);return h("M1",i,e.ref,o,l)}function Fe(e){const t=`${e.items.length} request(s) need a helper \u2013 ${e.digest_time}`,r=e.items.map((p,c)=>{const _=T(p.appointment_date),u=$(p.appointment_time),g=w(p.appointment_date,p.appointment_time);return`
      <div style="margin:0 0 16px;padding:12px 0;border-bottom:1px solid #e5e7eb;">
        <p style="margin:0 0 6px;"><strong>${c+1}. ${a(p.ref)}</strong> \xB7 ${a(p.parent_name)} (${p.parent_age}) \xB7 ${a(_)} ${a(u)} (${a(g)})</p>
        <p style="margin:0 0 6px;">${a(s(p.area))} ${a(s(p.pincode))} \xB7 Preference: ${a(S(p.helper_preference))}</p>
        <p style="margin:0 0 10px;">Why: ${a(G(p.reason))}</p>
        <p style="margin:0;">${f(p.assign_url,"Assign","primary")}</p>
      </div>
    `}).join(""),i=e.items.map((p,c)=>{const _=T(p.appointment_date),u=$(p.appointment_time),g=w(p.appointment_date,p.appointment_time);return[`${c+1}. ${p.ref} \xB7 ${p.parent_name} (${p.parent_age}) \xB7 ${_} ${u} (${g})`,`   ${s(p.area)} ${s(p.pincode)} \xB7 Preference: ${S(p.helper_preference)}`,`   Why: ${G(p.reason)}`,`   Assign: ${p.assign_url}`].join(`
`)}).join(`

`),o=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">These requests still need a helper. The soonest appointment is first.</p>
    ${r}
    <p style="margin:22px 0;">${f(e.open_all_url,"Open all in the portal","primary")}</p>
  `,l=[`Hi ${e.manager_first_name},`,"","These requests still need a helper. The soonest appointment is first.","",i,"",`Open all in the portal: ${e.open_all_url}`].join(`
`);return h("M2",t,null,o,l)}function Ye(e){const n=T(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),i=w(e.appointment_date,e.appointment_time),o=V(e.decline_reason),l=`${e.helper_full_name} declined \u2013 please assign another \xB7 ${e.parent_name}, ${n} ${r} \xB7 ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} declined the visit you offered.</p>
    ${d("Reason given",o)}
    <p style="margin:12px 0;">Appointment: ${a(t)} \xB7 ${a(r)} (${a(i)}) \xB7 ${a(s(e.area))}</p>
    <p style="margin:22px 0;">${f(e.assign_url,"Choose another helper","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} declined the visit you offered.`,m("Reason given",o),"",`Appointment: ${t} \xB7 ${r} (${i}) \xB7 ${s(e.area)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return h("M3",l,e.ref,p,c)}function Ke(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=`No response from ${e.helper_full_name} \u2013 please assign another \xB7 ${e.parent_name} \xB7 ${e.ref}`,o=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} didn't respond within ${a(e.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${a(n)} \xB7 ${a(t)} (${a(r)}) \xB7 ${a(s(e.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${a(s(e.helper_phone))}</p>
    <p style="margin:22px 0;">${f(e.assign_url,"Choose another helper","primary")}</p>
  `,l=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} didn't respond within ${e.expiry_window}, so the offer has been withdrawn.`,"",`Appointment: ${n} \xB7 ${t} (${r}) \xB7 ${s(e.area)}`,`Helper phone (if you'd like to call): ${s(e.helper_phone)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return h("M4",i,e.ref,o,l)}function ze(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=V(e.dropout_reason),o=`URGENT \u2013 ${e.helper_full_name} can't attend \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,l=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} has said they can't attend this visit.</p>
    ${d("Reason given",i)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${y("Visit details")}
    ${d("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${d("When",`${n} \xB7 ${t} (${r})`)}
    ${d("Pickup",P([e.area,e.city,e.pincode])||"\u2013")}
    ${d("Hospital",s(e.doctor_hospital))}
    ${d("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${f(e.assign_url,"Assign a replacement","primary")}</p>
  `,p=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has said they can't attend this visit.`,m("Reason given",i),"","The family has been told we're arranging a replacement. Please assign a new helper now.","","VISIT DETAILS",m("Patient",`${e.parent_name}, ${e.parent_age}`),m("When",`${n} \xB7 ${t} (${r})`),m("Pickup",P([e.area,e.city,e.pincode])||"\u2013"),m("Hospital",s(e.doctor_hospital)),m("Family",`${e.booking_person_name} (${s(e.relationship)}) \xB7 ${s(e.guardian_phone)}`),"",`Assign a replacement: ${e.assign_url}`].join(`
`);return h("M5",o,e.ref,l,p)}function ee(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=w(e.appointment_date,e.appointment_time),i=he(e.assigned_at),o=e.urgent?`URGENT \u2013 visit in 1 hour, ${e.helper_full_name} still not confirmed \xB7 ${e.parent_name} \xB7 ${e.ref}`:`Action needed \u2013 ${e.helper_full_name} hasn't confirmed \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,l=e.urgent?`The visit starts in about 1 hour and ${a(e.helper_full_name)} still hasn't confirmed. Please resolve this now.`:`${a(e.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,p=e.urgent?`The visit starts in about 1 hour and ${e.helper_full_name} still hasn't confirmed. Please resolve this now.`:`${e.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,c=e.urgent?`<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${a(e.helper_first_name)}: ${a(s(e.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".</li>
      </ol>`:`${y("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${a(e.helper_first_name)}: ${a(s(e.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone \u2013 nothing else happens, or</li>
            <li>Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`,_=e.urgent?[`1. Call ${e.helper_first_name}: ${s(e.helper_phone)}`,'2. Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".'].join(`
`):["WHAT TO DO NOW",`1. Call ${e.helper_first_name}: ${s(e.helper_phone)}`,"2. Then in the portal, choose:","   \u2022 Helper confirmed by phone \u2013 nothing else happens, or","   \u2022 Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper"].join(`
`),u=`
    ${y("Visit details")}
    ${d("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${d("When",`${n} \xB7 ${t} (${r})`)}
    ${d("Pickup",P([e.area,e.city,e.pincode])||"\u2013")}
    ${d("Hospital",s(e.doctor_hospital))}
    ${y("Helper status")}
    ${d("Assigned",i)}
    ${d("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`)}
    ${d("Confirmed","Not yet")}
  `,g=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${l}</p>
    ${c}
    ${u}
    <p style="margin:22px 0;">${f(e.open_url,"Open request","primary")}</p>
  `,b=[`Hi ${e.manager_first_name},`,"",p,"",_,"","VISIT DETAILS",m("Patient",`${e.parent_name}, ${e.parent_age}`),m("When",`${n} \xB7 ${t} (${r})`),m("Pickup",P([e.area,e.city,e.pincode])||"\u2013"),m("Hospital",s(e.doctor_hospital)),"","HELPER STATUS",m("Assigned",i),m("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`),m("Confirmed","Not yet"),"",`Open request: ${e.open_url}`].join(`
`);return h(e.urgent?"M7":"M6",o,e.ref,g,b)}function Ae(e){return ee({...e,urgent:!0})}function Je(e){const n=`Driving licence ${e.expiry_phrase} \u2013 ${e.helper_full_name}`,t=e.expired?`<p style="margin:0 0 12px;">If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).</p>`:'<p style="margin:0 0 12px;">If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.</p>',r=e.expired?`If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).`:"If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.",i=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)}'s driving licence ${a(e.expiry_phrase)} (${a(e.dl_expiry)}).</p>
    ${t}
    <p style="margin:22px 0;">${f(e.open_url,"Open helper profile","primary")}</p>
  `,o=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name}'s driving licence ${e.expiry_phrase} (${e.dl_expiry}).`,"",r,"",`Open helper profile: ${e.open_url}`].join(`
`);return h("M8",n,null,i,o)}function qe(e){const n=`Profile change request \u2013 ${e.helper_full_name}`,t=V(e.request_note),r=`
    <p style="margin:0 0 12px;">Hi ${a(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${a(e.helper_full_name)} has asked to update their profile:</p>
    <p style="margin:0 0 12px;padding:12px 14px;background:#f3f6fb;border-radius:8px;font-style:italic;">"${a(t)}"</p>
    <p style="margin:0 0 12px;">Please review and update their details in the portal if appropriate.</p>
    <p style="margin:22px 0;">${f(e.open_url,"Open helper profile","primary")}</p>
  `,i=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has asked to update their profile:`,"",`"${t}"`,"","Please review and update their details in the portal if appropriate.","",`Open helper profile: ${e.open_url}`].join(`
`);return h("M9",n,null,r,i)}const Qe={accept_confirm:{title:"Accept this visit?",message:"{{appointment_date_short}} \xB7 {{appointment_time}} \xB7 {{area}}. Tap Confirm to take this visit.",button:"Confirm"},accepted:{title:"This visit is yours!",message:"We've emailed you the full details. Thank you, {{helper_first_name}}."},already_taken:{title:"Already taken",message:"Another helper accepted this visit first. Thank you for responding quickly."},helper_engaged:{title:"You're already booked",message:"You have another visit around this time, so we can't assign this one to you."},declined:{title:"Thanks for letting us know",message:"We've offered this visit to another helper."},confirmed:{title:"See you there!",message:"Thanks for confirming. The family is counting on you."},cant_make_it_confirm:{title:"Can't make this visit?",message:"Tell us why (optional), then tap Confirm. We'll arrange a replacement.",button:"Confirm"},cant_make_it_done:{title:"Thanks for telling us",message:"Our care team will arrange a replacement."},link_inactive:{title:"This link is no longer active",message:"The visit may have been assigned, cancelled or already passed. Please contact your manager if you need help."}};function Xe(e,n){return e.replace(/\{\{(\w+)\}\}/g,(t,r)=>s(n[r],""))}async function Te(e,n){const t=Deno.env.get(n)?.trim()||"";if(t)return t;const{data:r,error:i}=await e.rpc("get_app_secret",{p_name:n});return i?(console.error(`get_app_secret(${n}) failed`,i),null):(typeof r=="string"?r.trim():"")||null}function Ze(e,n){const t=new TextEncoder,r=t.encode(e),i=t.encode(n),o=Math.max(r.length,i.length);let l=r.length===i.length?0:1;for(let p=0;p<o;p++)l|=(r[p]??0)^(i[p]??0);return l===0}const U="https://nandhini-17223.github.io/elderly-care/admin",Pe="https://nandhini-17223.github.io/elderly-care/respond.html",ve="https://nandhini-17223.github.io/elderly-care/admin/helper.html",Ce="Manager";function Re(e){const n=`needs-action.html?request=${encodeURIComponent(e)}`;return`${U}/login.html?next=${encodeURIComponent(n)}`}function en(){return`${U}/login.html?next=${encodeURIComponent("needs-action.html")}`}function nn(e){const n=`helper.html?id=${encodeURIComponent(e)}`;return`${U}/login.html?next=${encodeURIComponent(n)}`}function tn(e,n="Assign helper"){return`<a href="${e}" style="background:#1d6fd8;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;">${a(n)}</a>`}function rn(e){const n=B(e.appointmentDate)??e.appointmentDate,t=M(e.appointmentTime)??e.appointmentTime,r=[e.area,e.pincode].filter(Boolean).join(" \xB7 ")||"Area on file";return`
    <p>
      ${e.refNumber?`<strong>Ref:</strong> ${a(e.refNumber)}<br />`:""}
      <strong>Patient:</strong> ${a(e.parentName)} (age ${a(String(e.parentAge))})<br />
      <strong>Date:</strong> ${a(n)}<br />
      <strong>Time:</strong> ${a(t)}<br />
      <strong>Area:</strong> ${a(r)}<br />
      ${e.doctorHospital?`<strong>Doctor / Hospital:</strong> ${a(e.doctorHospital)}<br />`:""}
      ${e.helperPreference?`<strong>Helper preference:</strong> ${a(S(e.helperPreference))}<br />`:""}
      ${e.reason?`<strong>Reason:</strong> ${a(G(e.reason))}<br />`:""}
      ${e.address?`<strong>Address:</strong> ${a(e.address)}<br />`:""}
    </p>
  `}function an(e){return e==null||Number.isNaN(Number(e))?"Nearby":`~${Math.round(Number(e)*10)/10} km`}function ne(e){return e?"sent":"not sent"}function te(e){return[e.address_line1,e.street,e.area,e.city,e.pincode].map(n=>n?String(n).trim():"").filter(Boolean).join(", ")}function re(e){return`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e)}`}function ae(e){return`${e.phone_country_code} ${e.phone}`.trim()}function on(e){return{dateLabel:B(e.appointment_date)??e.appointment_date,timeLabel:M(e.appointment_time)??e.appointment_time}}function F(e,n){return`${Pe}?token=${encodeURIComponent(e)}&action=${encodeURIComponent(n)}`}function ie(e){return Array.from(e).map(n=>n.toString(16).padStart(2,"0")).join("")}async function Ee(e){const n=new TextEncoder().encode(e),t=await crypto.subtle.digest("SHA-256",n);return ie(new Uint8Array(t))}async function Ne(){const e=crypto.getRandomValues(new Uint8Array(32)),n=ie(e),t=await Ee(n);return{token:n,hash:t}}function Se(e,n,t){const r=te(e);return xe({ref:String(e.ref_number??"\u2013"),helper_first_name:j(n),parent_name:e.parent_name,parent_age:e.parent_age,address_line1:e.address_line1,street:e.street,area:e.area,city:e.city,pincode:e.pincode,landmark:e.landmark,maps_url:re(r),appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,guardian_phone:ae(e),cant_make_it_url:F(t,"cant_make_it")})}function sn(e,n,t){return Se(e,n,t).html}function Y(e,n,t,r){const i=te(e),o={ref:String(e.ref_number??"\u2013"),helper_first_name:j(n),parent_name:e.parent_name,area:e.area,appointment_date:e.appointment_date,appointment_time:e.appointment_time,full_address:i,maps_url:re(i),doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,guardian_phone:ae(e),cant_make_it_url:F(t,"cant_make_it")};return r==="6h"?He({...o,confirm_url:F(t,"confirm_attendance")}):we(o)}function pn(e,n,t,r){return Y(e,n,t,r).html}function Ie(e,n,t){return ke({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,helper_full_name:n.full_name,helper_phone:n.phone,helper_photo_url:n.photo_url,old_helper_first_name:t||"the previous helper",appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital})}function ln(e,n,t="the previous helper"){return Ie(e,n,t).html}function Me(e,n){return ye({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,helper_full_name:n.full_name,helper_phone:n.phone,helper_photo_url:n.photo_url,appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,address_line1:e.address_line1,street:e.street,area:e.area,city:e.city,pincode:e.pincode})}function mn(e,n){return Me(e,n).html}function De(e,n){return be({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,old_helper_first_name:j(n),appointment_date:e.appointment_date,appointment_time:e.appointment_time})}function dn(e,n){return De(e,n).html}function cn(e){if(e<=0)return"less than 1 minute";const n=Math.round(e/6e4);if(n<60)return`${n} minute${n===1?"":"s"}`;const t=Math.floor(n/60),r=n%60;return r===0?`${t} hour${t===1?"":"s"}`:`${t}h ${r}m`}function K(e,n=200){return new Response(JSON.stringify(e),{status:n,headers:{"Content-Type":"application/json",Connection:"keep-alive"}})}function oe(e){return{ref_number:e.ref_number,parent_name:e.parent_name,parent_age:e.parent_age,address_line1:e.address_line1,street:e.street,area:e.area,landmark:e.landmark,city:e.city,pincode:e.pincode,appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,phone_country_code:e.phone_country_code,phone:e.phone}}function se(e){return Date.parse(`${e.appointment_date}T${String(e.appointment_time).slice(0,8)}+05:30`)}async function pe(e,n,t){const{token:r,hash:i}=await Ne(),{data:o,error:l}=await e.rpc("create_assignment_token",{p_request_id:n,p_helper_id:t,p_token_hash:i});return l?(console.error("create_assignment_token",l),null):o?.ok?r:null}async function O(e,n,t){const{data:r,error:i}=await e.from("consultation_requests").update({[t]:new Date().toISOString()}).eq("id",n).eq("status","assigned").is(t,null).select("id").maybeSingle();return i?(console.error(`markSent ${t}`,i),!1):!!r?.id}async function je(e,n,t){const r=[];for(const i of n){if(i.status!=="assigned")continue;const o=t.get(i.assigned_helper_id);if(!o)continue;const l=se(i),p=Date.parse(i.assigned_at);if(!Number.isFinite(l)||!Number.isFinite(p))continue;const c=(l-p)/36e5,_=c<12,u=c<6,{data:g}=await e.rpc("effective_reminder_at",{p_appointment:new Date(l).toISOString(),p_hours_before:12,p_assigned_at:i.assigned_at}),{data:b}=await e.rpc("effective_reminder_at",{p_appointment:new Date(l).toISOString(),p_hours_before:6,p_assigned_at:i.assigned_at}),x=Date.now(),H=typeof g=="string"?Date.parse(g):NaN,C=typeof b=="string"?Date.parse(b):NaN,R={request_id:i.id,helper_id:o.id,hours_lead:Math.round(c*100)/100,skip12:_,skipBoth:u,due12:g,due6:b};if(!u&&!_&&!i.reminder_12h_sent_at&&Number.isFinite(H)&&x>=H)if(await O(e,i.id,"reminder_12h_sent_at")){const I=await pe(e,i.id,o.id);if(I){const E=Y(oe(i),o.full_name,I,"12h"),W=await D({to:o.email,toName:o.full_name,subject:E.subject,html:E.html,text:E.text});R.reminder_12h={sent:W.ok}}else R.reminder_12h={sent:!1,error:"token_failed"}}else R.reminder_12h={skipped:"already_sent"};if(!u&&!i.reminder_6h_sent_at&&Number.isFinite(C)&&x>=C)if(await O(e,i.id,"reminder_6h_sent_at")){const I=await pe(e,i.id,o.id);if(I){const E=Y(oe(i),o.full_name,I,"6h"),W=await D({to:o.email,toName:o.full_name,subject:E.subject,html:E.html,text:E.text});R.reminder_6h={sent:W.ok}}else R.reminder_6h={sent:!1,error:"token_failed"}}else R.reminder_6h={skipped:"already_sent"};r.push(R)}return r}async function Oe(e,n,t){const r=await Te(e,"SENIOR_EMAIL"),i=[];if(!r)return[{error:"missing_senior_secrets"}];for(const o of n){if(o.helper_confirmed_at)continue;const l=t.get(o.assigned_helper_id);if(!l)continue;const p=se(o);if(!Number.isFinite(p))continue;const c=(p-Date.now())/36e5,_=Re(o.id),u={ref:String(o.ref_number??"\u2013"),manager_first_name:Ce,helper_full_name:l.full_name,helper_first_name:j(l.full_name),helper_phone:l.phone,parent_name:o.parent_name,parent_age:o.parent_age,appointment_date:o.appointment_date,appointment_time:o.appointment_time,area:o.area,city:o.city,pincode:o.pincode,doctor_hospital:o.doctor_hospital,assigned_at:o.assigned_at,r12_status:ne(o.reminder_12h_sent_at),r6_status:ne(o.reminder_6h_sent_at),open_url:_},g={request_id:o.id,hours_left:Math.round(c*100)/100};if(c<=3&&c>0&&!o.no_confirm_alert_sent_at&&await O(e,o.id,"no_confirm_alert_sent_at")){const x=ee(u),H=await D({to:r,toName:"Senior coordinator",subject:x.subject,html:x.html,text:x.text});g.alert_3h={sent:H.ok}}if(c<=1&&c>0&&!o.no_confirm_second_alert_sent_at){const{data:b}=await e.from("consultation_requests").select("helper_confirmed_at, status, assigned_helper_id").eq("id",o.id).maybeSingle();if(b?.status==="assigned"&&!b.helper_confirmed_at&&b.assigned_helper_id===o.assigned_helper_id&&await O(e,o.id,"no_confirm_second_alert_sent_at")){const H=Ae(u),C=await D({to:r,toName:"Senior coordinator",subject:H.subject,html:H.html,text:H.text});g.alert_1h={sent:C.ok}}}i.push(g)}return i}Deno.serve(async e=>{if(e.method==="OPTIONS")return new Response(null,{status:204});if(e.method!=="POST")return K({error:"Method not allowed"},405);try{const n=Deno.env.get("SUPABASE_URL"),t=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");if(!n||!t)throw new Error("Missing Supabase environment configuration");const r=me(n,t),i=await e.json().catch(()=>({}));let o=r.from("consultation_requests").select("id, ref_number, status, parent_name, parent_age, address_line1, street, area, landmark, city, pincode, appointment_date, appointment_time, doctor_hospital, booking_person_name, relationship, phone_country_code, phone, assigned_helper_id, assigned_at, helper_confirmed_at, reminder_12h_sent_at, reminder_6h_sent_at, no_confirm_alert_sent_at, no_confirm_second_alert_sent_at").eq("status","assigned").not("assigned_helper_id","is",null);i.request_id&&(o=o.eq("id",i.request_id));const{data:l,error:p}=await o;if(p)throw p;const c=l??[],_=[...new Set(c.map(x=>x.assigned_helper_id))],u=new Map;if(_.length){const{data:x,error:H}=await r.from("helpers").select("id, full_name, email, phone").in("id",_);if(H)throw H;for(const C of x??[])u.set(C.id,C)}const g=await je(r,c,u),b=await Oe(r,c,u);return K({ok:!0,reason:i.reason??"manual",assigned_count:c.length,reminders:g,alerts:b})}catch(n){console.error(n);const t=n instanceof Error?n.message:"Unknown error";return K({ok:!1,error:t},500)}});
