const ne=globalThis.__sb.createClient,H="+91 73399 11220",te="https://nandhini-17223.github.io/elderly-care/helper/",re="https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg",V="#1d6fd8",ae="#4a9cf7",B="#1f2937",G="#6b7280",M=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],ie=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function i(e){return e.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;")}function o(e,n="\u2013"){if(e==null)return n;const t=String(e).trim();return!t||t.toLowerCase()==="null"||t.toLowerCase()==="undefined"?n:t}function D(e){return o(e,"None given")}function C(e){if(!e)return null;const n=/^(\d{4})-(\d{2})-(\d{2})$/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]),a=Number(n[3]);return!r||r<1||r>12||!a||a<1||a>31?null:{year:t,month:r,day:a}}function U(e){if(!e)return null;const n=/^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(e.trim());if(!n)return null;const t=Number(n[1]),r=Number(n[2]);return!Number.isInteger(t)||!Number.isInteger(r)||t<0||t>23||r<0||r>59?null:{hour24:t,minute:r}}function oe(e,n){const t=C(e),r=U(n)??{hour24:0,minute:0};return t?Date.parse(`${String(t.year).padStart(4,"0")}-${String(t.month).padStart(2,"0")}-${String(t.day).padStart(2,"0")}T${String(r.hour24).padStart(2,"0")}:${String(r.minute).padStart(2,"0")}:00+05:30`):NaN}function j(e){const n=C(e);return n?`${n.day} ${M[n.month-1]} ${n.year}`:null}function A(e){const n=C(e);return n?`${n.day} ${M[n.month-1]}`:o(e)}function k(e){const n=C(e);if(!n)return o(e);const t=new Date(Date.UTC(n.year,n.month-1,n.day)).getUTCDay();return`${ie[t]}, ${n.day} ${M[n.month-1]} ${n.year}`}function N(e){const n=U(e);if(!n)return null;const t=n.hour24%12||12,r=n.hour24<12?"AM":"PM";return`${t}:${String(n.minute).padStart(2,"0")} ${r}`}function Ce(e,n){const t=j(e),r=N(n);return!t||!r?null:`${t}, ${r}`}function F(e){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(e))}function x(e,n,t=Date.now()){const r=oe(e,n);if(!Number.isFinite(r))return"\u2013";const a=F(t),s=F(r),c=C(a),p=C(s),d=Math.round((Date.UTC(p.year,p.month-1,p.day)-Date.UTC(c.year,c.month-1,c.day))/864e5);if(d===0){const u=r-t;if(u<=0)return"today";const h=Math.round(u/6e4);if(h<60)return`today \xB7 in ${h} minute${h===1?"":"s"}`;const _=Math.round(h/60);return`today \xB7 in ${_} hour${_===1?"":"s"}`}return d===1?"tomorrow":d>1?`in ${d} days`:d===-1?"yesterday":`${Math.abs(d)} days ago`}function se(e){if(!e)return"\u2013";const n=Date.parse(e);if(!Number.isFinite(n))return o(e);const t=new Date(n),r=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Kolkata",weekday:"short",day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit",hour12:!0}).formatToParts(t),a=P=>r.find(S=>S.type===P)?.value??"",s=a("day"),c=a("month"),p=a("year"),d=a("weekday"),u=a("hour"),h=a("minute"),_=a("dayPeriod").toUpperCase();return`${d}, ${s} ${c} ${p} \xB7 ${u}:${h} ${_}`}function f(e,n,t="primary"){const r=t==="primary"?V:"#e5e7eb",a=t==="primary"?"#ffffff":"#111827";return`<a href="${i(e)}" style="background:${r};color:${a};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${i(n)}</a>`}function Y(){return`This is an automated message from ABI Parent Care. For help, call ${H}.`}function pe(e){const n=o(e.ref,""),t=n?`<td align="right" style="font-size:13px;color:${G};white-space:nowrap;">Ref <strong style="color:${B};">${i(n)}</strong></td>`:"<td></td>";return`<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${e.preheader?`<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${i(e.preheader)}</div>`:""}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${V},${ae});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${re}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${n?`<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${i(n)}</strong></td>`:""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${B};">
          ${e.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${G};">
          ${i(Y())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`}function le(e){return["ABI Parent Care",e.ref?`Ref ${o(e.ref)}`:null,"",e.bodyText.trim(),"",Y()].filter(t=>t!==null).join(`
`)}async function K(e){const n=Deno.env.get("RESEND_API_KEY");if(!n)throw new Error("Missing RESEND_API_KEY secret");const t=Deno.env.get("EMAIL_TEST_MODE")==="true",r=Deno.env.get("TEST_EMAIL_TO")?.trim()||"",a=(e.toName?.trim()||e.to).trim(),s=t&&r?r:e.to,c=t&&r?`[To: ${a}] ${e.subject}`:e.subject,p={from:"ABI Parent Care <onboarding@resend.dev>",to:[s],subject:c,html:e.html};e.text&&e.text.trim()&&(p.text=e.text);const d=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify(p)}),u=await d.json();return d.ok?{ok:!0,status:d.status,id:typeof u?.id=="string"?u.id:void 0,to:s,subject:c,testMode:t}:(console.error("Resend error:",u),{ok:!1,status:d.status,to:s,subject:c,testMode:t,error:u})}function R(e){const n=String(e??"").trim();return n?n.split(/\s+/)[0]??n:"there"}function E(e){return e==="female"?"Female helper":e==="male"?"Male helper":e==="no_preference"||e==="none"||!e?"No preference":o(e,"No preference")}function O(e){switch(e){case"no_acceptance":return"No helper accepted within 2 hours";case"no_suitable_helpers":return"No suitable helper nearby";case"all_declined":return"All offered helpers declined";case"short_notice":return"Booked at short notice";case"helper_dropped":return"Helper dropped out";case"helper_not_confirmed":return"Helper didn't confirm";case"helper_unavailable":return"Helper no longer available";default:return e?e.replaceAll("_"," "):"Needs senior attention"}}function $(e){return N(e)??o(e)}function y(e){return`<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${i(e)}</p>`}function m(e,n){return`<div style="margin:0 0 6px;"><strong>${i(e)}:</strong> ${i(n)}</div>`}function l(e,n){return`${e}: ${n}`}function z(e){return e?`<p style="margin:16px 0;"><img src="${i(e)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`:""}function w(e){return e.map(n=>String(n??"").trim()).filter(Boolean).join(", ")}function g(e,n,t,r,a){return{id:e,subject:n,html:pe({bodyHtml:r,ref:t,preheader:n}),text:le({bodyText:a,ref:t})}}function Ee(e){const n=A(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),a=w([e.area,e.city,e.pincode])||"\u2013",s=E(e.helper_preference),c=`We've received your request \u2013 ${e.parent_name}, ${n} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Thank you for choosing ABI Parent Care. We've received your request for ${i(e.parent_name)}'s doctor appointment.</p>
    ${y("Appointment")}
    ${m("Date & time",`${t} \xB7 ${r}`)}
    ${m("Doctor/Hospital",o(e.doctor_hospital))}
    ${m("Pickup from",a)}
    ${m("Helper preference",s)}
    ${y("What happens next")}
    <p style="margin:0 0 12px;">We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.</p>
    <p style="margin:0 0 12px;">Need to change anything? Call us on ${i(H)} and quote Ref ${i(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,d=[`Dear ${e.booking_person_name},`,"",`Thank you for choosing ABI Parent Care. We've received your request for ${e.parent_name}'s doctor appointment.`,"","APPOINTMENT",l("Date & time",`${t} \xB7 ${r}`),l("Doctor/Hospital",o(e.doctor_hospital)),l("Pickup from",a),l("Helper preference",s),"","WHAT HAPPENS NEXT","We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.","",`Need to change anything? Call us on ${H} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return g("G1",c,e.ref,p,d)}function Re(e){const n=A(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),a=`Update on ${e.parent_name}'s appointment \u2013 ${n} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${i(e.parent_name)}'s appointment on ${i(t)} at ${i(r)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${i(H)} and quote Ref ${i(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`A quick update: our care team is personally arranging a suitable helper for ${e.parent_name}'s appointment on ${t} at ${r}.`,"","You don't need to do anything. We'll email you the helper's details shortly.","",`If you'd like to speak to us, call ${H} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return g("G2",a,e.ref,s,c)}function me(e){const n=A(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),a=x(e.appointment_date,e.appointment_time),s=w([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",c=`Helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name}, ${n} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news \u2013 ${i(e.helper_full_name)} will accompany ${i(e.parent_name)} to the appointment.</p>
    ${z(e.helper_photo_url)}
    ${y("Your helper")}
    ${m("Name",e.helper_full_name)}
    ${m("Phone",o(e.helper_phone))}
    ${m("Verified","ID and background checked by ABI Parent Care")}
    ${y("Appointment")}
    ${m("Date & time",`${t} \xB7 ${r} (${a})`)}
    ${m("Doctor/Hospital",o(e.doctor_hospital))}
    ${m("Pickup from",s)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${i(e.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,d=[`Dear ${e.booking_person_name},`,"",`Good news \u2013 ${e.helper_full_name} will accompany ${e.parent_name} to the appointment.`,"","YOUR HELPER",l("Name",e.helper_full_name),l("Phone",o(e.helper_phone)),l("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT",l("Date & time",`${t} \xB7 ${r} (${a})`),l("Doctor/Hospital",o(e.doctor_hospital)),l("Pickup from",s),"",`For safety, please share this with ${e.parent_name} so they know who to expect.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return g("G3",c,e.ref,p,d)}function ce(e){const n=A(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),a=`Change of helper for ${e.parent_name} \u2013 ${n} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${i(e.old_helper_first_name)} is unable to attend ${i(e.parent_name)}'s appointment on ${i(t)} at ${i(r)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${i(H)} and quote Ref ${i(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`We're sorry \u2013 ${e.old_helper_first_name} is unable to attend ${e.parent_name}'s appointment on ${t} at ${r}.`,"","Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.","",`The appointment itself is unchanged. If you have concerns, call ${H} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return g("G4",a,e.ref,s,c)}function de(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=`New helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${i(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} will now accompany ${i(e.parent_name)} to the appointment, in place of ${i(e.old_helper_first_name)}.</p>
    ${z(e.helper_photo_url)}
    ${y("Your new helper")}
    ${m("Name",e.helper_full_name)}
    ${m("Phone",o(e.helper_phone))}
    ${m("Verified","ID and background checked by ABI Parent Care")}
    ${y("Appointment (unchanged)")}
    ${m("Date & time",`${n} \xB7 ${t} (${r})`)}
    ${m("Doctor/Hospital",o(e.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`${e.helper_full_name} will now accompany ${e.parent_name} to the appointment, in place of ${e.old_helper_first_name}.`,"","YOUR NEW HELPER",l("Name",e.helper_full_name),l("Phone",o(e.helper_phone)),l("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT (unchanged)",l("Date & time",`${n} \xB7 ${t} (${r})`),l("Doctor/Hospital",o(e.doctor_hospital)),"","Thank you for your patience.","","Warm regards,","The ABI Parent Care team"].join(`
`);return g("G5",a,e.ref,s,c)}function Se(e){const n=A(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),a=x(e.appointment_date,e.appointment_time),s=e.distance_km==null||Number.isNaN(Number(e.distance_km))?"\u2013":String(Math.round(Number(e.distance_km)*10)/10),c=o(e.area),p=`New visit near you \u2013 ${n}, ${r} \xB7 ${c} (${s} km)`,d=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${m("When",`${t} \xB7 ${r} (${a})`)}
    ${m("Pickup area",`${c}, ${o(e.pincode)} \xB7 about ${s} km from you`)}
    ${m("Hospital",o(e.doctor_hospital))}
    ${m("Patient",`Age ${e.parent_age}`)}
    <p style="margin:22px 0;">
      ${f(e.accept_url,"Accept","primary")}
      ${f(e.decline_url,"Decline","secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,u=[`Hi ${e.helper_first_name},`,"","A new hospital visit is available near you. The first helper to accept gets it.","",l("When",`${t} \xB7 ${r} (${a})`),l("Pickup area",`${c}, ${o(e.pincode)} \xB7 about ${s} km from you`),l("Hospital",o(e.doctor_hospital)),l("Patient",`Age ${e.parent_age}`),"",`Accept: ${e.accept_url}`,`Decline: ${e.decline_url}`,"","The patient's name, full address and family contact are shared after you accept.","",`Ref ${e.ref}`].join(`
`);return g("H1",p,e.ref,d,u)}function _e(e){const n=A(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),a=x(e.appointment_date,e.appointment_time),s=w([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",c=`Confirmed: ${e.parent_name}, ${n} ${r} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${y("Patient")}
    ${m("Name",`${e.parent_name}, ${e.parent_age}`)}
    ${m("Pickup",s)}
    ${m("Landmark",o(e.landmark))}
    <p style="margin:10px 0 16px;">${f(e.maps_url,"Open in Google Maps","secondary")}</p>
    ${y("Appointment")}
    ${m("When",`${t} \xB7 ${r} (${a})`)}
    ${m("Hospital",o(e.doctor_hospital))}
    ${y("Family contact")}
    <p style="margin:0 0 12px;">${i(e.booking_person_name)} (${i(o(e.relationship))}) \xB7 ${i(o(e.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${f(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,d=[`Hi ${e.helper_first_name},`,"","This visit is yours. Thank you!","","PATIENT",l("Name",`${e.parent_name}, ${e.parent_age}`),l("Pickup",s),l("Landmark",o(e.landmark)),`Open in Google Maps: ${e.maps_url}`,"","APPOINTMENT",l("When",`${t} \xB7 ${r} (${a})`),l("Hospital",o(e.doctor_hospital)),"","FAMILY CONTACT",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`,"","We'll remind you 12 hours and 6 hours before.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return g("H2",c,e.ref,p,d)}function ue(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=`Reminder: visit ${r} ${t} \u2013 ${e.parent_name}, ${o(e.area)}`,s=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${i(e.parent_name)} ${i(r)}.</p>
    ${m("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${i(o(e.full_address))} \xB7 <a href="${i(e.maps_url)}">Open in Google Maps</a></div>
    ${m("Hospital",o(e.doctor_hospital))}
    ${m("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${f(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,c=[`Hi ${e.helper_first_name},`,"",`A reminder that you're accompanying ${e.parent_name} ${r}.`,"",l("When",`${n} \xB7 ${t}`),l("Pickup",`${o(e.full_address)} \xB7 ${e.maps_url}`),l("Hospital",o(e.doctor_hospital)),l("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"","Plan to reach the pickup address 15 minutes early.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return g("H3",a,e.ref,s,c)}function ge(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=`Please confirm: ${e.parent_name} at ${t} \u2013 ${r}`,s=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${i(e.parent_name)} is ${i(r)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${f(e.confirm_url,"I'll be there","primary")}
      ${f(e.cant_make_it_url,"Can't make it","secondary")}
    </p>
    ${m("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${i(o(e.full_address))} \xB7 <a href="${i(e.maps_url)}">Open in Google Maps</a></div>
    ${m("Hospital",o(e.doctor_hospital))}
    ${m("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${i(e.ref)}</p>
  `,c=[`Hi ${e.helper_first_name},`,"",`Your visit with ${e.parent_name} is ${r}. Please confirm you'll be there.`,"",`I'll be there: ${e.confirm_url}`,`Can't make it: ${e.cant_make_it_url}`,"",l("When",`${n} \xB7 ${t}`),l("Pickup",`${o(e.full_address)} \xB7 ${e.maps_url}`),l("Hospital",o(e.doctor_hospital)),l("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"","If we don't hear from you, our care team will call you.","",`Ref ${e.ref}`].join(`
`);return g("H4",a,e.ref,s,c)}function Ne(e){const n=e.helper_app_link||te,t="Welcome to ABI Parent Care \u2013 your helper app login",r=`
    <p style="margin:0 0 12px;">Hi ${i(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${m("App link",n)}
    ${m("Login email",e.helper_email)}
    ${m("Password","the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${f(n,"Open helper app","primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${i(H)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `,a=[`Hi ${e.helper_first_name},`,"","Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.","",l("App link",n),l("Login email",e.helper_email),l("Password","the temporary password given to you by your manager"),"","You'll be asked to set your own password the first time you log in.","",'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',"",`Questions? Call ${H}.`,"","The ABI Parent Care team"].join(`
`);return g("H5",t,null,r,a)}function Ie(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=`URGENT \u2013 Helper needed in ${e.time_remaining} \xB7 ${e.parent_name} (${e.parent_age}) \xB7 ${t} \xB7 ${o(e.area)} \xB7 ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${i(r)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${y("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${y("Visit details")}
    ${m("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${m("When",`${n} \xB7 ${t} (${r})`)}
    ${m("Pickup",w([e.area,e.city,e.pincode])||"\u2013")}
    ${m("Hospital",o(e.doctor_hospital))}
    ${m("Preference",E(e.helper_preference))}
    ${m("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${f(e.assign_url,"Assign a helper","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"",`A booking has come in for ${r}. There isn't time to send offers automatically, so please assign a helper now.`,"","WHAT TO DO NOW","Open the request, pick an available helper and send them an offer.","","VISIT DETAILS",l("Patient",`${e.parent_name}, ${e.parent_age}`),l("When",`${n} \xB7 ${t} (${r})`),l("Pickup",w([e.area,e.city,e.pincode])||"\u2013"),l("Hospital",o(e.doctor_hospital)),l("Preference",E(e.helper_preference)),l("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"",`Assign a helper: ${e.assign_url}`].join(`
`);return g("M1",a,e.ref,s,c)}function Me(e){const t=`${e.items.length} request(s) need a helper \u2013 ${e.digest_time}`,r=e.items.map((p,d)=>{const u=A(p.appointment_date),h=$(p.appointment_time),_=x(p.appointment_date,p.appointment_time);return`
      <div style="margin:0 0 16px;padding:12px 0;border-bottom:1px solid #e5e7eb;">
        <p style="margin:0 0 6px;"><strong>${d+1}. ${i(p.ref)}</strong> \xB7 ${i(p.parent_name)} (${p.parent_age}) \xB7 ${i(u)} ${i(h)} (${i(_)})</p>
        <p style="margin:0 0 6px;">${i(o(p.area))} ${i(o(p.pincode))} \xB7 Preference: ${i(E(p.helper_preference))}</p>
        <p style="margin:0 0 10px;">Why: ${i(O(p.reason))}</p>
        <p style="margin:0;">${f(p.assign_url,"Assign","primary")}</p>
      </div>
    `}).join(""),a=e.items.map((p,d)=>{const u=A(p.appointment_date),h=$(p.appointment_time),_=x(p.appointment_date,p.appointment_time);return[`${d+1}. ${p.ref} \xB7 ${p.parent_name} (${p.parent_age}) \xB7 ${u} ${h} (${_})`,`   ${o(p.area)} ${o(p.pincode)} \xB7 Preference: ${E(p.helper_preference)}`,`   Why: ${O(p.reason)}`,`   Assign: ${p.assign_url}`].join(`
`)}).join(`

`),s=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">These requests still need a helper. The soonest appointment is first.</p>
    ${r}
    <p style="margin:22px 0;">${f(e.open_all_url,"Open all in the portal","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"","These requests still need a helper. The soonest appointment is first.","",a,"",`Open all in the portal: ${e.open_all_url}`].join(`
`);return g("M2",t,null,s,c)}function De(e){const n=A(e.appointment_date),t=k(e.appointment_date),r=$(e.appointment_time),a=x(e.appointment_date,e.appointment_time),s=D(e.decline_reason),c=`${e.helper_full_name} declined \u2013 please assign another \xB7 ${e.parent_name}, ${n} ${r} \xB7 ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} declined the visit you offered.</p>
    ${m("Reason given",s)}
    <p style="margin:12px 0;">Appointment: ${i(t)} \xB7 ${i(r)} (${i(a)}) \xB7 ${i(o(e.area))}</p>
    <p style="margin:22px 0;">${f(e.assign_url,"Choose another helper","primary")}</p>
  `,d=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} declined the visit you offered.`,l("Reason given",s),"",`Appointment: ${t} \xB7 ${r} (${a}) \xB7 ${o(e.area)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return g("M3",c,e.ref,p,d)}function je(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=`No response from ${e.helper_full_name} \u2013 please assign another \xB7 ${e.parent_name} \xB7 ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} didn't respond within ${i(e.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${i(n)} \xB7 ${i(t)} (${i(r)}) \xB7 ${i(o(e.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${i(o(e.helper_phone))}</p>
    <p style="margin:22px 0;">${f(e.assign_url,"Choose another helper","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} didn't respond within ${e.expiry_window}, so the offer has been withdrawn.`,"",`Appointment: ${n} \xB7 ${t} (${r}) \xB7 ${o(e.area)}`,`Helper phone (if you'd like to call): ${o(e.helper_phone)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return g("M4",a,e.ref,s,c)}function he(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=D(e.dropout_reason),s=`URGENT \u2013 ${e.helper_full_name} can't attend \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,c=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} has said they can't attend this visit.</p>
    ${m("Reason given",a)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${y("Visit details")}
    ${m("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${m("When",`${n} \xB7 ${t} (${r})`)}
    ${m("Pickup",w([e.area,e.city,e.pincode])||"\u2013")}
    ${m("Hospital",o(e.doctor_hospital))}
    ${m("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${f(e.assign_url,"Assign a replacement","primary")}</p>
  `,p=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has said they can't attend this visit.`,l("Reason given",a),"","The family has been told we're arranging a replacement. Please assign a new helper now.","","VISIT DETAILS",l("Patient",`${e.parent_name}, ${e.parent_age}`),l("When",`${n} \xB7 ${t} (${r})`),l("Pickup",w([e.area,e.city,e.pincode])||"\u2013"),l("Hospital",o(e.doctor_hospital)),l("Family",`${e.booking_person_name} (${o(e.relationship)}) \xB7 ${o(e.guardian_phone)}`),"",`Assign a replacement: ${e.assign_url}`].join(`
`);return g("M5",s,e.ref,c,p)}function fe(e){const n=k(e.appointment_date),t=$(e.appointment_time),r=x(e.appointment_date,e.appointment_time),a=se(e.assigned_at),s=e.urgent?`URGENT \u2013 visit in 1 hour, ${e.helper_full_name} still not confirmed \xB7 ${e.parent_name} \xB7 ${e.ref}`:`Action needed \u2013 ${e.helper_full_name} hasn't confirmed \xB7 ${e.parent_name} \xB7 ${t} (${r}) \xB7 ${e.ref}`,c=e.urgent?`The visit starts in about 1 hour and ${i(e.helper_full_name)} still hasn't confirmed. Please resolve this now.`:`${i(e.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,p=e.urgent?`The visit starts in about 1 hour and ${e.helper_full_name} still hasn't confirmed. Please resolve this now.`:`${e.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,d=e.urgent?`<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${i(e.helper_first_name)}: ${i(o(e.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".</li>
      </ol>`:`${y("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${i(e.helper_first_name)}: ${i(o(e.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone \u2013 nothing else happens, or</li>
            <li>Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`,u=e.urgent?[`1. Call ${e.helper_first_name}: ${o(e.helper_phone)}`,'2. Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".'].join(`
`):["WHAT TO DO NOW",`1. Call ${e.helper_first_name}: ${o(e.helper_phone)}`,"2. Then in the portal, choose:","   \u2022 Helper confirmed by phone \u2013 nothing else happens, or","   \u2022 Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper"].join(`
`),h=`
    ${y("Visit details")}
    ${m("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${m("When",`${n} \xB7 ${t} (${r})`)}
    ${m("Pickup",w([e.area,e.city,e.pincode])||"\u2013")}
    ${m("Hospital",o(e.doctor_hospital))}
    ${y("Helper status")}
    ${m("Assigned",a)}
    ${m("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`)}
    ${m("Confirmed","Not yet")}
  `,_=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${c}</p>
    ${d}
    ${h}
    <p style="margin:22px 0;">${f(e.open_url,"Open request","primary")}</p>
  `,P=[`Hi ${e.manager_first_name},`,"",p,"",u,"","VISIT DETAILS",l("Patient",`${e.parent_name}, ${e.parent_age}`),l("When",`${n} \xB7 ${t} (${r})`),l("Pickup",w([e.area,e.city,e.pincode])||"\u2013"),l("Hospital",o(e.doctor_hospital)),"","HELPER STATUS",l("Assigned",a),l("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`),l("Confirmed","Not yet"),"",`Open request: ${e.open_url}`].join(`
`);return g(e.urgent?"M7":"M6",s,e.ref,_,P)}function Oe(e){return fe({...e,urgent:!0})}function We(e){const n=`Driving licence ${e.expiry_phrase} \u2013 ${e.helper_full_name}`,t=e.expired?`<p style="margin:0 0 12px;">If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).</p>`:'<p style="margin:0 0 12px;">If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.</p>',r=e.expired?`If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).`:"If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.",a=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)}'s driving licence ${i(e.expiry_phrase)} (${i(e.dl_expiry)}).</p>
    ${t}
    <p style="margin:22px 0;">${f(e.open_url,"Open helper profile","primary")}</p>
  `,s=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name}'s driving licence ${e.expiry_phrase} (${e.dl_expiry}).`,"",r,"",`Open helper profile: ${e.open_url}`].join(`
`);return g("M8",n,null,a,s)}function Le(e){const n=`Profile change request \u2013 ${e.helper_full_name}`,t=D(e.request_note),r=`
    <p style="margin:0 0 12px;">Hi ${i(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${i(e.helper_full_name)} has asked to update their profile:</p>
    <p style="margin:0 0 12px;padding:12px 14px;background:#f3f6fb;border-radius:8px;font-style:italic;">"${i(t)}"</p>
    <p style="margin:0 0 12px;">Please review and update their details in the portal if appropriate.</p>
    <p style="margin:22px 0;">${f(e.open_url,"Open helper profile","primary")}</p>
  `,a=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has asked to update their profile:`,"",`"${t}"`,"","Please review and update their details in the portal if appropriate.","",`Open helper profile: ${e.open_url}`].join(`
`);return g("M9",n,null,r,a)}const b={accept_confirm:{title:"Accept this visit?",message:"{{appointment_date_short}} \xB7 {{appointment_time}} \xB7 {{area}}. Tap Confirm to take this visit.",button:"Confirm"},accepted:{title:"This visit is yours!",message:"We've emailed you the full details. Thank you, {{helper_first_name}}."},already_taken:{title:"Already taken",message:"Another helper accepted this visit first. Thank you for responding quickly."},helper_engaged:{title:"You're already booked",message:"You have another visit around this time, so we can't assign this one to you."},declined:{title:"Thanks for letting us know",message:"We've offered this visit to another helper."},confirmed:{title:"See you there!",message:"Thanks for confirming. The family is counting on you."},cant_make_it_confirm:{title:"Can't make this visit?",message:"Tell us why (optional), then tap Confirm. We'll arrange a replacement.",button:"Confirm"},cant_make_it_done:{title:"Thanks for telling us",message:"Our care team will arrange a replacement."},link_inactive:{title:"This link is no longer active",message:"The visit may have been assigned, cancelled or already passed. Please contact your manager if you need help."}};function Ve(e,n){return e.replace(/\{\{(\w+)\}\}/g,(t,r)=>o(n[r],""))}async function $e(e,n){const t=Deno.env.get(n)?.trim()||"";if(t)return t;const{data:r,error:a}=await e.rpc("get_app_secret",{p_name:n});return a?(console.error(`get_app_secret(${n}) failed`,a),null):(typeof r=="string"?r.trim():"")||null}function Be(e,n){const t=new TextEncoder,r=t.encode(e),a=t.encode(n),s=Math.max(r.length,a.length);let c=r.length===a.length?0:1;for(let p=0;p<s;p++)c|=(r[p]??0)^(a[p]??0);return c===0}const W="https://nandhini-17223.github.io/elderly-care/admin",ye="https://nandhini-17223.github.io/elderly-care/respond.html",Ge="https://nandhini-17223.github.io/elderly-care/admin/helper.html",be="Manager";function ke(e){const n=`needs-action.html?request=${encodeURIComponent(e)}`;return`${W}/login.html?next=${encodeURIComponent(n)}`}function Ue(){return`${W}/login.html?next=${encodeURIComponent("needs-action.html")}`}function Fe(e){const n=`helper.html?id=${encodeURIComponent(e)}`;return`${W}/login.html?next=${encodeURIComponent(n)}`}function Ye(e,n="Assign helper"){return`<a href="${e}" style="background:#1d6fd8;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;">${i(n)}</a>`}function Ke(e){const n=j(e.appointmentDate)??e.appointmentDate,t=N(e.appointmentTime)??e.appointmentTime,r=[e.area,e.pincode].filter(Boolean).join(" \xB7 ")||"Area on file";return`
    <p>
      ${e.refNumber?`<strong>Ref:</strong> ${i(e.refNumber)}<br />`:""}
      <strong>Patient:</strong> ${i(e.parentName)} (age ${i(String(e.parentAge))})<br />
      <strong>Date:</strong> ${i(n)}<br />
      <strong>Time:</strong> ${i(t)}<br />
      <strong>Area:</strong> ${i(r)}<br />
      ${e.doctorHospital?`<strong>Doctor / Hospital:</strong> ${i(e.doctorHospital)}<br />`:""}
      ${e.helperPreference?`<strong>Helper preference:</strong> ${i(E(e.helperPreference))}<br />`:""}
      ${e.reason?`<strong>Reason:</strong> ${i(O(e.reason))}<br />`:""}
      ${e.address?`<strong>Address:</strong> ${i(e.address)}<br />`:""}
    </p>
  `}function ze(e){return e==null||Number.isNaN(Number(e))?"Nearby":`~${Math.round(Number(e)*10)/10} km`}function Je(e){return e?"sent":"not sent"}function J(e){return[e.address_line1,e.street,e.area,e.city,e.pincode].map(n=>n?String(n).trim():"").filter(Boolean).join(", ")}function Q(e){return`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e)}`}function X(e){return`${e.phone_country_code} ${e.phone}`.trim()}function Qe(e){return{dateLabel:j(e.appointment_date)??e.appointment_date,timeLabel:N(e.appointment_time)??e.appointment_time}}function L(e,n){return`${ye}?token=${encodeURIComponent(e)}&action=${encodeURIComponent(n)}`}function Z(e){return Array.from(e).map(n=>n.toString(16).padStart(2,"0")).join("")}async function q(e){const n=new TextEncoder().encode(e),t=await crypto.subtle.digest("SHA-256",n);return Z(new Uint8Array(t))}async function Xe(){const e=crypto.getRandomValues(new Uint8Array(32)),n=Z(e),t=await q(n);return{token:n,hash:t}}function xe(e,n,t){const r=J(e);return _e({ref:String(e.ref_number??"\u2013"),helper_first_name:R(n),parent_name:e.parent_name,parent_age:e.parent_age,address_line1:e.address_line1,street:e.street,area:e.area,city:e.city,pincode:e.pincode,landmark:e.landmark,maps_url:Q(r),appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,guardian_phone:X(e),cant_make_it_url:L(t,"cant_make_it")})}function Ze(e,n,t){return xe(e,n,t).html}function Te(e,n,t,r){const a=J(e),s={ref:String(e.ref_number??"\u2013"),helper_first_name:R(n),parent_name:e.parent_name,area:e.area,appointment_date:e.appointment_date,appointment_time:e.appointment_time,full_address:a,maps_url:Q(a),doctor_hospital:e.doctor_hospital,booking_person_name:e.booking_person_name,relationship:e.relationship,guardian_phone:X(e),cant_make_it_url:L(t,"cant_make_it")};return r==="6h"?ge({...s,confirm_url:L(t,"confirm_attendance")}):ue(s)}function qe(e,n,t,r){return Te(e,n,t,r).html}function He(e,n,t){return de({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,helper_full_name:n.full_name,helper_phone:n.phone,helper_photo_url:n.photo_url,old_helper_first_name:t||"the previous helper",appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital})}function ve(e,n,t="the previous helper"){return He(e,n,t).html}function Ae(e,n){return me({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,helper_full_name:n.full_name,helper_phone:n.phone,helper_photo_url:n.photo_url,appointment_date:e.appointment_date,appointment_time:e.appointment_time,doctor_hospital:e.doctor_hospital,address_line1:e.address_line1,street:e.street,area:e.area,city:e.city,pincode:e.pincode})}function en(e,n){return Ae(e,n).html}function v(e,n){return ce({ref:String(e.ref_number??"\u2013"),booking_person_name:e.booking_person_name,parent_name:e.parent_name,old_helper_first_name:R(n),appointment_date:e.appointment_date,appointment_time:e.appointment_time})}function nn(e,n){return v(e,n).html}function tn(e){if(e<=0)return"less than 1 minute";const n=Math.round(e/6e4);if(n<60)return`${n} minute${n===1?"":"s"}`;const t=Math.floor(n/60),r=n%60;return r===0?`${t} hour${t===1?"":"s"}`:`${t}h ${r}m`}const ee={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};function T(e,n=200){return new Response(JSON.stringify(e),{status:n,headers:{...ee,"Content-Type":"application/json",Connection:"keep-alive"}})}async function we(e,n,t,r){const[{data:a},{data:s}]=await Promise.all([e.from("consultation_requests").select("id, ref_number, parent_name, parent_age, area, pincode, appointment_date, appointment_time, doctor_hospital, helper_preference, needs_senior_reason, booking_person_name, relationship, phone_country_code, phone, email, address_line1, street, landmark, city").eq("id",n).maybeSingle(),e.from("helpers").select("id, full_name, phone").eq("id",t).maybeSingle()]);if(!a||!s)return{senior:!1,guardian:!1};const c=await $e(e,"SENIOR_EMAIL"),p=`${a.phone_country_code??""} ${a.phone??""}`.trim();let d=!1;if(c){const _=he({ref:String(a.ref_number??"\u2013"),manager_first_name:be,helper_full_name:s.full_name,parent_name:a.parent_name,parent_age:a.parent_age,appointment_date:a.appointment_date,appointment_time:a.appointment_time,area:a.area,city:a.city,pincode:a.pincode,doctor_hospital:a.doctor_hospital,booking_person_name:a.booking_person_name,relationship:String(a.relationship??""),guardian_phone:p,dropout_reason:r,assign_url:ke(n)});d=(await K({to:c,toName:"Senior coordinator",subject:_.subject,html:_.html,text:_.text})).ok}const u=v({parent_name:a.parent_name,parent_age:a.parent_age,address_line1:a.address_line1,street:a.street,area:a.area,landmark:a.landmark,city:a.city,pincode:a.pincode,appointment_date:a.appointment_date,appointment_time:a.appointment_time,doctor_hospital:a.doctor_hospital,booking_person_name:a.booking_person_name,relationship:String(a.relationship??""),phone_country_code:String(a.phone_country_code??""),phone:String(a.phone??""),email:a.email,ref_number:a.ref_number},s.full_name),h=await K({to:a.email,toName:a.booking_person_name,subject:u.subject,html:u.html,text:u.text});return{senior:d,guardian:h.ok}}async function Pe(e,n,t){const{data:r}=await e.from("assignment_tokens").select("id, invalidated_at, helpers(full_name), consultation_requests(ref_number, status, appointment_date, appointment_time, area)").eq("token_hash",n).maybeSingle();return!r||r.invalidated_at?{ok:!1,code:"invalid_token",title:b.link_inactive.title,message:b.link_inactive.message}:t==="cant_make_it"?{ok:!0,code:"preview",title:b.cant_make_it_confirm.title,message:b.cant_make_it_confirm.message,button:b.cant_make_it_confirm.button,helper_first_name:R(r.helpers?.full_name),ref_number:r.consultation_requests?.ref_number}:{ok:!0,code:"preview",title:"Confirm you'll be there",message:"Tap Confirm to let us know you'll attend.",button:"Confirm",helper_first_name:R(r.helpers?.full_name)}}Deno.serve(async e=>{if(e.method==="OPTIONS")return new Response(null,{status:204,headers:ee});if(e.method!=="POST")return T({error:"Method not allowed"},405);try{const n=Deno.env.get("SUPABASE_URL"),t=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");if(!n||!t)throw new Error("Missing Supabase environment configuration");const r=await e.json().catch(()=>({})),a=String(r.token??"").trim(),s=String(r.action??"").trim().toLowerCase(),c=String(r.reason??"").trim();if(!a||s!=="confirm_attendance"&&s!=="cant_make_it")return T({ok:!1,message:"Missing token or action."},400);const p=await q(a),d=ne(n,t);if(r.preview)return T(await Pe(d,p,s));if(s==="confirm_attendance"){const{data:P,error:S}=await d.rpc("confirm_helper_attendance",{p_token_hash:p});if(S)return console.error("confirm_helper_attendance",S),T({ok:!1,title:b.link_inactive.title,message:"Could not confirm attendance."},500);const I=P;return I?.ok?T({ok:!0,code:I?.code,title:b.confirmed.title,message:b.confirmed.message}):T({ok:!1,code:I?.code,title:b.link_inactive.title,message:b.link_inactive.message})}const{data:u,error:h}=await d.rpc("helper_cant_make_it",{p_token_hash:p,p_reason:c||null});if(h)return console.error("helper_cant_make_it",h),T({ok:!1,title:b.link_inactive.title,message:"Could not process this response."},500);const _=u;return _?.ok&&_.request_id&&_.helper_id&&await we(d,_.request_id,_.helper_id,_.dropout_reason??(c||null)),_?.ok?T({ok:!0,code:_?.code,title:b.cant_make_it_done.title,message:b.cant_make_it_done.message}):T({ok:!1,code:_?.code,title:b.link_inactive.title,message:b.link_inactive.message})}catch(n){console.error(n);const t=n instanceof Error?n.message:"Unknown error";return T({ok:!1,message:t},500)}});
