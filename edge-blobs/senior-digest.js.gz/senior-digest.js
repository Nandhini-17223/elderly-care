const U=globalThis.__sb.createClient,k="+91 73399 11220",F="https://nandhini-17223.github.io/elderly-care/helper/",Y="https://nandhini-17223.github.io/elderly-care/assets/img/logo.svg",M="#1d6fd8",K="#4a9cf7",D="#1f2937",j="#6b7280",E=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],z=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function r(e){return e.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;")}function i(e,n="\u2013"){if(e==null)return n;const t=String(e).trim();return!t||t.toLowerCase()==="null"||t.toLowerCase()==="undefined"?n:t}function N(e){return i(e,"None given")}function H(e){if(!e)return null;const n=/^(\d{4})-(\d{2})-(\d{2})$/.exec(e.trim());if(!n)return null;const t=Number(n[1]),a=Number(n[2]),o=Number(n[3]);return!a||a<1||a>12||!o||o<1||o>31?null:{year:t,month:a,day:o}}function O(e){if(!e)return null;const n=/^(\d{1,2}):(\d{2})(?::\d{2})?/.exec(e.trim());if(!n)return null;const t=Number(n[1]),a=Number(n[2]);return!Number.isInteger(t)||!Number.isInteger(a)||t<0||t>23||a<0||a>59?null:{hour24:t,minute:a}}function J(e,n){const t=H(e),a=O(n)??{hour24:0,minute:0};return t?Date.parse(`${String(t.year).padStart(4,"0")}-${String(t.month).padStart(2,"0")}-${String(t.day).padStart(2,"0")}T${String(a.hour24).padStart(2,"0")}:${String(a.minute).padStart(2,"0")}:00+05:30`):NaN}function W(e){const n=H(e);return n?`${n.day} ${E[n.month-1]} ${n.year}`:null}function T(e){const n=H(e);return n?`${n.day} ${E[n.month-1]}`:i(e)}function y(e){const n=H(e);if(!n)return i(e);const t=new Date(Date.UTC(n.year,n.month-1,n.day)).getUTCDay();return`${z[t]}, ${n.day} ${E[n.month-1]} ${n.year}`}function R(e){const n=O(e);if(!n)return null;const t=n.hour24%12||12,a=n.hour24<12?"AM":"PM";return`${t}:${String(n.minute).padStart(2,"0")} ${a}`}function se(e,n){const t=W(e),a=R(n);return!t||!a?null:`${t}, ${a}`}function V(e){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(e))}function b(e,n,t=Date.now()){const a=J(e,n);if(!Number.isFinite(a))return"\u2013";const o=V(t),s=V(a),c=H(o),p=H(s),u=Math.round((Date.UTC(p.year,p.month-1,p.day)-Date.UTC(c.year,c.month-1,c.day))/864e5);if(u===0){const g=a-t;if(g<=0)return"today";const d=Math.round(g/6e4);if(d<60)return`today \xB7 in ${d} minute${d===1?"":"s"}`;const x=Math.round(d/60);return`today \xB7 in ${x} hour${x===1?"":"s"}`}return u===1?"tomorrow":u>1?`in ${u} days`:u===-1?"yesterday":`${Math.abs(u)} days ago`}function Z(e){if(!e)return"\u2013";const n=Date.parse(e);if(!Number.isFinite(n))return i(e);const t=new Date(n),a=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Kolkata",weekday:"short",day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit",hour12:!0}).formatToParts(t),o=C=>a.find(q=>q.type===C)?.value??"",s=o("day"),c=o("month"),p=o("year"),u=o("weekday"),g=o("hour"),d=o("minute"),x=o("dayPeriod").toUpperCase();return`${u}, ${s} ${c} ${p} \xB7 ${g}:${d} ${x}`}function h(e,n,t="primary"){const a=t==="primary"?M:"#e5e7eb",o=t==="primary"?"#ffffff":"#111827";return`<a href="${r(e)}" style="background:${a};color:${o};padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:600;margin:0 8px 8px 0;">${r(n)}</a>`}function L(){return`This is an automated message from ABI Parent Care. For help, call ${k}.`}function Q(e){const n=i(e.ref,""),t=n?`<td align="right" style="font-size:13px;color:${j};white-space:nowrap;">Ref <strong style="color:${D};">${r(n)}</strong></td>`:"<td></td>";return`<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
<body style="margin:0;padding:0;background:#f3f6fb;">
${e.preheader?`<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${r(e.preheader)}</div>`:""}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f6fb;padding:24px 12px;">
  <tr><td align="center">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
      <tr>
        <td style="background:linear-gradient(135deg,${M},${K});padding:18px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="vertical-align:middle;">
                <img src="${Y}" alt="ABI Parent Care" width="36" height="36" style="display:inline-block;vertical-align:middle;border:0;" />
                <span style="display:inline-block;vertical-align:middle;margin-left:10px;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;letter-spacing:0.02em;">ABI Parent Care</span>
              </td>
              ${n?`<td align="right" style="vertical-align:middle;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:13px;">Ref <strong>${r(n)}</strong></td>`:""}
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="padding:28px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:${D};">
          ${e.bodyHtml}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 22px 22px;border-top:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.5;color:${j};">
          ${r(L())}
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`}function X(e){return["ABI Parent Care",e.ref?`Ref ${i(e.ref)}`:null,"",e.bodyText.trim(),"",L()].filter(t=>t!==null).join(`
`)}async function v(e){const n=Deno.env.get("RESEND_API_KEY");if(!n)throw new Error("Missing RESEND_API_KEY secret");const t=Deno.env.get("EMAIL_TEST_MODE")==="true",a=Deno.env.get("TEST_EMAIL_TO")?.trim()||"",o=(e.toName?.trim()||e.to).trim(),s=t&&a?a:e.to,c=t&&a?`[To: ${o}] ${e.subject}`:e.subject,p={from:"ABI Parent Care <onboarding@resend.dev>",to:[s],subject:c,html:e.html};e.text&&e.text.trim()&&(p.text=e.text);const u=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify(p)}),g=await u.json();return u.ok?{ok:!0,status:u.status,id:typeof g?.id=="string"?g.id:void 0,to:s,subject:c,testMode:t}:(console.error("Resend error:",g),{ok:!1,status:u.status,to:s,subject:c,testMode:t,error:g})}function pe(e){const n=String(e??"").trim();return n?n.split(/\s+/)[0]??n:"there"}function P(e){return e==="female"?"Female helper":e==="male"?"Male helper":e==="no_preference"||e==="none"||!e?"No preference":i(e,"No preference")}function I(e){switch(e){case"no_acceptance":return"No helper accepted within 2 hours";case"no_suitable_helpers":return"No suitable helper nearby";case"all_declined":return"All offered helpers declined";case"short_notice":return"Booked at short notice";case"helper_dropped":return"Helper dropped out";case"helper_not_confirmed":return"Helper didn't confirm";case"helper_unavailable":return"Helper no longer available";default:return e?e.replaceAll("_"," "):"Needs senior attention"}}function f(e){return R(e)??i(e)}function $(e){return`<p style="margin:22px 0 8px;font-size:12px;letter-spacing:0.06em;text-transform:uppercase;color:#6b7280;font-weight:700;">${r(e)}</p>`}function m(e,n){return`<div style="margin:0 0 6px;"><strong>${r(e)}:</strong> ${r(n)}</div>`}function l(e,n){return`${e}: ${n}`}function B(e){return e?`<p style="margin:16px 0;"><img src="${r(e)}" alt="Helper photo" width="160" height="160" style="border-radius:12px;object-fit:cover;display:block;border:1px solid #e5e7eb;" /></p>`:""}function A(e){return e.map(n=>String(n??"").trim()).filter(Boolean).join(", ")}function _(e,n,t,a,o){return{id:e,subject:n,html:Q({bodyHtml:a,ref:t,preheader:n}),text:X({bodyText:o,ref:t})}}function le(e){const n=T(e.appointment_date),t=y(e.appointment_date),a=f(e.appointment_time),o=A([e.area,e.city,e.pincode])||"\u2013",s=P(e.helper_preference),c=`We've received your request \u2013 ${e.parent_name}, ${n} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Dear ${r(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Thank you for choosing ABI Parent Care. We've received your request for ${r(e.parent_name)}'s doctor appointment.</p>
    ${$("Appointment")}
    ${m("Date & time",`${t} \xB7 ${a}`)}
    ${m("Doctor/Hospital",i(e.doctor_hospital))}
    ${m("Pickup from",o)}
    ${m("Helper preference",s)}
    ${$("What happens next")}
    <p style="margin:0 0 12px;">We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.</p>
    <p style="margin:0 0 12px;">Need to change anything? Call us on ${r(k)} and quote Ref ${r(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,u=[`Dear ${e.booking_person_name},`,"",`Thank you for choosing ABI Parent Care. We've received your request for ${e.parent_name}'s doctor appointment.`,"","APPOINTMENT",l("Date & time",`${t} \xB7 ${a}`),l("Doctor/Hospital",i(e.doctor_hospital)),l("Pickup from",o),l("Helper preference",s),"","WHAT HAPPENS NEXT","We're matching a verified helper near you. As soon as a helper is confirmed, we'll email you their name, photo and phone number.","",`Need to change anything? Call us on ${k} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return _("G1",c,e.ref,p,u)}function me(e){const n=T(e.appointment_date),t=y(e.appointment_date),a=f(e.appointment_time),o=`Update on ${e.parent_name}'s appointment \u2013 ${n} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${r(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">A quick update: our care team is personally arranging a suitable helper for ${r(e.parent_name)}'s appointment on ${r(t)} at ${r(a)}.</p>
    <p style="margin:0 0 12px;">You don't need to do anything. We'll email you the helper's details shortly.</p>
    <p style="margin:0 0 12px;">If you'd like to speak to us, call ${r(k)} and quote Ref ${r(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`A quick update: our care team is personally arranging a suitable helper for ${e.parent_name}'s appointment on ${t} at ${a}.`,"","You don't need to do anything. We'll email you the helper's details shortly.","",`If you'd like to speak to us, call ${k} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return _("G2",o,e.ref,s,c)}function ce(e){const n=T(e.appointment_date),t=y(e.appointment_date),a=f(e.appointment_time),o=b(e.appointment_date,e.appointment_time),s=A([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",c=`Helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name}, ${n} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Dear ${r(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">Good news \u2013 ${r(e.helper_full_name)} will accompany ${r(e.parent_name)} to the appointment.</p>
    ${B(e.helper_photo_url)}
    ${$("Your helper")}
    ${m("Name",e.helper_full_name)}
    ${m("Phone",i(e.helper_phone))}
    ${m("Verified","ID and background checked by ABI Parent Care")}
    ${$("Appointment")}
    ${m("Date & time",`${t} \xB7 ${a} (${o})`)}
    ${m("Doctor/Hospital",i(e.doctor_hospital))}
    ${m("Pickup from",s)}
    <p style="margin:16px 0 12px;">For safety, please share this with ${r(e.parent_name)} so they know who to expect.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,u=[`Dear ${e.booking_person_name},`,"",`Good news \u2013 ${e.helper_full_name} will accompany ${e.parent_name} to the appointment.`,"","YOUR HELPER",l("Name",e.helper_full_name),l("Phone",i(e.helper_phone)),l("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT",l("Date & time",`${t} \xB7 ${a} (${o})`),l("Doctor/Hospital",i(e.doctor_hospital)),l("Pickup from",s),"",`For safety, please share this with ${e.parent_name} so they know who to expect.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return _("G3",c,e.ref,p,u)}function ue(e){const n=T(e.appointment_date),t=y(e.appointment_date),a=f(e.appointment_time),o=`Change of helper for ${e.parent_name} \u2013 ${n} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${r(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">We're sorry \u2013 ${r(e.old_helper_first_name)} is unable to attend ${r(e.parent_name)}'s appointment on ${r(t)} at ${r(a)}.</p>
    <p style="margin:0 0 12px;">Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.</p>
    <p style="margin:0 0 12px;">The appointment itself is unchanged. If you have concerns, call ${r(k)} and quote Ref ${r(e.ref)}.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`We're sorry \u2013 ${e.old_helper_first_name} is unable to attend ${e.parent_name}'s appointment on ${t} at ${a}.`,"","Our care team is arranging a replacement as a priority. We'll email you the new helper's details as soon as they're confirmed.","",`The appointment itself is unchanged. If you have concerns, call ${k} and quote Ref ${e.ref}.`,"","Warm regards,","The ABI Parent Care team"].join(`
`);return _("G4",o,e.ref,s,c)}function de(e){const n=y(e.appointment_date),t=f(e.appointment_time),a=b(e.appointment_date,e.appointment_time),o=`New helper confirmed for ${e.parent_name} \u2013 ${e.helper_full_name} \xB7 Ref ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Dear ${r(e.booking_person_name)},</p>
    <p style="margin:0 0 12px;">${r(e.helper_full_name)} will now accompany ${r(e.parent_name)} to the appointment, in place of ${r(e.old_helper_first_name)}.</p>
    ${B(e.helper_photo_url)}
    ${$("Your new helper")}
    ${m("Name",e.helper_full_name)}
    ${m("Phone",i(e.helper_phone))}
    ${m("Verified","ID and background checked by ABI Parent Care")}
    ${$("Appointment (unchanged)")}
    ${m("Date & time",`${n} \xB7 ${t} (${a})`)}
    ${m("Doctor/Hospital",i(e.doctor_hospital))}
    <p style="margin:16px 0 12px;">Thank you for your patience.</p>
    <p style="margin:18px 0 0;">Warm regards,<br />The ABI Parent Care team</p>
  `,c=[`Dear ${e.booking_person_name},`,"",`${e.helper_full_name} will now accompany ${e.parent_name} to the appointment, in place of ${e.old_helper_first_name}.`,"","YOUR NEW HELPER",l("Name",e.helper_full_name),l("Phone",i(e.helper_phone)),l("Verified","ID and background checked by ABI Parent Care"),"","APPOINTMENT (unchanged)",l("Date & time",`${n} \xB7 ${t} (${a})`),l("Doctor/Hospital",i(e.doctor_hospital)),"","Thank you for your patience.","","Warm regards,","The ABI Parent Care team"].join(`
`);return _("G5",o,e.ref,s,c)}function ge(e){const n=T(e.appointment_date),t=y(e.appointment_date),a=f(e.appointment_time),o=b(e.appointment_date,e.appointment_time),s=e.distance_km==null||Number.isNaN(Number(e.distance_km))?"\u2013":String(Math.round(Number(e.distance_km)*10)/10),c=i(e.area),p=`New visit near you \u2013 ${n}, ${a} \xB7 ${c} (${s} km)`,u=`
    <p style="margin:0 0 12px;">Hi ${r(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A new hospital visit is available near you. The first helper to accept gets it.</p>
    ${m("When",`${t} \xB7 ${a} (${o})`)}
    ${m("Pickup area",`${c}, ${i(e.pincode)} \xB7 about ${s} km from you`)}
    ${m("Hospital",i(e.doctor_hospital))}
    ${m("Patient",`Age ${e.parent_age}`)}
    <p style="margin:22px 0;">
      ${h(e.accept_url,"Accept","primary")}
      ${h(e.decline_url,"Decline","secondary")}
    </p>
    <p style="margin:0 0 12px;">The patient's name, full address and family contact are shared after you accept.</p>
    <p style="margin:0;color:#6b7280;">Ref ${r(e.ref)}</p>
  `,g=[`Hi ${e.helper_first_name},`,"","A new hospital visit is available near you. The first helper to accept gets it.","",l("When",`${t} \xB7 ${a} (${o})`),l("Pickup area",`${c}, ${i(e.pincode)} \xB7 about ${s} km from you`),l("Hospital",i(e.doctor_hospital)),l("Patient",`Age ${e.parent_age}`),"",`Accept: ${e.accept_url}`,`Decline: ${e.decline_url}`,"","The patient's name, full address and family contact are shared after you accept.","",`Ref ${e.ref}`].join(`
`);return _("H1",p,e.ref,u,g)}function _e(e){const n=T(e.appointment_date),t=y(e.appointment_date),a=f(e.appointment_time),o=b(e.appointment_date,e.appointment_time),s=A([e.address_line1,e.street,e.area,e.city,e.pincode])||"\u2013",c=`Confirmed: ${e.parent_name}, ${n} ${a} \xB7 Ref ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Hi ${r(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">This visit is yours. Thank you!</p>
    ${$("Patient")}
    ${m("Name",`${e.parent_name}, ${e.parent_age}`)}
    ${m("Pickup",s)}
    ${m("Landmark",i(e.landmark))}
    <p style="margin:10px 0 16px;">${h(e.maps_url,"Open in Google Maps","secondary")}</p>
    ${$("Appointment")}
    ${m("When",`${t} \xB7 ${a} (${o})`)}
    ${m("Hospital",i(e.doctor_hospital))}
    ${$("Family contact")}
    <p style="margin:0 0 12px;">${r(e.booking_person_name)} (${r(i(e.relationship))}) \xB7 ${r(i(e.guardian_phone))}</p>
    <p style="margin:0 0 12px;">We'll remind you 12 hours and 6 hours before.</p>
    <p style="margin:0 0 12px;">Can't make it? Tell us as early as possible:</p>
    <p style="margin:12px 0 16px;">${h(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${r(e.ref)}</p>
  `,u=[`Hi ${e.helper_first_name},`,"","This visit is yours. Thank you!","","PATIENT",l("Name",`${e.parent_name}, ${e.parent_age}`),l("Pickup",s),l("Landmark",i(e.landmark)),`Open in Google Maps: ${e.maps_url}`,"","APPOINTMENT",l("When",`${t} \xB7 ${a} (${o})`),l("Hospital",i(e.doctor_hospital)),"","FAMILY CONTACT",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`,"","We'll remind you 12 hours and 6 hours before.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return _("H2",c,e.ref,p,u)}function he(e){const n=y(e.appointment_date),t=f(e.appointment_time),a=b(e.appointment_date,e.appointment_time),o=`Reminder: visit ${a} ${t} \u2013 ${e.parent_name}, ${i(e.area)}`,s=`
    <p style="margin:0 0 12px;">Hi ${r(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">A reminder that you're accompanying ${r(e.parent_name)} ${r(a)}.</p>
    ${m("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${r(i(e.full_address))} \xB7 <a href="${r(e.maps_url)}">Open in Google Maps</a></div>
    ${m("Hospital",i(e.doctor_hospital))}
    ${m("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">Plan to reach the pickup address 15 minutes early.</p>
    <p style="margin:0 0 12px;">Can't make it?</p>
    <p style="margin:12px 0 16px;">${h(e.cant_make_it_url,"Can't make it","secondary")}</p>
    <p style="margin:0;color:#6b7280;">Ref ${r(e.ref)}</p>
  `,c=[`Hi ${e.helper_first_name},`,"",`A reminder that you're accompanying ${e.parent_name} ${a}.`,"",l("When",`${n} \xB7 ${t}`),l("Pickup",`${i(e.full_address)} \xB7 ${e.maps_url}`),l("Hospital",i(e.doctor_hospital)),l("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`),"","Plan to reach the pickup address 15 minutes early.","",`Can't make it? ${e.cant_make_it_url}`,"",`Ref ${e.ref}`].join(`
`);return _("H3",o,e.ref,s,c)}function fe(e){const n=y(e.appointment_date),t=f(e.appointment_time),a=b(e.appointment_date,e.appointment_time),o=`Please confirm: ${e.parent_name} at ${t} \u2013 ${a}`,s=`
    <p style="margin:0 0 12px;">Hi ${r(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Your visit with ${r(e.parent_name)} is ${r(a)}. Please confirm you'll be there.</p>
    <p style="margin:18px 0;">
      ${h(e.confirm_url,"I'll be there","primary")}
      ${h(e.cant_make_it_url,"Can't make it","secondary")}
    </p>
    ${m("When",`${n} \xB7 ${t}`)}
    <div style="margin:0 0 6px;"><strong>Pickup:</strong> ${r(i(e.full_address))} \xB7 <a href="${r(e.maps_url)}">Open in Google Maps</a></div>
    ${m("Hospital",i(e.doctor_hospital))}
    ${m("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`)}
    <p style="margin:16px 0 12px;">If we don't hear from you, our care team will call you.</p>
    <p style="margin:0;color:#6b7280;">Ref ${r(e.ref)}</p>
  `,c=[`Hi ${e.helper_first_name},`,"",`Your visit with ${e.parent_name} is ${a}. Please confirm you'll be there.`,"",`I'll be there: ${e.confirm_url}`,`Can't make it: ${e.cant_make_it_url}`,"",l("When",`${n} \xB7 ${t}`),l("Pickup",`${i(e.full_address)} \xB7 ${e.maps_url}`),l("Hospital",i(e.doctor_hospital)),l("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`),"","If we don't hear from you, our care team will call you.","",`Ref ${e.ref}`].join(`
`);return _("H4",o,e.ref,s,c)}function $e(e){const n=e.helper_app_link||F,t="Welcome to ABI Parent Care \u2013 your helper app login",a=`
    <p style="margin:0 0 12px;">Hi ${r(e.helper_first_name)},</p>
    <p style="margin:0 0 12px;">Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.</p>
    ${m("App link",n)}
    ${m("Login email",e.helper_email)}
    ${m("Password","the temporary password given to you by your manager")}
    <p style="margin:16px 0 12px;">You'll be asked to set your own password the first time you log in.</p>
    <p style="margin:0 0 12px;">Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.</p>
    <p style="margin:16px 0;">${h(n,"Open helper app","primary")}</p>
    <p style="margin:0 0 12px;">Questions? Call ${r(k)}.</p>
    <p style="margin:18px 0 0;">The ABI Parent Care team</p>
  `,o=[`Hi ${e.helper_first_name},`,"","Welcome to the ABI Parent Care team! Your profile is verified and your helper app account is ready.","",l("App link",n),l("Login email",e.helper_email),l("Password","the temporary password given to you by your manager"),"","You'll be asked to set your own password the first time you log in.","",'Tip: open the link on your phone and choose "Add to Home screen" to use it like an app.',"",`Questions? Call ${k}.`,"","The ABI Parent Care team"].join(`
`);return _("H5",t,null,a,o)}function ye(e){const n=y(e.appointment_date),t=f(e.appointment_time),a=b(e.appointment_date,e.appointment_time),o=`URGENT \u2013 Helper needed in ${e.time_remaining} \xB7 ${e.parent_name} (${e.parent_age}) \xB7 ${t} \xB7 ${i(e.area)} \xB7 ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">A booking has come in for ${r(a)}. There isn't time to send offers automatically, so please assign a helper now.</p>
    ${$("What to do now")}
    <p style="margin:0 0 12px;">Open the request, pick an available helper and send them an offer.</p>
    ${$("Visit details")}
    ${m("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${m("When",`${n} \xB7 ${t} (${a})`)}
    ${m("Pickup",A([e.area,e.city,e.pincode])||"\u2013")}
    ${m("Hospital",i(e.doctor_hospital))}
    ${m("Preference",P(e.helper_preference))}
    ${m("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${h(e.assign_url,"Assign a helper","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"",`A booking has come in for ${a}. There isn't time to send offers automatically, so please assign a helper now.`,"","WHAT TO DO NOW","Open the request, pick an available helper and send them an offer.","","VISIT DETAILS",l("Patient",`${e.parent_name}, ${e.parent_age}`),l("When",`${n} \xB7 ${t} (${a})`),l("Pickup",A([e.area,e.city,e.pincode])||"\u2013"),l("Hospital",i(e.doctor_hospital)),l("Preference",P(e.helper_preference)),l("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`),"",`Assign a helper: ${e.assign_url}`].join(`
`);return _("M1",o,e.ref,s,c)}function ee(e){const t=`${e.items.length} request(s) need a helper \u2013 ${e.digest_time}`,a=e.items.map((p,u)=>{const g=T(p.appointment_date),d=f(p.appointment_time),x=b(p.appointment_date,p.appointment_time);return`
      <div style="margin:0 0 16px;padding:12px 0;border-bottom:1px solid #e5e7eb;">
        <p style="margin:0 0 6px;"><strong>${u+1}. ${r(p.ref)}</strong> \xB7 ${r(p.parent_name)} (${p.parent_age}) \xB7 ${r(g)} ${r(d)} (${r(x)})</p>
        <p style="margin:0 0 6px;">${r(i(p.area))} ${r(i(p.pincode))} \xB7 Preference: ${r(P(p.helper_preference))}</p>
        <p style="margin:0 0 10px;">Why: ${r(I(p.reason))}</p>
        <p style="margin:0;">${h(p.assign_url,"Assign","primary")}</p>
      </div>
    `}).join(""),o=e.items.map((p,u)=>{const g=T(p.appointment_date),d=f(p.appointment_time),x=b(p.appointment_date,p.appointment_time);return[`${u+1}. ${p.ref} \xB7 ${p.parent_name} (${p.parent_age}) \xB7 ${g} ${d} (${x})`,`   ${i(p.area)} ${i(p.pincode)} \xB7 Preference: ${P(p.helper_preference)}`,`   Why: ${I(p.reason)}`,`   Assign: ${p.assign_url}`].join(`
`)}).join(`

`),s=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">These requests still need a helper. The soonest appointment is first.</p>
    ${a}
    <p style="margin:22px 0;">${h(e.open_all_url,"Open all in the portal","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"","These requests still need a helper. The soonest appointment is first.","",o,"",`Open all in the portal: ${e.open_all_url}`].join(`
`);return _("M2",t,null,s,c)}function be(e){const n=T(e.appointment_date),t=y(e.appointment_date),a=f(e.appointment_time),o=b(e.appointment_date,e.appointment_time),s=N(e.decline_reason),c=`${e.helper_full_name} declined \u2013 please assign another \xB7 ${e.parent_name}, ${n} ${a} \xB7 ${e.ref}`,p=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${r(e.helper_full_name)} declined the visit you offered.</p>
    ${m("Reason given",s)}
    <p style="margin:12px 0;">Appointment: ${r(t)} \xB7 ${r(a)} (${r(o)}) \xB7 ${r(i(e.area))}</p>
    <p style="margin:22px 0;">${h(e.assign_url,"Choose another helper","primary")}</p>
  `,u=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} declined the visit you offered.`,l("Reason given",s),"",`Appointment: ${t} \xB7 ${a} (${o}) \xB7 ${i(e.area)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return _("M3",c,e.ref,p,u)}function xe(e){const n=y(e.appointment_date),t=f(e.appointment_time),a=b(e.appointment_date,e.appointment_time),o=`No response from ${e.helper_full_name} \u2013 please assign another \xB7 ${e.parent_name} \xB7 ${e.ref}`,s=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${r(e.helper_full_name)} didn't respond within ${r(e.expiry_window)}, so the offer has been withdrawn.</p>
    <p style="margin:0 0 8px;">Appointment: ${r(n)} \xB7 ${r(t)} (${r(a)}) \xB7 ${r(i(e.area))}</p>
    <p style="margin:0 0 12px;">Helper phone (if you'd like to call): ${r(i(e.helper_phone))}</p>
    <p style="margin:22px 0;">${h(e.assign_url,"Choose another helper","primary")}</p>
  `,c=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} didn't respond within ${e.expiry_window}, so the offer has been withdrawn.`,"",`Appointment: ${n} \xB7 ${t} (${a}) \xB7 ${i(e.area)}`,`Helper phone (if you'd like to call): ${i(e.helper_phone)}`,"",`Choose another helper: ${e.assign_url}`].join(`
`);return _("M4",o,e.ref,s,c)}function ke(e){const n=y(e.appointment_date),t=f(e.appointment_time),a=b(e.appointment_date,e.appointment_time),o=N(e.dropout_reason),s=`URGENT \u2013 ${e.helper_full_name} can't attend \xB7 ${e.parent_name} \xB7 ${t} (${a}) \xB7 ${e.ref}`,c=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${r(e.helper_full_name)} has said they can't attend this visit.</p>
    ${m("Reason given",o)}
    <p style="margin:12px 0;">The family has been told we're arranging a replacement. Please assign a new helper now.</p>
    ${$("Visit details")}
    ${m("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${m("When",`${n} \xB7 ${t} (${a})`)}
    ${m("Pickup",A([e.area,e.city,e.pincode])||"\u2013")}
    ${m("Hospital",i(e.doctor_hospital))}
    ${m("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`)}
    <p style="margin:22px 0;">${h(e.assign_url,"Assign a replacement","primary")}</p>
  `,p=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has said they can't attend this visit.`,l("Reason given",o),"","The family has been told we're arranging a replacement. Please assign a new helper now.","","VISIT DETAILS",l("Patient",`${e.parent_name}, ${e.parent_age}`),l("When",`${n} \xB7 ${t} (${a})`),l("Pickup",A([e.area,e.city,e.pincode])||"\u2013"),l("Hospital",i(e.doctor_hospital)),l("Family",`${e.booking_person_name} (${i(e.relationship)}) \xB7 ${i(e.guardian_phone)}`),"",`Assign a replacement: ${e.assign_url}`].join(`
`);return _("M5",s,e.ref,c,p)}function ne(e){const n=y(e.appointment_date),t=f(e.appointment_time),a=b(e.appointment_date,e.appointment_time),o=Z(e.assigned_at),s=e.urgent?`URGENT \u2013 visit in 1 hour, ${e.helper_full_name} still not confirmed \xB7 ${e.parent_name} \xB7 ${e.ref}`:`Action needed \u2013 ${e.helper_full_name} hasn't confirmed \xB7 ${e.parent_name} \xB7 ${t} (${a}) \xB7 ${e.ref}`,c=e.urgent?`The visit starts in about 1 hour and ${r(e.helper_full_name)} still hasn't confirmed. Please resolve this now.`:`${r(e.helper_full_name)} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,p=e.urgent?`The visit starts in about 1 hour and ${e.helper_full_name} still hasn't confirmed. Please resolve this now.`:`${e.helper_full_name} hasn't yet confirmed they'll attend this visit. The family has not been informed.`,u=e.urgent?`<ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${r(e.helper_first_name)}: ${r(i(e.helper_phone))}</li>
        <li>Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".</li>
      </ol>`:`${$("What to do now")}
      <ol style="margin:0 0 12px;padding-left:20px;">
        <li>Call ${r(e.helper_first_name)}: ${r(i(e.helper_phone))}</li>
        <li>Then in the portal, choose:
          <ul style="margin:8px 0 0;padding-left:18px;">
            <li>Helper confirmed by phone \u2013 nothing else happens, or</li>
            <li>Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper</li>
          </ul>
        </li>
      </ol>`,g=e.urgent?[`1. Call ${e.helper_first_name}: ${i(e.helper_phone)}`,'2. Mark "Helper confirmed by phone", or choose "Helper unable \u2013 reassign".'].join(`
`):["WHAT TO DO NOW",`1. Call ${e.helper_first_name}: ${i(e.helper_phone)}`,"2. Then in the portal, choose:","   \u2022 Helper confirmed by phone \u2013 nothing else happens, or","   \u2022 Helper unable \u2013 reassign \u2013 we'll inform the family and you can pick a new helper"].join(`
`),d=`
    ${$("Visit details")}
    ${m("Patient",`${e.parent_name}, ${e.parent_age}`)}
    ${m("When",`${n} \xB7 ${t} (${a})`)}
    ${m("Pickup",A([e.area,e.city,e.pincode])||"\u2013")}
    ${m("Hospital",i(e.doctor_hospital))}
    ${$("Helper status")}
    ${m("Assigned",o)}
    ${m("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`)}
    ${m("Confirmed","Not yet")}
  `,x=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${c}</p>
    ${u}
    ${d}
    <p style="margin:22px 0;">${h(e.open_url,"Open request","primary")}</p>
  `,C=[`Hi ${e.manager_first_name},`,"",p,"",g,"","VISIT DETAILS",l("Patient",`${e.parent_name}, ${e.parent_age}`),l("When",`${n} \xB7 ${t} (${a})`),l("Pickup",A([e.area,e.city,e.pincode])||"\u2013"),l("Hospital",i(e.doctor_hospital)),"","HELPER STATUS",l("Assigned",o),l("Reminders",`12-hour ${e.r12_status} \xB7 6-hour ${e.r6_status}`),l("Confirmed","Not yet"),"",`Open request: ${e.open_url}`].join(`
`);return _(e.urgent?"M7":"M6",s,e.ref,x,C)}function Te(e){return ne({...e,urgent:!0})}function Ae(e){const n=`Driving licence ${e.expiry_phrase} \u2013 ${e.helper_full_name}`,t=e.expired?`<p style="margin:0 0 12px;">If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).</p>`:'<p style="margin:0 0 12px;">If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.</p>',a=e.expired?`If expired: They've been paused and won't receive offers until a renewed licence is recorded. Upcoming visits: ${e.upcoming_count} (moved to Needs action).`:"If not yet expired: Please ask them for the renewed licence before this date to avoid a pause.",o=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${r(e.helper_full_name)}'s driving licence ${r(e.expiry_phrase)} (${r(e.dl_expiry)}).</p>
    ${t}
    <p style="margin:22px 0;">${h(e.open_url,"Open helper profile","primary")}</p>
  `,s=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name}'s driving licence ${e.expiry_phrase} (${e.dl_expiry}).`,"",a,"",`Open helper profile: ${e.open_url}`].join(`
`);return _("M8",n,null,o,s)}function He(e){const n=`Profile change request \u2013 ${e.helper_full_name}`,t=N(e.request_note),a=`
    <p style="margin:0 0 12px;">Hi ${r(e.manager_first_name)},</p>
    <p style="margin:0 0 12px;">${r(e.helper_full_name)} has asked to update their profile:</p>
    <p style="margin:0 0 12px;padding:12px 14px;background:#f3f6fb;border-radius:8px;font-style:italic;">"${r(t)}"</p>
    <p style="margin:0 0 12px;">Please review and update their details in the portal if appropriate.</p>
    <p style="margin:22px 0;">${h(e.open_url,"Open helper profile","primary")}</p>
  `,o=[`Hi ${e.manager_first_name},`,"",`${e.helper_full_name} has asked to update their profile:`,"",`"${t}"`,"","Please review and update their details in the portal if appropriate.","",`Open helper profile: ${e.open_url}`].join(`
`);return _("M9",n,null,a,o)}const Pe={accept_confirm:{title:"Accept this visit?",message:"{{appointment_date_short}} \xB7 {{appointment_time}} \xB7 {{area}}. Tap Confirm to take this visit.",button:"Confirm"},accepted:{title:"This visit is yours!",message:"We've emailed you the full details. Thank you, {{helper_first_name}}."},already_taken:{title:"Already taken",message:"Another helper accepted this visit first. Thank you for responding quickly."},helper_engaged:{title:"You're already booked",message:"You have another visit around this time, so we can't assign this one to you."},declined:{title:"Thanks for letting us know",message:"We've offered this visit to another helper."},confirmed:{title:"See you there!",message:"Thanks for confirming. The family is counting on you."},cant_make_it_confirm:{title:"Can't make this visit?",message:"Tell us why (optional), then tap Confirm. We'll arrange a replacement.",button:"Confirm"},cant_make_it_done:{title:"Thanks for telling us",message:"Our care team will arrange a replacement."},link_inactive:{title:"This link is no longer active",message:"The visit may have been assigned, cancelled or already passed. Please contact your manager if you need help."}};function we(e,n){return e.replace(/\{\{(\w+)\}\}/g,(t,a)=>i(n[a],""))}async function te(e,n){const t=Deno.env.get(n)?.trim()||"";if(t)return t;const{data:a,error:o}=await e.rpc("get_app_secret",{p_name:n});return o?(console.error(`get_app_secret(${n}) failed`,o),null):(typeof a=="string"?a.trim():"")||null}function Ce(e,n){const t=new TextEncoder,a=t.encode(e),o=t.encode(n),s=Math.max(a.length,o.length);let c=a.length===o.length?0:1;for(let p=0;p<s;p++)c|=(a[p]??0)^(o[p]??0);return c===0}const S="https://nandhini-17223.github.io/elderly-care/admin",Ee="https://nandhini-17223.github.io/elderly-care/respond.html",Ne="https://nandhini-17223.github.io/elderly-care/admin/helper.html",re="Manager";function ae(e){const n=`needs-action.html?request=${encodeURIComponent(e)}`;return`${S}/login.html?next=${encodeURIComponent(n)}`}function ie(){return`${S}/login.html?next=${encodeURIComponent("needs-action.html")}`}function Re(e){const n=`helper.html?id=${encodeURIComponent(e)}`;return`${S}/login.html?next=${encodeURIComponent(n)}`}function Ie(e,n="Assign helper"){return`<a href="${e}" style="background:#1d6fd8;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none;display:inline-block;">${r(n)}</a>`}function Se(e){const n=W(e.appointmentDate)??e.appointmentDate,t=R(e.appointmentTime)??e.appointmentTime,a=[e.area,e.pincode].filter(Boolean).join(" \xB7 ")||"Area on file";return`
    <p>
      ${e.refNumber?`<strong>Ref:</strong> ${r(e.refNumber)}<br />`:""}
      <strong>Patient:</strong> ${r(e.parentName)} (age ${r(String(e.parentAge))})<br />
      <strong>Date:</strong> ${r(n)}<br />
      <strong>Time:</strong> ${r(t)}<br />
      <strong>Area:</strong> ${r(a)}<br />
      ${e.doctorHospital?`<strong>Doctor / Hospital:</strong> ${r(e.doctorHospital)}<br />`:""}
      ${e.helperPreference?`<strong>Helper preference:</strong> ${r(P(e.helperPreference))}<br />`:""}
      ${e.reason?`<strong>Reason:</strong> ${r(I(e.reason))}<br />`:""}
      ${e.address?`<strong>Address:</strong> ${r(e.address)}<br />`:""}
    </p>
  `}function Me(e){return e==null||Number.isNaN(Number(e))?"Nearby":`~${Math.round(Number(e)*10)/10} km`}function De(e){return e?"sent":"not sent"}function w(e,n=200){return new Response(JSON.stringify(e),{status:n,headers:{"Content-Type":"application/json",Connection:"keep-alive"}})}function G(e){const n=String(e.appointment_date),t=String(e.appointment_time).slice(0,8);return Date.parse(`${n}T${t}+05:30`)}function oe(e=new Date){const n=new Intl.DateTimeFormat("en-US",{timeZone:"Asia/Kolkata",hour:"numeric",minute:"2-digit",hour12:!0}).formatToParts(e),t=n.find(s=>s.type==="hour")?.value??"",a=n.find(s=>s.type==="minute")?.value??"00",o=(n.find(s=>s.type==="dayPeriod")?.value??"AM").toUpperCase();return`${t}:${a} ${o}`}Deno.serve(async e=>{if(e.method==="OPTIONS")return new Response(null,{status:204});if(e.method!=="POST"&&e.method!=="GET")return w({error:"Method not allowed"},405);try{const n=Deno.env.get("SUPABASE_URL"),t=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");if(!n||!t)throw new Error("Missing Supabase environment configuration");const a=U(n,t),{data:o,error:s}=await a.from("consultation_requests").select("id, ref_number, parent_name, parent_age, area, pincode, appointment_date, appointment_time, helper_preference, needs_senior_reason").eq("status","needs_senior");if(s)throw s;const c=(o??[]).sort((d,x)=>G(d)-G(x));if(c.length===0)return w({ok:!0,skipped:!0,reason:"none",count:0});const p=await te(a,"SENIOR_EMAIL");if(!p)return w({error:"SENIOR_EMAIL missing"},500);const u=ee({manager_first_name:re,digest_time:oe(),open_all_url:ie(),items:c.map(d=>({ref:String(d.ref_number??"\u2013"),parent_name:d.parent_name,parent_age:d.parent_age,appointment_date:d.appointment_date,appointment_time:d.appointment_time,area:d.area,pincode:d.pincode,helper_preference:d.helper_preference,reason:d.needs_senior_reason,assign_url:ae(d.id)}))}),g=await v({to:p,toName:"Senior coordinator",subject:u.subject,html:u.html,text:u.text});return w({ok:g.ok,count:c.length,request_ids:c.map(d=>d.id),email_id:g.id,subject:g.subject,error:g.error})}catch(n){console.error(n);const t=n instanceof Error?n.message:"Unknown error";return w({error:t},500)}});
